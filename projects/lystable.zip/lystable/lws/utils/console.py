"""
lws.utils.console

Initialize a developer shell with convenience imports.
"""

import logging

from collections import OrderedDict
try:
    from IPython.terminal.embed import InteractiveShellEmbed
    use_ipython = True
except ImportError:
    use_ipython = False

DEFAULT_BANNER = """
Welcome to the interactive shell for {0}.

The following objects are imported:
{1}

Log level set to {2}
"""


def shell(name, expose=None, banner=None, pdb=False):
    """
    Drops into a developer shell

    Arguments
    ---------
    name
        Name of the application creating the shell
    expose
        A dictionary of items to be exposed.
    banner
        Customise the entire banner.
    """

    if not expose:
        expose = {}

    imported_objects = OrderedDict([(i, v) for i, v in expose.items()])

    if not len(imported_objects):
        imported_objects['None'] = None

    if not banner:
        banner = DEFAULT_BANNER.format(
            name,
            '    - ' + '\n    - '.join(imported_objects.keys()),
            logging.getLevelName(logging.getLogger().getEffectiveLevel())
        )

    if use_ipython:
        # IPython is importable, so use it

        ise = InteractiveShellEmbed
        ise.pdb = pdb
        ipshell = ise(user_ns=imported_objects, banner1=banner)
        ipshell()
    else:
        # Use default interpreter

        try:
            # Get readline and activate features if available
            import readline
        except ImportError:
            pass
        else:
            import rlcompleter
            readline.set_completer(
                rlcompleter.Completer(imported_objects).complete
            )
            readline.parse_and_bind("tab:complete")

        import code
        code.interact(banner=banner, local=expose)
