from datetime import datetime
from flask import current_app
from sqlalchemy import Column, ForeignKey
from sqlalchemy import Boolean, Integer, String, Text, DateTime
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.orm import relationship
from sqlalchemy.schema import UniqueConstraint
import hashlib

from lws.core.db import Base, DeletedMixin


class User(Base):

    __tablename__ = 'users'

    STATUS_UNCONFIRMED = 'UNCONFIRMED'
    STATUS_UNVERIFIED = 'UNVERIFIED'
    STATUS_VERIFIED = 'VERIFIED'
    STATUS_BLOCKED = 'BLOCKED'

    id = Column(Integer, autoincrement=True, primary_key=True)
    email = Column(String(127), index=True, nullable=False)
    password_hash = Column(String(127), nullable=False)
    status = Column(String(127), default=STATUS_UNCONFIRMED, nullable=False)
    name = Column(String(255), nullable=True)
    given_name = Column(Text, nullable=True)
    is_admin = Column(Boolean, nullable=True)
    verification_code = Column(String(127), nullable=True)
    picture_id = Column(Integer, nullable=True)

    @classmethod
    def get_password_hash(cls, password):
        salt = current_app.config.get('PASSWORD_SALT', 'lystable_salt')
        return hashlib.sha256((salt + password).encode('utf-8')).hexdigest()

    @property
    def password(self):
        raise AttributeError("Password is not a readable attribute")

    @password.setter
    def password(self, password):
        self.password_hash = User.get_password_hash(password)

    def verify_password(self, password):
        return User.get_password_hash(password) == self.password_hash

    def to_dict(self, exclude_keys=('password_hash', 'verification_code')):
        return super(User, self).to_dict(exclude_keys)


class UserProfile(Base):

    __tablename__ = 'user_profiles'

    USER_LEVEL_STANDARD = 'STANDARD'
    USER_LEVEL_OWNER = 'OWNER'

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    team_id = Column(Integer, index=True, nullable=False)
    user_level = Column(String(127), default=USER_LEVEL_STANDARD,
                        nullable=False)

    user = relationship('User', backref='profiles')

    __table_args__ = (
        # only one user profile per team
        UniqueConstraint(
            user_id, team_id, name='team_profile_idx'),
    )


class SessionToken(Base):

    __tablename__ = 'session_tokens'

    token = Column(String(127), primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    last_access = Column(DateTime, nullable=False, default=datetime.now)


class PasswordResetToken(Base, DeletedMixin):

    __tablename__ = 'password_reset_tokens'

    token = Column(String(127), primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    used_at = Column(DateTime, nullable=True)

    @hybrid_property
    def used(self):
        return self.used_at is not None

    @used.expression
    def used(cls):
        return cls.used_at.isnot(None)
