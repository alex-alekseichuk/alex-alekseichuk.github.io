"""added picture column to users table

Revision ID: 1b220f5510e
Revises: 144086252cf
Create Date: 2015-06-16 14:21:59.191840

"""

# revision identifiers, used by Alembic.
revision = '1b220f5510e'
down_revision = '144086252cf'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('users', sa.Column('picture_id', sa.Integer(),
                                     nullable=True))


def downgrade():
    op.drop_column('users', 'picture_id')
