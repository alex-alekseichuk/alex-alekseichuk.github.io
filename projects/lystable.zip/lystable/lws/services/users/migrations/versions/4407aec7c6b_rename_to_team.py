""" rename to team

Revision ID: 4407aec7c6b
Revises: 52b70bc5962
Create Date: 2015-06-30 20:50:36.208373

"""

# revision identifiers, used by Alembic.
revision = '4407aec7c6b'
down_revision = '52b70bc5962'

from alembic import op


def upgrade():
    op.drop_index('ix_user_profiles_organisation_id', table_name='user_profiles')
    op.drop_constraint('user_profiles_user_id_organisation_id_key', 'user_profiles', type_='unique')
    op.alter_column('user_profiles', 'organisation_id', new_column_name='team_id')
    op.create_index(op.f('ix_user_profiles_team_id'), 'user_profiles', ['team_id'], unique=False)
    op.create_unique_constraint('team_profile_idx', 'user_profiles', ['user_id', 'team_id'])


def downgrade():
    op.drop_index('ix_user_profiles_team_id', table_name='user_profiles')
    op.drop_constraint('team_profile_idx', 'user_profiles', type_='unique')
    op.alter_column('user_profiles', 'team_id', new_column_name='organisation_id')
    op.create_index(op.f('ix_user_profiles_organisation_id'), 'user_profiles', ['organisation_id'], unique=False)
    op.create_unique_constraint('user_profiles_user_id_organisation_id_key', 'user_profiles', ['user_id', 'organisation_id'])
