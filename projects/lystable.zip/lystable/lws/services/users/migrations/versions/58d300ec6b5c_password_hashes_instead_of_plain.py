"""password hashes instead of plain

Revision ID: 58d300ec6b5c
Revises: 2f6cba560df3
Create Date: 2015-04-22 13:09:49.031495

"""

# revision identifiers, used by Alembic.
revision = '58d300ec6b5c'
down_revision = '2f6cba560df3'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('users',
                  sa.Column('password_hash', sa.String(127), nullable=False))
    op.drop_column('users', 'password')


def downgrade():
    op.add_column('users',
                  sa.Column('password', sa.String(127), nullable=False))
    op.drop_column('users', 'password_hash')
