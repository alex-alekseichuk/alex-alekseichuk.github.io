"""create reset_password_tokens table

Revision ID: 52b70bc5962
Revises: 1b220f5510e
Create Date: 2015-06-22 12:37:27.113571

"""

# revision identifiers, used by Alembic.
revision = '52b70bc5962'
down_revision = '1b220f5510e'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


def upgrade():
    op.create_table('password_reset_tokens',
        sa.Column('deleted', sa.Boolean(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('token', sa.String(length=127), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('used_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('token')
    )


def downgrade():
    op.drop_table('password_reset_tokens')
