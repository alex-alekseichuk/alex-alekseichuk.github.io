"""initial migration

Revision ID: 216a0ce60ec8
Revises: None
Create Date: 2015-04-08 00:18:04.439004

"""

# revision identifiers, used by Alembic.
revision = '216a0ce60ec8'
down_revision = None

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table(
        'users',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('email', sa.String(127), index=True, nullable=False),
        sa.Column('password', sa.String(127), nullable=True),
        sa.Column('status', sa.String(127), nullable=True),
        sa.Column('name', sa.String(255), nullable=True),
        sa.Column('given_name', sa.Text, nullable=True),
    )

    op.execute(sa.text(
        'UPDATE users '
        'SET status=:status '
        'WHERE status IS NULL'
    ).bindparams(status='UNVERIFIED'))

    op.alter_column('users', 'status', nullable=False)

    op.create_table(
        'user_profiles',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.Integer, nullable=False),
        sa.Column('organisation_id', sa.Integer, nullable=False, index=True),
        sa.UniqueConstraint('user_id', 'organisation_id'),
    )


def downgrade():
    op.drop_table('user_profiles')
    op.drop_table('users')
