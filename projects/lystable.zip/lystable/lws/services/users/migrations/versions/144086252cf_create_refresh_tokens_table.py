"""create session tokens table

Revision ID: 144086252cf
Revises: 2507e3640209
Create Date: 2015-06-04 21:48:20.329897

"""

# revision identifiers, used by Alembic.
revision = '144086252cf'
down_revision = '2507e3640209'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table('session_tokens',
        sa.Column('token', sa.String(length=127), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('last_access', sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('token')
    )


def downgrade():
    op.drop_table('session_tokens')
