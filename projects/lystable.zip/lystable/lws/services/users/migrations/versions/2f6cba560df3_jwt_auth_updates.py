"""jwt auth updates

Revision ID: 2f6cba560df3
Revises: 216a0ce60ec8
Create Date: 2015-04-20 17:30:21.151767

"""

# revision identifiers, used by Alembic.
revision = '2f6cba560df3'
down_revision = '216a0ce60ec8'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('users', sa.Column('is_admin', sa.Boolean, nullable=True))

    op.add_column(
        'user_profiles',
        sa.Column('user_level', sa.String(127), nullable=True))

    op.execute(sa.text(
        'UPDATE user_profiles '
        'SET user_level=:user_level '
        'WHERE user_level IS NULL'
    ).bindparams(user_level='STANDARD'))

    op.alter_column('user_profiles', 'user_level', nullable=False)

    op.create_foreign_key(
        'fk_user_profile', 'user_profiles', 'users', ['user_id'], ['id'])


def downgrade():
    op.drop_constraint('fk_user_profile', 'user_profiles')
    op.drop_column('user_profiles', 'user_level')

    op.drop_column('users', 'is_admin')
