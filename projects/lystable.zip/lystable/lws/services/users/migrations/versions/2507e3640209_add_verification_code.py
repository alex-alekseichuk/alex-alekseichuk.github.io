"""add verification code

Revision ID: 2507e3640209
Revises: 58d300ec6b5c
Create Date: 2015-04-22 20:35:18.687260

"""

# revision identifiers, used by Alembic.
revision = '2507e3640209'
down_revision = '58d300ec6b5c'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('users', sa.Column('verification_code',
                                     sa.String(length=127), nullable=True))


def downgrade():
    op.drop_column('users', 'verification_code')
