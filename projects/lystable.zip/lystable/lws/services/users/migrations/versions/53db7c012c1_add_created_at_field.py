"""add created_at field

Revision ID: 53db7c012c1
Revises: 4407aec7c6b
Create Date: 2015-07-06 12:59:10.920278

"""

# revision identifiers, used by Alembic.
revision = '53db7c012c1'
down_revision = '4407aec7c6b'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('session_tokens',
                  sa.Column('created_at', sa.DateTime(), nullable=False))
    op.add_column('user_profiles',
                  sa.Column('created_at', sa.DateTime(), nullable=False))
    op.add_column('users',
                  sa.Column('created_at', sa.DateTime(), nullable=False))


def downgrade():
    op.drop_column('users', 'created_at')
    op.drop_column('user_profiles', 'created_at')
    op.drop_column('session_tokens', 'created_at')
