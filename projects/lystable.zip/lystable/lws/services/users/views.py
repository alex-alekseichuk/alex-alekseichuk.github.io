from flask import request, g
from sqlalchemy import and_
from lws.core.auth import perms
from lws.core.db import commit_or_abort
from lws.core.exceptions import BadRequest, Forbidden, NotFound, NotAcceptable
from lws.core.service import ResourceView, request_json
from lws.core.service.decorators import route
from .models import User, UserProfile
from .schemas import UserProfileSchema


def is_sole_owner(profile):
    return (
        profile.user_level == UserProfile.USER_LEVEL_OWNER and
        g.session.query(UserProfile).filter(and_(
            UserProfile.team_id == profile.team_id,
            UserProfile.user_level == UserProfile.USER_LEVEL_OWNER
        )).count() == 1
    )


class UserProfileView(ResourceView):

    schema = UserProfileSchema

    @perms.checkers(perms.is_authenticated)
    def index(self, schema):
        """ List user profiles of the specified team

        Parameters
        ----------
        team_id : int
            Filter the list of returned suppliers by the provided
            team id.

        Returns
        -------
        list
            A list of all User profiles for the specified team

        """

        model = schema.get_model()
        data = request_json()
        team_id = data.get('team_id')
        if not team_id:
            raise BadRequest

        UserProfileView._check_team_member(team_id)

        profiles = g.session.query(model).filter(
            model.team_id == team_id
        ).order_by(UserProfile.id)

        return profiles

    @route(rule='/', method='post', internal=True)
    def post(self, schema):
        """ Create user profile.

        Intended use:
        1) for new team by just registered user
        2) by team's owner to add another user to org.
        3) by user's email matching team primary_domain
        *These conditions are not being checked in this endpoint!*

        Parameters
        ----------
        user_id : int
            The user to create the profile for.
        team_id : int
            The team to create the profile for.

        Returns
        -------
        UserProfile
            The newly created user profile

        Raises
        ------
        NotFound
            If the specified user id does not exist
        Forbidden
            If the user is attempting to sign themselves up to an
            team without a primary domain email address.

        """
        data = request_json()

        if (
            'user_id' not in data or
            'team_id' not in data
        ):
            raise BadRequest

        user_id = data['user_id']
        team_id = data['team_id']

        user = g.session.query(User).get(user_id)
        if user is None:
            raise NotFound  # specified user not found

        UserProfileView._check_profile_doesnt_exist(user_id, team_id)

        # check if team has no profile(s) yet
        if not UserProfileView._team_has_profile(team_id):
            # first profile of team is owner
            data['user_level'] = UserProfile.USER_LEVEL_OWNER
        else:
            # add new profile to team with existing profile(s)
            data['user_level'] = data.get('user_level',
                                          UserProfile.USER_LEVEL_STANDARD)
        profile = schema.create(data)
        g.session.add(profile)
        commit_or_abort()

        return profile, 201

    @route(rule='/<id:int>/', method='put', internal=True)
    def put(self, schema, id):
        """ Change user_level of profile by team owner

        Parameters
        ----------
        user_id : int
            The user to create the profile for.
        team_id : int
            The team to create the profile for.

        Returns
        -------
        UserProfile
            The newly created user profile

        Raises
        ------
        NotAcceptable
            If an owner attempts to downgrade their status when they
            are the sole owner of the team

        """
        model = schema.get_model()
        profile = g.session.query(model).get(id)
        if not profile:
            raise NotFound
        UserProfileView._check_team_owner(profile.team_id)

        # check if it's not last owner to revoke ownership
        data = request_json()
        if (
            'user_level' in data and
            is_sole_owner(profile) and
            data['user_level'] == UserProfile.USER_LEVEL_STANDARD
        ):
            raise NotAcceptable

        profile = schema.update(data, profile)
        g.session.add(profile)
        commit_or_abort()
        return profile

    @route(rule='profile_for_invite', method='post', internal=True)
    def profile_for_invite(self):
        """ Get user profile by invitation parameters.
            Called by teams service during invitation.
        """
        data = request_json()
        team_id = data.get('team_id')
        if team_id is None:
            raise BadRequest
        email = data.get('email')
        if email is None:
            raise BadRequest
        profile = g.session.query(UserProfile).join(User).filter(and_(
            UserProfile.team_id == team_id,
            User.email == email
        )).first()
        return profile

    @staticmethod
    def _check_team_member(team_id):
        """ check if current user is member of team
        """
        profile = g.session.query(UserProfile).filter(
            UserProfile.team_id == team_id,
            UserProfile.user_id == request.auth_data.get('user_id')).first()
        if profile is None:
            raise Forbidden

    @staticmethod
    def _check_team_owner(team_id):
        """ Checks current user is an owner of team.
        """
        owner_profile = g.session.query(UserProfile).filter(
            UserProfile.team_id == team_id,
            UserProfile.user_id == request.auth_data.get('user_id')).first()
        if (owner_profile is None or
                owner_profile.user_level != UserProfile.USER_LEVEL_OWNER):
            raise Forbidden

    @staticmethod
    def _check_profile_doesnt_exist(user_id, team_id):
        """ check if profile already exists
        """
        profile = g.session.query(UserProfile).filter(
            UserProfile.team_id == team_id,
            UserProfile.user_id == user_id).first()
        if profile is not None:
            raise BadRequest

    @staticmethod
    def _team_has_profile(team_id):
        profile = g.session.query(UserProfile).filter(
            UserProfile.team_id == team_id).first()
        return profile is not None
