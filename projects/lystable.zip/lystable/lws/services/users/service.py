from datetime import datetime, timedelta
import hashlib
import uuid

import jwt
from flask import Blueprint, current_app, request, g, url_for
import requests
from sqlalchemy import and_
from sqlalchemy.exc import SQLAlchemyError
from lws.core.auth import perms

from lws.core.db import commit_or_abort
from lws.core.nameko import dispatcher
from lws.core.service import (
    client_url, Service, register_service, request_json, ServiceProxy,
    request_overrides
)
from lws.core.service.decorators import route
from lws.core.exceptions import (
    NotAcceptable, BadRequest, Unauthorized,
    Forbidden, NotFound, Conflict,  # bit of a fascist view this one
    ServerError)
from lws.services.files.models import File
from lws.workers.mail import Notification
from lws.serialise.decorators import marshal_with
from .schemas import UserProfileSchema, UserSchema
from .views import UserProfileView
from .models import User, UserProfile, SessionToken, PasswordResetToken


files_proxy = ServiceProxy('files')

DEFAULT_JWT_EXPIRY_SECONDS = 5 * 60  # 5 mins


VERIFY_EMAIL_URL = '/verify_email/?code={code}'
RESET_PASSWORD_URL = '/reset_password/?token={token}'


def token_generator():
    return uuid.uuid4().hex


class UserService(Service):
    """ The ``users`` service is responsible for managing user data as well
    as providing APIs for authenticating.

    """

    name = 'users'
    permission_checkers = ()
    profiles = UserProfileView

    @staticmethod
    def _generate_token(user, session_token_record, team_id=None):
        now = datetime.utcnow()
        token_expiry = current_app.config.get(
            'JWT_EXPIRY_SECONDS', DEFAULT_JWT_EXPIRY_SECONDS)

        payload = {
            'exp': request.auth_data.get('exp') if request.auth_data
            else now + timedelta(seconds=token_expiry)
        }

        if session_token_record is not None:
            payload['session_token'] = session_token_record.token

        if user:
            if user.status != User.STATUS_VERIFIED:
                raise Forbidden

            payload['user_id'] = user.id
            payload['is_admin'] = True if user.is_admin else False

            # TODO: add some kind of `default team` for user
            if team_id:
                # try and pull out a profile for this user
                profile = g.session.query(UserProfile).filter_by(
                    user_id=user.id, team_id=team_id).first()

                if profile is None:
                    # User attempted to create a token for an team they
                    # didn't have access to.
                    raise Unauthorized

                payload['team_id'] = team_id
                payload['user_level'] = profile.user_level

        token = jwt.encode(payload, current_app.config['JWT_KEY'])
        # Token needs to be string and not bytes
        return token.decode()

    @staticmethod
    def get_session_token(user):
        """ Generate and save new session token for specified user.
        """
        token = SessionToken(token=token_generator(), user_id=user.id)
        g.session.add(token)
        g.session.commit()
        return token

    @staticmethod
    def _check_session_token(session_token):
        """ Check that session token is active.
            Return its record.
        """
        if session_token is None:
            raise Unauthorized  # incorrect session_token
        session_token_record = g.session.query(SessionToken).get(
            session_token)
        if session_token_record is None:
            raise Unauthorized  # unknown/expired session_token
        return session_token_record

    @route(rule='authenticate', method='post')
    def authenticate(self):
        """ Authenticate user by email and password.

        It's used on first client connection or after long period of time,
        when session token has expired.
        Returns both JWT and session tokens.

        If login credentials are specified, a new token for that
        account will be generated provided the credentials are
        correct.

        Parameters
        ----------
        email : str
            The email address to log a user in by. Must be used in
            conjunction with ``password`` in order to generate an
            authenticated token.
        password : str
            The corresponding password for the specified email
            address. Must be used in conjunction with ``email``
            in order to generate an authenticated token.
        team_id : int (optional)
            The team to generate the token for. If omitted,
            the generated token may not provide access to certain
            APIs which need to authorise access based team
            membership.

        Returns
        -------
        dict
            A single item dictionary containing the generated ``token``
            and ``session_token``.

        Raises
        ------
        Unauthorized
            If the specified credentials are invalid. Also
            if the user is not a member of the specified team

        Forbidden
            If the user account has not been verified (eg. it is yet
            to be verified or it has since been blocked)

        """
        data = request_json()
        if 'email' not in data or 'password' not in data:
            raise Unauthorized
        user = g.session.query(User).filter_by(
            email=data['email']).first()
        if user is None:
            raise Unauthorized  # unknown email
        if not user.verify_password(data['password']):
            raise Unauthorized  # password is incorrect
        if user.status != User.STATUS_VERIFIED:
            raise Forbidden

        session_token_record = UserService.get_session_token(user)
        token = UserService._generate_token(
            user,
            session_token_record,
            data.get('team_id'))

        return {'token': token, 'session_token': session_token_record.token}

    @route(rule='revoke', method='post')
    def revoke_session_token(self):
        """ Revoke session token authority and remove the record in DB.

        It's used for logging out. It uses ``session_token`` input parameter
        or appropriate value from authentication token.

        Parameters
        ----------
        session_token : str (optional)
            ``session_token`` is used to identify session token record,
            which is not valid anymore.

        Returns
        -------
        (None, 204)

        Raises
        ------
        BadRequest
            If there not neither ``session_token`` input parameter
            nor ``session_token`` key in auth. token dict.

        """
        data = request_json()
        if 'session_token' in data:
            session_token = data['session_token']
        elif request.auth_data:
            session_token = request.auth_data.get('session_token')
        else:
            raise BadRequest
        session_token_record = UserService._check_session_token(session_token)
        g.session.delete(session_token_record)
        g.session.commit()
        return None, 204

    @route(rule='generate_token', method='post')
    def generate_token(self):
        """ Generate a new auth token.

        If ``session_token`` input parameter specified, a new ``token``
        for that account will be generated.

        Alternatively, an existing auth token can be included in the
        request headers. This allows exchanging an existing ``token`` for
        another (eg. for a different team). In this case,
        it uses ``session_token`` value saved in the auth. ``token``.

        If no ``session_token`` or ``token`` are passed, an anonymous token
        will be generated which may provide access to certain APIs.

        The value of ``last_access`` field is set to current datetime
        all the time a client hits a ``session_token`` by this endpoint.
        We are going to provide session_token expiration by checking these
        values in background by some job periodically and remove old records.
        TODO: background job to remove expired session_token records.

        Parameters
        ----------
        session_token : str (optional)
            Existing valid session token of already authenticated user account.
        team_id : int (optional)
            The team to generate the token for. If omitted,
            the generated token may not provide access to certain
            APIs which need to authorise access based team
            membership

        Returns
        -------
        dict
            A single item dictionary containing the generated ``token``

        Raises
        ------
        Unauthorized
            If the specified credentials or token are invalid. Also
            if the user is not a member of the specified team

        """
        user = None
        session_token_record = None
        data = request_json()
        if 'session_token' in data:
            session_token = data['session_token']
            session_token_record = UserService._check_session_token(
                session_token)
            user = g.session.query(User).get(session_token_record.user_id)
            if user is None:
                raise Unauthorized  # unknown user
        elif request.auth_data:
            user_id = request.auth_data.get('user_id')
            # If there is no auth. params
            if not user_id:
                raise Unauthorized  # then not authorized
            user = g.session.query(User).get(user_id)
            if user is None:
                # The user attempted to generate a token with
                # invalid credentials
                raise Unauthorized
            session_token = request.auth_data.get('session_token')
            session_token_record = UserService._check_session_token(
                session_token)

        # prolong life of session token
        if session_token_record is not None:
            session_token_record.last_access = datetime.now()
            g.session.commit()

        token = UserService._generate_token(
            user, session_token_record, data.get('team_id'))

        return {'token': token}

    @route(rule='register', method='post')
    @marshal_with(schema=UserSchema)
    def register(self, schema):
        """ Registers a new user account

        Parameters
        ----------
        email : str
            The email address for the new user account. Must be
            unique.
        password : str
            The password for this user account.

        Returns
        -------
        User
            A representation of the newly created User resource

        Raises
        ------
        Conflict
            If the specified email address has already been used
        NotAcceptable
            If the password does not match the minimum requirements
            (currently > 6 characters long)

        """
        data = request_json()

        if (
            'email' not in data or
            'password' not in data
        ):
            raise BadRequest

        email = data['email'] = data['email'].lower()
        if email and g.session.query(User).filter(User.email == email).first():
            raise Conflict('Sorry, the Email is already registered.')

        password = data['password']
        if not password or len(password) < 6:
            raise NotAcceptable('Sorry, the password should be at least'
                                '6 characters long.')

        user = schema.create(data)

        code = hashlib.sha256(
            (email + str(datetime.utcnow())).encode('utf-8')
        ).hexdigest()
        user.verification_code = code
        user.password = data['password']

        g.session.add(user)
        commit_or_abort()

        # send registration email
        notification = Notification(
            template_name='registration',
            to=[{'email': user.email}],
            context=[
                {
                    'name': 'verify_email_url',
                    'content': client_url(VERIFY_EMAIL_URL, code=code)
                }
            ]
        )
        dispatch = dispatcher()
        dispatch(notification)

        return user, 201

    @route(rule='/verify/<code>')
    def verify_email(self, code):
        """ Verify a user account with the specified `code`

        Returns
        -------
        User
            A representation of the newly created User resource

        Raises
        ------
        NotFound
            If the user account with the specified verification code
            couldn't be found. This most commonly occurs when using
            an outdated verification code or if the account has been
            blocked.

        """
        # TODO: maybe add more checks on status
        user = g.session.query(User).filter(and_(
            User.verification_code == code,
            User.status != User.STATUS_BLOCKED)).one()

        if not user:
            raise NotFound

        user.status = User.STATUS_VERIFIED
        g.session.commit()

        return None, 204

    def _get_user(self, user_id):
        if not user_id:
            raise BadRequest
        user = g.session.query(User).get(user_id)
        if user is None:
            raise NotFound
        return user

    @route(rule='/<int:user_id>', internal=True)
    @marshal_with(schema=UserSchema)
    def get_user(self, schema, user_id):
        """ Get user with profiles. Called by teams service.
        """
        return self._get_user(user_id)

    @route(rule='/user_profiles/', method='get')
    @marshal_with(schema=UserProfileSchema)
    @perms.checkers(perms.is_authenticated)
    def list_profiles(self, schema):
        """ List user profiles of authorized user.

        Returns
        -------
        list
            A list of UserProfile resources

        """

        model = schema.get_model()
        profiles = g.session.query(model).filter(
            model.user_id == request.auth_data['user_id'])
        return profiles.all()

    @route(rule='/<int:user_id>/picture/', method='post')
    def upload_picture(self, user_id):
        """ Upload file and link it to specified user account.
        Removes previous picture file, if it exists.
        """
        user = self._get_user(user_id)
        previous_picture_id = user.picture_id
        data = request_json()
        with request_overrides(
                data={'type': File.PICTURE,
                      'content': data.get('content', '')}):
            user.picture_id = files_proxy.post().get('data', {}).get('id')
        commit_or_abort()
        if previous_picture_id is not None:
            with request_overrides(method='delete', data=None):
                files_proxy.delete(id=previous_picture_id)
        return None, 201

    @route(rule='/<int:user_id>/picture_url/', method='get')
    def get_picture_url(self, user_id):
        """
        Returns
        -------
        str
            Temporary URL to the picture file. If there is no picture,
            it returns None.

        Raises
        ------
        NotFound
            If user has no picture.

        """
        user = self._get_user(user_id)
        if user.picture_id is None:
            return NotFound
        url = files_proxy.get_url(id=user.picture_id)
        return url

    @route(rule='/initiate_password_reset/', method='post')
    def initiate_password_reset(self):
        """ To start reset-password procedure, it sends email to the user
        to identify the user. The email contains a link to the client app.
        The link has unique reset_token, used to continue reset-password
        procedure.

        Parameters
        ----------
        email : str
            The email of the user.

        Returns
        -------
        (None, 204)

        Raises
        ------
        BadRequest
            If there is no email in parameters
        NotFound
            If there is not user with such email

        """
        data = request_json()
        email = data.get('email')
        if email is None:
            raise BadRequest
        email = email.lower()

        user = g.session.query(User).filter(and_(
            User.email == email, User.status != User.STATUS_BLOCKED)).first()
        if user is None:
            raise NotFound

        # mark as deleted all unused tokens for this user
        g.session.query(PasswordResetToken).filter(and_(
            PasswordResetToken.user_id == user.id,
            (PasswordResetToken.used == False)
        )).update({'deleted': True})
        commit_or_abort()

        # generate new token
        reset_token = token_generator()
        g.session.add(PasswordResetToken(token=reset_token, user_id=user.id))
        commit_or_abort()

        # send reset_password email
        notification = Notification(
            template_name='reset_password',
            to=[{'email': user.email}],
            context=[
                {
                    'name': 'reset_password_url',
                    'content': client_url(RESET_PASSWORD_URL,
                                          token=reset_token)
                }
            ]
        )
        dispatch = dispatcher()
        dispatch(notification)
        return None, 204

    @route(rule='/reset_password/', method='post')
    def reset_password(self):
        """ Checks for correct reset_token and email, then set new password
        and delete all session tokens of the user.

        Parameters
        ----------
        reset_token : str
            The token to identify user account and continue procedure
        email : str
            The email of the user for additional check
        new_password : str
            A new value of user's password

        Returns
        -------
        (None, 204)

        Raises
        ------
        BadRequest
            If user is blocked or has incorrect email. If reset_token is
            incorrect, deleted or already used.

        """
        data = request_json()
        if (
            'email' not in data or
            'reset_token' not in data or
            'new_password' not in data
        ):
            raise BadRequest

        email = data['email'].lower()
        new_password = data['new_password']

        # check reset token
        reset = g.session.query(PasswordResetToken).get(data['reset_token'])
        if reset is None or reset.deleted or reset.used:
            raise BadRequest

        # check user
        user = g.session.query(User).get(reset.user_id)
        if (user is None or user.status == User.STATUS_BLOCKED or
                user.email != email):
            raise BadRequest

        reset.used_at = datetime.now()
        user.password = new_password

        # delete all session_token's for this user
        g.session.query(SessionToken).filter(
            SessionToken.user_id == user.id).delete()

        commit_or_abort()
        return None, 204

    @route(rule='/handle_google_callback')
    @perms.checkers()
    def handle_google_callback(self):
        """ Handles callback from Google. Google makes a callback to client
        application, then it calls this endpoint with some code.

        Parameters
        ----------
        code : str
            is some hex code for authorization
        error : str
            error code, that google may pass via client application

        Returns
        -------
        str
            authentication token

        Raises
        ------
        BadRequest
            If there is some problem with google authentication or parameter.
        ServerError
            If it can't add new record for incoming user.

        """
        data = request_json()
        if 'error' in data:
            raise BadRequest(detail=data['error'])
        if 'code' not in data:
            raise BadRequest(detail='There is no Authorization Code')
        code = data['code']

        # get access token and authorization code
        response = requests.post(
            "https://www.googleapis.com/oauth2/v3/token",
            params={
                'code': code,
                'client_id': current_app.config.get('GOOGLE_CLIENT_ID'),
                'client_secret': current_app.config.get(
                    'GOOGLE_CLIENT_SECRET'
                ),
                'redirect_uri': url_for('users.handle_google_callback',
                                        _external=True),
                'grant_type': 'authorization_code'
            }, headers={
                'Content-type': 'application/x-www-form-urlencoded'
            })
        if response.status_code != 200:
            raise BadRequest(
                detail="Can't obtain Access Token: {} {}".format(
                    response.status, response.reason
                )
            )

        data = response.json()
        access_token = data.get('access_token')
        if not access_token:
            raise BadRequest(detail='There is no Access Token')

        # get google profile
        response = requests.get('https://www.googleapis.com/userinfo/v2/me',
                                params={'access_token': access_token})
        if response.status_code != 200:
            raise BadRequest(
                detail="Can't obtain Google profile: {} {}".format(
                    response.status, response.reason
                )
            )
        google_profile = response.json()
        email = google_profile['email'].lower()
        if not email:
            raise BadRequest(details='There is no Email address')
        if not google_profile['verified_email']:
            raise BadRequest(details='Email address is not verified')

        # check if email is already registered
        user = g.session.query(User).filter(User.email == email).first()
        if user is None:
            # add new user
            user = User(
                email=email,
                password=token_generator(),
                status=User.STATUS_VERIFIED,
                name=google_profile.get('name', ''),
                given_name=google_profile.get('given_name', ''))
            g.session.add(user)
            try:
                g.session.commit()
            except SQLAlchemyError:
                raise ServerError(detail="Can't add new User record")

        return UserService._generate_token(user)


users = Blueprint(UserService.name, __name__)
service = UserService.register_on(users)
register_service(service)
