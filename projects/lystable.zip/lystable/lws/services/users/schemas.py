from lws.serialise import fields, Schema
from .models import UserProfile, User


class UserProfileSchema(Schema):
    id = fields.Integer(read_only=True)
    user_level = fields.Select(choices=(UserProfile.USER_LEVEL_STANDARD,
                                        UserProfile.USER_LEVEL_OWNER),
                               required=True)
    user_id = fields.Integer(read_only=True)
    team_id = fields.Integer(read_only=True)

    class Meta:
        title = 'user_profile'
        model = UserProfile
        fields = ('id', 'user_level', 'user_id', 'team_id')


class UserSchema(Schema):
    id = fields.Integer(read_only=True)
    email = fields.String()
    name = fields.String()
    given_name = fields.String()
    status = fields.String()
    is_admin = fields.Boolean()
    profiles = fields.Nested(UserProfileSchema, many=True)

    class Meta:
        model = User
        title = 'user'
        fields = ('id', 'email', 'name', 'given_name', 'status', 'is_admin',
                  'profiles')
        many_exclude = ('profiles', )
