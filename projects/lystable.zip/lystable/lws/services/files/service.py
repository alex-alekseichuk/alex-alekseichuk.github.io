from flask import Blueprint
from lws.core.service import Service, register_service
from .views import FileView


files = Blueprint('files', __name__)


class FileService(Service):
    """ This service is for handling static files uploaded into the system
    by another services. There are resources like documents, profile pictures,
    etc.

    """

    root = FileView


service = FileService.register_on(files)
register_service(service)
