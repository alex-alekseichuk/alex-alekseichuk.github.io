"""create files table

Revision ID: 21fb27c936e
Revises: None
Create Date: 2015-06-16 11:42:49.696692

"""

# revision identifiers, used by Alembic.
revision = '21fb27c936e'
down_revision = None

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table(
        'files',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('type', sa.String(64), nullable=False),
        sa.Column('filename', sa.String(255), nullable=True),
        sa.Column('size', sa.Integer(), nullable=False, default=0),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False),
    )


def downgrade():
    op.drop_table('files')
