from lws.serialise import fields, Schema
from .models import File


class FileSchema(Schema):
    id = fields.Integer(read_only=True)
    filename = fields.String(required=False)
    size = fields.Integer(read_only=True)
    type = fields.String(required=True)

    class Meta:
        model = File
        fields = ('id', 'filename', 'size', 'type')
