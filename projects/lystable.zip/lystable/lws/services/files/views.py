from flask import g, current_app
from lws.core.db import commit_or_abort
from lws.core.exceptions import BadRequest, NotFound, ConfigurationError
from lws.core.s3 import get_url, upload_content, delete_key
from lws.core.service import ResourceView, request_json, decode
from lws.core.service.decorators import route
from lws.serialise.decorators import noschema
from .models import File
from .schemas import FileSchema


class FileView(ResourceView):
    """ A View to deal with file object as a resource.
    """

    schema = FileSchema

    @route(rule='/', method='post', internal=True)
    def post(self, schema):
        """ Save uploaded file to S3 bucket.

        Returns
        -------
        (lws.services.files.models.File, 201)

        """
        data = request_json()
        content = data.pop('content', None)
        if content is None:
            raise BadRequest
        content = decode(content)
        data['size'] = len(content)
        file = schema.create(data)
        g.session.add(file)
        commit_or_abort()
        upload_content(FileView.bucket_name(file.type), str(file.id), content)
        return file, 201

    @route(rule='/<int:id>/', internal=True)
    def get(self, schema, id):
        """ Get information about a file.

        Returns
        -------
        lws.services.files.models.File

        """
        if id is None:
            raise BadRequest
        file = g.session.query(File).get(id)
        if file is None:
            raise NotFound
        return file

    @route(rule='/<int:id>/url/', internal=True)
    @noschema
    def get_url(self, id):
        """ Get temporary URL to the file.

        Returns
        -------
        str
            Absolute URL to the file.

        """
        if id is None:
            raise BadRequest
        file = g.session.query(File).get(id)
        if file is None:
            raise NotFound
        return get_url(FileView.bucket_name(file.type), str(file.id))

    @route(rule='/<int:id>/', method='delete', internal=True)
    def delete(self, schema, id):
        """ Delete the file.

        Returns
        -------
        None

        """
        if id is None:
            raise BadRequest
        file = g.session.query(File).get(id)
        if file is None:
            raise NotFound
        delete_key(FileView.bucket_name(file.type), str(file.id))
        g.session.delete(file)
        commit_or_abort()

    @staticmethod
    def bucket_name(type):
        bucket_name = current_app.config.get('S3_BUCKETS', {}).get(type)
        if bucket_name is None:
            raise ConfigurationError
        return bucket_name
