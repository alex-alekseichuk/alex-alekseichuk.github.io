from sqlalchemy import Column, String, Integer
from lws.core.db import Base, DeletedMixin


class File(Base, DeletedMixin):

    __tablename__ = 'files'

    PICTURE = 'picture'

    id = Column(Integer, autoincrement=True, primary_key=True)
    type = Column(String(64), nullable=False)
    filename = Column(String(255), nullable=True)
    size = Column(Integer, nullable=False, default=0)
