from flask import g, request
from lws.core.db import commit_or_abort
from lws.core.exceptions import (
    NotFound, NotAcceptable, Forbidden, BadRequest)
from lws.core.service import (
    request_json, ResourceView, ServiceProxy, request_overrides)
from lws.core.service.decorators import route
from lws.serialise.decorators import noschema
from lws.core.auth import perms
from .models import Team
from .schemas import (
    TeamSchema, AccessRequestSchema, InvitationSchema, TeamConfigSchema)


users_proxy = ServiceProxy('users')

OWNER = 'OWNER'
STANDARD = 'STANDARD'


def _get_team_from_id(team_id):
    """ Gets the team from an id.
        Also checks that current user is authorized (has a profile)
        for that team.
    """
    team = g.session.query(Team).filter(
        Team.id == team_id,
        Team.deleted != True
    ).first()  # noqa

    if not team:
        raise NotFound
    if request.auth_data.get('team_id'):
        if team.id != request.auth_data['team_id']:
            raise Forbidden
    return team


class TeamView(ResourceView):

    schema = TeamSchema

    def index(self, schema):
        """ List all teams active on the Lystable platform.

        .. todo::
            Permission checking to only return teams
            accessible by the provided auth token

        Returns
        -------
        list
            A list of all teams

        """

        model = schema.get_model()
        return g.session.query(model).order_by(model.created_at)

    def get(self, schema, id):
        """ Get the full representation of an ``Team`` resource.

        Returns
        -------
        Team
            A full Team representation.

        Raises
        ------
        NotFound
            If the specified team id does not exist

        """

        model = schema.get_model()

        team = g.session.query(model).get(id)
        if not team:
            raise NotFound

        return team

    def delete(self, schema, id):
        """ Deletes the specified Team resource.

        Raises
        ------
        NotFound
            If the specified team id does not exist

        """

        team = g.session.query(Team).get(id)

        if not team:
            raise NotFound

        # TODO: We probably need additional handling around related data /
        #       services and notifications etc.
        schema.delete(team)
        commit_or_abort()

    def post(self, schema):
        """ Creates a new team resource.

        Returns
        -------
        Team
            A full Team representation.

        """
        return self._create_team(), 201

    def put(self, schema, id):
        """ Updates attributes of the specified team resource.

        Returns
        -------
        Team
            A full Team representation.

        Raises
        ------
        NotFound
            If the specified team id does not exist

        """

        model = schema.get_model()

        team = g.session.query(model).get(id)
        if not team:
            raise NotFound

        data = request_json()
        config_data = data.pop('config', None)
        if config_data is not None and team.config is not None:
            g.session.add(TeamConfigSchema().update(config_data, team.config))
        team = schema.update(data, team)
        g.session.add(team)
        commit_or_abort()
        return team

    @staticmethod
    def _handle_join(
            user_id, team, first_user=False):
        # Get email:
        with request_overrides(method='get'):
            user_data = users_proxy.get_user(user_id=user_id).get('data')
        email = user_data.get('email')

        # Make sure user email and team domain match:
        if (
            email.split('@')[1] == team.config.primary_domain or
            first_user and team.config.primary_domain
        ):
            data = {'user_id': user_id,
                    'team_id': team.id}
            with request_overrides(data=data):
                return users_proxy.profiles.post()
        else:
            AccessRequestView.create_access_request(
                user_id, team.id)
            raise Forbidden('Access request created')

    @route(rule='join', method='post')
    @perms.checkers(perms.is_authenticated)
    def create_team_and_join(self, schema):
        """Creates team and joins the user."""
        team = self._create_team()

        # create owner user profile
        TeamView._handle_join(
            request.auth_data.get('user_id'), team, first_user=True)
        return team, 201

    @route(rule='join/<int:team_id>', method='post')
    @perms.checkers(perms.is_authenticated)
    def join_existing_team(self, schema, team_id):
        """Join a user into an existing team."""
        model = schema.get_model()
        team = g.session.query(model).get(team_id)
        if not team:
            raise NotFound

        user_id = request.auth_data.get('user_id')

        TeamView._handle_join(user_id, team)
        return team

    @noschema
    @route(rule='signup', method='post')
    @perms.checkers()
    def register_and_join_team(self):
        """ Signup a new user into an existing team

        Creates:
        1) User
        2) UserProfile.
            The new user will be the owner of the team
            doesn't already have one.

        Parameters
        ----------
        name : str
            User name
        email : str
            The email address for the new user account. Must be unique
        password : str
            The password for this user account
        team_id : int
            ID of the target team

        Returns
        -------
        204
            If created successfully

        Raises
        ------
        Forbidden
            If can't join the specified team
        BadRequest
            Missing Parameters
        NotFound
            No team with the specified ID found
        Conflict
            If the email address is taken
        NotAcceptable
            If the password does not match the strength standard
            (currently > 6 characters long)

        """
        data = request_json()
        if (
            'name' not in data or
            'email' not in data or
            'password' not in data or
            'team_id' not in data
        ):
            raise BadRequest

        target_team = g.session.query(Team).get(
            data['team_id'])

        if not target_team:
            raise NotFound

        with request_overrides(data={'email': data['email'],
                                     'password': data['password'],
                                     'name': data['name']}):
            res = users_proxy.register()
        TeamView._handle_join(res['data']['id'], target_team)

    def _create_team(self):
        s = TeamSchema()
        data = request_json()
        config_data = data.pop('config', None)
        team = s.create(data)
        if config_data is not None:
            team.config = TeamConfigSchema().create(config_data)
        g.session.add(team)
        commit_or_abort()
        return team


class AccessRequestView(ResourceView):

    schema = AccessRequestSchema

    @perms.checkers(perms.is_authenticated, perms.is_in_team)
    def index(self, schema, team_id):
        """ List all access requests for a team.

        Returns
        -------
        list
            A list of all access requests matching the filter parameters

        Raises
        ------
        NotFound
            If the specified team id does not exist
        Forbidden
            If the provided auth token is not for the specified team id

        """

        team = _get_team_from_id(team_id)
        model = schema.get_model()
        return g.session.query(model).filter(
            model.team_id == team.id)

    @route(rule='<int:id>/reject', method='post')
    @perms.checkers(perms.is_authenticated, perms.is_owner)
    def reject(self, schema, team_id, id):
        """ Reject the specified access request for the team.

        Returns
        -------
        AccessRequest
            A representation of the rejected access request

        Raises
        ------
        NotFound
            If the specified team id or access request id
            does not exist.
        Forbidden
            If the provided auth token is not for the specified
            team id or the token is not for an owner of the team.

        """

        # Prepare resources:
        _get_team_from_id(team_id)
        access_request = g.session.query(schema.get_model()).get(id)
        if not access_request:
            raise NotFound

        # Mark the access request as actioned, rejected:
        access_request.actioned_by = request.auth_data['user_id']
        access_request.accepted = False
        g.session.add(access_request)
        commit_or_abort()
        return access_request, 200

    @route(rule='<int:id>/accept', method='post')
    @perms.checkers(perms.is_authenticated, perms.is_owner)
    def accept(self, schema, team_id, id):
        """ Accept the specified access request for the team.

        This action also creates a UserProfile within the ``users``
        service for the given user.

        Returns
        -------
        AccessRequest
            A representation of the accepted access request

        Raises
        ------
        NotFound
            If the specified team id or access request id
            does not exist.
        Forbidden
            If the provided auth token is not for the specified
            team id or the token is not for an owner of the
            team.

        """

        _get_team_from_id(team_id)
        access_request = g.session.query(schema.get_model()).get(id)
        if not access_request:
            raise NotFound

        with request_overrides(data={
                'user_id': access_request.user_id,
                'team_id': access_request.team_id
        }):
            users_proxy.profiles.post()

        # Mark the access request as actioned, accepted:
        access_request.actioned_by = request.auth_data['user_id']
        access_request.accepted = True
        g.session.add(access_request)
        commit_or_abort()
        return access_request, 200

    def post(self, schema, team_id):
        """ Request access to the specified team.

        Returns
        -------
        AccessRequest
            A representation of the access request

        Raises
        ------
        NotFound
            If the specified team id or access request id
            does not exist.
        Forbidden
            If the provided auth token is not for the specified
            team id.
        NotAcceptable
            The provided access request data was insufficient / invalid.

        """

        team = _get_team_from_id(team_id)
        user_id = request.auth_data['user_id']
        model = schema.get_model()

        # If a pending access request already exists, reject
        if g.session.query(model).filter(
            model.user_id == request.auth_data['user_id'],
            model.actioned_by == None
        ).count():  # noqa
            raise NotAcceptable

        # If the user was kind enough to send profile data with the request:
        if team.id == request.auth_data.get('team_id'):
            raise NotAcceptable

        with request_overrides(method='get'):
            user_data = users_proxy.get_user(user_id=user_id).get('data')

        # If the user's email and the team have the same domain, reject
        if user_data['email'].split('@')[1] == team.config.primary_domain:
            raise NotAcceptable

        # If the user already has profile, reject
        for profile in user_data['profiles']:
            if profile['team_id'] == team.id:
                raise NotAcceptable

        instance = schema.create(dict(user_id=user_id, team_id=team.id))
        g.session.add(instance)
        commit_or_abort()
        return AccessRequestView.create_access_request(user_id, team.id), 201

    @staticmethod
    def create_access_request(user_id, team_id):
        s = AccessRequestSchema()
        access_request = s.create(dict(user_id=user_id,
                                       team_id=team_id))
        g.session.add(access_request)
        commit_or_abort()
        return access_request


class InvitationView(ResourceView):

    schema = InvitationSchema

    @perms.checkers(perms.is_authenticated, perms.is_in_team)
    def index(self, schema, team_id):
        """ List all invitations for an team.

        Returns
        -------
        list
            A list of all invitations matching the filter parameters

        Raises
        ------
        NotFound
            If the specified team id does not exist
        Forbidden
            If the provided auth token is not for the specified team id

        """

        team = _get_team_from_id(team_id)
        model = schema.get_model()
        return g.session.query(model).filter(
            model.team_id == team.id).order_by(model.created_at)

    @perms.checkers(perms.is_authenticated, perms.is_in_team)
    def post(self, schema, team_id):
        """ Invites a new user to join the specified team.

        Returns
        -------
        Invitation
            The newly created invitation.

        Raises
        ------
        NotFound
            If the specified team id does not exist
        Forbidden
            If the provided auth token is not for the specified team id
        NotAcceptable
            The provided invitation data was insufficient / invalid.

        """

        team = _get_team_from_id(team_id)
        user_id = request.auth_data['user_id']
        model = schema.get_model()
        data = request_json()

        # If a pending invitation exists, reject
        if g.session.query(model).filter(
            model.email == data['email'],
            model.accepted != True,
            model.team_id == team.id
        ).count():  # noqa
            raise NotAcceptable

        # If the user is already a member of the team, reject
        if team.id == request.auth_data.get('team_id'):
            raise NotAcceptable

        # Check a profile (team, email) doesn't exist
        with request_overrides(data={
                'team_id': team.id,
                'email': data['email']
        }):
            if users_proxy.profiles.profile_for_invite() is not None:
                raise NotAcceptable

        invitation = schema.create({
            'inviter': user_id,
            'team_id': team.id,
            'email': data['email'],
        })
        g.session.add(invitation)
        commit_or_abort()
        return invitation, 201

    @perms.checkers(perms.is_authenticated, perms.is_in_team)
    def delete(self, schema, team_id, id):
        """ Delete the specified Invitation.

        Raises
        ------
        NotFound
            If the specified Invitation does not exist
        Forbidden
            If the provided auth token is not for the specified
            team id or the token is not for an owner of the team.

        """

        _get_team_from_id(team_id)

        invitation = g.session.query(schema.get_model()).get(id)
        if not invitation:
            raise NotFound

        if request.auth_data['user_level'] != OWNER:
            if invitation.inviting_id != request.auth_data['user_id']:
                raise Forbidden

        schema.delete(invitation)
        commit_or_abort()

    @route(rule='<int:id>/accept', method='post')
    @perms.checkers(perms.is_authenticated)
    def accept(self, schema, team_id, id):
        """ Accepts the Invitation and creates a new User Profile for the team.

        Returns
        -------
        Invitation
            A representation of the invitation

        Raises
        ------
        NotFound
            If the specified Invitation does not exist
        Forbidden
            If the provided auth token is not for the specified
            team id or the token is not for an owner of the team.

        """

        _get_team_from_id(team_id)
        invitation = g.session.query(schema.get_model()).get(id)
        if not invitation:
            raise NotFound
        if invitation.accepted:
            raise NotFound

        with request_overrides(data={
                'user_id': request.auth_data['user_id'],
                'team_id': invitation.team_id
        }):
            users_proxy.profiles.post()

        # Mark the access request as actioned, accepted:
        invitation.accepted = True
        invitation.invited_id = request.auth_data['user_id']
        g.session.add(invitation)
        commit_or_abort()
        return invitation, 200
