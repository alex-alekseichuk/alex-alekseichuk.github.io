from lws.serialise import fields, Schema
from .models import Team, AccessRequest, Invitation, TeamConfig


class TeamSchema(Schema):
    id = fields.Integer(read_only=True)
    slug = fields.String(required=True)
    display_name = fields.String(required=True)
    created_at = fields.DateTime(read_only=True)
    created_by = fields.Integer(read_only=True)
    accepted = fields.Boolean()

    config = fields.Nested(
        'TeamConfigSchema', default=None, attribute='config')

    class Meta:
        title = 'team'
        model = Team
        fields = (
            'id', 'slug', 'display_name', 'created_at', 'created_by', 'config'
        )


class TeamConfigSchema(Schema):
    id = fields.Integer(read_only=True)
    primary_domain = fields.String(required=False)

    class Meta:
        model = TeamConfig
        fields = ('primary_domain', )


class AccessRequestSchema(Schema):
    id = fields.Integer(read_only=True)
    team_id = fields.Integer(required=True)
    user_id = fields.Integer(required=True)
    created_at = fields.DateTime(read_only=True)
    actioned_by = fields.Integer()
    accepted = fields.Boolean()

    class Meta:
        title = 'access_request'
        model = AccessRequest
        fields = ('id', 'team_id', 'user_id', 'actioned_by',
                  'created_at', 'accepted',
                  )


class InvitationSchema(Schema):
    id = fields.Integer(read_only=True)
    team_id = fields.Integer(required=True)
    inviting_id = fields.Integer(required=True)
    invited_id = fields.Integer()
    created_at = fields.DateTime(read_only=True)
    email = fields.String(required=True)
    accepted = fields.Boolean()

    class Meta:
        title = 'invitation'
        model = Invitation
        fields = ('id', 'team_id', 'inviting_id', 'invited_id',
                  'email', 'created_at', 'accepted',
                  )
