from sqlalchemy import Column, String, Integer, ForeignKey, Boolean
from sqlalchemy.orm import relationship, backref

from lws.core.db import Base, DeletedMixin
from lws.core.db.types import CrossServiceForeignKey


class Team(Base, DeletedMixin):

    __tablename__ = 'teams'

    id = Column(Integer, autoincrement=True, primary_key=True)
    slug = Column(String(127), index=True, nullable=False)
    display_name = Column(String(255), index=True, nullable=False)
    created_by = Column(Integer, nullable=True)
    config_id = Column(Integer, ForeignKey('team_configs.id'))
    config = relationship(
        'TeamConfig', backref=backref('team', uselist=False))


class TeamConfig(Base):

    __tablename__ = 'team_configs'

    id = Column(Integer, autoincrement=True, primary_key=True)
    primary_domain = Column(String(127), nullable=True)


class AccessRequest(Base):

    __tablename__ = 'access_requests'

    id = Column(Integer, autoincrement=True, primary_key=True)

    #: Team to join
    team_id = Column(Integer,
                     ForeignKey('teams.id'),
                     nullable=False,
                     index=True)

    #: ID of requesting user
    user_id = Column(
        CrossServiceForeignKey('users.User'),
        nullable=False
    )

    #: ID of responding user
    actioned_by = Column(
        CrossServiceForeignKey('users.User'),
        nullable=True
    )

    #: Whether the response was accepted
    accepted = Column(Boolean, nullable=True)


class Invitation(Base):

    __tablename__ = 'invitations'

    id = Column(Integer, autoincrement=True, primary_key=True)

    team_id = Column(Integer,
                     ForeignKey('teams.id'),
                     nullable=False,
                     index=True)

    email = Column(String(127), index=True, nullable=False)

    #: ID of user making the invitation
    inviting_id = Column(
        CrossServiceForeignKey('users.User'),
        nullable=False
    )

    #: ID of outsider being invited. The outsider's ID is not known to the
    #: inviter, and so remains None when creating the invitation. There might
    #: not even be a registered user with the email address being invited.
    #: Only after accepting the invitation the invited_id is populated.
    invited_id = Column(
        CrossServiceForeignKey('users.User'),
        nullable=True
    )

    accepted = Column(Boolean, nullable=True)
