"""add created_at field

Revision ID: 181607f4fc5
Revises: b8e7b32267
Create Date: 2015-07-06 12:57:36.350421

"""

# revision identifiers, used by Alembic.
revision = '181607f4fc5'
down_revision = 'b8e7b32267'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('team_configs',
                  sa.Column('created_at', sa.DateTime(), nullable=False))


def downgrade():
    op.drop_column('team_configs', 'created_at')
