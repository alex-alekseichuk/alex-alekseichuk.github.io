""" add teams tables

Revision ID: 20d4020edc34
Revises: None
Create Date: 2015-04-24 14:56:25.892179

"""

# revision identifiers, used by Alembic.
revision = '20d4020edc34'
down_revision = None

from alembic import op
import sqlalchemy as sa


def upgrade():
    # remove teams tables of previous organisations version
    op.execute("""
        DROP INDEX IF EXISTS ix_organisations_invited;
        DROP TABLE IF EXISTS invitations;

        DROP INDEX IF EXISTS ix_organisations_to_join;
        DROP TABLE IF EXISTS access_requests;

        DROP INDEX IF EXISTS ix_organisations_slug;
        DROP INDEX IF EXISTS ix_organisations_display_name;
        DROP TABLE IF EXISTS organisations;
    """)

    op.create_table('teams',
        sa.Column('deleted', sa.Boolean(), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('slug', sa.String(length=127), nullable=False),
        sa.Column('display_name', sa.String(length=255), nullable=False),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('primary_domain', sa.String(length=127), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_teams_display_name'), 'teams', ['display_name'], unique=False)
    op.create_index(op.f('ix_teams_slug'), 'teams', ['slug'], unique=True)

    op.create_table('access_requests',
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('team_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('actioned_by', sa.Integer(), nullable=True),
        sa.Column('accepted', sa.Boolean(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['team_id'], ['teams.id'], ),
    )
    op.create_index(op.f('ix_teams_to_join'), 'access_requests',
            ['team_id'], unique=False)

    op.create_table('invitations',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('team_id', sa.Integer(), nullable=False),
        sa.Column('inviting_id', sa.Integer(), nullable=False),
        sa.Column('email', sa.String(127), index=True, nullable=False),
        sa.Column('invited_id', sa.Integer(), nullable=True),
        sa.Column('accepted', sa.Boolean(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['team_id'], ['teams.id'], ),
    )
    op.create_index(op.f('ix_teams_invited'), 'invitations',
            ['team_id'], unique=False)


def downgrade():
    op.drop_index(op.f('ix_teams_invited'), table_name='invitations')
    op.drop_table('invitations')

    op.drop_index(op.f('ix_teams_to_join'), table_name='access_requests')
    op.drop_table('access_requests')

    op.drop_index(op.f('ix_teams_slug'), table_name='teams')
    op.drop_index(op.f('ix_teams_display_name'), table_name='teams')
    op.drop_table('teams')
