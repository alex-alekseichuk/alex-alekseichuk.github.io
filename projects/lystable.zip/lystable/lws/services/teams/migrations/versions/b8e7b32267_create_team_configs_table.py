"""create team_configs table

Revision ID: b8e7b32267
Revises: 20d4020edc34
Create Date: 2015-07-02 12:50:19.948554

"""

# revision identifiers, used by Alembic.
revision = 'b8e7b32267'
down_revision = '20d4020edc34'

from alembic import op
import sqlalchemy as sa


metadata = sa.MetaData()
teams = sa.Table(
    'teams', metadata,
    sa.Column('id', sa.Integer, sa.Sequence('teams_id_seq'), primary_key=True),
    sa.Column('primary_domain', sa.String(127)),
    sa.Column('config_id', sa.Integer)
)
team_configs = sa.Table(
    'team_configs', metadata,
    sa.Column('id', sa.Integer, sa.Sequence('team_configs_id_seq'),
              primary_key=True),
    sa.Column('primary_domain', sa.String(127))
)


def upgrade():
    op.create_table(
        'team_configs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('primary_domain', sa.String(length=127), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.add_column('teams', sa.Column('config_id', sa.Integer(), nullable=True))

    # create team_configs and move primary_domain values there
    conn = op.get_bind()
    teams_rows = conn.execute(
        sa.select([teams.c.id, teams.c.primary_domain])).fetchall()
    for row in teams_rows:
        result = conn.execute(team_configs.insert().values(
            primary_domain=row['primary_domain']))
        conn.execute(teams.update().where(teams.c.id == row['id']).values(
            config_id=result.inserted_primary_key[0]))

    op.create_foreign_key('fk_teams_team_configs', 'teams', 'team_configs',
                          ['config_id'], ['id'])
    op.drop_column('teams', 'primary_domain')


def downgrade():
    op.add_column('teams', sa.Column('primary_domain', sa.VARCHAR(length=127),
                                     nullable=True))

    # move primary_domain values from team_configs to teams
    conn = op.get_bind()
    teams_rows = conn.execute(
        sa.select([teams.c.id, teams.c.config_id])).fetchall()
    for team_row in teams_rows:
        result = conn.execute(sa.select(
            [team_configs.c.primary_domain]
        ).where(team_configs.c.id == team_row['config_id']))
        if result.returns_rows:
            config_row = result.fetchone()
            if config_row is not None:
                conn.execute(teams.update().where(
                    teams.c.id == team_row['id']).values(
                    primary_domain=config_row['primary_domain']))

    op.drop_constraint('fk_teams_team_configs', 'teams', type_='foreignkey')
    op.drop_column('teams', 'config_id')
    op.drop_table('team_configs')
