from flask import Blueprint
from lws.core.service import Service, register_service
from .views import (
    TeamView, AccessRequestView, InvitationView
)

teams = Blueprint('teams', __name__)


class TeamService(Service):
    """ This service encapsulates all high level actions for teams
    / teams signed up to the Lystable platform.

    A team is the umbrella under which all other actions take place.
    As such, there are a number of other actions which must take place through
    this service in order for additional authorisation checks to be performed.

    ``team_id`` is referenced in many other services and users have a
    `UserProfile` for each team they are a member of. This data lives
    in the ``users`` service and is bolted on to each auth token for
    authorising API requests, however, user profiles are managed by actions
    through this service via private APIs to ensure atomic operations.

    """

    root = TeamView
    access_requests = AccessRequestView.mount('<int:team_id>/access-requests')
    invitations = InvitationView.mount('<int:team_id>/invitations')

service = TeamService.register_on(teams)
register_service(service)
