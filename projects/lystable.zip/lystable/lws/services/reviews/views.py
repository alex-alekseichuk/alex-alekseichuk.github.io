from flask import g, request
from sqlalchemy.orm.exc import NoResultFound

from lws.core.db import commit_or_abort
from lws.core.service import (
    ResourceView, ServiceProxy, request_json
)
from lws.core.exceptions import NotFound

from .schemas import ReviewSchema

proxy = ServiceProxy('suppliers')


class ReviewView(ResourceView):

    schema = ReviewSchema

    def index(self, schema):
        """Gets a list of all reviews.

        Does not list reviews outside the current user's team.

        Returns
        -------
        sqlalchemy.orm.query.Query

        """
        model = schema.get_model()

        team_id = request.auth_data.get('team_id')
        supplier_id = request.args.get('supplier_id')

        query = g.session.query(model)

        if supplier_id:
            query = query.filter(model.supplier_id == supplier_id)

        reviews = query.filter(model.team_id == team_id)

        return reviews

    def get(self, schema, id):
        """Gets a review.

        Raises
        ------
        NotFound
            If the Review is not found, or it does not belong to the
            currently logged in team.

        Returns
        -------
        Review

        """
        model = schema.get_model()
        team_id = request.auth_data.get('team_id')

        query = g.session.query(model)
        query = query.filter(
            model.team_id == team_id,
            model.id == id
        )

        try:
            review = query.one()
        except NoResultFound:
            raise NotFound

        return review

    def post(self, schema):
        """Creates a review.

        Raises
        ------
        BadRequest
            If the supplier_profile_id provided does not exist.

        Returns
        -------
        Review

        """
        data = request_json()

        team_id = request.auth_data.get('team_id')
        supplier_id = data.get('supplier_id')

        data['team_id'] = team_id

        review = schema.create(dict(**data))
        review.supplier_id = supplier_id
        g.session.add(review)
        commit_or_abort()

        return review, 201

    def put(self, schema, id):
        """Updates a review.

        Raises
        ------
        NotFound
            If the Review is not found, or it does not belong to the
            currently logged in team.

        Returns
        -------
        Review

        """
        model = schema.get_model()
        team_id = request.auth_data.get('team_id')

        query = g.session.query(model)
        query = query.filter(model.team_id == team_id)
        try:
            review = query.one()
        except NoResultFound:
            raise NotFound

        review = schema.update(request_json(), review)
        g.session.add(review)
        commit_or_abort()

        return review

    def delete(self, schema):
        """Deletes a review.

        Raises
        ------
        NotFound
            If the Review is not found, or it does not belong to the
            currently logged in team.
        """
        model = schema.get_model()

        team_id = request.auth_data.get('team_id')

        query = g.session.query(model)
        query = query.filter(model.team_id == team_id)
        query = query.filter(model.id == id)

        try:
            review = query.one()
        except NoResultFound:
            raise NotFound

        schema.delete(review)
        commit_or_abort()
