from sqlalchemy import (
    Column, Integer, ForeignKey, Text, Boolean
)
from sqlalchemy.orm import relationship
from sqlalchemy.schema import UniqueConstraint

from lws.core.db import Base, DeletedMixin
from lws.core.db.types import CrossServiceForeignKey


class Review(Base, DeletedMixin):
    """A review"""

    __tablename__ = 'reviews'

    id = Column(Integer, autoincrement=True, primary_key=True)

    #: Team that this review belongs to
    team_id = Column(
        CrossServiceForeignKey('teams.Team'),
        nullable=False
    )

    #: Review comment.
    comment = Column(Text)

    #: Sentiment of review. Can be positive, negative, or neutral (ie. None).
    sentiment = Column(Boolean)

    supplier_id = Column(
        CrossServiceForeignKey('suppliers.Supplier'),
        nullable=False
    )


class ReviewSkill(Base):
    """A fake-join table to the Supplier service's Skill model.
    """

    __tablename__ = 'reviews_skills'

    id = Column(Integer, autoincrement=True, primary_key=True)

    review_id = Column(Integer, ForeignKey('reviews.id'), nullable=False)
    review = relationship(Review, backref='skills')

    #: The Skill ID in the supplier service
    skill_id = Column(
        CrossServiceForeignKey('suppliers.Skill'),
        nullable=False
    )

    __table_args__ = (UniqueConstraint(review_id, skill_id), )
