from lws.serialise import fields, Schema

from .models import Review


class ReviewSchema(Schema):
    id = fields.Integer(read_only=True)
    comment = fields.String()
    sentiment = fields.Boolean()
    supplier_id = fields.Integer()
    team_id = fields.Integer()

    class Meta:
        title = 'review'
        model = Review
