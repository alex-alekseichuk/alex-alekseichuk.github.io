"""rename to team

Revision ID: 4c11fbefd8a
Revises: c0da422185
Create Date: 2015-06-30 21:12:48.538303

"""

# revision identifiers, used by Alembic.
revision = '4c11fbefd8a'
down_revision = 'c0da422185'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


def upgrade():
    op.alter_column('reviews', 'organisation_id', new_column_name='team_id')


def downgrade():
    op.alter_column('reviews', 'team_id', new_column_name='organisation_id')
