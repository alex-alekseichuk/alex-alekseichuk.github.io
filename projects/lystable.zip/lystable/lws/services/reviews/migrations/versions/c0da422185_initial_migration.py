"""Initial migration

Revision ID: c0da422185
Revises: None
Create Date: 2015-06-19 14:34:17.511592

"""

# revision identifiers, used by Alembic.
revision = 'c0da422185'
down_revision = None

from alembic import op
import sqlalchemy as sa
from lws.core.db.types import CrossServiceForeignKey as CSFK


def upgrade():
    op.create_table(
        'reviews',
        sa.Column('id', sa.Integer, nullable=False, primary_key=True),
        sa.Column('comment', sa.Text()),
        sa.Column('sentiment', sa.Boolean()),
        sa.Column(
            'organisation_id',
            CSFK('teams.Team'),
            nullable=False
        ),
        sa.Column(
            'supplier_id',
            CSFK('suppliers.Supplier'),
            nullable=False
        ),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False)
    )

    op.create_table(
        'reviews_skills',
        sa.Column('id', sa.Integer, nullable=False, primary_key=True),
        sa.Column('review_id', sa.Integer, nullable=False),
        sa.Column(
            'skill_id',
            CSFK('suppliers.Skill'),
            nullable=False
        ),
        sa.UniqueConstraint('review_id', 'skill_id'),
        sa.ForeignKeyConstraint(['review_id'], ['reviews.id']),
        sa.Column('created_at', sa.DateTime(), nullable=False),
    )


def downgrade():
    op.drop_table('reviews_skills')
    op.drop_table('reviews')
