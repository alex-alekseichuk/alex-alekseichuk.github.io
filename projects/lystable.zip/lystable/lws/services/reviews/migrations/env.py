from alembic import context
from lws.core.app import app
from lws.core.db import get_engine, Base, DB_URI_KEY

config = context.config

target_metadata = Base.metadata


def run_migrations_online():
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    app.config.from_envvar('LWS_ENVFILE')

    engine = get_engine(app.config[DB_URI_KEY])
    version_table = config.get_main_option("version_table")

    connection = engine.connect()
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        version_table=version_table
    )

    try:
        with context.begin_transaction():
            context.run_migrations()
    finally:
        connection.close()

if context.is_offline_mode():
    raise NotImplementedError('No support for offline migrations')
else:
    run_migrations_online()
