from flask import Blueprint, g
from sqlalchemy.sql import select, func

from lws.core.service import Service, register_service
from lws.core.service.decorators import route
from lws.core.auth.perms import is_authenticated, is_in_team

from .views import ReviewView
from .models import Review


class ReviewService(Service):

    permission_checkers = (is_authenticated, is_in_team)

    """This service tracks information about the reviews on suppliers..

    It also keeps track of supplier information for a single team.

    Note
    ----
        This may change once we engage suppliers to manage their own profiles

    """

    name = 'reviews'
    root = ReviewView

    @route(rule='score/<int:id>', internal=True)
    def score(self, id):
        """Calculates the Lystable score for a given supplier.

        Returns
        -------
        float
            Score for the supplier.
        """

        selector = select([func.count(Review.__table__.c.id)]) \
            .where(Review.supplier_id == id)

        positive_selector = selector.where(Review.sentiment == True).alias()
        negative_selector = selector.where(Review.sentiment == False).alias()

        positive, negative = g.session.query(
            positive_selector,
            negative_selector
        ).one()

        score = positive - negative

        return score


reviews = Blueprint(ReviewService.name, __name__)
service = ReviewService.register_on(reviews)
register_service(service)
