from flask import Blueprint, g, request
from sqlalchemy.orm.exc import NoResultFound

from lws.core.exceptions import NotFound, Conflict, BadRequest
from lws.core.service import ResourceView, request_json
from lws.core.db import commit_or_abort

from .schemas import SupplierSchema, SkillSchema, SupplierProfileSchema

suppliers = Blueprint('suppliers', __name__)


class SupplierView(ResourceView):
    """Resource view for suppliers.

    This view cannot create suppliers externally, only fetch them.
    """

    schema = SupplierSchema

    def index(self, schema):
        """List all suppliers in the system.

        Note
        ----
        This endpoint should be secured at some point, for instance by
        allowing only queries with filters. This is not a problem as long as
        suppliers are essentially only an ID.

        Returns
        -------
        sqlalchemy.orm.query.Query
            A query matching any filter parameters

        """

        model = schema.get_model()

        suppliers = g.session.query(model)

        return suppliers

    def get(self, schema, id):
        """Get the full representation of a ``Supplier`` resource.

        Returns
        -------
        Supplier

        Raises
        ------
        NotFound
            If the specified supplier id does not exist
        """

        model = schema.get_model()

        supplier = g.session.query(model).get(id)
        if not supplier:
            raise NotFound

        return supplier

    def post(self, schema):
        """Create a Supplier with a corresponding SupplierProfile.

        Raises
        ------
        Conflict
            If the supplier profile already exists or a supplier already
            exists and creation of a profile is not attempted.

        Returns
        -------
        Supplier
        """
        model = schema.get_model()

        data = request_json()
        profile = data.pop('profile', None) or {}

        # If the supplier exists, move on to checking if it has a profile.
        created = False

        try:
            supplier = g.session.query(model).filter(
                model.email == data.get('email')
            ).one()
        except NoResultFound:
            created = True
            supplier = schema.create(data)

        # If the profile exists, we don't allow the user to continue.
        # We can't get a profile from the newly created supplier.
        if not created and supplier.contextual_profile:
            raise Conflict('Supplier profile already exists')

        # If the profile data isn't passed, we're trying to create a supplier
        # that already exists in the system.
        if not created and not profile:
            raise Conflict('Supplier already exists.')

        profile = SupplierProfileSchema().create(profile)
        supplier.profiles.append(profile)
        profile.team_id = request.auth_data.get('team_id')

        g.session.add(supplier)
        g.session.add(profile)
        commit_or_abort()

        return supplier, 201

    def put(self, schema, id):
        """Updates a Supplier.

        Can only update the profile related to the currently logged in user.

        Raises
        ------
        BadRequest
            If data that cannot be changed was passed in.

        Returns
        -------
        Supplier
        """
        model = schema.get_model()

        supplier = g.session.query(model).get(id)
        if not supplier:
            raise NotFound

        profile = supplier.contextual_profile

        data = request_json()

        profile_data = data.pop('profile', None)
        if len(data) > 0:
            raise BadRequest('Can only update supplier profile data.')

        if not profile:
            profile = SupplierProfileSchema().create(profile_data)
        else:
            profile = SupplierProfileSchema().update(profile_data, profile)

        # Appending an existing profile works fine and does not lead to
        # duplicates.
        supplier.profiles.append(profile)

        commit_or_abort()

        return supplier


class SkillView(ResourceView):

    schema = SkillSchema

    def index(self, schema):
        """List all skills.

        Returns
        -------
        sqlalchemy.orm.query.Query
            A query that can be resolved into Skill objects.

        """
        model = schema.get_model()

        skills = g.session.query(model)

        return skills

    def get(self, schema, id):
        """Gets a specific skill.

        Raises
        ------
        NotFound
            Raised if the skill id does not exist.

        Returns
        -------
        Skill

        """
        model = schema.get_model()

        skill = g.session.query(model).get(id)
        if not skill:
            raise NotFound

        return skill

    def post(self, schema):
        """Creates a skill.

        Returns
        -------
        Skill

        """
        skill = schema.create(request_json())

        g.session.add(skill)

        commit_or_abort()

        return skill, 201
