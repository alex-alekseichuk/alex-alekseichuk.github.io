from enum import Enum
from sqlalchemy import (
    Column, String, Integer, ForeignKey
)
from sqlalchemy.orm import relationship, backref
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.ext.associationproxy import association_proxy
from sqlalchemy.dialects.postgresql import JSONB, ENUM
from sqlalchemy.schema import UniqueConstraint

from lws.core.db import Base, DeletedMixin
from lws.core.db.types import CrossServiceForeignKey


class Supplier(Base, DeletedMixin):
    """A supplier.

    This model carries a minimum amount of identifiable information
    for a supplier to be recognised throughout Lystable. More specific
    information for each team interacting with the supplier is
    found in the :py:class:lws.services.teams.models.SupplierProfile
    model.

    See also
    --------
    :py:class:lws.services.suppliers.models.SupplierProfile
    """

    __tablename__ = 'suppliers'

    id = Column(Integer, autoincrement=True, primary_key=True)

    #: Name of supplier. Not mandatory.
    name = Column(String)

    #: Email of supplier. Not mandatory.
    email = Column(String(255), index=True, unique=True)

    #: Any extra global data for the supplier.
    #: This is meant for data imports, not for setting from the view.
    extra = Column(JSONB)

    skills = association_proxy('suppliers_skills_assoc', 'skill')

    @staticmethod
    def _get_team_id():
        """Get the team ID for the currently logged in user.

        It returns None if it is called without a request context, so that a
        profile will simply not be attached to the supplier rather than failing
        with an exception.

        Returns
        -------
        int
            Identifier of currently logged in team. Will be None if
            called without a request context.
        """
        from flask import request

        try:
            return request.auth_data.get('team_id')
        except RuntimeError:
            return None

    @property
    def contextual_profile(self):
        """Finds the supplier profile for a supplier based on the currently
        logged in user's team.

        Returns
        -------
        SupplierProfile
        """
        team_id = self._get_team_id()

        if not team_id:
            return

        try:
            return self.profiles.filter_by(
                team_id=team_id
            ).one()
        except NoResultFound:
            return None

    @contextual_profile.setter
    def contextual_profile(self, profile):
        """Sets the profile on the supplier.

        The type checking is due to SQLAlchemy passing a constructed object and
        Marshmallow passing a dictionary.
        """
        if type(profile) == dict:
            self.profiles.append(SupplierProfile(**profile))
        else:
            self.profiles.append(profile)


class SupplierProfile(Base, DeletedMixin):
    """A profile for a supplier.

    It contains team-local (but not necessarily specific or exclusive)
    information about a supplier, meant to be fetched based on a current user's
    authentication data.

    Each team can only have one supplier profile per supplier.
    """
    __tablename__ = 'supplier_profiles'

    id = Column(Integer, autoincrement=True, primary_key=True)

    #: Email address used by the team that owns the profile.
    contact_email = Column(String, index=True)

    #: Contact person for the team that owns the profile.
    contact_name = Column(String)

    #: Any extra team-specific data on the supplier.
    #: This is meant for data imports, not for setting from the view.
    extra = Column(JSONB)

    supplier_id = Column(Integer, ForeignKey('suppliers.id'), nullable=False)
    supplier = relationship(
        Supplier,
        backref=backref('profiles', lazy='dynamic')
    )

    team_id = Column(
        CrossServiceForeignKey('teams.Team'),
        nullable=False
    )

    # One profile per supplier per team
    __table_args__ = (UniqueConstraint(supplier_id, team_id), )


class ConnectionSources(Enum):
    """Enumerates the source of a connection between users and suppliers.

    Prefer enumerating another source over using OTHER.
    """
    ENDPOINT = 'endpoint'
    SPREADSHEET_IMPORT = 'spreadsheet_import'
    CONTACT_UPLOAD = 'contact_upload'
    REVIEW = 'review'
    REFERRAL = 'referral'
    OTHER = 'other'

    @staticmethod
    def values():
        return [t.value for t in ConnectionSources]


class UserConnection(Base, DeletedMixin):
    """An indicator that a user and a supplier is connected, and why.

    Used for data imports or manual connections.
    """
    __tablename__ = 'user_connections'

    id = Column(Integer, autoincrement=True, primary_key=True)

    #: Source of connection, ie. manual or from an import
    connection_source = Column(
        ENUM(*ConnectionSources.values(), name='connection_source'),
        nullable=False
    )

    supplier_id = Column(Integer, ForeignKey('suppliers.id'), nullable=False)
    supplier = relationship(
        Supplier,
        backref=backref('user_connections', lazy='dynamic')
    )

    user_id = Column(
        CrossServiceForeignKey('users.User'),
        nullable=False
    )

    team_id = Column(
        CrossServiceForeignKey('team.Team'),
        nullable=False
    )

    __table_args__ = (
        # One connection per reason per user per team
        UniqueConstraint(
            connection_source, user_id, team_id
        ),
    )


class Skill(Base):
    """A skill on a supplier.
    """

    __tablename__ = 'skills'

    id = Column(Integer, autoincrement=True, primary_key=True)

    #: Name of this skill
    name = Column(String, nullable=False, unique=True)

    suppliers = association_proxy('suppliers_skills_assoc', 'supplier')


class SupplierSkill(Base):
    """Join table between Supplier and Skill."""

    __tablename__ = 'suppliers_skills'

    id = Column(Integer, autoincrement=True, primary_key=True)

    supplier_id = Column(Integer, ForeignKey('suppliers.id'), nullable=False)
    skill_id = Column(Integer, ForeignKey('skills.id'), nullable=False)

    supplier = relationship('Supplier', backref='suppliers_skills_assoc')
    skill = relationship('Skill', backref='suppliers_skills_assoc')
