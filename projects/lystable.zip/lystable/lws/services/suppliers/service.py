from flask import Blueprint, request, g
from sqlalchemy.exc import IntegrityError

from lws.core.auth.perms import is_authenticated, is_in_team
from lws.core.exceptions import BadRequest
from lws.core.service import Service, register_service
from lws.core.service.decorators import route

from .models import UserConnection, ConnectionSources
from .schemas import SupplierSchema
from .views import SupplierView, SkillView


class SupplierService(Service):

    permission_checkers = (is_authenticated, is_in_team)

    """This service tracks information about the suppliers of an team.

    It also tracks skills and skill taxonomy.

    Note
    ----
    This service requires a user to be logged on with an team.
    """

    name = 'suppliers'

    root = SupplierView
    skills = SkillView

    @route(rule='/<int:id>/connect/', method='post')
    def connect(self, id):
        """Connects the current user to the given supplier, indicating
        a prior relationship between the two.

        Raises
        ------
        BadRequest
            If the connection between the user and the supplier is already made
            within the current team.

        Returns
        -------
        tuple
            (None, 201)
        """
        supplier = self.root().get(SupplierSchema, id)
        team_id = request.auth_data.get('team_id')
        user_id = request.auth_data.get('user_id')

        user_connection = UserConnection(
            user_id=user_id,
            team_id=team_id,
            connection_source=ConnectionSources.ENDPOINT.value
        )

        supplier.user_connections.append(user_connection)

        g.session.add(supplier)

        try:
            g.session.commit()
        except IntegrityError:
            g.session.rollback()
            raise BadRequest('Connection already made')

        return None, 201


suppliers = Blueprint(SupplierService.name, __name__)
service = SupplierService.register_on(suppliers)
register_service(service)
