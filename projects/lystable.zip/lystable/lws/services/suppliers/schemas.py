from lws.serialise import fields, Schema
from lws.serialise.validators import not_null

from .models import Supplier, SupplierProfile, Skill


class SupplierSchema(Schema):
    id = fields.Integer(read_only=True)

    #: Email of supplier.
    #: This field is not required on the model, but we want the schema
    #: to require it.
    email = fields.Email(required=True, validate=not_null)

    #: Name of supplier.
    #: This field is not required on the model, but we want the schema
    #: to require it.
    name = fields.String(required=True, validate=not_null)

    #: SupplierProfile fetched from Supplier's `profile` property.
    #: The default means we get None instead of an empty SupplierProfileSchema
    #: if the profile does not exist.
    profile = fields.Nested(
        'SupplierProfileSchema',
        default=None,
        attribute='contextual_profile'
    )

    class Meta:
        model = Supplier
        title = 'supplier'
        description = 'A supplier'


class SupplierProfileSchema(Schema):
    contact_email = fields.Email()
    contact_name = fields.String()

    class Meta:
        title = 'supplier_profile'
        model = SupplierProfile


class SkillSchema(Schema):
    id = fields.Integer(read_only=True)
    name = fields.String(required=True, validate=not_null)

    class Meta:
        title = 'skill'
        model = Skill
