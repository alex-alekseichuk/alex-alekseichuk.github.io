"""create skills tables

Revision ID: 37e521d29f6
Revises: 207bbdbabfd0
Create Date: 2015-05-14 12:58:13.999165

"""

# revision identifiers, used by Alembic.
revision = '37e521d29f6'
down_revision = '207bbdbabfd0'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table('skill_tags',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_skill_tags_name'), 'skill_tags', ['name'],
                    unique=True)

    op.create_table('votes',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('endorsement_id', sa.Integer(), nullable=False),
        sa.Column('tag_id', sa.Integer(), nullable=False),
        sa.Column('positive_experience', sa.Boolean(), nullable=False),
        sa.ForeignKeyConstraint(['endorsement_id'], ['endorsements.id'], ),
        sa.ForeignKeyConstraint(['tag_id'], ['skill_tags.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('endorsement_id', 'tag_id')
    )
    op.create_index(op.f('ix_votes_endorsement_id'), 'votes',
                    ['endorsement_id'], unique=False)
    op.create_index(op.f('ix_votes_tag_id'), 'votes', ['tag_id'],
                    unique=False)

    op.create_table('skills',
        sa.Column('supplier_id', sa.Integer(), nullable=False),
        sa.Column('tag_id', sa.Integer(), nullable=False),
        sa.Column('positive', sa.Integer(), nullable=False, default=0),
        sa.Column('negative', sa.Integer(), nullable=False, default=0),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], ),
        sa.ForeignKeyConstraint(['tag_id'], ['skill_tags.id'], ),
        sa.PrimaryKeyConstraint('supplier_id', 'tag_id'),
        sa.UniqueConstraint('supplier_id', 'tag_id')
    )


def downgrade():
    op.drop_table('skills')

    op.drop_index(op.f('ix_votes_tag_id'), table_name='votes')
    op.drop_index(op.f('ix_votes_endorsement_id'), table_name='votes')
    op.drop_table('votes')

    op.drop_index(op.f('ix_skill_tags_name'), table_name='skill_tags')
    op.drop_table('skill_tags')
