"""initial migration

Revision ID: 4f9581c50e5f
Revises: None
Create Date: 2015-04-07 23:38:49.609728

"""

# revision identifiers, used by Alembic.
revision = '4f9581c50e5f'
down_revision = None

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table(
        'suppliers',
        sa.Column('id', sa.Integer, nullable=False, primary_key=True),
        sa.Column('email', sa.String(length=255), nullable=False, index=True),
        sa.Column('organisation_id', sa.Integer, nullable=False, index=True),
    )


def downgrade():
    op.drop_table('suppliers')
