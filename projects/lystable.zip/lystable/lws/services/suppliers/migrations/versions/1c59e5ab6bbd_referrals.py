"""referrals

Revision ID: 1c59e5ab6bbd
Revises: 108934a3435a
Create Date: 2015-04-17 16:26:37.589750

"""

# revision identifiers, used by Alembic.
revision = '1c59e5ab6bbd'
down_revision = '108934a3435a'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table('referrals',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
        sa.Column('referred_by', sa.Integer(), nullable=False),
        sa.Column('supplier_id', sa.Integer(), nullable=False, index=True),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], ),
    )


def downgrade():
    op.drop_table('referrals')
