"""rename to team

Revision ID: 1c36f4888d5
Revises: 56ee0d40956
Create Date: 2015-06-30 21:38:44.370197

"""

# revision identifiers, used by Alembic.
revision = '1c36f4888d5'
down_revision = '56ee0d40956'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.drop_constraint('supplier_profiles_supplier_id_organisation_id_key', 'supplier_profiles', type_='unique')
    op.alter_column('supplier_profiles', 'organisation_id', new_column_name='team_id')
    op.create_unique_constraint('supplier_profiles_supplier_id_team_id_key', 'supplier_profiles', ['supplier_id', 'team_id'])

    op.drop_constraint('user_connections_connection_source_user_id_organisation_id_key', 'user_connections', type_='unique')
    op.alter_column('user_connections', 'organisation_id', new_column_name='team_id')
    op.create_unique_constraint('user_connections_connection_source_user_id_team_id_key', 'user_connections', ['connection_source', 'user_id', 'team_id'])


def downgrade():
    op.drop_constraint('supplier_profiles_supplier_id_team_id_key', 'supplier_profiles', type_='unique')
    op.alter_column('supplier_profiles', 'team_id', new_column_name='organisation_id')
    op.create_unique_constraint('supplier_profiles_supplier_id_organisation_id_key', 'supplier_profiles', ['supplier_id', 'organisation_id'])

    op.drop_constraint('user_connections_connection_source_user_id_team_id_key', 'user_connections', type_='unique')
    op.alter_column('user_connections', 'team_id', new_column_name='organisation_id')
    op.create_unique_constraint('user_connections_connection_source_user_id_organisation_id_key', 'user_connections', ['connection_source', 'user_id', 'organisation_id'])
