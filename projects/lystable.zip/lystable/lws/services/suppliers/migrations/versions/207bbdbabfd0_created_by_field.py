"""created_by field

Revision ID: 207bbdbabfd0
Revises: 1c59e5ab6bbd
Create Date: 2015-04-17 17:55:45.048199

"""

# revision identifiers, used by Alembic.
revision = '207bbdbabfd0'
down_revision = '1c59e5ab6bbd'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.alter_column('endorsements', 'recorded_at', new_column_name='created_at')
    op.add_column('referrals', sa.Column('created_at', sa.DateTime(),
                                         nullable=False))
    op.create_index('ix_referrals_referred_by', 'referrals', ['referred_by'],
                    unique=False)


def downgrade():
    op.alter_column('endorsements', 'created_at', new_column_name='recorded_at')
    op.drop_column('referrals', 'created_at')
    op.drop_index('ix_referrals_referred_by', table_name='referrals')
