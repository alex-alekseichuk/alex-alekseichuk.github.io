"""Add UserConnection

Revision ID: 56ee0d40956
Revises: 3ced4bc5247
Create Date: 2015-06-26 14:10:31.606625

"""

# revision identifiers, used by Alembic.
revision = '56ee0d40956'
down_revision = '3ced4bc5247'

from alembic import op
import sqlalchemy as sa
from lws.core.db.types import CrossServiceForeignKey as CSFK
from lws.services.suppliers.models import ConnectionSources


def upgrade():
    op.create_table(
        'user_connections',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False),
        sa.Column(
            'connection_source',
            sa.dialects.postgresql.ENUM(
                *ConnectionSources.values(), name='connection_source'
            ),
            nullable=False,
        ),
        sa.Column(
            'user_id',
            CSFK('users.User'),
            nullable=False
        ),
        sa.Column(
            'organisation_id',
            CSFK('teams.Team'),
            nullable=False
        ),
        sa.Column('supplier_id', sa.Integer(), nullable=False),
        sa.UniqueConstraint('connection_source', 'user_id', 'organisation_id'),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'])
    )


def downgrade():
    op.drop_table('user_connections')
