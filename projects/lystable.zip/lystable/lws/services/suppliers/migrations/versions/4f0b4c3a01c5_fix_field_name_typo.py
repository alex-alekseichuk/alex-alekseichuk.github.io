"""fix field name typo

Revision ID: 4f0b4c3a01c5
Revises: f3ba05b2701
Create Date: 2015-04-14 20:59:34.041653

"""

# revision identifiers, used by Alembic.
revision = '4f0b4c3a01c5'
down_revision = 'f3ba05b2701'

from alembic import op
import sqlalchemy as sa


def upgrade():
    # add index for FK
    op.create_index(op.f('ix_endorsements_supplier_id'), 'endorsements', ['supplier_id'], unique=False)


def downgrade():
    # drop index for FK
    op.drop_index('ix_endorsements_supplier_id', table_name='endorsements')
