"""create endorsements table

Revision ID: f3ba05b2701
Revises: 4f9581c50e5f
Create Date: 2015-04-13 18:34:25.752340

"""

# revision identifiers, used by Alembic.
revision = 'f3ba05b2701'
down_revision = '4f9581c50e5f'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table('endorsements',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
        sa.Column('created_by', sa.Integer(), nullable=False),
        sa.Column('supplier_id', sa.Integer(), nullable=False),
        sa.Column('comment', sa.Text(), nullable=True),
        sa.Column('positive_experience', sa.Boolean(), nullable=True),
        sa.Column('recorded_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], )
    )


def downgrade():
    op.drop_table('endorsements')
