"""Remove unused column/models and add new ones

Revision ID: 15122997a7f
Revises: 37e521d29f6
Create Date: 2015-06-19 13:56:35.547666

"""

# revision identifiers, used by Alembic.
revision = '15122997a7f'
down_revision = '37e521d29f6'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.drop_table('referrals')

    op.drop_index(op.f('ix_votes_tag_id'), table_name='votes')
    op.drop_index(op.f('ix_votes_endorsement_id'), table_name='votes')
    op.drop_table('votes')

    op.drop_table('endorsements')

    op.drop_index(op.f('ix_skill_tags_name'), table_name='skill_tags')
    op.drop_table('skills')
    op.drop_table('skill_tags')

    # New stuff
    op.add_column('suppliers', sa.Column('created_at', sa.DateTime(),
                                         nullable=False))
    op.add_column('suppliers', sa.Column('name', sa.String()))
    op.alter_column('suppliers', 'email', nullable=True)
    op.drop_column('suppliers', 'organisation_id')

    op.create_table(
        'skills',
        sa.Column('id', sa.Integer, nullable=False, primary_key=True),
        sa.Column('name', sa.String, nullable=False, unique=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
    )

    op.create_table(
        'suppliers_skills',
        sa.Column('id', sa.Integer, nullable=False, primary_key=True),
        sa.Column('supplier_id', sa.Integer, nullable=False, unique=True),
        sa.Column('skill_id', sa.Integer, nullable=False, unique=True),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id']),
        sa.ForeignKeyConstraint(['skill_id'], ['skills.id'])
    )


def downgrade():
    # New stuff
    op.alter_column('suppliers', 'email', nullable=False)
    op.drop_column('suppliers', 'created_at')
    op.drop_column('suppliers', 'name')
    op.add_column(
        'suppliers',
        sa.Column('organisation_id', sa.Integer, nullable=False, index=True)
    )
    op.drop_table('suppliers_skills')
    op.drop_table('skills')

    # Old junk

    op.create_table('endorsements',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
        sa.Column('created_by', sa.Integer(), nullable=False),
        sa.Column('supplier_id', sa.Integer(), nullable=False),
        sa.Column('comment', sa.Text(), nullable=True),
        sa.Column('positive_experience', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], )
    )

    op.create_index(
        op.f('ix_endorsements_supplier_id'),
        'endorsements', ['supplier_id'], unique=False
    )

    op.create_table('skill_tags',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_skill_tags_name'), 'skill_tags', ['name'],
                    unique=True)

    op.create_table('votes',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('endorsement_id', sa.Integer(), nullable=False),
        sa.Column('tag_id', sa.Integer(), nullable=False),
        sa.Column('positive_experience', sa.Boolean(), nullable=False),
        sa.ForeignKeyConstraint(['endorsement_id'], ['endorsements.id'], ),
        sa.ForeignKeyConstraint(['tag_id'], ['skill_tags.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('endorsement_id', 'tag_id')
    )
    op.create_index(op.f('ix_votes_endorsement_id'), 'votes',
                    ['endorsement_id'], unique=False)
    op.create_index(op.f('ix_votes_tag_id'), 'votes', ['tag_id'],
                    unique=False)

    op.create_table('skills',
        sa.Column('supplier_id', sa.Integer(), nullable=False),
        sa.Column('tag_id', sa.Integer(), nullable=False),
        sa.Column('positive', sa.Integer(), nullable=False, default=0),
        sa.Column('negative', sa.Integer(), nullable=False, default=0),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], ),
        sa.ForeignKeyConstraint(['tag_id'], ['skill_tags.id'], ),
        sa.PrimaryKeyConstraint('supplier_id', 'tag_id'),
        sa.UniqueConstraint('supplier_id', 'tag_id')
    )

    op.create_table('referrals',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
        sa.Column('referred_by', sa.Integer(), nullable=False),
        sa.Column('supplier_id', sa.Integer(), nullable=False, index=True),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], ),
        sa.Column('created_at', sa.DateTime(), nullable=False)
    )
    op.create_index('ix_referrals_referred_by', 'referrals', ['referred_by'],
                    unique=False)
