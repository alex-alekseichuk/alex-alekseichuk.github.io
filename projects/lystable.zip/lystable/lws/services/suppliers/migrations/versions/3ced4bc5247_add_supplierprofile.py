"""Add SupplierProfile

Revision ID: 3ced4bc5247
Revises: 15122997a7f
Create Date: 2015-06-23 16:49:06.770854

"""

# revision identifiers, used by Alembic.
revision = '3ced4bc5247'
down_revision = '15122997a7f'

from alembic import op
import sqlalchemy as sa
from lws.core.db.types import CrossServiceForeignKey as CSFK


def upgrade():
    op.add_column(
        'suppliers',
        sa.Column('extra', sa.dialects.postgresql.JSONB)
    )

    op.create_table(
        'supplier_profiles',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False),
        sa.Column('contact_email', sa.String(), index=True),
        sa.Column('contact_name', sa.String()),
        sa.Column('extra', sa.dialects.postgresql.JSONB),
        sa.Column(
            'organisation_id',
            CSFK('team.Team'),
            nullable=False
        ),
        sa.Column('supplier_id', sa.Integer(), nullable=False),
        sa.UniqueConstraint('supplier_id', 'organisation_id'),
        sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'])
    )


def downgrade():
    op.drop_column('suppliers', 'extra')
    op.drop_table('supplier_profiles')
