"""add created_at field

Revision ID: 1ccbd74bfae
Revises: 1c36f4888d5
Create Date: 2015-07-06 12:54:46.717883

"""

# revision identifiers, used by Alembic.
revision = '1ccbd74bfae'
down_revision = '1c36f4888d5'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('suppliers_skills',
                  sa.Column('created_at', sa.DateTime(), nullable=False))


def downgrade():
    op.drop_column('suppliers_skills', 'created_at')
