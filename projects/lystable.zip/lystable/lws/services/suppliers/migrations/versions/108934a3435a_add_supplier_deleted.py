"""add supplier deleted

Revision ID: 108934a3435a
Revises: 1bf750d51e63
Create Date: 2015-04-16 16:24:53.938488

"""

# revision identifiers, used by Alembic.
revision = '108934a3435a'
down_revision = '4f0b4c3a01c5'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import Boolean


def upgrade():
    op.add_column('suppliers', sa.Column('deleted', sa.Boolean(), nullable=False))
    suppliers = table('suppliers',
        column('deleted', Boolean)
    )
    op.execute(suppliers.update().values({'deleted': op.inline_literal('0')}))


def downgrade():
    op.drop_column('suppliers', 'deleted')
