from marshmallow import ValidationError


def not_null(data):
    if not data:
        raise ValidationError('No data provided.')
