from flask import g

from marshmallow import SchemaOpts, Schema, pre_dump, post_dump
from lws.core.exceptions import SchemaError, BadRequest


class ExtraOptionsSchemaOpts(SchemaOpts):

    def __init__(self, meta):
        SchemaOpts.__init__(self, meta)
        self.model = getattr(meta, 'model', None)
        self.many_exclude = getattr(meta, 'many_exclude', None)


class CRUDSchema(Schema):
    """Adds CRUD-like methods to the schema. Also loads options from
    `ExtraOptionsSchemaOpts`.

    Options
    -------
    model:
        A database model that the schema is coupled with
    many_exclude:
        Fields that should not be included when rendering the schema
        using `many=True`

    Example
    -------
    class FooSchema(Schema):
        class Meta:
            model = Model
            many_exclude = ('foo', 'bar')
    """

    OPTIONS_CLASS = ExtraOptionsSchemaOpts

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.model = self.opts.model
        self.opts.single_exclude = self.opts.exclude
        self.original_fields = self.fields.copy()

    @classmethod
    def get_model(cls):
        return getattr(cls.Meta, 'model', None)

    @pre_dump(raw=True)
    def many_excludes(self, data, many):
        if many and self.opts.many_exclude:
            exclude = self.opts.single_exclude + self.opts.many_exclude
        else:
            exclude = self.opts.single_exclude

        self.opts.exclude = exclude

        return data

    @post_dump()
    def reset_fields(self, data):
        self.opts.exclude = self.opts.single_exclude
        self.fields = self.original_fields

        return data

    def create(self, data):
        """Validates and then creates an object from the tied in model.

        Errors are handled elsewhere.
        """

        marshalled = self.load(data)

        if marshalled.errors:
            raise SchemaError(marshalled.errors)

        return self.model(**marshalled.data)

    def update(self, data, ob):
        """Validates and then updates an object from the tied in model.
        """
        marshalled = self.load(data)

        if marshalled.errors:
            raise SchemaError(marshalled.errors)

        for k, v in marshalled.data.items():
            if self.fields.get(k).metadata.get('read_only', False):
                if v != getattr(ob, k):
                    try:
                        session = getattr(g, 'session')
                    except RuntimeError:
                        # We're not in an application context
                        pass
                    else:
                        session.expunge(ob)

                    raise BadRequest(
                        'Cannot update read-only field',
                        paths=['/{}'.format(k)]
                    )

            setattr(ob, k, v)

        return ob

    def delete(self, ob):
        """Deletes an object.

        Override this method for different deletion logic.
        """
        if hasattr(ob, 'delete'):
            ob.delete()
        else:
            g.session.delete(ob)

Schema = CRUDSchema
