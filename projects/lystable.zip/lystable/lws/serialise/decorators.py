import collections
import inspect
from wrapt import decorator

from lws.core.helpers import unpack_payload, is_payload_wrapped
from lws.core.exceptions import ServerError


def marshal_with(schema):
    """Marshals a view function with a given schema.

    Injects a ``schema`` parameter into the decorated function signature
    which is an instance of the specified schema.

    Arguments
    ---------
    schema
        A schema used to marshal data.
    envelope
        Envelope that the processed data gets wrapped in, defaults to
        `data`.

    """

    # Accept both `@marshal_with(MySchema)` and `@marshal_with(MySchema())`
    if inspect.isclass(schema):
        schema = schema()

    @decorator
    def wrapper(wrapped, instance, args, kwargs):
        if getattr(wrapped, '__noschema', None):
            return wrapped(*args, **kwargs)

        payload = wrapped(schema, *args, **kwargs)

        payload, status = unpack_payload(payload)

        # No payload
        if payload is None:
            return None, status

        if is_payload_wrapped(payload):
            data = payload.get('data')
            payload_is_wrapped = True
        else:
            data = payload
            payload_is_wrapped = False

        # No data
        if data is None:
            return payload, status

        # Check if we have a usable iterable, if so, instantiate schema
        # with many=True.
        if (
            isinstance(data, collections.Iterable) and
            not isinstance(data, (dict, str))
        ):
            # We've got many objects
            processed = schema.dump(data, many=True).data
        elif isinstance(data, str):
            # The resource didn't return something we can process.
            raise ServerError
        else:
            # One object to process
            processed = schema.dump(data).data

        if payload_is_wrapped:
            payload['data'] = processed
        else:
            payload = processed
        return payload, status

    setattr(wrapper, '__has_schema', True)
    return wrapper


def noschema(f):
    """Tells a resource view not to wrap the view function's return value
    with a schema.
    """
    setattr(f, '__noschema', True)
    return f
