import logging

from mandrill import Mandrill
from marshmallow import Schema
from nameko.extensions import DependencyProvider
from nameko.events import event_handler

from lws.core.nameko import Event
from lws.core.worker import register_worker
from lws.serialise import fields

log = logging.getLogger(__name__)


MESSAGE_DEFAULTS = {
    'merge_language': 'handlebars',
}


class MandrillAPI(DependencyProvider):
    """ Provides an interface for interacting with mandrill in nameko services.
    """

    def get_dependency(self, worker_ctx):
        mandrill_api_key = self.container.config.get('MANDRILL_API_KEY')

        if mandrill_api_key is None:
            log.error('Unable to send notification. '
                      '`MANDRILL_API_KEY` is not configured')
            return None

        return Mandrill(mandrill_api_key)


class MetaToSchema(Schema):
    email = fields.String(required=True)
    name = fields.String()
    type = fields.Select(choices=('to', 'cc', 'bcc'), default='to')


class MetaAttachmentSchema(Schema):
    type = fields.String(required=True)
    name = fields.String(required=True)
    content = fields.String(required=True)


class MetaSchema(Schema):
    html = fields.String()
    text = fields.String()
    subject = fields.String(required=True)
    from_email = fields.String()
    from_name = fields.String()
    headers = fields.Raw()
    important = fields.Boolean()
    track_opens = fields.Boolean()
    track_clicks = fields.Boolean()
    auto_text = fields.Boolean()
    auto_html = fields.Boolean()
    inline_css = fields.Boolean()
    url_strip_qs = fields.Boolean()
    preserve_recipients = fields.Boolean()
    view_content_link = fields.Boolean()
    bcc_address = fields.String()
    tracking_domain = fields.String()
    signing_domain = fields.String()
    return_path_domain = fields.String()
    merge = fields.Boolean()
    tags = fields.List(fields.String)
    subaccount = fields.String()
    google_analytics_domains = fields.List(fields.String)
    google_analytics_campaign = fields.String()
    attachments = fields.Nested(MetaAttachmentSchema, many=True,
                                allow_null=True)
    images = fields.Nested(MetaAttachmentSchema, many=True, allow_null=True)


class SchemaMixin(object):
    def check_schema(self, to, meta):
        try:
            schema = MetaToSchema()
            to, errors = schema.load(to, many=True)
            if errors:
                raise ValueError("to is incorrect")
        except TypeError:
            raise ValueError("to is incorrect")
        if meta is not None:
            try:
                meta, errors = MetaSchema().load(meta)
                if errors:
                    raise ValueError("meta is incorrect")
            except TypeError:
                raise ValueError("meta is incorrect")
        return to, meta


class Notification(Event, SchemaMixin):
    """ An email notification to dispatch.

    This provides an abstraction layer which the underlying worker will
    format correctly before dispatching to our email provider.

    Parameters
    ----------
    template_name : str
        The name of the notification template to send.
    to : list
        A list of addresses to send this notification to structured with the
        keys: `email`, `name` and `type` (one of [to, cc, bcc]).
        Only `email` is required for each recipient.
    context : dict
        The data accessible to the template for rendering. This data will
        undergo no further processing so ensure everything within it is
        fully rendered and serialisable.
    template_content : dict (optional)
        Structured blocks of content to be rendered into the target template.
        This differs from `context` which should primarily be variables
        to be used in the rendering of content defined within the template.
    meta : dict (optional)
        Data to describe the email being sent. This dictionary will be sent
        through to the email provider where possible.
    send_at : iso-formatted datetime
        If provided, the notification will be sent at the specified time
        instead of immediately.

    """

    type = 'notification'

    def __init__(self, template_name, to, context,
                 template_content=None, meta=None, send_at=None):
        to, meta = self.check_schema(to, meta)
        super(Notification, self).__init__({
            'template_name': template_name,
            'to': to,
            'context': context,
            'template_content': template_content,
            'meta': meta,
            'send_at': send_at,
        })


class TextNotification(Event, SchemaMixin):
    """ A text email notification to dispatch.

    This provides an abstraction layer which the underlying worker will
    format correctly before dispatching to our email provider.

    Parameters
    ----------
    text : str
        The plain text content of the email.
    to : list
        A list of addresses to send this notification to structured with the
        keys: `email`, `name` and `type` (one of [to, cc, bcc]).
        Only `email` is required for each recipient.
    html : str (optional)
        The HTML version of the email content.
    meta : dict (optional)
        Data to describe the email being sent. This dictionary will be sent
        through to the email provider where possible.
    send_at : iso-formatted datetime
        If provided, the notification will be sent at the specified time
        instead of immediately.

    """

    type = 'text_notification'

    def __init__(self, text, to, html=None, meta=None, send_at=None):
        to, meta = self.check_schema(to, meta)
        super(TextNotification, self).__init__({
            'text': text,
            'html': html,
            'to': to,
            'meta': meta,
            'send_at': send_at,
        })


class MailWorker(object):
    name = 'mail'

    mandrill = MandrillAPI()

    @event_handler('services', Notification.type, reliable_delivery=True)
    def send_notification(self, event_data):
        """ Sends HTML notifications through Mandrill

        See the `Parameters` section in the following link for more detail:
        https://mandrillapp.com/api/docs/messages.python.html#method=send-template

        """

        template_name = event_data['template_name']
        template_content = event_data['template_content']
        to = event_data['to']
        meta = event_data.get('meta') or {}
        context = event_data['context']
        send_at = event_data['send_at']

        message = MESSAGE_DEFAULTS.copy()
        message.update(meta)

        message['to'] = to
        message['global_merge_vars'] = context

        self.mandrill.messages.send_template(
            template_name=template_name,
            # required for mandrill
            template_content=template_content or [],
            message=message,
            async=False,
            send_at=send_at,
        )

    @event_handler('services', TextNotification.type, reliable_delivery=True)
    def send_text_notification(self, event_data):
        """ Sends text notifications through Mandrill

        See the `Parameters` section in the following link for more detail:
        https://mandrillapp.com/api/docs/messages.python.html#method=send

        """

        text = event_data['text']
        html = event_data['html']
        to = event_data['to']
        meta = event_data.get('meta') or {}
        send_at = event_data['send_at']

        message = MESSAGE_DEFAULTS.copy()
        message.update(meta)

        message['text'] = text
        message['to'] = to

        if html:
            message['html'] = html

        self.mandrill.messages.send(
            message=message,
            async=False,
            send_at=send_at,
        )

register_worker(MailWorker)
