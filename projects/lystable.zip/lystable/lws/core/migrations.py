from os.path import dirname, join

from alembic import config

from .app import app
from .db import DB_URI_KEY


class AlembicConfig(config.Config):
    """ Subclass to allow us to use alembic across multiple services
    without requiring multiple (manually edited) alembic.ini configs
    """
    def __init__(self, service_name):
        super(AlembicConfig, self).__init__()

        self.set_main_option("sqlalchemy.url", app.config[DB_URI_KEY])

        version_table = 'alembic_{}_version'.format(service_name)
        self.set_main_option("version_table", version_table)

        base_path = dirname(dirname(__file__))
        script_location = join(
            base_path, 'services', service_name, 'migrations')
        self.set_main_option('script_location', script_location)

        # we should not need the file name, but alembic doesn't work
        # correctly without it
        self.config_file_name = 'must-be-set-due-to-alembic-bug'

    def get_template_directory(self):
        return join(dirname(__file__), 'alembic_template')
