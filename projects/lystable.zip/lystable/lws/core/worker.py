import pkgutil


class RegistrationError(Exception):
    pass


registered_workers = dict()


def register_worker(worker):
    worker_name = worker.name

    if worker_name in registered_workers:
        raise RegistrationError(
            'worker already registered with the name '
            '`{}`'.format(worker_name))

    registered_workers[worker_name] = worker


def unregister_worker(worker_name):
    if worker_name not in registered_workers:
        raise RegistrationError(
            'No worker registered with the name `{}`'.format(worker_name))

    del registered_workers[worker_name]


def discover_workers():
    from lws import workers

    def bubble_onerror(mod):
        """ Standard behaviour for `walk_packages` is to silence
        exceptions raised during discovery. We want to raise them instead
        """
        raise

    for _, name, ispkg in pkgutil.walk_packages(
        workers.__path__,
        workers.__name__ + '.',
        onerror=bubble_onerror,
    ):
        should_import = not name.startswith('_')
        if not ispkg and should_import:
            __import__(name)
