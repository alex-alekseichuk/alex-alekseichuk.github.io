"""
lws.core.cors
=============

CORS handling for the API. Inspired by Flask-CORS but implemented here
to handle services better, and enable hooks for self-documenting OPTIONS
responses.
"""

from flask import current_app, request

from lws.core.exceptions import ImproperlyConfigured, BadRequest
from lws.core.helpers import make_response

# Header names
ACL_ORIGIN = 'Access-Control-Allow-Origin'
ACL_HEADERS = 'Access-Control-Allow-Headers'
ACL_METHODS = 'Access-Control-Allow-Methods'
ACL_EXPOSE_HEADERS = 'Access-Control-Expose-Headers'
ACL_AGE = 'Access-Control-Max-Age'

# Configuration
AGE = 3600  # Cache for one hour
ALLOWED_HEADERS = [
    'Content-Type',
    'Authorization'
]
EXPOSE_HEADERS = [
    'Authorization'
]


def request_origins():
    """Returns a set of valid origins for the application. These must be
    set in the application configuration with the ``CORS_ORIGIN`` flag.

    Example
    -------
        >>> from lws.core.cors import request_origins
        >>> from flask import current_app
        >>> current_app.config['CORS_ORIGINS'] = ['*']
        >>> with current_app.app_context():
            print(request_origins())
        ['*']

    Returns
    -------
    list
        List of valid origins.
    """

    origins = current_app.config.get('CORS_ORIGINS', None)
    if not origins:
        raise ImproperlyConfigured('The CORS_ORIGINS configuration variable '
                                   'must be set.')

    return origins.split(',')


def cross_origin_response(response, preflight=False):
    """Applies cross-origin support to any response.

    This does not support the entire CORS specification, only the bits we need.

    Returns
    -------
    flask.wrappers.Response
        a Flask response object
    """

    valid_origins = request_origins()
    wildcard = True if '*' in valid_origins else False

    if 'Origin' not in request.headers:
        # Lack of Origin header means CORS shouldn't be processed
        return response

    origin = request.headers.get('Origin', None)

    # If there is no match, just return the response.
    if not wildcard and origin not in valid_origins:
        return response

    # Set the response as either wildcard or the incoming origin header
    if wildcard:
        response.headers[ACL_ORIGIN] = '*'
    else:
        response.headers[ACL_ORIGIN] = origin

    if preflight:
        # Get the allowed methods from the URL rule
        response.headers[ACL_METHODS] = ', '.join(
            sorted(request.url_rule.methods)
        )

        # Get allowed headers
        response.headers[ACL_HEADERS] = ', '.join(ALLOWED_HEADERS)

        # The client can cache the CORS part of the response for the given age
        response.headers[ACL_AGE] = AGE

    else:
        # Get the expose headers
        response.headers[ACL_EXPOSE_HEADERS] = ', '.join(EXPOSE_HEADERS)

    return response


def setup_cors(app):

    @app.before_request
    def cors_request():

        # Save flag in the environment of request
        # because custom request attributes don't survive on request patching
        # during internal calls by ServiceProxy
        request.environ['preflight'] = False

        if request.method == 'OPTIONS':
            # This is a preflight request
            if 'Origin' not in request.headers:
                raise BadRequest('Origin header not set for OPTIONS request')
            else:
                request.environ['preflight'] = True
                return make_response()

    @app.after_request
    def apply_cross_origin_response(response):
        return cross_origin_response(
            response, request.environ.get('preflight'))
