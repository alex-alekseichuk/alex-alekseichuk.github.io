import jwt

from flask import request, current_app

from lws.core.exceptions import BadRequest, Unauthorized

from .perms import check_perms


def auth_check(view_func):
    request.auth_data = auth_data = getattr(request, 'auth_data', None)

    header = request.headers.get('Authorization')
    if header is None:
        check_perms(view_func, auth_data=auth_data)
        return

    try:
        bearer, token = header.split()
        assert bearer.lower() == 'bearer'
    except (AssertionError, ValueError):
        # malformed auth header
        raise BadRequest

    try:
        auth_data = jwt.decode(token, current_app.config['JWT_KEY'])
    except jwt.ExpiredSignatureError:
        raise Unauthorized

    request.auth_data = auth_data

    check_perms(view_func, auth_data)
