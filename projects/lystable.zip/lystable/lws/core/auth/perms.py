from lws.core.exceptions import Forbidden
# N.B. This pattern should be considered a prototype to be
#      re-evaluated when necessary


def is_authenticated(auth_data):
    return (
        auth_data and
        auth_data.get('user_id') is not None
    )


def is_in_team(auth_data):
    return (
        auth_data and
        auth_data.get('team_id') is not None
    )


def is_owner(auth_data):
    return (
        auth_data and
        auth_data.get('team_id') is not None and
        auth_data.get('user_level') == 'OWNER'
    )


# we want some security by default
DEFAULT_CHECKERS = (is_authenticated, )


def check_perms(view_func, auth_data):
    check_funcs = getattr(view_func, '__perm_checkers', DEFAULT_CHECKERS)

    for func in check_funcs:
        if not func(auth_data):
            raise Forbidden


def checkers(*funcs):
    def wrapper(view_func):
        setattr(view_func, '__perm_checkers', set(funcs))
        return view_func

    return wrapper
