from flask import request
from werkzeug.exceptions import NotFound

from lws.core.app import app
from .utils import auth_check


@app.before_request
def standalone_view_auth_check():
    try:
        view_func = app.view_functions[request.endpoint]
    except KeyError:
        raise NotFound

    # Defer to service class
    if getattr(view_func, 'in_service', False):
        return
    else:
        auth_check(view_func)
