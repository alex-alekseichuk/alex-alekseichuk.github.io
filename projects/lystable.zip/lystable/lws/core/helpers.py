from flask import make_response as flask_make_response, jsonify


def is_payload_wrapped(payload):
    return type(payload) is dict and payload.get('data') is not None


def unpack_payload(payload):
    """Unpacks a payload tuple with a status code to separate items."""
    if payload is None:
        return None, 204
    if type(payload) is tuple:
        payload, status = payload
    else:
        status = 200
    return payload, status


def make_response(data=None, errors=None, links=None,
                  meta=None, status=200):
    """Makes a standard LWS API response."""

    payload = {
        'data': data,
        'errors': errors,
        'links': links,
        'meta': meta,
    }

    payload = {k: v for k, v in payload.items() if v}

    response = flask_make_response(jsonify(payload), status)

    return response
