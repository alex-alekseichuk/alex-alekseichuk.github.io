import inspect

from flask.views import http_method_funcs
from flask import request

from ..auth import perms
from ..auth.utils import auth_check

from .views import BaseView
from .decorators import route
from ..helpers import make_response, unpack_payload, is_payload_wrapped
from ..exceptions import MethodNotAllowed, Unauthorized


class ServiceType(type):

    def __new__(mcs, name, bases, attrs):
        # Set the ping function on the class being created if it's not
        # defined already.
        if not attrs.get('ping'):
            service_base_class = [
                base for base in bases if base.__name__ is 'Service'
            ][0]
            attrs['ping'] = service_base_class.ping
        new_class = type.__new__(mcs, name, bases, attrs)

        return new_class


class Service(metaclass=ServiceType):

    #: Default permissions checkers for the service
    permission_checkers = perms.DEFAULT_CHECKERS

    _methods = http_method_funcs

    def dispatch_request(self, view_class=None, *args, **kwargs):
        """ Gathers the appropriate view function and creates a response.
        """
        if not view_class:
            view_class = self.__class__

        endpoint = request.endpoint.split('.')[-1]
        method = request.method.lower()
        internal_request = getattr(request, 'is_internal', False)

        # Dispatcher for views directly on the service class
        if self.__class__ == view_class:
            func = getattr(self, endpoint)
            func_method = getattr(func, '__method')

            if func_method != method:
                raise MethodNotAllowed

        # Defer to the view class for dispatching
        else:
            func = view_class().dispatch_request(*args, **kwargs)

        # Check whether we're calling a private API from a service proxy
        # N.B. This differs from standard permission checking as it doesn't
        #      rely on the auth_data of the user
        if getattr(func, '__internal', False) and not internal_request:
            raise Unauthorized

        # Check permissions on view function
        if not hasattr(func, '__perm_checkers'):
            setattr(func.__func__, '__perm_checkers', self.permission_checkers)

        auth_check(func)

        # Get data from view function and create a response
        payload = func(*args, **kwargs)

        payload, status = unpack_payload(payload)
        if is_payload_wrapped(payload):
            return make_response(data=payload.get('data'),
                                 meta=payload.get('meta'),
                                 links=payload.get('links'),
                                 status=status)
        else:
            return make_response(data=payload, status=status)

    @classmethod
    def as_view(cls, endpoint, rule, func, real_view_class,
                *class_args, **class_kwargs):
        """Wraps the view function in a method that runs the dispatcher on
        the service class instead of running the view function directly.

        Mostly copied from flask.views.View. Thanks, Armin.
        """
        def view(*args, **kwargs):
            self = view.view_class(*class_args, **class_kwargs)
            return self.dispatch_request(view.real_view_class, *args, **kwargs)

        view.view_class = cls
        view.real_view_class = real_view_class
        view.rule = rule
        view.in_service = True

        view.__name__ = endpoint
        view.__doc__ = cls.__doc__
        view.__module__ = cls.__module__
        view.methods = cls._methods

        return view

    @classmethod
    def view_functions(cls):
        """Iterate on the mounted views and find all view functions"""
        cache = getattr(cls, '__view_function_cache__', None)
        if not cache:
            cache = {}

            for name, attr in cls.__dict__.items():
                # If it's a view class, get the result of `view_functions` on
                # the view
                if inspect.isclass(attr) and issubclass(attr, BaseView):
                    cache[name] = attr.view_functions()
                # If it's a function, check if it has the @route decorator
                elif (
                    inspect.isfunction(attr) and
                    getattr(attr, '__method', None)
                ):
                    cache[name] = attr

            cls.__view_function_cache__ = cache

        return cache

    @classmethod
    def construct_rules(cls, recipient):
        """Build the rules for the service and any attached views."""
        rules = []

        view_functions = cls.view_functions()

        for name, attr in view_functions.items():
            if type(attr) is dict:
                # Defer construction to the view class
                for func_name, func in attr.items():
                    view_class = getattr(cls, name)
                    endpoint, rule, base_rule_added = \
                        view_class.construct_rule(func_name)

                    if not name == 'root':
                        endpoint = '{}.{}'.format(name, endpoint)

                        if rule:
                            if not base_rule_added:
                                rule = '{}/{}'.format(name, rule)
                        else:
                            rule = name

                    rules.append((endpoint, rule, func, view_class))
            else:
                # View function is directly on the service class
                endpoint = name
                rule = getattr(attr, '__rule', None) or name

                rules.append((endpoint, rule, attr, cls))

        return rules

    @classmethod
    def register_on(cls, recipient):
        """Register routes on the given application or blueprint."""

        cls.app_or_blueprint = recipient
        cls.name = recipient.name

        rules = cls.construct_rules(recipient)

        added_endpoints = []

        for endpoint, rule, func, view_class in set(rules):
            if endpoint in added_endpoints:
                continue

            if not rule.endswith('/'):
                rule = rule + '/'
            if not rule.startswith('/'):
                rule = '/' + rule

            view = cls.as_view(endpoint, rule, func, view_class)

            recipient.add_url_rule(rule, view_func=view)

            added_endpoints.append(endpoint)

        return cls

    @route(rule='ping', method='get')
    @perms.checkers()
    def ping(self):
        """Ping the service.

        Returns
        -------
        str
            'pong'
        """
        return 'pong'
