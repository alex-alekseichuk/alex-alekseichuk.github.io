import inspect

from flask import request

from lws.core.exceptions import MethodNotAllowed, NotFound
from lws.core.service.decorators import paging
from lws.serialise.decorators import marshal_with

# `base_methods` are methods that get used with a route
# that does not include an identifier.
# `id_methods` will be used with an id.
base_methods = ['index', 'post']
id_methods = ['get', 'delete', 'put', 'patch']


class BaseView():

    base_rule = None

    @classmethod
    def mount(cls, rule):
        cls.base_rule = rule
        return cls

    def dispatch_request(self, *args, **kwargs):
        raise NotImplementedError()

    @classmethod
    def endpoint_from_func(cls, name):
        raise NotImplementedError()

    @classmethod
    def construct_rule(cls, name):
        raise NotImplementedError()


class ResourceView(BaseView):
    """Resource view for services.
    """

    #: Default schema to use with all endpoints
    schema = None

    def dispatch_request(self, *args, **kwargs):
        """Dispatches the request to the correct endpoint."""
        endpoint = request.endpoint.split('.')[-1]
        method = request.method.lower()

        func = None

        # Dispatch to `index` function to list or `post` to create
        if endpoint == 'index':
            if method == 'get':
                func = getattr(self, "index", None)
                func = paging()(func)
            elif method == 'post':
                func = getattr(self, "post", None)
            else:
                raise MethodNotAllowed
        # Dispatch to a view function that manipulates a single resource
        elif endpoint == 'object':
            func = getattr(self, method, None)

            # Alias PUT and PATCH if one or the other does not exist
            if not func:
                # TODO: refactoring? patch --> put
                alias_methods = ['put', 'patch']
                if method in alias_methods:
                    func = getattr(
                        self,
                        alias_methods[alias_methods.index(method) - 1],
                        None)

            if not func:
                raise MethodNotAllowed
        # Dispatch to a custom view function
        else:
            func = getattr(self, endpoint, None)
            func_method = getattr(func, '__method', None)

            if func and func_method:
                # We have a view
                if method != func_method:
                    raise MethodNotAllowed

        if not func:
            raise NotFound

        if self.schema:
            func = marshal_with(self.schema)(func)

        return func

    @classmethod
    def construct_rule(cls, name):
        """Constructs a rule for the service this view is mounted on."""

        if name in base_methods:
            endpoint = 'index'
            rule = ''
        elif name in id_methods:
            endpoint = 'object'
            rule = '<int:id>'
        else:
            endpoint = name
            func = getattr(cls, name, None)
            func_rule = getattr(func, '__rule', None)
            if func_rule:
                rule = func_rule
            else:
                rule = name

        if cls.base_rule:
            if rule:
                rule = '{}/{}'.format(cls.base_rule, rule)
            else:
                rule = cls.base_rule

        return endpoint, rule, bool(cls.base_rule)

    @classmethod
    def view_functions(cls):
        """List all view functions on the class."""

        # Return any function named for a http method, or that uses
        # the @route decorator
        funcs = {
            k: v for k, v in cls.__dict__.items()
            if inspect.isfunction(v) and
            (getattr(v, '__method', None) or k in base_methods + id_methods)
        }

        return funcs
