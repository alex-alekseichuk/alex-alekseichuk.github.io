import base64
import pkgutil
import re

from contextlib import contextmanager
from copy import copy
from flask import current_app, json, request, url_for

from lws.core.exceptions import (
    BadRequest, ImproperlyConfigured, ConfigurationError)

from .views import base_methods, id_methods


class ServiceRegistrationError(Exception):
    pass


registered_services = dict()


def _inspect_uniqueness_of_rules(rules, service, base_rule):
    for attr_name in [attr for attr in dir(service) if (
            not attr.startswith('_') and attr != 'dispatch_request')]:
        attr = getattr(service, attr_name, None)
        if attr.__class__.__name__ == 'function':
            if not getattr(attr, '__rule', None):
                continue
            original_rule = base_rule + '/' + getattr(attr, '__rule')
            rule = original_rule.replace('/', '')
            if rule in rules:
                if attr.__method in rules[rule]:
                    raise ImproperlyConfigured(
                        'Function `{a}` is being routed to a rule that is '
                        'already taken:\n\tHTTP method: {m}, \'{r}\''.format(
                            a=attr_name, m=attr.__method, r=original_rule))
            else:
                rules[rule] = list()
            rules[rule].append(attr.__method)

rules = dict()


def register_service(service):
    blueprint = service.app_or_blueprint

    service_name = blueprint.name

    if service_name in registered_services:
        raise ServiceRegistrationError(
            'Service already registered with the name '
            '`{}`'.format(service_name))

    base_rule = service_name
    if service_name != 'test':
        _inspect_uniqueness_of_rules(rules, service, base_rule)
        for attr_name in [at for at in dir(service) if not at.startswith('_')]:
            attr = getattr(service, attr_name, None)
            if attr.__class__.__name__ in ['type']:
                _inspect_uniqueness_of_rules(
                    rules, attr, str(base_rule) + '/' + str(attr.base_rule))

    registered_services[service_name] = service


def unregister_service(service_name):
    if service_name not in registered_services:
        raise ServiceRegistrationError(
            'No service registered with the name `{}`'.format(service_name))

    del registered_services[service_name]


def discover_services():
    from lws import services

    def bubble_onerror(mod):
        """ Standard behaviour for `walk_packages` is to silence
        exceptions raised during discovery. We want to raise them instead
        """
        raise

    for _, name, ispkg in pkgutil.walk_packages(
        services.__path__,
        services.__name__ + '.',
        onerror=bubble_onerror,
    ):
        should_import = re.search('.service', name)
        if not ispkg and should_import:
            __import__(name)


class ServiceProxy(object):
    """Provides an interface for calling other services.

    Usage
    -----

        from lws.core.service import ServiceProxy

        my_service = ServiceProxy('my_service')

    Then, from within a request context (customised with
    `request_overrides` if necessary)::

        # calls the index view on the `root` resource
        my_service.index()

        # calls the `resource` resource
        my_service.resource.index()

        # calls the view with arguments
        my_service.resource.get(id=1)

        # calls an api which isn't exposed over http
        my_service.private_api()

    Requests are made with a modified request context which inherits
    as much from the current request context as can be reasonably
    extracted.

    Note
    ----
        Calls to ResourceView based classes will override the
        request method in order to be correctly routed by the
        framework.

    Warning
    -------
        This implementation is still very tightly coupled requiring
        all services to be configured on the `app` being served as
        the view function is looked up in the registry and called
        directly.

        In the not-so-distant future we will want to remedy this by
        having an implementation which enforces a stricter separation
        of services. This utility is intended to provide a layer of
        abstraction behind which we can perform future refactors
        without affecting existing service code.

    """

    def __init__(self, service_name, target=None):
        self.service_name = service_name
        self.target = target or service_name

    def __getattr__(self, name):
        target = '{}.{}'.format(self.target, name)
        return ServiceProxy(self.service_name, target)

    def _get_endpoint(self):
        path, name = self.target.rsplit('.', 1)

        if name in base_methods:
            name = 'index'
        elif name in id_methods:
            name = 'object'

        return '{}.{}'.format(path, name)

    def __call__(self, **kwargs):
        endpoint = self._get_endpoint()
        path, name = self.target.rsplit('.', 1)

        if name == 'index':
            # reserved keyword to differentiate between GET methods
            # with and without the `id` param
            method = 'get'
        elif name in (base_methods + id_methods):
            # handle remaining RESTful API endpoints
            method = name
        else:
            # defer to the method of the parent request context if
            # it's not a restful resource
            method = request.method

        data = copy(request.data)
        auth_data = copy(request.auth_data)

        view = current_app.view_functions[endpoint]

        # Do the call with a simulated request so that it's accessible
        # within the view
        environ = request.environ.copy()
        environ.pop('werkzeug.request', None)
        environ.update({
            'CONTENT_TYPE': 'application/json',
            'PATH_INFO': url_for(endpoint, **kwargs),
            'REQUEST_METHOD': method,
        })
        with current_app.request_context(environ):
            request.data = data
            request.auth_data = auth_data
            request.is_internal = True
            res = view(**kwargs)

        res = json.loads(res.data)
        return res


@contextmanager
def request_overrides(*, data=None, auth_data=None, method=None):
    """ Provides overrides for when using a service proxy

    Usage::

        with request_overrides(data=data):
            proxy.some_api(name=1)
    """
    if data is None:
        data = request.data
    else:
        data = json.dumps(data)

    if auth_data is None:
        auth_data = getattr(request, 'auth_data', None)

    if method is None:
        method = request.method

    environ = request.environ.copy()
    environ['REQUEST_METHOD'] = method

    with current_app.request_context(environ):
        request.data = data
        request.auth_data = auth_data
        yield


def request_json():
    """ Returns the deserialized JSON data passed in the body of the request.

    If the body of the request is not valid JSON, raise a BadRequest exception
    to close out the request.
    """
    if not request.data:
        return {}
    try:
        return json.loads(request.data)
    except ValueError:
        raise BadRequest


def encode(content):
    return base64.b64encode(content).decode()


def decode(content):
    return base64.b64decode(content)


def client_url(url_template, **kwargs):
    """ Generate specific URL

    Returns
    -------
    str
        Absolute URL

    Raises
    ------
    ConfigurationError
        If BASE_CLIENT_URL is not set up.

    """
    base_url = current_app.config.get('BASE_CLIENT_URL')
    if base_url is None:
        raise ConfigurationError
    return base_url + url_template.format(**kwargs)
