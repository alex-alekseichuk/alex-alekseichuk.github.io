import logging

from flask import g, request
from sqlalchemy import create_engine, Column, Boolean, DateTime
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import (
    scoped_session, sessionmaker, object_mapper, ColumnProperty
)
import datetime

from lws.core.exceptions import BadRequest

log = logging.getLogger(__name__)

DB_URI_KEY = 'DB_URI'


class ModelBase(object):

    def to_dict(self, exclude_keys=()):
        """ TODO: Remove after services are converted to using
            Marshmallow/Schema
        """
        mapper = object_mapper(self)
        return {
            col.key: getattr(self, col.key)
            for col in mapper.iterate_properties
            if isinstance(col, ColumnProperty) and col.key not in exclude_keys
        }

    created_at = Column(
        DateTime,
        default=datetime.datetime.now,
        nullable=False
    )


Base = declarative_base(cls=ModelBase)

session_factory = sessionmaker(autocommit=False, autoflush=False)


def get_engine(db_uri):
    if db_uri not in get_engine.mapping:
        get_engine.mapping[db_uri] = create_engine(
            db_uri, convert_unicode=True, client_encoding='utf8')

    return get_engine.mapping[db_uri]

get_engine.mapping = {}


def configure_db(app):
    """ Connects to the database and attaches a session to the `g`
    object during the request lifecycle.

    This utility also schedules the necessary tidyup (namely closing
    the connections and removing the scoped session) to be performed
    at the end of the application lifecycle.
    """

    engine = get_engine(app.config[DB_URI_KEY])
    get_session = scoped_session(session_factory)
    get_session.configure(bind=engine)

    @app.before_request
    def attach_session():
        g.session = get_session()

    @app.teardown_request
    def rollback_and_warn(exception):
        session = getattr(g, 'session', None)
        if session is not None and session.dirty:
            log.warn('Request to {} completed with dirty session: {!r}'.format(
                request.url, session.dirty))

            session.rollback()

    @app.teardown_appcontext
    def shutdown_session(exception=None):
        # tears down any active sessions
        get_session.remove()


def get_session():
    session = getattr(g, 'session', None)

    if session is None:
        raise LookupError(
            'No session available. Ensure you\'ve run `configure_db` '
            'and are calling this within a request context.')

    return session


def create_tables(app):
    engine = get_engine(app.config[DB_URI_KEY])

    Base.metadata.create_all(engine)


def reset_tables(session):
    for table in reversed(Base.metadata.sorted_tables):
        session.execute(table.delete())
        session.commit()


def drop_db(connstring, server_engine=None, if_exists=True):
    base, dbname = connstring.rsplit('/', 1)

    # Dispose of the connection pool which may be open on the engine
    # used to connect to the database which may have idle connections
    # held open for reuse. As we're about to drop the database, these
    # connections will need to be re-established regardless.
    db_engine = get_engine(connstring)
    db_engine.dispose()

    if server_engine is None:
        server_engine = get_engine(base)

    drop_string = 'DROP DATABASE '
    if if_exists:
        drop_string = drop_string + 'IF EXISTS '

    with server_engine.connect() as con:
        # get out of the transaction SQLAlchemy automatically gives us
        con.execute("commit")
        con.execute('%s %s' % (drop_string, dbname))


def create_db(connstring, drop_if_exists=True, if_not_exists=False):
    base, dbname = connstring.rsplit('/', 1)
    server_engine = get_engine(base)

    if drop_if_exists:
        drop_db(connstring, server_engine, if_exists=True)

    create_str = 'CREATE DATABASE '

    if if_not_exists:
        create_str += 'IF NOT EXISTS '

    with server_engine.connect() as con:
        # get out of the transaction SQLAlchemy automatically gives us
        con.execute("commit")
        con.execute('{} {}'.format(create_str, dbname))


def commit_or_abort():
    try:
        g.session.commit()
    except SQLAlchemyError:
        g.session.rollback()
        raise BadRequest


class DeletedMixin:
    deleted = Column(Boolean, default=False, nullable=False)

    def delete(self):
        self.deleted = True
