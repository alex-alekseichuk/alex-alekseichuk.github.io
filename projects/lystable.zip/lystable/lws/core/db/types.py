from sqlalchemy.types import TypeDecorator, Integer


class CrossServiceForeignKey(TypeDecorator):
    """Fake foreign key type for objects that belong to another service.

    At the moment, it does nothing but allowing identification of such a key.
    """

    def __init__(self, dotted, *args, **kwargs):
        super().__init__(*args, **kwargs)

        try:
            split = dotted.split('.')
            self.service, self.model = split

            if not self.service or not self.model:
                raise ValueError

        except (IndexError, ValueError):
            raise ValueError('Provide a \'service.Model\' dotted identifier')

    impl = Integer
