import boto
from boto.exception import S3ResponseError
from flask import current_app
from lws.core.exceptions import ServerError


def get_bucket(bucket_name):
    """ Internal function to get reference to bucket.

    Returns
    -------
    boto.file.bucket.Bucket

    Raises
    ------
    ServerError
        If there is not such bucket or credentials are incorrect.

    """
    access_key_id = current_app.config.get('S3_ACCESS_KEY_ID', '')
    secret_access_key = current_app.config.get('S3_SECRET_KEY', '')
    try:
        conn = boto.connect_s3(access_key_id, secret_access_key)
        return conn.get_bucket(bucket_name)
    except S3ResponseError:
        raise ServerError("Can't get bucket {}".format(bucket_name))


def upload_content(bucket_name, path, content):
    """ Upload some file/data to S3 under specified path.

    Parameters
    ----------
    path : str
        Unique path to specified resource in the bucket.
        E.g., pictures/pic-123
    content : bytes
        Content of the file to save.

    """
    bucket = get_bucket(bucket_name)
    key = bucket.new_key(path)
    if key is None:
        raise ServerError("Can't create new S3 key {}".format(path))
    key.set_contents_from_string(content)


def get_url(bucket_name, path, expires_in=120, secure=True):
    """ Generates URL for specified resource.

    Parameters
    ----------
    path : str
        Unique path to specified resource in the bucket.
        E.g., pictures/pic-123
    expires_in : int
        Period of time in seconds of URL's life. After that time the file will
        be unavailable by the URL.
    secure : bool
        Flag to generate HTTPS URL instead of HTTP.

    Returns
    -------
    str
        Url to the file for download or None if there is not such path.

    Raises
    ------
    ServerError
        If there is not such bucket or credentials are incorrect.

    """
    bucket = get_bucket(bucket_name)
    key = bucket.get_key(path)
    if key is None:
        return None
    force_http = not secure
    return key.generate_url(expires_in=expires_in, force_http=force_http)


def delete_key(bucket_name, path):
    """ Deletes key in the bucket by path.

    Parameters
    ----------
    path : str
        Unique path to specified resource in the bucket.
        E.g., pictures/pic-123

    Returns
    -------
    None

    Raises
    ------
    ServerError
        If there is not such bucket or credentials are incorrect.

    """
    bucket = get_bucket(bucket_name)
    key = bucket.get_key(path)
    if key is None:
        return None
    bucket.delete_key(key)
