import logging

# Do not use relative imports in this file
from lws.core.app import app, configure_app
from lws.core.auth import checks  # noqa
from lws.core.db import configure_db


def configure_app_for_serving():
    logging.basicConfig()

    configure_app()
    configure_db(app)

configure_app_for_serving()

application = app
