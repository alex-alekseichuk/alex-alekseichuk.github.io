import yaml

from flask import json
from pkg_resources import require
from smore import swagger

from lws.core.app import app
from lws.core.service.views import base_methods, id_methods


class SwaggerGenerator:
    """Class used to generate API documentation that is compliant with the
    Swagger 2.0 specification.

    The online documentation also contains definitions for the object
    generators in this class.

    See also
    --------
    https://github.com/swagger-api/swagger-spec/blob/master/versions/2.0.md
    """

    def __init__(self, services=None):
        self.result = {}
        self.services = services

        # If the SERVER_NAME environment variable isn't set, the host will
        # not be part of the output definition. The host is not required in
        # Swagger, but it's not optimal to build definitions without it.
        self.host = app.config.get('SERVER_NAME')

    #: API documentation description. Should be oriented towards API consumers.
    description = 'Lystable Web Services API'

    def info(self):
        """Generates a Swagger 2.0 Info object."""
        setup_info = require('lws')[0]

        info = {
            'title': setup_info.project_name,
            'description': self.description,
            'version': setup_info.version
        }

        return info

    def _get_schema(self, view):
        """Uses black magic to find the schema for a view."""
        if getattr(view, '__noschema', None):
            return

        class_name = view.__qualname__.split('.')[0]
        klass = view.__globals__[class_name]
        schema = getattr(klass, 'schema', None)

        if schema:
            required = []
            result = swagger.schema2jsonschema(schema)

            # smore does not generate an entirely valid schema, so we're
            # fixing the `required` attribute here.
            for k, v in result.items():
                if type(v) == dict:
                    for name, field in v.items():
                        req = field.pop('required')
                        if req:
                            required.append(name)

            result['required'] = required
            return result

    def _extract_view_info(
        self,
        view,
        base_path,
        service_name,
        responses=True
    ):
        rule = getattr(view, '__rule', None)
        method = getattr(view, '__method', None)

        if getattr(view, '__internal', None):
            return

        if not rule:
            if view.__name__ in base_methods:
                path = base_path
            elif view.__name__ in id_methods:
                path = '{}{}/'.format(base_path, '<int:id>')

            method = view.__name__
        else:
            path = '{}{}/'.format(base_path, rule)

        if method == 'index':
            method = 'get'

        result = {
            path: {
                method: {
                    'tags': [service_name],
                    'description': view.__doc__,
                    'responses': {
                        'default': {
                            # Description is required but we don't have one.
                            'description': 'Response',
                            'schema': self._get_schema(view)
                        }
                    }
                },
            }
        }

        default = result[path][method]['responses']['default']

        if not default.get('schema'):
            default.pop('schema')

        if not responses:
            result[path][method].pop('responses')

        return result

    @staticmethod
    def _merge_paths(paths):
        """Merges separated paths into one path object.

        For example, there could be several operations under '/service/' that
        need to be merged together in the dictionary.
        """
        merged = {}

        for p in paths:
            path, method = list(p.items())[0]

            if not merged.get(path):
                merged[path] = method
            else:
                k, v = list(method.items())[0]
                merged[path][k] = v

        return merged

    def paths_for_service(self, service, responses=True):
        """Generates a Swagger 2.0 Paths object for a specific service class.

        Returns
        -------
        dict
            A Swagger 2.0 Paths object
        """

        result = []

        view_functions = service.view_functions()
        base_path = '/{}/'.format(service.name)

        for name, view in view_functions.items():
            if type(view) == dict:
                for subview in view.values():
                    if name == 'root':
                        new_base_path = base_path
                    else:
                        new_base_path = '{}{}/'.format(base_path, name)
                    view_info = self._extract_view_info(
                        subview,
                        new_base_path,
                        service.name,
                        responses=responses
                    )

                    if view_info:
                        result.append(view_info)
            else:
                view_info = self._extract_view_info(
                    view,
                    base_path,
                    service.name,
                    responses=responses
                )

                if view_info:
                    result.append(view_info)

        merged_result = self._merge_paths(result)

        return merged_result

    def paths(self):
        """Generates a Swagger 2.0 Paths object.
        """

        paths = {}

        for service in self.services:
            paths.update(self.paths_for_service(service))

        return paths

    def definitions(self):
        """Generates a Swagger 2.0 Definitions object.
        """

    def parameters(self):
        """Generates a Swagger 2.0 Parameters Definitions object.
        """

    def responses(self):
        """Generates a Swagger 2.0 Responses Definitions object.
        """

    def security_defintions(self):
        """Generates a Swagger 2.0 Security Defintions object.
        """

    def security(self):
        """Generates a Swagger 2.0 Security Requirement object.
        """

    def tags(self):
        """Generates a Swagger 2.0 Tag object.
        """

    def external_docs(self):
        """Generates a Swagger 2.0 External Documentation object.
        """

    def generate(self):
        """Generates Swagger 2.0-compliant data.

        Returns
        -------
        dict
            Swagger 2.0 compliant dictionary. Must be converted into JSON
            or YAML.
        """
        definition = {
            'swagger': '2.0',
            'info': self.info(),
            'host': self.host,
            'basePath': '/',
            'schemes': ['https'],
            'consumes': ['application/json', 'application/vnd.api+json'],
            'produces': ['application/json', 'application/vnd.api+json'],
            'paths': self.paths(),
            'definitions': self.definitions(),
            'parameters': self.parameters(),
            'responses': self.responses(),
            'securityDefinitions': self.security_defintions(),
            'security': self.security(),
            'tags': self.tags(),
            'externalDocs': self.external_docs()
        }

        # Remove any empty fields.
        definition = {k: v for k, v in definition.items() if v is not None}

        return definition


class JSONSwaggerGenerator(SwaggerGenerator):
    def generate(self):
        result = super().generate()
        return json.dumps(result, sort_keys=True, indent=2)


class YAMLSwaggerGenerator(SwaggerGenerator):
    def generate(self):
        result = super().generate()
        return yaml.dump(result, default_flow_style=False)
