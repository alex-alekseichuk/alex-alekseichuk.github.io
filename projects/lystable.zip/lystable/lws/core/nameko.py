from __future__ import absolute_import

from nameko.containers import MAX_WORKERS_CONFIG_KEY
from nameko.messaging import AMQP_URI_CONFIG_KEY
from nameko.standalone.events import event_dispatcher
from flask import current_app


def get_nameko_config():
    amqp_uri = current_app.config.get('AMQP_URI')

    if not amqp_uri:
        raise RuntimeError(
            'AMQP_URI must be configured in order to run this worker'
        )

    return {
        AMQP_URI_CONFIG_KEY: amqp_uri,

        # we're not threadsafe, but don't need concurrency, only async
        MAX_WORKERS_CONFIG_KEY: 1,
    }


class Event(object):

    type = NotImplemented
    event_data = NotImplemented

    def __init__(self, data):
        self.event_data = data


def dispatcher(source=None):
    config = get_nameko_config()
    dispatch = event_dispatcher(config)

    def dispatch_event(event, source='services'):
        dispatch(source, event.type, event.event_data)

    return dispatch_event
