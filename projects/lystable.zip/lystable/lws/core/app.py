from flask import Flask
from wrapt import decorator

from .cors import setup_cors
from .exceptions import ServerError
from .service import discover_services, registered_services


def setup_error_handlers(app):

    @app.errorhandler(Exception)
    def uncaught_exception_handler(error):
        message = 'An error occured while processing this request.'
        return ServerError(message).get_response()


def initialise_app():
    app = Flask(__name__)

    discover_services()

    for service_name, service in registered_services.items():
        url_prefix = '/{}'.format(service_name)
        app.register_blueprint(service.app_or_blueprint, url_prefix=url_prefix)

    setup_error_handlers(app)
    setup_cors(app)

    return app


app = initialise_app()


def configure_app():
    app.config.from_envvar('LWS_ENVFILE')


@decorator
def offline_app_context(wrapped, instance, args, kwargs):
    """ Provides the decorated function with a Flask app context.

    Allows offline generation of urls using `url_for` if a `SERVER_NAME`
    was provided as part of the application configuration.

    """
    with app.app_context():
        return wrapped(*args, **kwargs)
