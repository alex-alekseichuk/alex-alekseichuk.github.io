"""
lws.core.exceptions
-------------------

API exceptions for services.

Keep sorted by error code.
"""

from werkzeug.exceptions import HTTPException

from lws.core.helpers import make_response


class ImproperlyConfigured(Exception):
    """Raised when any part of the application is improperly configured."""


class ObjectAlreadyExists(Exception):
    """Raised when an object or several objects already exists when they
    cannot be present."""


class APIException(HTTPException):
    """Generic error class for API exceptions.

    Attempts to follow the `JSON API standard`_ for field names.

    .. _JSON API standard: http://jsonapi.org/format/#errors
    """

    def __init__(self, detail=None, paths=None, *args, **kwargs):
        super(APIException, self).__init__(*args, **kwargs)

        self.detail = detail
        self.paths = paths

    def get_response(self, environ=None):
        """Creates an appropriate response for the exceptions."""
        error = {
            'status': self.status,
            'title': self.title,
            'detail': self.detail,
            'paths': self.paths,
        }

        return make_response(errors=[error], status=self.status)

    @property
    def status(self):
        """The status code of the exception.

        Follows RFC 7231."""
        raise NotImplementedError(
            'The `status` attribute must be defined on exception class.'
        )

    @property
    def title(self):
        """The title of the exception – such as "Not Found" or "Forbidden".

        Follows RFC 7231."""
        raise NotImplementedError(
            'The `title` attribute must be defined on exception class.'
        )

    @property
    def description(self):
        """Overrides `HTTPException`'s description with our title"""
        return self.title

    @property
    def code(self):
        """Overrides `HTTPException`'s code with our status"""
        return self.status


class BadRequest(APIException):
    status = 400
    title = 'Bad Request'


class SchemaError(BadRequest):
    """Takes a Marshmallow error dictionary and turns it into
    an array of errors"""

    def __init__(self, error):
        error_array = []

        for field, details in error.items():
            error_array.append({
                'status': self.status,
                'title': self.title,
                'detail': details[0],
                'paths': ['/{}'.format(field)],
            })

        self.error_array = error_array

    def get_response(self, environ=None):
        return make_response(errors=self.error_array, status=self.status)


class Unauthorized(APIException):
    status = 401
    title = 'Unauthorized'


class Forbidden(APIException):
    status = 403
    title = 'Forbidden'


class NotFound(APIException):
    status = 404
    title = 'Not Found'


class MethodNotAllowed(APIException):
    status = 405
    title = 'Method Not Allowed'


class NotAcceptable(APIException):
    status = 406
    title = 'Not Acceptable'


class Conflict(APIException):
    status = 409
    title = 'Conflict'


class Gone(APIException):
    status = 410
    title = 'Gone'


class ServerError(APIException):
    status = 500
    title = 'Internal Server Error'


class ConfigurationError(APIException):
    status = 500
    title = 'Configuration Server Error'
