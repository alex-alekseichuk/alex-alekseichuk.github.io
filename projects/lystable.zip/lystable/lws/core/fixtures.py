import sys

from flask import json
from sqlalchemy.exc import ProgrammingError

from lws.core.service import Service
from lws.core.app import app
from lws.core import db
from lws.core.exceptions import ObjectAlreadyExists


class FixtureLoader:
    """Loads fixtures from JSON format into the database.

    Use one and only one file per model.

    Example format:

        {
            "model": "users.User",
            "objects": [
                {
                    "id": 1,
                    "email": "react@lystable.com",
                    "password": "password"
                },
                {
                    "id": 2,
                    "email": "test@test.com",
                    "password": "password"
                }
            ]
        }
    """

    def __init__(self, files):
        self.files = files

    def _load_file(self, file, drop_existing):
        with open(file, 'rb') as fixture:
            to_load = json.loads(fixture.read())

        model = to_load['model']
        objects = to_load['objects']

        service = [
            service for service in Service.__subclasses__()
            if service.name == model.split('.')[0]
        ][0]

        module = '.'.join(service.__module__.split('.')[:-1])
        real_model = getattr(sys.modules[module].models, model.split('.')[1])

        uri = app.config.get('DB_URI')
        engine = db.get_engine(uri)
        get_session = db.scoped_session(db.session_factory)
        get_session.configure(bind=engine)

        session = get_session()

        # Try to create the database and ignore if it already exists
        try:
            db.create_db(uri, drop_if_exists=drop_existing)
        except ProgrammingError:
            pass

        db.create_tables(app)

        if session.query(real_model).count():
            raise ObjectAlreadyExists(
                'Cannot insert fixture objects into non-empty table.'
            )

        for ob in objects:
            with app.app_context():
                session.add(real_model(**ob))

        session.commit()
        print(
            'Successfully loaded fixtures for {}'.format(real_model.__name__)
        )

    def load(self, drop_existing):
        for file in self.files:
            self._load_file(file, drop_existing)
