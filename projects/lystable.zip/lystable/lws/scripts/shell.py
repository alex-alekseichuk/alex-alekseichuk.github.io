from lws.utils.console import shell

from lws.core import db
from lws.core.app import app


def main(args):
    db_uri = app.config.get('DB_URI')

    if db_uri:
        engine = db.get_engine(app.config['DB_URI'])
        session = db.scoped_session(db.session_factory)
        session.configure(bind=engine)
    else:
        session = None

    expose = {
        'db': db,
        'session': session,
        'app': app,
    }

    shell('Lystable Web Services', expose=expose)
