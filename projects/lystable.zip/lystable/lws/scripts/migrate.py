import os
import sys

from alembic import config

from lws.core.migrations import AlembicConfig


def main(args):
    """ TODO: move scripting logic out of alembic_wrapper and into here
    """

    service_name = args.unknown_args[0]
    alembic_params = args.unknown_args[1:]

    alembic_cfg = AlembicConfig(service_name)

    script_location = alembic_cfg.get_main_option('script_location')
    if not os.path.isdir(script_location) and alembic_params[0] != 'init':
        sys.stderr.write(
            '{} has no migrations dir; skipping\n'.format(service_name))
        return

    if alembic_params[0] == 'init':
        alembic_params = ['init', script_location]

    cmdline = config.CommandLine()

    options = cmdline.parser.parse_args(alembic_params)

    try:
        cmdline.run_cmd(alembic_cfg, options)
    except UnboundLocalError:
        # we don't have a alembic.ini.mako file in our templates, which
        # causes the init script to bork in its final output telling you
        # to edit that file
        if alembic_params[0] != 'init':
            raise
