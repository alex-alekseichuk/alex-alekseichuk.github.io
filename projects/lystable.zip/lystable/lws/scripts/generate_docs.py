import logging
import warnings

from lws.core.service import Service
from lws.core.docs.swagger import JSONSwaggerGenerator, YAMLSwaggerGenerator


def main(args):
    warnings.simplefilter("ignore")
    logging.getLogger().setLevel(logging.CRITICAL)
    ops = args.unknown_args or []

    json = '--json' in ops or '-j' in ops
    yaml = '--yaml' in ops or '-y' in ops
    help = '--options' in ops or '-o' in ops

    if help:
        print('\t--json or -j: print results dictionary in json format')
        print('\t--yaml or -y: print results dictionary in yaml format')
        return

    if (json and yaml) or (not json and not yaml):
        print('Select one of either json (-j) or yaml (-y) formats')
        return

    services = [
        s for s in Service.__subclasses__()
        if not s.__module__.startswith('test')
    ]

    if json:
        print(JSONSwaggerGenerator(services).generate())

    if yaml:
        print(YAMLSwaggerGenerator(services).generate())
