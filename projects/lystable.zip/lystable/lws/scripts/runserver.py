import os


def main(args):
    """Starts a development server with uwsgi"""
    port = 8000
    app = 'lws.core.wsgi'

    flags = [
        '--workers 1',
        '--http 0.0.0.0:{0}'.format(port),
        '--honour-stdin',
        '--py-autoreload 1',
        '-w {0}'.format(app)
    ]

    command = 'uwsgi ' + ' '.join(flags)

    os.system(command)
