from lws.core.app import app
from lws.core.db import get_engine
from lws.services.suppliers.models import Skill


def main(args):
    """ cmd line script to update skills table by endorsements/votes
    """
    engine = get_engine(app.config['DB_URI'])
    connection = engine.connect()
    Skill.reset(connection)
    connection.close()
