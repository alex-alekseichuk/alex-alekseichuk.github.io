import eventlet
eventlet.monkey_patch()  # noqa

from nameko.runners import ServiceRunner

from lws.core.app import app, configure_app
from lws.core.worker import discover_workers, registered_workers


def main(args):
    discover_workers()

    service_runner = ServiceRunner(app.config)

    for name in args.workers:
        worker = registered_workers[name]
        service_runner.add_service(worker)

    service_runner.start()
    service_runner.wait()


def init_parser(parser):
    parser.add_argument(
        'workers', metavar='WORKERS', nargs='*', help="Target workers")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    init_parser(parser)
    args, unknown = parser.parse_known_args()

    configure_app()

    main(args)
