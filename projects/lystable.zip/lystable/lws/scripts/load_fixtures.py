import inspect
import os

from lws.core.service import Service
from lws.core.fixtures import FixtureLoader


def main(args):
    ops = args.unknown_args or []

    drop = '--drop' in ops or '-d' in ops
    help = '--options' in ops or '-o' in ops

    if help:
        print('Loads fixtures. Use -d to drop existing tables.')

    services = Service.__subclasses__()
    fixtures = []
    for service in services:
        fixtures_folder = os.path.abspath(
            os.path.join(inspect.getfile(service), '..', 'fixtures')
        )

        try:
            fixture_list = os.listdir(fixtures_folder)
        except FileNotFoundError:
            pass
        else:
            fixture_list = [
                os.path.join(fixtures_folder, f) for f in fixture_list
            ]
            fixtures.append(*fixture_list)

    loader = FixtureLoader(fixtures)
    loader.load(drop_existing=drop)
