if __name__ == '__main__':
    from lws.scripts import main
    main()
