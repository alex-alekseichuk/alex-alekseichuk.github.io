from importlib import import_module
import logging
import os
import pkgutil
import sys

import argcomplete
import argparse

from lws.core.app import configure_app

logging.basicConfig(filename='dev.log', level=logging.INFO)
logger = logging.getLogger(__name__)

dirname = os.path.dirname(__file__)
SCRIPTS = [import_module('lws.scripts.{}'.format(name))
           for _, name, _ in pkgutil.iter_modules([dirname])
           if not name.startswith('__')]


def main():
    configure_app()

    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(title='subcommands',
                                       help='subcommand help')

    for module in SCRIPTS:
        module_name = module.__name__.rsplit('.', 1)[-1]
        module_alias = module_name.strip('_')
        module_parser = subparsers.add_parser(
            module_alias, description=module.__doc__)

        if hasattr(module, 'init_parser'):
            module.init_parser(module_parser)

        module_parser.set_defaults(main=module.main)

    argcomplete.autocomplete(parser)

    args, unknown = parser.parse_known_args()
    args.unknown_args = unknown

    try:
        args.main(args)
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        logger.exception('Failure running %s: %s', sys.argv, exc)
        sys.exit(1)
