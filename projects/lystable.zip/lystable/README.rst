Lystable Web Services
=====================

These are the Web microservices that make up the Lystable platform.

They provide HTTP APIs for use in front end applications and various
integrations.

Love from Lystable


Getting Started
---------------

Install dependencies (in a Python 3.4 virtualenv)::

    $ pip install -r requirements/dev.txt

Configure your local instance::

    $ cp environment.py.sample environment_test.py
    $ vim environment_test.py  # update settings as necessary

Run tests (N.B. tests destructively drop and recreate the configured
database)::

    $ LWS_ENVFILE=environment_test.py py.test

To run the server::

    $ cp environment.py.sample environment.py
    $ vim environment.py  # You probably want to use a different database
    $ pip install uwsgi
    $ LWS_ENVFILE=environment.py uwsgi --http 0.0.0.0:8000 lws.core.gunicorn:app

If you need to configure a new database (from within a python shell)::

    >>> from lws.core.db import create_db, create_tables
    >>> from lws.core.app import app
    >>> app.config['DB_URI'] = DB_CONNECTION_STRING
    >>> create_db(app.config['DB_URI'])
    >>> create_tables(app)

Using Docker
------------

The application is also set up to use Docker, via ``docker-compose``. Assuming
that Docker is installed, the server can be run like this::

    $ pip install docker-compose
    $ docker-compose build
    $ docker-compose up lws

When changes are made to the code, re-run the last two commands.

Builds, tests, deployment
-------------------------

Any push to any branch is automatically built and tested by CircleCI. It will
also build documentation and push it to an S3 bucket, currently hosted on
http://lystable-docs.s3-website-us-east-1.amazonaws.com/<branch>/.

A build on master will be automatically deployed to AWS.
