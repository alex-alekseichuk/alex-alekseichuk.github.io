.. _validation-and-serialisation:

Validation and serialisation
============================

We are using a schema-based validation framework built on Marshmallow_.
This acts as a middleware between views and models.

.. _Marshmallow: http://marshmallow.rtfd.org/

Writing schemas
---------------

For an example SQLAlchemy model like this one:

.. sourcecode:: python

    class Supplier(Base):
        __tablename__ = 'suppliers'
        id = Column(Integer, autoincrement=True, primary_key=True)
        email = Column(String(255), index=True, nullable=False)
        team_id = Column(Integer, index=True, nullable=False)

The schema could look like this:

.. sourcecode:: python

    class SupplierSchema(Schema):
        id = fields.Integer(read_only=True)
        email = fields.String(required=True)
        team_id = fields.Integer()

        class Meta:
            model = Supplier
            fields = ('id', 'email', 'team_id', 'endorsements')
            many_exclude = ('endorsements', )

The ``read_only`` flag to the ``id`` field makes sure that the field will
only be rendered, but never changed. If data is passed in with this field,
it will simply be ignored.

In ``Meta``, the ``many_exclude`` option has been added. Fields listed here
will not be included when the schema is instantiated with ``many=True``.

API Reference
-------------

This is on top of the official Marshmallow documentation.

.. automodule:: lws.serialise.schema
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: lws.serialise.decorators
    :members:
    :undoc-members:
    :show-inheritance:
