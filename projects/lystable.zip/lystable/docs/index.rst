.. Lystable Web Services documentation master file, created by
   sphinx-quickstart on Fri Apr  3 18:09:01 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Lystable Web Services's documentation!
=================================================

## Endpoint documentation

All endpoints are documented automatically in Swagger. To download the latest
definitions, download `services.yaml`_ from the master documentation
repository.

If you're reading the online documentation for a branch,
`click here <services.yaml>`_ for up to date documentation.

.. _`services.yaml`: http://lystable-docs.s3-website-us-east-1.amazonaws.com/master/services.yaml

Contents:

.. toctree::
   :maxdepth: 2

   services
   models
   schema
   exceptions
   documentation
   auth
   emails



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

