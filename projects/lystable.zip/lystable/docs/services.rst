Writing services
================

Creating the service class
--------------------------

An LWS service is an instance of :py:class:`lws.core.service.Service` with
views attached to it. The service then attaches to a Flask application or
blueprint.

Creating and registering one is simple:

.. sourcecode:: python

    from flask import Blueprint

    from lws.core.service import Service, register_service

    suppliers = Blueprint('suppliers', __name__)

    class SupplierService(Service):

        root = SupplierView
        endorsements = EndorsementView
        referrals = ReferralView

    service = SupplierService.register_on(suppliers)
    register_service(service)

This service would create a URL mapping on the blueprint that had
all view functions on the ``SupplierView`` under its base URL, ``root`` being
special, everything from ``EndorsementView`` under ``/endorsements/``, and
``ReferralView`` under ``/referrals/``.

All URLs have trailing slashes.

Models and schemas
------------------

See the section on :ref:`schemas <validation-and-serialisation>`.

Writing views
-------------

A service can have one or more views attached to it. The
:py:class:`lws.core.service.views.ResourceView` class is the base class for
resource views, and other views can be registered directly on the service.

The ResourceView class
''''''''''''''''''''''

By default, any view function with the same name as a HTTP method will be dispatched
to when a request comes in using that method. The mapping looks like this:

- ``GET /`` calls ``index``
- ``POST /`` calls ``post``
- ``GET /123`` calls ``get`` with ``id`` argument ``123``
- ``PUT /123`` calls ``put`` with ``id`` argument ``123``

Any other method such as ``PATCH`` or ``DELETE`` is also mapped to individual
objects.

Arbitrary views can be registered with the
:py:func:`lws.core.service.decorators.route` decorator.

The ``schema`` class attribute can set a schema that will be used to process
the return data from the functions of every view function in the class.

If there is a namespace collision between two resources (or, indeed, any
routes), Flask will raise an exception on loading the application.

A complete resource can look like this:

.. sourcecode:: python

    class SupplierView(ResourceView):

        schema = SupplierSchema

        # GET /, automatically processed through SupplierSchema
        def index(self, schema):
            return ['list', 'of', 'objects']

        # POST /, automatically processed through SupplierSchema
        def post(self, schema):
            return 'post'

        # GET /<int>, automatically processed through SupplierSchema
        def get(self, schema, id):
            return 'get supplier {0}'.format(id)

        # PATCH /<int>, NOT processed through SupplierSchema
        @noschema
        def patch(self, id):
            return 'patch {0}'.format(id)

        # GET /thisthing
        @route(rule='thisthing')
        def thisthing(self):
            return 'this thing'

        # POST /foo/<int> (see modified_rules above)
        @route(rule='foo/<int>', method='post')
        def otherthing(self, id):
            return 'foo {0}'.format(id)

The return data will be wrapped in an envelope called ``data``. Make
sure the data returned is JSON serialisable. If the view function returns
a tuple, it is expected that the tuple will have two items, the former
being the data to render, and the second being a HTTP status code.

The view is then registered with a service, as described above.

Standalone views
''''''''''''''''

A standalone view function can be written either on the service class, or in
a view class.

.. sourcecode:: python

    from lws.core.service import Service
    from lws.core.service.decorators import route

    class FooService(Service):

        @route(rule='<int:id>/foo', method='get')
        def foo(self, id):
            return '{}'.format(id)

        @route(rule='bar', method='post')
        def bar(self):
            return 'bar'

These views would be served from a GET request to ``/<int:id>/foo/`` and
a POST request to ``/bar/`` respectively-

Decorators
----------

There are two decorators, outside of the routing decorator,
that enable or negate functionality in the resource views.

For a resource that has a default ``schema`` set, use the
:py:func:`lws.serialise.decorators.noschema` to disable the default schema
for that view alone.

If the default schema is not set, use the
:py:func:`lws.serialise.decorators.marshal_with` decorator to process the
output data from that view with a schema.

Error handling
--------------

The :py:mod:`lws.core.exceptions` module has exceptions that play well
with the rest of the system. If these are raised in a view function, the
response will be neatly wrapped up with a JSON response having a top-level
item called ``errors``.

Ping
----

Every service is automatically given a ``/ping/`` endpoint, which by default
replies with a JSON document containing ``pong``. This is used for things like
health checks in deployment.

If it's overriden, make sure it doesn't have any permissions checkers, and that
it does not reveal neither sensitive or computationally heavy data.

API Reference
-------------

Reference documentation for ``lws.core.service.base``.

.. automodule:: lws.core.service.base
    :members:
    :undoc-members:
    :show-inheritance:

Reference documentation for ``lws.core.service.views``.

.. automodule:: lws.core.service.views
    :members:
    :undoc-members:
    :show-inheritance:

Reference documentation for ``lws.core.service.decorators``.

.. automodule:: lws.core.service.decorators
    :members:
    :undoc-members:
    :show-inheritance:

Reference documentation for ``lws.core.service.utils``.

.. automodule:: lws.core.service.utils
    :members:
    :undoc-members:
    :show-inheritance:
