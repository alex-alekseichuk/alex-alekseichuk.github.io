Exceptions
==========

LWS has a collection of exceptions that handle HTTP error codes.

Services should raise these exceptions rather than use Flask/Werkzeug
builtins. This is so we can wrap them in an appropriate JSON response rather
than returning HTML.

API Reference
-------------

Reference documentation for ``lws.core.exceptions``.

.. automodule:: lws.core.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
