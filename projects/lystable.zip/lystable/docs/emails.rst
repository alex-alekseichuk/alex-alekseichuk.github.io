Emails
======

There are emails generated and sent during workflow. There is
Mandril service used to send emails to users. There is a set of email
templates hosted under Mandril account. There are dynamic tags in the
templates populated on the server.

There are absolute URLs (gates) to client application. They are used in emails.
The URLs configured as templates in the environment.py config.


Registration
------------

Registration email is sent on successful registration process to verify
user email address.

Mandril template name: `registration`

Tags:
  * `verify_email_url` is a link to client app with registration `code`
    to verify


Reset password
--------------

To reset password, user provides his email. Service generates reset password
`token`, save it to DB and send reset password email to user.

Mandril template name: `reset_password`

Tags:
  * `reset_password_url` is a link to client app with reset password `token`
