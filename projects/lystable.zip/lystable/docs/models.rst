.. _data-modelling:

Data Modelling
==============

We use SQLAlchemy to declaratively define our data models and the associated
data tables.

Models
------

A model should look something like this one:

.. sourcecode:: python

    class Supplier(Base):

        __tablename__ = 'suppliers'

        id = Column(Integer, autoincrement=True, primary_key=True)

        #: Primary email address of supplier
        email = Column(String(255), index=True, nullable=False)

        team_id = Column(Integer,
                         ForeignKey('Team.id'),
                         index=True,
                         nullable=False)

        team = relationship('Team')


Some things to be conscious of:
  * Model names should be singular
  * Table names should be plural
  * Favour auto-incrementing integer identifiers over composite keys
  * Favour auto-incrementing integer identifiers over unique keys that are
    subject to change
  * Foreign keys should indicate the column they point to
    (ie. team_id instead of team) to allow the relationship
    to be defined without the suffix.
  * Consider whether columns should be nullable in order to provide flexibility
    or consistency in the API


Migrations
----------

We use Alembic to manage schema and data migrations for the services platform.

Every new model requires a corresponding schema migration to initially
create the table as it is first described (as a base for any further
schema migrations).

You can initialise the migration environment for a new service through the
``lws-cmd`` interface which wraps the `Alembic command line interface
<http://alembic.readthedocs.org/en/latest/tutorial.html#create-a-migration-script>`_
(replacing `SERVICE_NAME` with the name of the service)::

    lws-cmd migrate SERVICE_NAME init

This will generate a ``migrations`` directory within the service package.

Writing Migrations
''''''''''''''''''

Once initialised you can generate new migration scripts from the commandline
which will generate a new revision version in the `migrations/versions`
directory with some boilerplate code::

    lws-cmd migrate SERVICE_NAME revision -m "Initial migration"

Update the ``upgrade`` and ``downgrade`` functions in the generated file to
describe the changes to the schema since the last revision:

.. sourcecode:: python

    def upgrade():
        op.create_table(
            'suppliers',
            sa.Column(
                'id', sa.Integer,
                nullable=False, primary_key=True),
            sa.Column(
                'email', sa.String(length=255),
                nullable=False, index=True),
            sa.Column(
                'team_id', sa.Integer,
                nullable=False, index=True),
        )


    def downgrade():
        op.drop_table('suppliers')


Running Migrations
''''''''''''''''''

To make sure your local database is up to date with the latest schema changes
run the following for any affected services::

    lws-cmd migrate SERVICE_NAME upgrade head

There is no integration with git to determine which migrations to roll back
if you need to switch to another branch, but you can explicitly roll back any
number of revisions using the ``downgrade`` command::

    lws-cmd migrate SERVICE_NAME downgrade -1


.. note::
    We should consider separating the concerns of schema and data migrations.
    There are cases where we might want to perform a schema migration without
    modifying any data and vice-versa. Having said that, it's not the most
    pressing on the technical roadmap until we have any valid deployment
    requirements for this.
