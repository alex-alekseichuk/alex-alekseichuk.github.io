Authentication & Authorisation
==============================

The HTTP API uses `JSON Web Tokens <http://jwt.io/>`_ for auth. These
are transient packets of authenticatication data encrypted on the
platform which can then be used for communication with platform
services and APIs. Because the tokens are not persisted in a database
each token has an expiry which is checked on each request to force
periodic re-authentication.

Generating a token
------------------

In order to generate a new token, the client must send a ``POST``
request to ``/users/generate_token/``::

    $ curl -d '' http://$(boot2docker ip):8000/users/generate_token/
    {
      "data": {
        "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE0MzMxNTU3ODR9.9YzGEHK6xnAsgaWaEmBb0w-dOLod60ySGrj0acmFjdI"
      }
    }

If you include ``email`` and ``password`` in the JSON request body,
the endpoint will attempt to generate an authenticated token using
those credentials. This will allow you access to most APIs on the
platform.

Using the token
---------------

Most endpoints will refuse access without an auth token. In order to
use the generated token for these requests, include it in the
``Authorization`` header as a `bearer` token::

    curl \
        -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE0MzMxNTU3ODR9.9YzGEHK6xnAsgaWaEmBb0w-dOLod60ySGrj0acmFjdI" \
        http://$(boot2docker ip):8000/users/profiles/

Exchanging a token
------------------

Another important (optional) parameter is ``team_id`` which
allows you to authenticate as the member of an organisation / team.

You can exchange an authenticated token for another (eg. with a
different team so you can switch teams). To do this use the
same ``generate_token`` endpoint along with the original token to
generate a new one::

    $ curl \
        -d '{"team_id": 1}' \
        -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE0MzMxNTU3ODR9.9YzGEHK6xnAsgaWaEmBb0w-dOLod60ySGrj0acmFjdI" \
        http://$(boot2docker ip):8000/users/generate_token/
    {
      "data": {
        "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE0MzMxNTY4MzR9.6xua7fivoYK3BcHMHy53917csyepELsJwNNQRwHFHrg"
      }
    }

