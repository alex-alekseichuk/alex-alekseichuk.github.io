Documenting Services and Views
==============================

When writing service code it's important to document both the public
and private APIs that will be exposed to other service developers and
engineers working on applications built on the public HTTP API.

Documenting Services
--------------------

Services provide an important encapsulation around the platforms
business logic. As such, each Service should have a docstring giving
an overview of it's reason for being as well as it's boundries
including covering any design decisions made during it's development.

.. sourcecode:: python

    class SupplierService(Service):
        """ This service tracks information about the suppliers of an team.

        Supplier information is always team specific and never
        aggregated across multiple teams.

        Note
        ----
            This may change once we engage suppliers to manage their
            own profiles

        """

        ...


Documenting APIs
----------------

Each API should have clear documentation describing it's behaviour
and outlining it's inputs and outputs.

Each function providing an API should have a docstring containing the
following sections:

.. sourcecode:: python

    @route('<int:resource_id>/public')
    def public_api(self, resource_id):
        """ A short sentence describing the API.

        Cover the behaviour in additional paragraphs here if
        necessary. Remember to focus especially on any behaviour that
        may not be immediately obvious from looking at the URI.

        Include any justifications of design decisions that have been
        made in order to add context for the behaviour being
        described.

        Parameters
        ----------
        resource_id : int
            The id of the resource
        team_id : int
            Required parameter to be included in the JSON body of
            the request.
        note : str (optional)
            An optional parameter to be included in the JSON body

        Returns
        -------
        Resource
            Describes the object being returned for a successful call
            to this API. Try to include any semantics which may aid
            in the caller correctly processing the response.

        Raises
        ------
        NotFound
            If the specified ``resource_id`` could not be found
        NotAcceptable
            If the `Resource` is not owned by the specified
            team.

        """

.. important::
    Expect APIs to be called internally through the ServiceProxy as
    well as externally over HTTP. As such, try to avoid using
    language that may be misleading depending on the context.


Documenting Resources
---------------------

Resources should have slightly more predictable behaviour than custom
APIs so avoid going into unnecessary amounts of detail where
convention can safely be assumed.

.. todo::
    Need to talk about Schemas and auto generating documentation to
    describe the expected representations of objects when being
    serialised through a schema.
