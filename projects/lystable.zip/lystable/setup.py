#!/usr/bin/env python
import os
from setuptools import find_packages, setup

here = os.path.abspath(os.path.dirname(__file__))
try:
    README = open(os.path.join(here, 'README.rst')).read()
except IOError:
    README = ''


setup(
    name='lws',
    version=0.1,
    description='the Lystable Web Services platform',
    long_description=README,
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    entry_points={
        'console_scripts': [
            'lws-cmd = lws.scripts:main',
        ],
    },
    classifiers=[
        'Private :: Do Not Upload',
    ],
)
