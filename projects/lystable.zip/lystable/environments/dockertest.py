import os

JWT_KEY = '123'
CORS_ORIGINS = '*'
PREFERRED_URL_SCHEME = 'http'

DB_URI = 'postgres://{db_user}:{db_pass}@{db_host}/{db_user}_test'.format(
    db_user=os.getenv('TESTDB_ENV_POSTGRES_USER'),
    db_pass=os.getenv('TESTDB_ENV_POSTGRES_PASSWORD'),
    db_host=os.getenv('TESTDB_PORT').split('//')[1]
)

AMQP_URI = 'amqp://guest@{amqp_host}/{amqp_node}'.format(
    amqp_host=os.getenv('TESTAMQP_PORT').split('//')[1],
    amqp_node=os.getenv('TESTAMQP_ENV_RABBITMQ_NODENAME')
)

RABBIT_CTL_URI = 'http://guest:guest@{rctl_host}:15672'.format(
    rctl_host=os.getenv('TESTAMQP_PORT').split('//')[1].split(':')[0],
)
