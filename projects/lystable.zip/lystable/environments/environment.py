DB_URI = 'postgres://localhost:5432/lws'

# Private key to be used when encoding and decoding JWTs for auth
JWT_KEY = 'secret'

AMQP_URI = 'amqp://guest:guest@localhost:5672/'
CORS_ORIGINS = '*'

# this is needed by tests to reset vhosts and the like
RABBIT_CTL_URI = 'http://guest:guest@localhost:15672'

SERVER_NAME = 'localhost:8000'
PREFERRED_URL_SCHEME = 'http'

# These are pure test application settings. Provide here correct parameters.
GOOGLE_CLIENT_ID = ('732039293992-crp8cq8d9hk70phbnvvg98160mlgfcv9'
                    '.apps.googleusercontent.com')
GOOGLE_CLIENT_SECRET = 'BYoEjg7Czj3RqjdG1hcHij0w'

MANDRILL_API_KEY = ''

PASSWORD_SALT = 'lystable_salt'
SESSION_TOKEN_SALT = 'lystable_salt'

S3_ACCESS_KEY_ID = 'AKIAIAKT3CGKOC2VZEPQ'
S3_SECRET_KEY = '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'

# gates to the client app from emails
BASE_CLIENT_URL = 'http://www.lystable.com'
