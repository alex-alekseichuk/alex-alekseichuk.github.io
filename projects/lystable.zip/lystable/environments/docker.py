import os

JWT_KEY = '123'
CORS_ORIGINS = '*'
SERVER_NAME = 'localdocker:8000'
PREFERRED_URL_SCHEME = 'http'

DB_URI = 'postgres://{db_user}:{db_pass}@{db_host}/{db_user}'.format(
    db_user=os.getenv('DB_ENV_POSTGRES_USER'),
    db_pass=os.getenv('DB_ENV_POSTGRES_PASSWORD'),
    db_host=os.getenv('DB_PORT').split('//')[1]
)

AMQP_URI = 'amqp://guest@{amqp_host}/{amqp_node}'.format(
    amqp_host=os.getenv('AMQP_PORT').split('//')[1],
    amqp_node=os.getenv('AMQP_ENV_RABBITMQ_NODENAME')
)

RABBIT_CTL_URI = 'http://guest:guest@{rctl_host}:15672'.format(
    rctl_host=os.getenv('AMQP_PORT').split('//')[1].split(':')[0],
)
