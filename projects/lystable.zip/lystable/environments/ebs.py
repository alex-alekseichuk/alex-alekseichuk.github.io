import os

DB_URI = 'postgres://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}'.format(
    db_user=os.getenv('RDS_USERNAME'),
    db_pass=os.getenv('RDS_PASSWORD'),
    db_host=os.getenv('RDS_HOSTNAME'),
    db_port=os.getenv('RDS_PORT'),
    db_name=os.getenv('RDS_DB_NAME'),
)

JWT_KEY = os.getenv('JWT_KEY')
