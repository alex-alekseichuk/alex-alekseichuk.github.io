FactoryGirl.define do
  factory :user do
    email { Faker::Internet.email }
    password 'pass12345'
    password_confirmation 'pass12345'
    role 'user'
    name { Faker::Name.first_name }
    surname { Faker::Name.last_name }
    is_active true
    is_confirmed true
    company { Faker::Company.name }

    trait :unconfirmed do
      is_active false
      is_confirmed false
    end
  end
end
