# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :template do
    name "MyString"
    user_id 1
    properties "MyText"
  end
end
