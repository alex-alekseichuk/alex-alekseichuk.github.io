FactoryGirl.define do
  factory :report do
    user
    time_start '00:00:00'
    time_end '23:59:59'
  end
end
