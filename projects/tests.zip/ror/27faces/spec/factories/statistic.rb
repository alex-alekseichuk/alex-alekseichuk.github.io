FactoryGirl.define do
  factory :statistic do
    camera
    session
    sequence(:start_at) { |n| 1.day.ago + n }
    sequence(:end_at) { |n| 1.day.ago + n + 10 }
    sequence(:class_id)
    gender 0
    age 0
    is_viewer false
    uuid { SecureRandom.uuid }
  end

  trait :two_days_ago do
    sequence(:start_at) { |n| 2.day.ago + n }
    sequence(:end_at) { |n| 2.day.ago + n + 10 }
  end

  trait :three_days_ago do
    sequence(:start_at) { |n| 3.day.ago + n }
    sequence(:end_at) { |n| 3.day.ago + n + 10 }
  end

  trait :one_monthes_ago do
    sequence(:start_at) { |n| 1.month.ago + n }
    sequence(:end_at) { |n| 1.month.ago + n + 10 }
  end

  trait :two_monthes_ago do
    sequence(:start_at) { |n| 2.month.ago + n }
    sequence(:end_at) { |n| 2.month.ago + n + 10 }
  end
end
