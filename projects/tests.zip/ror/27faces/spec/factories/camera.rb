FactoryGirl.define do
  factory :camera do
    location 'Kitchen'
    state 'off'
    api_key
  end
end
