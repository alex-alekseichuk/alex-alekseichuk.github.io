FactoryGirl.define do
  factory :api_key do
    expires_on 3.month.since
    user

    trait :expired do
      expires_on 3.month.ago
    end
  end
end
