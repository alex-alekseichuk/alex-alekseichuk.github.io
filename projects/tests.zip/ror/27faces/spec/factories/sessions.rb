FactoryGirl.define do
  factory :session do
    uuid { SecureRandom.uuid }
    camera
  end
end
