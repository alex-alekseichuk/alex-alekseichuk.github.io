require 'spec_helper'

describe Report do
  let!(:camera) { create(:camera) }

  describe '#perform_calculation' do
    context 'data_type: audience_ots' do
      context 'x_axis: time' do
        let!(:statistic1) { create(:statistic, :one_monthes_ago, camera: camera) }
        let!(:statistic2) { create(:statistic, :two_monthes_ago, camera: camera) }
        let!(:statistic3) { create(:statistic, :three_days_ago, camera: camera) }
        let!(:statistic4) { create(:statistic, :three_days_ago, camera: camera) }
        let!(:statistic5) { create(:statistic, :three_days_ago, camera: camera) }
        let!(:statistic6) { create(:statistic, :two_days_ago, camera: camera) }
        let!(:statistic7) { create(:statistic, camera: camera) }
        let!(:statistic8) { create(:statistic, camera: camera) }

        context 'group_by_month' do
          let(:report) do
            create(
              :report,
              date_start: 3.month.ago, date_end: Date.today, cameras: [camera],
              data_types: ['audience_ots'], time_detailing: 'group_by_month'
            )
          end

          specify do
            expect(report.chart[:series][0][:data]).to eq([
              [statistic1.start_at.beginning_of_day.to_i * 1000, 5.0]
            ])
          end
        end

        context 'group_by_day' do
          let(:report) do
            create(
              :report,
              date_start: 3.days.ago, date_end: Date.today, cameras: [camera],
              data_types: ['audience_ots'], time_detailing: 'group_by_day'
            )
          end

          specify do
            expect(report.chart[:series][0][:data]).to eq([
              [statistic3.start_at.beginning_of_day.to_i * 1000, 3.0],
              [statistic6.start_at.beginning_of_day.to_i * 1000, 1.0],
              [statistic7.start_at.beginning_of_day.to_i * 1000, 2.0]
            ])
          end
        end
      end
    end
  end
end
