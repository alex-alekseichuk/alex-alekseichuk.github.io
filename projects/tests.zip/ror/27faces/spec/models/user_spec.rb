require 'spec_helper'

describe User do
  context 'associations' do
    specify { expect(subject).to have_many(:api_keys) }
    specify { expect(subject).to have_many(:cameras) }
    specify { expect(subject).to have_many(:reports) }
  end

  context 'validations' do
    specify { expect(subject).to validate_presence_of(:name) }
    specify { expect(subject).to validate_presence_of(:surname) }
    specify { expect(subject).to validate_presence_of(:email) }
    specify { expect(subject).to validate_presence_of(:company) }
    specify { expect(subject).to validate_uniqueness_of(:email) }
  end

  let(:user) { create(:user) }

  describe '#is?' do
    let(:some_user) { create(:user, role: 'some_role') }

    specify { expect(some_user.is?('some_role')).to be_true }
  end

  describe '#number_of_used_cameras' do
    let(:api_key1) { create(:api_key, user: user) }
    let(:api_key2) { create(:api_key, user: user) }
    let!(:camera1) { create(:camera, api_key: api_key1) }
    let!(:camera2) { create(:camera, api_key: api_key2) }

    specify { expect(user.number_of_used_cameras).to eq(2) }
  end

  describe '#confirm_email!' do
    let(:confirmation_token) { '123' }
    let(:unconfirmed_user) { create(:user, :unconfirmed, confirmation_token: confirmation_token) }

    it 'confirms with right token' do
      unconfirmed_user.confirm_email!(confirmation_token)
      expect(unconfirmed_user.reload.is_confirmed).to be_true
    end

    it 'returns false with wrong token' do
      expect(unconfirmed_user.confirm_email!('321')).to be_false
      expect(unconfirmed_user.reload.is_confirmed).to be_false
    end
  end
end
