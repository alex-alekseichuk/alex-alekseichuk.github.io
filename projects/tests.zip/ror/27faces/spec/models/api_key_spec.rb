require 'spec_helper'

describe ApiKey do
  context 'associations' do
    specify{ expect(subject).to belong_to(:user) }
    specify{ expect(subject).to have_one(:camera) }
  end

  context 'scopes' do
    let(:expired_api_key) { build(:api_key, :expired) }
    let!(:active_api_key) { create(:api_key) }

    before { expired_api_key.save(validate: false) }

    describe '#expired' do
      specify { expect(ApiKey.expired).to eq([expired_api_key]) }
    end

    describe '#active' do
      specify { expect(ApiKey.active).to eq([active_api_key]) }
    end
  end

  describe '.is_active?' do
    let(:user) { create(:user) }
    let(:unconfirmed_user) { create(:user, :unconfirmed) }
    let(:api_key1) { create(:api_key, user: user) }
    let(:api_key2) { create(:api_key, user: unconfirmed_user) }

    it 'is true with active user' do
      expect(api_key1.is_valid?).to be_true
    end

    it 'is false with unconfirmed user' do
      expect(api_key2.is_valid?).to be_false
    end
  end

  describe '.expires_on_cannot_be_in_the_past' do
    let(:expired_api_key) { build(:api_key, :expired) }

    it "raises an error if end time is not present" do
      expired_api_key.valid?
      expect(expired_api_key.errors.messages).to include(:expires_on)
    end
  end
end
