require 'spec_helper'

describe 'API v2 Statistics' do
  let!(:camera) { create(:camera, state: 'on') }
  let!(:session) { create(:session, camera: camera) }

  before(:each) do
    @env = {}
    @env['CONTENT_TYPE'] = 'application/json'
    @env['ACCEPT'] = 'application/json'
  end

  describe 'POST #create' do
    def post_create(params)
      post "/api/v2/cameras/#{camera.id}/statistics", params.to_json, @env
    end

    let(:params1) do
      {
        token: camera.access_token,
        statistics: [
          {
            uuid: SecureRandom.uuid,
            session_uuid: session.uuid,
            class_id: 564,
            start_at: '2014-02-19T00:10:05+04:00',
            end_at: '2014-02-19T00:19:53+04:00',
            is_viewer: false
          },
          {
            uuid: SecureRandom.uuid,
            session_uuid: session.uuid,
            class_id: 564,
            start_at: '2014-02-19T00:12:34+04:00',
            end_at: '2014-02-19T00:13:55+04:00',
            gender: 1,
            age: 2,
            is_viewer: true
          },
          {
            uuid: SecureRandom.uuid,
            session_uuid: session.uuid,
            class_id: 565,
            start_at: '2014-02-19T10:45:01+04:00',
            end_at: '2014-02-19T10:46:34+04:00',
            is_viewer: false
          }
        ]
      }
    end

    context 'with valid attributes' do
      it 'has success response' do
        post_create(params1)
        expect(response).to be_success
      end

      it 'creates statistics' do
        expect { post_create(params1) }.to change(Statistic, :count).by(3)
      end

      it 'does not duplicates statistics' do
        post_create(params1)
        expect { post_create(params1) }.to change(Statistic, :count).by(0)
      end

      it 'returns uuid of imported statistics' do
        uuids = params1[:statistics].reduce([]) { |a, e| a << { 'uuid' => e[:uuid] } }
        post_create(params1)
        expect(json['imported_statistics']).to eq(uuids)
      end
    end

    context 'with invalid attributes' do
      it 'fails with wrong session uuid' do
        params = {
          token: camera.access_token,
          statistics: [
            {
              uuid: SecureRandom.uuid,
              session_uuid: 'nonexisted',
              class_id: 564,
              start_at: '2014-02-19T00:10:05+04:00',
              end_at: '2014-02-19T00:19:53+04:00',
              is_viewer: false
            }
          ]
        }
        post_create(params)
        expect(json['failed_statistics'][0]['code']).to eq(3)
      end

      it 'fails without start_at and end_at' do
        params = {
          token: camera.access_token,
          statistics: [
            {
              uuid: SecureRandom.uuid,
              session_uuid: session.uuid,
              class_id: 564,
              is_viewer: false
            }
          ]
        }
        post_create(params)
        expect(json['failed_statistics'][0]['code']).to eq(2)
      end

      it 'returns non unique error' do
        post_create(params1)
        post_create(params1)
        expect(json['failed_statistics'][0]['code']).to eq(2)
      end
    end
  end
end
