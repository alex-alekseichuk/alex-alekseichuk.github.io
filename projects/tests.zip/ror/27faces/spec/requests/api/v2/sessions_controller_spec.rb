require 'spec_helper'

describe 'API v2 Sessions' do
  let!(:camera) { create(:camera, state: 'on') }

  before(:each) do
    @env = {}
    @env['CONTENT_TYPE'] = 'application/json'
    @env['ACCEPT'] = 'application/json'
  end

  describe 'POST #create' do
    def post_create
      post "/api/v2/cameras/#{camera.id}/sessions", { token: camera.access_token }.to_json, @env
    end

    it 'has success response' do
      post_create
      expect(response).to be_success
    end

    it 'returns camera id' do
      post_create
      expect(json['camera_id']).to eq(camera.id)
    end

    it 'creates new session' do
      expect { post_create }.to change(Session, :count).by(1)
    end

    it 'returns session uuid' do
      post_create
      expect(json['uuid']).not_to be_nil
    end
  end

  describe 'PUT #close' do
    let(:session) { create(:session, camera: camera) }

    def put_close
      put "/api/v2/cameras/#{camera.id}/sessions/#{session.uuid}/close", { token: camera.access_token }.to_json, @env
    end

    it 'changes camera status' do
      expect { put_close }.to change { camera.reload.state }.from('on').to('off')
    end

    it 'returns closed time' do
      put_close
      expect(json['closed_at']).not_to be_nil
    end
  end
end
