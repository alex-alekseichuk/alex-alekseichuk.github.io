import { INestApplication } from '@nestjs/common'
import { TestingModuleBuilder } from '@nestjs/testing'
import { OIDC_VALIDATION_DISABLED_TOKEN } from 'account/account.tokens'
import { CoinApiClient } from 'account/providers/coin-api.provider'
import { CoinApiClientMock } from 'account/providers/__test__/coin-api.provider.mock'
import request from 'supertest'
import { authToken, badToken } from '../helpers/example-jwk'
import { getTestApplication, getTestApplicationModule } from './application-module.factory'

const GET_ALL_BALANCES_URL = '/product/banking/account/v1/balances'

describe('OIDC Authorization token', () => {
  let app: INestApplication
  let moduleFixture: TestingModuleBuilder

  beforeAll(async () => {
    moduleFixture = getTestApplicationModule()
      .overrideProvider(OIDC_VALIDATION_DISABLED_TOKEN)
      .useFactory({ factory: () => false })
      .overrideProvider(CoinApiClient)
      .useClass(CoinApiClientMock)
    app = getTestApplication(await moduleFixture.compile())
    await app.init()
  })

  describe(`(GET) ${GET_ALL_BALANCES_URL}`, () => {
    it('should return status 200 if token is valid', async () => {
      await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).set('auth', authToken).expect(200)
    })
    it('should return status 403 if the token is invalid', async () => {
      await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).set('auth', 'token').expect(403)
    })
    it('should return status 403 if the token was signed with a different certificate', async () => {
      await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).set('auth', badToken).expect(403)
    })
    it('should return status 403 if the token was not passed', async () => {
      await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).set('auth', '').expect(403)
    })
    it('should return status 200 if any token is passed and validation is disabled', async () => {
      await app.close()
      moduleFixture = getTestApplicationModule()
        .overrideProvider(OIDC_VALIDATION_DISABLED_TOKEN)
        .useFactory({ factory: () => true })
        .overrideProvider(CoinApiClient)
        .useClass(CoinApiClientMock)
      app = getTestApplication(await moduleFixture.compile())
      await app.init()
      await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).set('auth', '').expect(200)
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
