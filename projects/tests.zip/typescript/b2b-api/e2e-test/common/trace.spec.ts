import { INestApplication } from '@nestjs/common'
import { TraceMiddleware } from 'common/middlewares/trace.middleware'
import request from 'supertest'
import { getTestAccountModule } from '../account/account-module.factory'
import { getTestApplication } from './application-module.factory'

const EXAMPLE_URL = '/product/banking/account/v1/balances'

describe('Account', () => {
  let app: INestApplication

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    app.use(new TraceMiddleware().use)
    await app.init()
  })

  describe(`(GET) ${EXAMPLE_URL}`, () => {
    describe('Attach trace ID to headers if it was sent', () => {
      it('should respond in Content-Type JSON', async () => {
        await request(app.getHttpServer())
          .get(EXAMPLE_URL)
          .set('traceId', 'ABCD')
          .expect('Content-Type', /json/)
          .expect('traceId', 'ABCD')
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
