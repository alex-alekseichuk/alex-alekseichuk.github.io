import { getLoggerMock } from 'logger/logger-provider.mock'
import { LoggerModule } from 'logger/logger.module'

export const getLoggerModuleMock = () => LoggerModule.forRoot(getLoggerMock())
