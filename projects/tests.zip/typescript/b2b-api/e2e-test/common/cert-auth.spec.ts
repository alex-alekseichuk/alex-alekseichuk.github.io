import { INestApplication } from '@nestjs/common'
import request from 'supertest'
import { Agent } from 'https'
import { AuthGuard } from 'common/guards/auth.guard'
import { getAppOptions } from 'app-options.factory'
import { CERT_AUTH_DISABLED_TOKEN, REQUEST_CERT_DISABLED_TOKEN } from 'account/account.tokens'
import { TestingModuleBuilder } from '@nestjs/testing'
import { CoinApiClient } from 'account/providers/coin-api.provider'
import { CoinApiClientMock } from 'account/providers/__test__/coin-api.provider.mock'
import { AuthGuardMock } from '../mocks/auth-guard.mock'
import { getTestApplication, getTestApplicationModule } from './application-module.factory'
import {
  ExampleServerKey,
  ExampleServerCert,
  ExampleClientKey,
  ExampleClientCert,
  ExampleFailKey,
  ExampleFailCert,
} from '../helpers/example-certificates'

const EXAMPLE_URL = '/product/banking/account/v1/balances'

describe('Certificate Authentication', () => {
  let app: INestApplication
  let module: TestingModuleBuilder

  beforeEach(async () => {
    module = getTestApplicationModule()
      .overrideGuard(AuthGuard)
      .useClass(AuthGuardMock)
      .overrideProvider(CoinApiClient)
      .useClass(CoinApiClientMock)
      .overrideProvider(CERT_AUTH_DISABLED_TOKEN)
      .useFactory({ factory: () => false })
      .overrideProvider(REQUEST_CERT_DISABLED_TOKEN)
      .useFactory({ factory: () => false })

    app = getTestApplication(
      await module.compile(),
      undefined,
      getAppOptions({
        NODE_ENV: 'production',
        KEY_CONTENT: ExampleServerKey,
        CERT_CONTENT: ExampleServerCert,
        CA_CONTENT: ExampleClientCert,
        CERT_AUTH_DISABLED: 'false,',
      }),
    )

    await app.init()
  })

  afterEach(async () => {
    app.close()
  })

  describe(`(GET) ${EXAMPLE_URL}`, () => {
    it('should return data if certificate is whitelisted', async () => {
      await request(app.getHttpServer())
        .get(EXAMPLE_URL)
        .agent(
          new Agent({
            rejectUnauthorized: false,
            cert: ExampleClientCert,
            key: ExampleClientKey,
          }),
        )
        .expect(200)
    })
    it('should reject connection (403) if no certificate is specified', async () => {
      await request(app.getHttpServer())
        .get(EXAMPLE_URL)
        .agent(
          new Agent({
            rejectUnauthorized: false,
          }),
        )
        .expect(403)
    })
    it('should reject connection (403) if a certificate is not white-listed', async () => {
      await request(app.getHttpServer())
        .get(EXAMPLE_URL)
        .agent(
          new Agent({
            rejectUnauthorized: false,
            cert: ExampleFailCert,
            key: ExampleFailKey,
          }),
        )
        .expect(403)
    })

    it('should return data if certificate request is disabled and certificate is missing', async () => {
      const otherModule = getTestApplicationModule()
        .overrideGuard(AuthGuard)
        .useClass(AuthGuardMock)
        .overrideProvider(CERT_AUTH_DISABLED_TOKEN)
        .useFactory({ factory: () => false })
        .overrideProvider(REQUEST_CERT_DISABLED_TOKEN)
        .useFactory({ factory: () => true })
        .overrideProvider(CoinApiClient)
        .useClass(CoinApiClientMock)

      const otherApp = getTestApplication(
        await otherModule.compile(),
        undefined,
        getAppOptions({
          NODE_ENV: 'production',
          KEY_CONTENT: ExampleServerKey,
          CERT_CONTENT: ExampleServerCert,
          REQUEST_CERT_DISABLED: 'true',
          CERT_AUTH_DISABLED: 'false',
        }),
      )
      await otherApp.init()

      await request(otherApp.getHttpServer())
        .get(EXAMPLE_URL)
        .agent(
          new Agent({
            rejectUnauthorized: false,
          }),
        )
        .expect(200)
    })
  })

  describe(`Should allow access to health endpoints without certs.`, () => {
    it('(GET) /health/liveness', async () => {
      await request(app.getHttpServer())
        .get('/health/liveness')
        .agent(
          new Agent({
            rejectUnauthorized: false,
          }),
        )
        .expect(200)
    })

    it('(GET) /health/readiness', async () => {
      await request(app.getHttpServer())
        .get('/health/readiness')
        .agent(
          new Agent({
            rejectUnauthorized: false,
          }),
        )
        .expect(200)
    })
  })
})
