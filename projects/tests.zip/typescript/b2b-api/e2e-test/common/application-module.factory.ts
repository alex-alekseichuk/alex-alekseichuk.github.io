import { BadRequestException, HttpServer, NestApplicationOptions, ValidationPipe } from '@nestjs/common'
import { AbstractHttpAdapter } from '@nestjs/core'
import { Test, TestingModule } from '@nestjs/testing'
import { ConfigService } from '@nestjs/config'
import { JWK_TOKEN } from 'account/account.tokens'
import { AppModule } from 'app.module'
import {
  CryptoPositionsApi as ClientCryptoPositionsApi,
  CustomersApi as ClientCustomersApi,
  OrdersApi as ClientOrdersApi,
  SettingsApi as ClientSettingsApi,
  TradingApi as ClientTradingApi,
} from 'c-vault/public-client-api'
import { PositionsApi as BankPositionsApi } from 'c-vault/public-bank-api'
import { ClientCryptoPositionsApiMock } from 'api/mocks/client/crypto-positions-api.mock'
import { ClientCustomersApiMock } from 'api/mocks/client/customers-api.mock'
import { ClientOrdersApiMock } from 'api/mocks/client/orders-api.mock'
import { ClientSettingsApiMock } from 'api/mocks/client/settings-api.mock'
import { BankPositionsApiMock } from 'api/mocks/bank/positions-api.mock'
import { CustomConfigService } from 'common/services/custom-config.service'
import { getLoggerMock } from 'logger/logger-provider.mock'
import { ClientTradingApiMock } from 'api/mocks/client/trading-api.mock'
import { ExampleJWK } from '../helpers/example-jwk'
import { CustomConfigServiceMock } from '../mocks/custom-config.service.mock'

export const getTestApplicationModule = () =>
  Test.createTestingModule({
    imports: [AppModule.forRoot(getLoggerMock())],
    providers: [
      {
        provide: ConfigService,
        useFactory: () => new ConfigService({}),
      },
    ],
  })
    .overrideProvider(ClientCryptoPositionsApi)
    .useClass(ClientCryptoPositionsApiMock)
    .overrideProvider(ClientCustomersApi)
    .useClass(ClientCustomersApiMock)
    .overrideProvider(ClientOrdersApi)
    .useClass(ClientOrdersApiMock)

    .overrideProvider(ClientSettingsApi)
    .useClass(ClientSettingsApiMock)
    .overrideProvider(ClientTradingApi)
    .useClass(ClientTradingApiMock)
    .overrideProvider(BankPositionsApi)
    .useClass(BankPositionsApiMock)
    .overrideProvider(CustomConfigService)
    .useClass(CustomConfigServiceMock)
    .overrideProvider(JWK_TOKEN)
    .useValue(ExampleJWK)

export const getTestApplication = (
  testingModule: TestingModule,
  httpAdapter?: HttpServer | AbstractHttpAdapter,
  options?: NestApplicationOptions,
) => {
  const app = testingModule.createNestApplication(httpAdapter, options)
  app.useGlobalPipes(
    new ValidationPipe({
      exceptionFactory: errors => new BadRequestException(errors),
    }),
  )
  return app
}
