import { Test } from '@nestjs/testing'
import {
  ALLOWED_CLIENT_CRYPTOPOSITION_TYPES,
  CERT_AUTH_DISABLED_TOKEN,
  JWK_TOKEN,
  OIDC_VALIDATION_DISABLED_TOKEN,
  REQUEST_CERT_DISABLED_TOKEN,
} from 'account/account.tokens'
import { AuthGuard } from 'common/guards/auth.guard'
import { AccountModule } from 'account/account.module'
import {
  CryptoPositionsApi as ClientCryptoPositionsApi,
  CustomersApi as ClientCustomersApi,
  OrdersApi as ClientOrdersApi,
  SettingsApi as ClientSettingsApi,
  TradingApi as ClientTradingApi,
} from 'c-vault/public-client-api'
import { PositionsApi as BankPositionsApi } from 'c-vault/public-bank-api'
import { ClientCryptoPositionsApiMock } from 'api/mocks/client/crypto-positions-api.mock'
import { ClientCustomersApiMock } from 'api/mocks/client/customers-api.mock'
import { ClientOrdersApiMock } from 'api/mocks/client/orders-api.mock'
import { ClientSettingsApiMock } from 'api/mocks/client/settings-api.mock'
import { BankPositionsApiMock } from 'api/mocks/bank/positions-api.mock'
import { CustomConfigService } from 'common/services/custom-config.service'
import { ClientTradingApiMock } from 'api/mocks/client/trading-api.mock'
import { CoinApiClientMock } from 'account/providers/__test__/coin-api.provider.mock'
import { CoinApiClient } from 'account/providers/coin-api.provider'
import { DEFAULT_TRADING_PAIRS_BASE, DEFAULT_TRADING_PAIRS_QUOTE } from 'account/configuration/trading-pairs'
import { ExampleJWK } from '../helpers/example-jwk'
import { CustomConfigServiceMock } from '../mocks/custom-config.service.mock'
import { AuthGuardMock } from '../mocks/auth-guard.mock'
import { getLoggerModuleMock } from '../common/logger-module.factory'

export const getTestAccountModule = () =>
  Test.createTestingModule({
    imports: [AccountModule, getLoggerModuleMock()],
  })
    .overrideProvider(CERT_AUTH_DISABLED_TOKEN)
    .useFactory({ factory: () => true })
    .overrideProvider(REQUEST_CERT_DISABLED_TOKEN)
    .useFactory({ factory: () => true })
    .overrideProvider(JWK_TOKEN)
    .useValue(ExampleJWK)
    .overrideProvider(OIDC_VALIDATION_DISABLED_TOKEN)
    .useFactory({ factory: () => true })
    .overrideGuard(AuthGuard)
    .useClass(AuthGuardMock)
    .overrideProvider(ClientCryptoPositionsApi)
    .useClass(ClientCryptoPositionsApiMock)
    .overrideProvider(ClientCustomersApi)
    .useClass(ClientCustomersApiMock)
    .overrideProvider(ClientOrdersApi)
    .useClass(ClientOrdersApiMock)
    .overrideProvider(ClientSettingsApi)
    .useClass(ClientSettingsApiMock)
    .overrideProvider(BankPositionsApi)
    .useClass(BankPositionsApiMock)
    .overrideProvider(CustomConfigService)
    .useClass(CustomConfigServiceMock)
    .overrideProvider(CoinApiClient)
    .useClass(CoinApiClientMock)
    .overrideProvider(ClientTradingApi)
    .useClass(ClientTradingApiMock)
    .overrideProvider(ALLOWED_CLIENT_CRYPTOPOSITION_TYPES)
    .useFactory({ factory: () => ['SEGREGATED', 'TRADING', 'OMNIBUS'] })
    .overrideProvider(DEFAULT_TRADING_PAIRS_BASE)
    .useFactory({ factory: () => ['BTC', 'ETH'] })
    .overrideProvider(DEFAULT_TRADING_PAIRS_QUOTE)
    .useFactory({ factory: () => ['USD', 'SGD', 'CHF'] })
