import { INestApplication } from '@nestjs/common'
import request from 'supertest'
import { AccountService } from 'account/account.service'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'

const GET_ALL_BALANCES_URL = '/product/banking/account/v1/balances'

describe('Account', () => {
  let app: INestApplication
  let accountService: AccountService

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    accountService = module.get(AccountService)
    await app.init()
  })

  describe(`(GET) ${GET_ALL_BALANCES_URL}`, () => {
    describe('when C-Vault API is available', () => {
      it('should respond in Content-Type JSON', async () => {
        await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).expect('Content-Type', /json/)
      })
      it('should return status 200 if there is no error', async () => {
        await request(app.getHttpServer()).get(GET_ALL_BALANCES_URL).expect(200)
      })
      it('should return success response in expected format', async () => {
        const expected = await accountService.getBalances('auth_token')
        await request(app.getHttpServer())
          .get(GET_ALL_BALANCES_URL)
          .then(response => {
            expect(response.body).toBeDefined()
            expect(response.body).toMatchObject(expected)
          })
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
