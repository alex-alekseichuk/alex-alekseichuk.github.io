/* eslint-disable object-shorthand */
import { INestApplication } from '@nestjs/common'
import request from 'supertest'
import { AccountService } from 'account/account.service'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'
import { buildCreateSellHelper, CreateSellOrderPayload, PayloadBuilder } from './__test__/create-sell.helper'

const CREATE_SELL_ORDER_URL = '/product/banking/account/v1/sellOrder'

describe('Account', () => {
  let app: INestApplication

  let buildSellOrderPayload: PayloadBuilder
  let buildLimitSellOrderPayload: PayloadBuilder
  let buildMarketSellOrderPayload: PayloadBuilder
  let buildStopLossSellOrderPayload: PayloadBuilder
  let buildStopLimitSellOrderPayload: PayloadBuilder

  function placeSellOrder(payload: CreateSellOrderPayload) {
    return request(app.getHttpServer()).post(CREATE_SELL_ORDER_URL).send(payload)
  }

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    await app.init()

    /* Set the relevant customer from generated data - after using the data-generator user names and related entities uuids may change
     * Customer with index 4 should always have: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH)wp
     * */
    const customers = await module.get(AccountService).getBalances('auth_token')
    const representativeCustomer = customers[4]!

    const helpers = buildCreateSellHelper({
      customerUuid: representativeCustomer.customerUuid,
      cryptoPositionUuid: representativeCustomer.cryptoWallets[0]!.cryptoPositionUuid,
      customerFiatAccountUuid: representativeCustomer.fiatAccounts[0]!.customerFiatAccountUuid,
      orderType: 'MARKET' as const,
      sellAmount: 1,
      limitPrice: 1,
      stopPrice: 1,
      orderValidUntil: '2020-05-30',
    })

    buildSellOrderPayload = helpers.buildSellOrderPayload
    buildLimitSellOrderPayload = helpers.buildLimitSellOrderPayload
    buildMarketSellOrderPayload = helpers.buildMarketSellOrderPayload
    buildStopLossSellOrderPayload = helpers.buildStopLossSellOrderPayload
    buildStopLimitSellOrderPayload = helpers.buildStopLimitSellOrderPayload
  })

  describe(`(POST) ${CREATE_SELL_ORDER_URL}`, () => {
    describe('Happy Path', () => {
      it('should provide correct response for Limit Order', async () => {
        await placeSellOrder(buildLimitSellOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })

      it('should provide correct response for Market Order', async () => {
        await placeSellOrder(buildMarketSellOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })

      it('should provide correct response for Stop Loss Order', async () => {
        await placeSellOrder(buildStopLossSellOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })

      it('should provide correct response for Stop Limit Order', async () => {
        await placeSellOrder(buildStopLimitSellOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })
    })

    describe('Error Handling', () => {
      describe('customerUuid', () => {
        it('should return validation error (400) when customerUuid is missing', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ fieldsToOmit: ['customerUuid'] })).expect(400)
        })
        it('should return validation error (400) when customerUuid is empty', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { customerUuid: '' } })).expect(400)
        })
        it('should return validation error (400) when customerUuid is invalid', async () => {
          await placeSellOrder(
            buildMarketSellOrderPayload({ payload: { customerUuid: 'invalid-customer-uuid' } }),
          ).expect(400)
        })
        it('should return validation error (400) when customerUuid is not a string', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { customerUuid: 200 } })).expect(400)
        })
      })

      describe('cryptoPositionUuid', () => {
        it('should return validation error (400) when cryptoPositionUuid is missing', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ fieldsToOmit: ['cryptoPositionUuid'] })).expect(400)
        })
        it('should return validation error (400) when cryptoPositionUuid is invalid', async () => {
          await placeSellOrder(
            buildMarketSellOrderPayload({ payload: { cryptoPositionUuid: 'invalid-cryptoPositionUuid' } }),
          ).expect(400)
        })
        it('should return validation error (400) when cryptoPositionUuid is empty', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { cryptoPositionUuid: '' } })).expect(400)
        })
        it('should return validation error (400) when cryptoPositionUuid is not a string', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { cryptoPositionUuid: 200 } })).expect(400)
        })
      })

      describe('customerFiatAccountUuid', () => {
        it('should return validation error (400) when customerFiatAccountUuid is missing', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ fieldsToOmit: ['customerFiatAccountUuid'] })).expect(400)
        })
        it('should return validation error (400) when customerFiatAccountUuid is invalid', async () => {
          await placeSellOrder(
            buildMarketSellOrderPayload({ payload: { customerFiatAccountUuid: 'invalid-customerFiatAccountUuid' } }),
          ).expect(400)
        })
        it('should return validation error (400) when customerFiatAccountUuid is empty', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { customerFiatAccountUuid: '' } })).expect(400)
        })
        it('should return validation error (400) when customerFiatAccountUuid is not a string', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { customerFiatAccountUuid: 200 } })).expect(400)
        })
      })

      describe('sellAmount', () => {
        it('should return validation error (400) when sellAmount is missing', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ fieldsToOmit: ['sellAmount'] })).expect(400)
        })

        it('should return validation error (400) when sellAmount is not a number', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { sellAmount: 'not-a-number' } })).expect(400)
        })

        it('should return validation error (400) when sellAmount equal to 0', async () => {
          await placeSellOrder(buildMarketSellOrderPayload({ payload: { sellAmount: 0 } })).expect(400)
        })
      })

      describe('orderType', () => {
        it('should return validation error (400) when order type is invalid', async () => {
          await placeSellOrder(buildSellOrderPayload({ payload: { orderType: 'invalid-order-type' } })).expect(400)
        })
        it('should return validation error (400) when order type is MARKET and limitPrice is present', async () => {
          await placeSellOrder(buildSellOrderPayload({ payload: { orderType: 'MARKET', limitPrice: 1 } })).expect(400)
        })
        it('should return validation error (400) when order type is MARKET and orderValidUntil is present', async () => {
          await placeSellOrder(
            buildSellOrderPayload({ payload: { orderType: 'MARKET', orderValidUntil: '2020-05-30' } }),
          ).expect(400)
        })
      })

      describe('limitPrice', () => {
        it('should return validation error (400) when orderValidUntil is present and limitPrice is missing', async () => {
          await placeSellOrder(buildLimitSellOrderPayload({ fieldsToOmit: ['limitPrice'] })).expect(400)
        })
        it('should return validation error (400) when limitPrice is not a number', async () => {
          await placeSellOrder(buildLimitSellOrderPayload({ payload: { limitPrice: 'not-a-number' } })).expect(400)
        })
        it('should return validation error (400) when limitPrice is equal 0', async () => {
          await placeSellOrder(buildLimitSellOrderPayload({ payload: { limitPrice: 0 } })).expect(400)
        })
      })

      describe('orderValidUntil', () => {
        it('should return validation error (400) when valid limitPrice is present and orderValidUntil is missing', async () => {
          await placeSellOrder(buildLimitSellOrderPayload({ fieldsToOmit: ['orderValidUntil'] })).expect(400)
        })
        it('should return validation error (400) when valid limitPrice is present and orderValidUntil is empty', async () => {
          await placeSellOrder(buildLimitSellOrderPayload({ payload: { orderValidUntil: '' } })).expect(400)
        })
        it('should return validation error (400) when valid limitPrice is present and orderValidUntil has incorrect date format', async () => {
          await placeSellOrder(buildLimitSellOrderPayload({ payload: { orderValidUntil: '02-02-2020' } })).expect(400)
        })
      })

      describe('stopPrice', () => {
        it('should return validation error (400) when stopPrice is missing for STOP_LOSS', async () => {
          await placeSellOrder(buildStopLossSellOrderPayload({ fieldsToOmit: ['stopPrice'] })).expect(400)
        })
        it('should return validation error (400) when stopPrice is missing for STOP_LIMIT', async () => {
          await placeSellOrder(buildStopLimitSellOrderPayload({ fieldsToOmit: ['stopPrice'] })).expect(400)
        })
        it('should return validation error (400) when stopPrice is not a number', async () => {
          await placeSellOrder(buildStopLossSellOrderPayload({ payload: { stopPrice: 'not-a-number' } })).expect(400)
        })
        it('should return validation error (400) when stopPrice is equal 0', async () => {
          await placeSellOrder(buildStopLossSellOrderPayload({ payload: { stopPrice: 0 } })).expect(400)
        })
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
