import { INestApplication } from '@nestjs/common'
import { Customer } from 'account/models/customer.model'
import request from 'supertest'
import { AccountService } from 'account/account.service'
import { OrdersApi } from 'c-vault/public-client-api'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'

const GET_ORDER_URL = (customerUuid: string, orderUuid: string) =>
  `/product/banking/account/v1/customer/${customerUuid}/order/${orderUuid}`

describe('Account', () => {
  let app: INestApplication
  let accountService: AccountService
  let representativeCustomer: Customer

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    accountService = module.get(AccountService)
    await app.init()

    /* Set the relevant customer from generated data - after using the data-generator user names and related entities uuids may change
     * Customer with index 4 should always have: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH)wp
     * */
    const customers = await accountService.getBalances('auth_token')
    representativeCustomer = customers[4]!
  })

  describe(`(GET) ${GET_ORDER_URL(':customerUuid', ':orderUuid')}`, () => {
    describe('when C-Vault API is available', () => {
      describe('and valid orderUuid was provided', () => {
        let orderUuid: string
        beforeAll(async () => {
          const response = await app.get(OrdersApi).getCustomerOrders('auth-token', representativeCustomer.customerUuid)
          orderUuid = response.data.rows![0]!.orderUuid
        })

        it('should return status 200 if there is no error', async () => {
          await request(app.getHttpServer())
            .get(GET_ORDER_URL(representativeCustomer.customerUuid, orderUuid))
            .expect(200)
        })
      })
      describe('and invalid orderUuid was provided', () => {
        it('should return 404 error when order not found', async () => {
          await request(app.getHttpServer())
            .get(GET_ORDER_URL(representativeCustomer.customerUuid, 'b6b5bda7-23a9-4f30-8f77-4a155a8ce173'))
            .expect(404)
            .then(response => {
              expect(response.body).toHaveProperty('message')
              expect(response.body.message).toContain('orderUuid')
            })
        })
        it('should return 400 validation error when provided orderUuid is not valid UUID', async () => {
          await request(app.getHttpServer())
            .get(GET_ORDER_URL(representativeCustomer.customerUuid, 'not-a-valid-uuid'))
            .expect(400)
        })
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
