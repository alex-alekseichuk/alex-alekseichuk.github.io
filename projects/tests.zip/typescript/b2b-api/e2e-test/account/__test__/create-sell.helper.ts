interface DefaultSellOrderValues {
  sellAmount: number
  customerUuid: string
  cryptoPositionUuid: string
  customerFiatAccountUuid: string
  orderType: 'LIMIT' | 'MARKET' | 'STOP_LOSS' | 'STOP_LIMIT'
  limitPrice: number
  orderValidUntil: string
  stopPrice: number
}

export type CreateSellOrderPayload = {
  [key in keyof DefaultSellOrderValues]?: unknown
}

type AvailableFieldsToOmit = keyof CreateSellOrderPayload
type PayloadCreationSettings = {
  payload?: CreateSellOrderPayload
  fieldsToOmit?: AvailableFieldsToOmit[]
}

export type PayloadBuilder = (settings?: PayloadCreationSettings) => CreateSellOrderPayload

export const buildCreateSellHelper = (defaultValues: DefaultSellOrderValues) => {
  const buildSellOrderPayload: PayloadBuilder = ({
    payload = {},
    fieldsToOmit = [],
  }: PayloadCreationSettings = {}): CreateSellOrderPayload => {
    return {
      ...(!fieldsToOmit.includes('customerUuid') && {
        customerUuid: payload.customerUuid ?? defaultValues.customerUuid,
      }),
      ...(!fieldsToOmit.includes('cryptoPositionUuid') && {
        cryptoPositionUuid: payload.cryptoPositionUuid ?? defaultValues.cryptoPositionUuid,
      }),
      ...(!fieldsToOmit.includes('customerFiatAccountUuid') && {
        customerFiatAccountUuid: payload.customerFiatAccountUuid ?? defaultValues.customerFiatAccountUuid,
      }),
      ...(!fieldsToOmit.includes('orderType') && { orderType: payload.orderType ?? defaultValues.orderType }),
      ...(!fieldsToOmit.includes('sellAmount') && { sellAmount: payload.sellAmount ?? defaultValues.sellAmount }),
      ...(!fieldsToOmit.includes('limitPrice') && { limitPrice: payload.limitPrice ?? defaultValues.limitPrice }),
      ...(!fieldsToOmit.includes('orderValidUntil') && {
        orderValidUntil: payload.orderValidUntil ?? defaultValues.orderValidUntil,
      }),
      ...(!fieldsToOmit.includes('stopPrice') && { stopPrice: payload.stopPrice ?? defaultValues.stopPrice }),
    }
  }

  const buildLimitSellOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildSellOrderPayload({
      payload: { orderType: 'LIMIT', ...settings.payload },
      fieldsToOmit: ['stopPrice', ...(settings.fieldsToOmit || [])],
    })

  const buildMarketSellOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildSellOrderPayload({
      payload: { orderType: 'MARKET', ...settings.payload },
      fieldsToOmit: ['limitPrice', 'orderValidUntil', 'stopPrice', ...(settings.fieldsToOmit || [])],
    })

  const buildStopLossSellOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildSellOrderPayload({
      payload: { orderType: 'STOP_LOSS', ...settings.payload },
      fieldsToOmit: ['limitPrice', 'orderValidUntil', ...(settings.fieldsToOmit || [])],
    })

  const buildStopLimitSellOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildSellOrderPayload({
      payload: { orderType: 'STOP_LIMIT', ...settings.payload },
      fieldsToOmit: settings.fieldsToOmit || [],
    })

  return {
    buildSellOrderPayload,
    buildLimitSellOrderPayload,
    buildMarketSellOrderPayload,
    buildStopLossSellOrderPayload,
    buildStopLimitSellOrderPayload,
  }
}
