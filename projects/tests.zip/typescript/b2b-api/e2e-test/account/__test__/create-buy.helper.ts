interface DefaultBuyOrderValues {
  buyAmount: number
  customerUuid: string
  cryptoPositionUuid: string
  customerFiatAccountUuid: string
  orderType: 'LIMIT' | 'MARKET' | 'STOP_LOSS' | 'STOP_LIMIT'
  limitPrice: number
  orderValidUntil: string
  stopPrice: number
}

export type CreateBuyOrderPayload = {
  [key in keyof DefaultBuyOrderValues]?: unknown
}

type AvailableFieldsToOmit = keyof CreateBuyOrderPayload
type PayloadCreationSettings = {
  payload?: CreateBuyOrderPayload
  fieldsToOmit?: AvailableFieldsToOmit[]
}

export type PayloadBuilder = (settings?: PayloadCreationSettings) => CreateBuyOrderPayload

export const buildCreateBuyHelper = (defaultValues: DefaultBuyOrderValues) => {
  const buildBuyOrderPayload: PayloadBuilder = ({
    payload = {},
    fieldsToOmit = [],
  }: PayloadCreationSettings = {}): CreateBuyOrderPayload => {
    return {
      ...(!fieldsToOmit.includes('customerUuid') && {
        customerUuid: payload.customerUuid ?? defaultValues.customerUuid,
      }),
      ...(!fieldsToOmit.includes('cryptoPositionUuid') && {
        cryptoPositionUuid: payload.cryptoPositionUuid ?? defaultValues.cryptoPositionUuid,
      }),
      ...(!fieldsToOmit.includes('customerFiatAccountUuid') && {
        customerFiatAccountUuid: payload.customerFiatAccountUuid ?? defaultValues.customerFiatAccountUuid,
      }),
      ...(!fieldsToOmit.includes('orderType') && { orderType: payload.orderType ?? defaultValues.orderType }),
      ...(!fieldsToOmit.includes('buyAmount') && { buyAmount: payload.buyAmount ?? defaultValues.buyAmount }),
      ...(!fieldsToOmit.includes('limitPrice') && { limitPrice: payload.limitPrice ?? defaultValues.limitPrice }),
      ...(!fieldsToOmit.includes('orderValidUntil') && {
        orderValidUntil: payload.orderValidUntil ?? defaultValues.orderValidUntil,
      }),
      ...(!fieldsToOmit.includes('stopPrice') && { stopPrice: payload.stopPrice ?? defaultValues.stopPrice }),
    }
  }

  const buildLimitBuyOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildBuyOrderPayload({
      payload: { orderType: 'LIMIT', ...settings.payload },
      fieldsToOmit: ['stopPrice', ...(settings.fieldsToOmit || [])],
    })

  const buildMarketBuyOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildBuyOrderPayload({
      payload: { orderType: 'MARKET', ...settings.payload },
      fieldsToOmit: ['limitPrice', 'orderValidUntil', 'stopPrice', ...(settings.fieldsToOmit || [])],
    })

  const buildStopLossBuyOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildBuyOrderPayload({
      payload: { orderType: 'STOP_LOSS', ...settings.payload },
      fieldsToOmit: ['limitPrice', 'orderValidUntil', ...(settings.fieldsToOmit || [])],
    })

  const buildStopLimitBuyOrderPayload: PayloadBuilder = (settings: PayloadCreationSettings = {}) =>
    buildBuyOrderPayload({
      payload: { orderType: 'STOP_LIMIT', ...settings.payload },
      fieldsToOmit: settings.fieldsToOmit || [],
    })

  return {
    buildBuyOrderPayload,
    buildLimitBuyOrderPayload,
    buildMarketBuyOrderPayload,
    buildStopLossBuyOrderPayload,
    buildStopLimitBuyOrderPayload,
  }
}
