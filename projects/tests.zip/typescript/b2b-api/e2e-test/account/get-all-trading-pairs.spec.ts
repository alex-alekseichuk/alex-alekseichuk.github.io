import { INestApplication } from '@nestjs/common'
import request from 'supertest'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'

const TRADING_PAIRS_URL = () => `/product/banking/account/v1/all-trading-pairs`

describe('Account', () => {
  let app: INestApplication

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    await app.init()
  })

  describe(`(GET) ${TRADING_PAIRS_URL()}`, () => {
    describe('when C-Vault API is available', () => {
      it('should respond in Content-Type JSON', async () => {
        await request(app.getHttpServer()).get(TRADING_PAIRS_URL()).expect('Content-Type', /json/)
      })
      it('should return status 200 if there is no error', async () => {
        await request(app.getHttpServer()).get(TRADING_PAIRS_URL()).expect(200)
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
