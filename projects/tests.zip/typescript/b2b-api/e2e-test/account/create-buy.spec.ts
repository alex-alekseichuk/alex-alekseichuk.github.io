/* eslint-disable object-shorthand */
import { INestApplication } from '@nestjs/common'
import request from 'supertest'
import { AccountService } from 'account/account.service'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'
import { CreateBuyOrderPayload, buildCreateBuyHelper, PayloadBuilder } from './__test__/create-buy.helper'

const CREATE_BUY_ORDER_URL = '/product/banking/account/v1/buyOrder'

describe('Account', () => {
  let app: INestApplication

  let buildBuyOrderPayload: PayloadBuilder
  let buildLimitBuyOrderPayload: PayloadBuilder
  let buildMarketBuyOrderPayload: PayloadBuilder
  let buildStopLossBuyOrderPayload: PayloadBuilder
  let buildStopLimitBuyOrderPayload: PayloadBuilder

  function placeBuyOrder(payload: CreateBuyOrderPayload) {
    return request(app.getHttpServer()).post(CREATE_BUY_ORDER_URL).send(payload)
  }

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    await app.init()

    /* Set the relevant customer from generated data - after using the data-generator user names and related entities uuids may change
     * Customer with index 4 should always have: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH)wp
     * */
    const customers = await module.get(AccountService).getBalances('auth_token')
    const representativeCustomer = customers[4]!

    const helpers = buildCreateBuyHelper({
      customerUuid: representativeCustomer.customerUuid,
      cryptoPositionUuid: representativeCustomer.cryptoWallets[0]!.cryptoPositionUuid,
      customerFiatAccountUuid: representativeCustomer.fiatAccounts[0]!.customerFiatAccountUuid,
      orderType: 'MARKET' as const,
      buyAmount: 1,
      limitPrice: 1,
      stopPrice: 1,
      orderValidUntil: '2020-05-30',
    })

    buildBuyOrderPayload = helpers.buildBuyOrderPayload
    buildLimitBuyOrderPayload = helpers.buildLimitBuyOrderPayload
    buildMarketBuyOrderPayload = helpers.buildMarketBuyOrderPayload
    buildStopLossBuyOrderPayload = helpers.buildStopLossBuyOrderPayload
    buildStopLimitBuyOrderPayload = helpers.buildStopLimitBuyOrderPayload
  })

  describe(`(POST) ${CREATE_BUY_ORDER_URL}`, () => {
    describe('Happy Path', () => {
      it('should provide correct response for Limit Order', async () => {
        await placeBuyOrder(buildLimitBuyOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })

      it('should provide correct response for Market Order', async () => {
        await placeBuyOrder(buildMarketBuyOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })

      it('should provide correct response for Stop Loss Order', async () => {
        await placeBuyOrder(buildStopLossBuyOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })

      it('should provide correct response for Stop Limit Order', async () => {
        await placeBuyOrder(buildStopLimitBuyOrderPayload())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('orderUuid')
            expect(response.body.orderUuid).toBeDefined()
          })
      })
    })

    describe('Error Handling', () => {
      describe('customerUuid', () => {
        it('should return validation error (400) when customerUuid is missing', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ fieldsToOmit: ['customerUuid'] })).expect(400)
        })
        it('should return validation error (400) when customerUuid is empty', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { customerUuid: '' } })).expect(400)
        })
        it('should return validation error (400) when customerUuid is invalid', async () => {
          await placeBuyOrder(
            buildMarketBuyOrderPayload({ payload: { customerUuid: 'invalid-customer-uuid' } }),
          ).expect(400)
        })
        it('should return validation error (400) when customerUuid is not a string', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { customerUuid: 200 } })).expect(400)
        })
      })

      describe('cryptoPositionUuid', () => {
        it('should return validation error (400) when cryptoPositionUuid is missing', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ fieldsToOmit: ['cryptoPositionUuid'] })).expect(400)
        })
        it('should return validation error (400) when cryptoPositionUuid is invalid', async () => {
          await placeBuyOrder(
            buildMarketBuyOrderPayload({ payload: { cryptoPositionUuid: 'invalid-cryptoPositionUuid' } }),
          ).expect(400)
        })
        it('should return validation error (400) when cryptoPositionUuid is empty', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { cryptoPositionUuid: '' } })).expect(400)
        })
        it('should return validation error (400) when cryptoPositionUuid is not a string', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { cryptoPositionUuid: 200 } })).expect(400)
        })
      })

      describe('customerFiatAccountUuid', () => {
        it('should return validation error (400) when customerFiatAccountUuid is missing', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ fieldsToOmit: ['customerFiatAccountUuid'] })).expect(400)
        })
        it('should return validation error (400) when customerFiatAccountUuid is invalid', async () => {
          await placeBuyOrder(
            buildMarketBuyOrderPayload({ payload: { customerFiatAccountUuid: 'invalid-customerFiatAccountUuid' } }),
          ).expect(400)
        })
        it('should return validation error (400) when customerFiatAccountUuid is empty', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { customerFiatAccountUuid: '' } })).expect(400)
        })
        it('should return validation error (400) when customerFiatAccountUuid is not a string', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { customerFiatAccountUuid: 200 } })).expect(400)
        })
      })

      describe('buyAmount', () => {
        it('should return validation error (400) when buyAmount is missing', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ fieldsToOmit: ['buyAmount'] })).expect(400)
        })

        it('should return validation error (400) when buyAmount is not a number', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { buyAmount: 'not-a-number' } })).expect(400)
        })

        it('should return validation error (400) when buyAmount equal to 0', async () => {
          await placeBuyOrder(buildMarketBuyOrderPayload({ payload: { buyAmount: 0 } })).expect(400)
        })
      })

      describe('orderType', () => {
        it('should return validation error (400) when order type is invalid', async () => {
          await placeBuyOrder(buildBuyOrderPayload({ payload: { orderType: 'invalid-order-type' } })).expect(400)
        })
        it('should return validation error (400) when order type is MARKET and limitPrice is present', async () => {
          await placeBuyOrder(buildBuyOrderPayload({ payload: { orderType: 'MARKET', limitPrice: 1 } })).expect(400)
        })
        it('should return validation error (400) when order type is MARKET and orderValidUntil is present', async () => {
          await placeBuyOrder(
            buildBuyOrderPayload({ payload: { orderType: 'MARKET', orderValidUntil: '2020-05-30' } }),
          ).expect(400)
        })
      })

      describe('limitPrice', () => {
        it('should return validation error (400) when orderValidUntil is present and limitPrice is missing', async () => {
          await placeBuyOrder(buildLimitBuyOrderPayload({ fieldsToOmit: ['limitPrice'] })).expect(400)
        })
        it('should return validation error (400) when limitPrice is not a number', async () => {
          await placeBuyOrder(buildLimitBuyOrderPayload({ payload: { limitPrice: 'not-a-number' } })).expect(400)
        })
        it('should return validation error (400) when limitPrice is equal 0', async () => {
          await placeBuyOrder(buildLimitBuyOrderPayload({ payload: { limitPrice: 0 } })).expect(400)
        })
      })

      describe('orderValidUntil', () => {
        it('should return validation error (400) when valid limitPrice is present and orderValidUntil is missing', async () => {
          await placeBuyOrder(buildLimitBuyOrderPayload({ fieldsToOmit: ['orderValidUntil'] })).expect(400)
        })
        it('should return validation error (400) when valid limitPrice is present and orderValidUntil is empty', async () => {
          await placeBuyOrder(buildLimitBuyOrderPayload({ payload: { orderValidUntil: '' } })).expect(400)
        })
        it('should return validation error (400) when valid limitPrice is present and orderValidUntil has incorrect date format', async () => {
          await placeBuyOrder(buildLimitBuyOrderPayload({ payload: { orderValidUntil: '02-02-2020' } })).expect(400)
        })
      })

      describe('stopPrice', () => {
        it('should return validation error (400) when stopPrice is missing for STOP_LOSS', async () => {
          await placeBuyOrder(buildStopLossBuyOrderPayload({ fieldsToOmit: ['stopPrice'] })).expect(400)
        })
        it('should return validation error (400) when stopPrice is missing for STOP_LIMIT', async () => {
          await placeBuyOrder(buildStopLimitBuyOrderPayload({ fieldsToOmit: ['stopPrice'] })).expect(400)
        })
        it('should return validation error (400) when stopPrice is not a number', async () => {
          await placeBuyOrder(buildStopLossBuyOrderPayload({ payload: { stopPrice: 'not-a-number' } })).expect(400)
        })
        it('should return validation error (400) when stopPrice is equal 0', async () => {
          await placeBuyOrder(buildStopLossBuyOrderPayload({ payload: { stopPrice: 0 } })).expect(400)
        })
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
