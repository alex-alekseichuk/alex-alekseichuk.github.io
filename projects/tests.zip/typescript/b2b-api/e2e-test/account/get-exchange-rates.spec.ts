/* eslint-disable object-shorthand */
import { INestApplication } from '@nestjs/common'
import request from 'supertest'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'

const GET_EXCHANGE_RATES_URL = '/product/banking/account/v1/exchange-rates'

type ExchangeRatesQuery = { base?: string; quote?: string; source?: string }
type ExchangeRatesFieldsToOmmit = keyof ExchangeRatesQuery
type ExchangeRatesQueryBuilder = (data?: {
  query?: ExchangeRatesQuery
  fieldsToOmit?: ExchangeRatesFieldsToOmmit[]
}) => ExchangeRatesQuery

const buildExchangeRatesQuery: ExchangeRatesQueryBuilder = ({ query = {}, fieldsToOmit = [] } = {}) => ({
  ...(!fieldsToOmit.includes('base') && { base: query.base || 'BTC' }),
  ...(!fieldsToOmit.includes('quote') && { quote: query.quote || 'USD' }),
  ...(!fieldsToOmit.includes('source') && { source: query.source || 'INTERNAL' }),
})

describe('ExchangeRates', () => {
  let app: INestApplication

  function getExchangeRates(payload: ExchangeRatesQuery) {
    return request(app.getHttpServer()).post(GET_EXCHANGE_RATES_URL).send(payload)
  }

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    await app.init()
  })

  describe(`(POST) ${GET_EXCHANGE_RATES_URL}`, () => {
    describe('Happy Path', () => {
      it('should provide correct response for Exchange Rates', async () => {
        await getExchangeRates(buildExchangeRatesQuery())
          .expect(200)
          .expect('Content-Type', /json/)
          .then(response => {
            expect(response.body).toHaveProperty('base')
            expect(response.body).toHaveProperty('quote')
            expect(response.body).toHaveProperty('bid')
            expect(response.body).toHaveProperty('ask')
          })
      })
    })

    describe('Error Handling', () => {
      describe('Missing fields', () => {
        it('should raise an error if base currency is missing', async () => {
          await getExchangeRates(buildExchangeRatesQuery({ fieldsToOmit: ['base'] })).expect(400)
        })
        it('should raise an error if quote currency is missing', async () => {
          await getExchangeRates(buildExchangeRatesQuery({ fieldsToOmit: ['quote'] })).expect(400)
        })
        it('should raise an error if data source is missing', async () => {
          await getExchangeRates(buildExchangeRatesQuery({ fieldsToOmit: ['source'] })).expect(400)
        })
      })

      describe('Invalid values', () => {
        it('should raise an error if invalid data source was provided', async () => {
          await getExchangeRates(buildExchangeRatesQuery({ query: { source: 'invalid-data-source' } })).expect(400)
        })
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
