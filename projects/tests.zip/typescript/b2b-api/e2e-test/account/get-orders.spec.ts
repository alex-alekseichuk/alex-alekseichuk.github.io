import { INestApplication } from '@nestjs/common'
import { Customer } from 'account/models/customer.model'
import request from 'supertest'
import { AccountService } from 'account/account.service'
import { CustomError } from 'common/errors/custom.error'
import { getTestApplication } from '../common/application-module.factory'
import { getTestAccountModule } from './account-module.factory'

const GET_ORDERS_URL = (customerUuid: string) => `/product/banking/account/v1/customer/${customerUuid}/orders`

describe('Account', () => {
  let app: INestApplication
  let accountService: AccountService
  let representativeCustomer: Customer

  beforeAll(async () => {
    const module = await getTestAccountModule().compile()
    app = getTestApplication(module)
    accountService = module.get(AccountService)
    await app.init()

    /* Set the relevant customer from generated data - after using the data-generator user names and related entities uuids may change
     * Customer with index 4 should always have: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH)wp
     * */
    const customers = await accountService.getBalances('auth_token')
    representativeCustomer = customers[4]!
  })

  describe(`(GET) ${GET_ORDERS_URL(':customerUuid')}`, () => {
    describe('when C-Vault API is available', () => {
      describe('correct request input payload were provided', () => {
        it('should return status 200 if there is no errors', async () => {
          await request(app.getHttpServer()).post(GET_ORDERS_URL(representativeCustomer.customerUuid)).expect(200)
        })
        it('should return status 200 if proper request input payload provided', async () => {
          await request(app.getHttpServer())
            .post(GET_ORDERS_URL(representativeCustomer.customerUuid))
            .send({
              page: 1,
              perPage: 20,
              type: 'SELL_ORDERS_WAIT_FOR_DELIVERY',
              orderBy: 'CREATION_TIMESTAMP',
              direction: 'ASC',
            })
            .expect(200)
            .then(response => {
              expect(response.body).toBeDefined()
              expect(response.body).toHaveProperty('orders')
              expect(Array.isArray(response.body.orders)).toBeTruthy()
              expect(response.body).toHaveProperty('total')
              expect(response.body).toHaveProperty('page')
              expect(response.body).toHaveProperty('perPage')
            })
        })
      })
      describe('missing request input payload fields and defaulting', () => {
        let getOrdersSpy: jest.SpyInstance

        beforeEach(() => {
          getOrdersSpy = jest.spyOn(accountService, 'getOrders')
        })
        afterAll(() => {
          jest.resetAllMocks()
        })

        it('should pass default arguments to values specified by C-Vault API', async () => {
          await request(app.getHttpServer()).post(GET_ORDERS_URL(representativeCustomer.customerUuid)).expect(200)
          expect(getOrdersSpy).toBeCalledWith(expect.anything(), expect.anything(), {
            direction: 'ASC',
            page: -1,
            perPage: 20,
            type: 'ALL',
          })
        })
      })
      describe('wrong request input payload were provided', () => {
        it('should return 400 when invalid order "type" provided in request input payload', async () => {
          await request(app.getHttpServer())
            .post(GET_ORDERS_URL(representativeCustomer.customerUuid))
            .send({
              type: 'invalid-type',
            })
            .expect(400)
            .then(response => {
              expect(response.body).toBeDefined()
              expect(Array.isArray(response.body)).toBeTruthy()
              expect(response.body.length).toEqual(1)
              const errors: CustomError[] = response.body
              errors.forEach(error => {
                expect(error.field).toEqual('type')
                expect(error.constraints).toHaveProperty('isIn')
                expect(error.constraints!.isIn).toContain('BUY_ORDERS_WAIT_FOR_DELIVERY')
              })
            })
        })
        it('should return 400 when invalid order "page" provided in request input payload', async () => {
          await request(app.getHttpServer())
            .post(GET_ORDERS_URL(representativeCustomer.customerUuid))
            .send({
              page: 'invalid-page',
            })
            .expect(400)
            .then(response => {
              expect(response.body).toBeDefined()
              expect(Array.isArray(response.body)).toBeTruthy()
              expect(response.body.length).toEqual(1)
              const errors: CustomError[] = response.body
              errors.forEach(error => {
                expect(error.field).toEqual('page')
                expect(error.constraints).toHaveProperty('isInt')
              })
            })
        })
        it('should return 400 when invalid order "perPage" provided in request input payload', async () => {
          await request(app.getHttpServer())
            .post(GET_ORDERS_URL(representativeCustomer.customerUuid))
            .send({
              perPage: 'invalid-page',
            })
            .expect(400)
            .then(response => {
              expect(response.body).toBeDefined()
              expect(Array.isArray(response.body)).toBeTruthy()
              expect(response.body.length).toEqual(1)
              const errors: CustomError[] = response.body
              errors.forEach(error => {
                expect(error.field).toEqual('perPage')
                expect(error.constraints).toHaveProperty('isInt')
              })
            })
        })
        it('should return 400 when invalid order "orderBy" provided in request input payload', async () => {
          await request(app.getHttpServer())
            .post(GET_ORDERS_URL(representativeCustomer.customerUuid))
            .send({
              orderBy: 'invalid-order-by',
            })
            .expect(400)
            .then(response => {
              expect(response.body).toBeDefined()
              expect(Array.isArray(response.body)).toBeTruthy()
              expect(response.body.length).toEqual(1)
              const errors: CustomError[] = response.body
              errors.forEach(error => {
                expect(error.field).toEqual('orderBy')
                expect(error.constraints).toHaveProperty('isIn')
                expect(error.constraints!.isIn).toContain('CRYPTO_CURRENCY_TYPE')
              })
            })
        })
        it('should return 400 when invalid order "direction" provided in request input payload', async () => {
          await request(app.getHttpServer())
            .post(GET_ORDERS_URL(representativeCustomer.customerUuid))
            .send({
              direction: 'invalid-order-by',
            })
            .expect(400)
            .then(response => {
              expect(response.body).toBeDefined()
              expect(Array.isArray(response.body)).toBeTruthy()
              expect(response.body.length).toEqual(1)
              const errors: CustomError[] = response.body
              errors.forEach(error => {
                expect(error.field).toEqual('direction')
                expect(error.constraints).toHaveProperty('isIn')
                expect(error.constraints!.isIn).toContain('ASC')
              })
            })
        })
      })
    })
  })

  afterAll(async () => {
    await app.close()
  })
})
