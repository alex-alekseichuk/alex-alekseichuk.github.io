import { CanActivate, ExecutionContext } from '@nestjs/common'

export class AuthGuardMock implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest()
    request.headers.auth = request.headers.auth ?? 'auth_token'
    return true
  }
}
