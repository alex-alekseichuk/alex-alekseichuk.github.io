import faker from 'faker'

export class CustomConfigServiceMock {
  getString(_key: string, _: { required?: boolean; fallback?: string } = {}) {
    return faker.random.alphaNumeric()
  }

  getNumber(_key: string, _: { required?: boolean; fallback?: number } = {}) {
    return faker.random.number({ min: 1, max: 999999 })
  }

  getBoolean(_key: string, _: { required?: boolean; fallback?: boolean } = {}) {
    return faker.random.boolean()
  }
}
