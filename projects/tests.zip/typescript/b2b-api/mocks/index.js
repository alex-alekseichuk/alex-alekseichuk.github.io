const path = require('path');
const dotenv = require('dotenv');
const expressListRoutes = require('express-list-routes');

dotenv.config({
  path: path.resolve(__dirname, '..', '.env'),
});

const { app } = require('./src/common/presenters/rest/bootstrap-express');
const { globalOptions } = require('./src/mockserver-configuration');

const port = globalOptions.PORT;

app.listen(port, () => {
  console.log(`Mock server listening at http://localhost:${port}`);
});

expressListRoutes(app);
