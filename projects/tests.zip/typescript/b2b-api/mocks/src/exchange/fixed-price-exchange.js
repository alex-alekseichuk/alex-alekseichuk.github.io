const { cryptoCurrencyExchangeOptions } = require('../mockserver-configuration');

class FixedPriceExchange {
  exchangeRates = new Map(cryptoCurrencyExchangeOptions.EXCHANGE_FIXED_RATES);
  fallbackRate = cryptoCurrencyExchangeOptions.EXCHANGE_FIXED_FALLBACK_RATE;

  setRate(ticker, rate) {
    this.exchangeRates.set(ticker, rate);
  }

  setFallbackRate(fallbackRate) {
    this.fallbackRate = fallbackRate;
  }

  getUnitPriceFor({ cryptoCurrencyType, currency }) {
    const rate = this.exchangeRates.get(`${cryptoCurrencyType}_${currency}`);
    return rate ?? this.fallbackRate;
  }

  toJSON() {
    return {
      exchangeRates: [...this.exchangeRates.entries()].reduce((rates, [ticker, rate]) => ({ ...rates, ...{ [ticker]: rate } }), {}),
      fallbackRate: this.fallbackRate,
    };
  }
}

exports.FixedPriceExchange = FixedPriceExchange;
