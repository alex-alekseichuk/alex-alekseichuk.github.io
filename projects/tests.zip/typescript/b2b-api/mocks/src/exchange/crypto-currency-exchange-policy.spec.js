const { CryptoCurrencyExchangePolicy } = require('./crypto-currency-exchange.policy');

describe('CryptoCurrencyExchangePolicy', () => {
  it('shoul work bulk exchange trigger', async () => {
    const policy = new CryptoCurrencyExchangePolicy();
    const exchangeSpy = jest.spyOn(policy, 'getUnitPriceFor').mockImplementation(async ({ cryptoCurrencyType }) => (cryptoCurrencyType === 'BTC' ? -1 : 42));

    const exchangeData = [
      { cryptoCurrencyType: 'ETH', currency: 'PLN' },
      { cryptoCurrencyType: 'BTC', currency: 'PLN' },
      { cryptoCurrencyType: 'ETH', currency: 'PLN' },
    ];

    const result = await policy.getBulkUnitPriceFor(exchangeData);

    expect(result).toHaveLength(3);
    expect(result[0]).toEqual(42);
    expect(result[1]).toEqual(-1);
    expect(result[2]).toEqual(42);
    expect(exchangeSpy).toHaveBeenCalledTimes(2);
  });
});
