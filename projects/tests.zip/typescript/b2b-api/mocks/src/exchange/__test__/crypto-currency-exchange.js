const BigNumber = require('bignumber.js');

class CryptoCurrencyExchange {
  getInitialPriceFor({ cryptoCurrencyType, currency, quantity, fixedPrice }) {
    return BigNumber(this.getUnitPriceFor({ cryptoCurrencyType, currency, fixedPrice })).times(quantity).toNumber();
  }

  getBulkUnitPriceFor(initialData) {
    return initialData.map(data => this.getInitialPriceFor(data));
  }

  getUnitPriceFor({ fixedPrice }) {
    return BigNumber(fixedPrice ?? 1000).toNumber();
  }
}

exports.CryptoCurrencyExchange = CryptoCurrencyExchange;
