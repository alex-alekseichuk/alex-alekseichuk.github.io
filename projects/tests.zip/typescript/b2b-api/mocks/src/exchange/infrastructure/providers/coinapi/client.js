const axios = require('axios');

class CoinApiClient {
  constructor(coinApiUrl, apiKey, exchangePrefix) {
    this.coinApiUrl = coinApiUrl;
    this.exchangePrefix = exchangePrefix;
    this.client = axios.create({
      headers: { 'X-CoinAPI-Key': apiKey },
      baseURL: coinApiUrl,
    });
  }

  async getExchangeRate(base, quote) {
    const { data } = await this.client.get(`v1/exchangerate/${base}/${quote}`);
    return data.rate;
  }

  async getCurrentPricing(base, quote) {
    const { data } = await this.client.get(`v1/quotes/${this.exchangePrefix}_${base}_${quote}/current`);
    return {
      bid: data.bid_price,
      ask: data.ask_price,
    };
  }

  toJSON() {
    return {
      coinApiUrl: this.coinApiUrl,
      exchangePrefix: this.exchangePrefix,
    };
  }
}

exports.CoinApiClient = CoinApiClient;
