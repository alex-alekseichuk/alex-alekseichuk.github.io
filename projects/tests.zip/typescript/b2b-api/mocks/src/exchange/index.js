const { CryptoCurrencyExchangePolicy } = require('./crypto-currency-exchange.policy');
const { FixedPriceExchange } = require('./fixed-price-exchange');
const { cryptoCurrencyExchangeOptions } = require('../mockserver-configuration');

const { CoinApiClient } = require('./infrastructure/providers/coinapi/client');

const buildCoinApiClient = () => {
  if (process.env.NODE_ENV === 'test') {
    return;
  }
  if (!cryptoCurrencyExchangeOptions.COIN_API_URL) {
    return console.warn('Missing CoinAPI setting: MOCK_SERVER_COIN_API_URL. Omitting creation of CoinApi client.');
  }
  if (!cryptoCurrencyExchangeOptions.COIN_API_APIKEY) {
    return console.warn('Missing CoinAPI setting: MOCK_SERVER_COIN_API_APIKEY. Omitting creation of CoinApi client.');
  }

  return new CoinApiClient(cryptoCurrencyExchangeOptions.COIN_API_URL, cryptoCurrencyExchangeOptions.COIN_API_APIKEY, cryptoCurrencyExchangeOptions.COINBASE_SPOT_PRICING_PREFIX);
};

const buildLogger = () => {
  if (process.env.NODE_ENV === 'test') {
    return;
  }
  return console;
};

exports.exchange = new CryptoCurrencyExchangePolicy(new FixedPriceExchange(), buildCoinApiClient(), buildLogger());
