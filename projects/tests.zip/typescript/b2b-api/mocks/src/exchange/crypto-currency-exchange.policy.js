const BigNumber = require('bignumber.js');

class CryptoCurrencyExchangePolicy {
  constructor(fixedPriceExchange, coinApiClient, logger) {
    this.fixedPriceExchange = fixedPriceExchange;
    this.coinApiClient = coinApiClient;
    this.logger = logger;

    this.allowMarketPrices = !!coinApiClient;
  }

  setAllowMarketPrices(allowMarketPrices) {
    this.allowMarketPrices = this.coinApiClient && allowMarketPrices;
  }

  setRate(ticker, rate) {
    this.fixedPriceExchange.setRate(ticker, rate);
  }

  setFallbackRate(fallbackRate) {
    this.fixedPriceExchange.setFallbackRate(fallbackRate);
  }

  async getInitialPriceFor({ cryptoCurrencyType, currency, quantity, fixedPrice }) {
    return this._times(await this.getUnitPriceFor({ cryptoCurrencyType, currency, fixedPrice }), quantity);
  }

  async getBulkUnitPriceFor(exchangeBulkData) {
    const priceMap = new Map();
    const tickerFor = ({ cryptoCurrencyType, currency }) => `${cryptoCurrencyType}_${currency}`;
    const result = [];
    for (let data of exchangeBulkData) {
      if (priceMap.has(tickerFor(data))) {
        result.push(priceMap.get(tickerFor(data)));
      } else {
        const price = await this.getUnitPriceFor({ cryptoCurrencyType: data.cryptoCurrencyType, currency: data.currency });
        priceMap.set(tickerFor(data), price);
        result.push(price);
      }
    }

    return result;
  }

  async getUnitPriceFor({ fixedPrice, ...data }) {
    if (fixedPrice) {
      return fixedPrice;
    }
    try {
      const marketPrice = await this.coinApiClient.getExchangeRate(data.cryptoCurrencyType, data.currency);
      if (marketPrice) {
        return marketPrice;
      }
    } catch (_error) {
      this.logger?.warn(`Could not fetch exchange rate for pair ${data.cryptoCurrencyType}/${data.currency}. Entering fallback.`);
    }
    return this.fixedPriceExchange.getUnitPriceFor(data);
  }

  async getCurrentPricing(base, quote) {
    try {
      const pricing = await this.coinApiClient.getCurrentPricing(base, quote);
      if (pricing) {
        return pricing;
      }
    } catch (_error) {
      this.logger?.warn(`Could not fetch BID/ASK quotes for pair ${base}/${quote}. Entering fallback.`);
    }
    const value = this.fixedPriceExchange.getUnitPriceFor({ cryptoCurrencyType: base, currency: quote });
    return {
      bid: value,
      ask: value,
    };
  }

  toJSON() {
    return {
      allowMarketPrices: this.allowMarketPrices,
      fixedPriceExchange: this.fixedPriceExchange.toJSON(),
      coinApiClient: this.coinApiClient.toJSON(),
    };
  }

  _times(price, quantity) {
    return BigNumber(price).times(quantity).toNumber();
  }
}

exports.CryptoCurrencyExchangePolicy = CryptoCurrencyExchangePolicy;
