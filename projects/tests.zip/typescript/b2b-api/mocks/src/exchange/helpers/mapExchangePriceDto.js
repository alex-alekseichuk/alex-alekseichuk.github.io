const mapExchangePriceDto = exchangePriceEntry => {
  return {
    ...(exchangePriceEntry.ask && { askPrice: exchangePriceEntry.ask }),
    ...(exchangePriceEntry.bid && { bidPrice: exchangePriceEntry.bid }),
    baseCurrency: exchangePriceEntry.base,
    quoteCurrency: exchangePriceEntry.quote,
    timestamp: new Date().getTime(),
    organisationUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    algoTraderAccountId: 0,
  };
};

exports.mapExchangePriceDto = mapExchangePriceDto;
