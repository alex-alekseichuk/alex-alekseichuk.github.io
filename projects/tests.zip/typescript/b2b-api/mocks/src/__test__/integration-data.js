exports.integrationTestData = [
  {
    customerUuid: 'customer-1-uuid',
    alias: 'alias',
    type: 'type',
    fiatAccounts: [
      { customerUuid: 'customer-1-uuid', customerFiatAccountUuid: 'fiat-account-0-uuid', balance: 0, currency: 'USD', accountId: 'accountId' },
      { customerUuid: 'customer-1-uuid', customerFiatAccountUuid: 'fiat-account-1-uuid', balance: 10000, currency: 'USD', accountId: 'accountId' },
    ],
    cryptoPositions: [
      { customerUuid: 'customer-1-uuid', cryptoPositionUuid: 'crypto-position-0-uuid', availableBalance: 0, cryptoCurrencyType: 'SHIB' },
      { customerUuid: 'customer-1-uuid', cryptoPositionUuid: 'crypto-position-1-uuid', availableBalance: 100, cryptoCurrencyType: 'SHIB' },
    ],
  },
];
