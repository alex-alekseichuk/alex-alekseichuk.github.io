const marketBuyPayload = ({ buyAmount = 10, customerFiatAccountUuid = 'fiat-account-1-uuid', cryptoPositionUuid = 'crypto-position-1-uuid' } = {}) => ({
  buyAmount,
  exchangeCurrency: 'CHF',
  debitCustomerFiatAccount: {
    customerFiatAccountUuid,
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  creditCryptoPosition: {
    cryptoPositionUuid,
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
});

const marketSellPayload = ({ sellAmount = 10, customerFiatAccountUuid = 'fiat-account-1-uuid', cryptoPositionUuid = 'crypto-position-1-uuid' } = {}) => ({
  sellAmount,
  exchangeCurrency: 'CHF',
  creditCustomerFiatAccount: {
    customerFiatAccountUuid,
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  debitCryptoPosition: {
    cryptoPositionUuid,
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
});

const limitSellPayload = ({
  sellAmount = 10,
  customerFiatAccountUuid = 'fiat-account-1-uuid',
  cryptoPositionUuid = 'crypto-position-1-uuid',
  limitAmount = 10,
  orderValidUntil = '2120-05-30',
} = {}) => ({
  sellAmount,
  limitAmount,
  orderValidUntil,
  exchangeCurrency: 'CHF',
  creditCustomerFiatAccount: {
    customerFiatAccountUuid,
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  debitCryptoPosition: {
    cryptoPositionUuid,
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
});

const limitBuyPayload = ({
  buyAmount = 10,
  customerFiatAccountUuid = 'fiat-account-1-uuid',
  cryptoPositionUuid = 'crypto-position-1-uuid',
  limitAmount = 10,
  orderValidUntil = '2120-05-30',
} = {}) => ({
  buyAmount,
  limitAmount,
  orderValidUntil,
  exchangeCurrency: 'CHF',
  debitCustomerFiatAccount: {
    customerFiatAccountUuid,
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  creditCryptoPosition: {
    cryptoPositionUuid,
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
});

const marketStopBuyPayload = ({ stopAmount = 1000, buyAmount = 10, customerFiatAccountUuid = 'fiat-account-1-uuid', cryptoPositionUuid = 'crypto-position-1-uuid' } = {}) => ({
  buyAmount,
  stopAmount,
  exchangeCurrency: 'CHF',
  debitCustomerFiatAccount: {
    customerFiatAccountUuid,
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  creditCryptoPosition: {
    cryptoPositionUuid,
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
});

const limitStopBuyPayload = ({
  stopAmount = 1000,
  buyAmount = 1,
  customerFiatAccountUuid = 'fiat-account-1-uuid',
  cryptoPositionUuid = 'crypto-position-1-uuid',
  limitAmount = 1000,
  orderValidUntil = '2120-05-30',
} = {}) => ({
  buyAmount,
  stopAmount,
  limitAmount,
  orderValidUntil,
  exchangeCurrency: 'CHF',
  debitCustomerFiatAccount: {
    customerFiatAccountUuid,
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  creditCryptoPosition: {
    cryptoPositionUuid,
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
});

const safeWhile = async predicate => {
  const max = 10;
  for (let i = 0; i < max; i++) {
    if (!(await predicate())) {
      return;
    }
  }
  throw new Error(`Maximum iterations reached!`);
};

exports.marketBuyPayload = marketBuyPayload;
exports.marketSellPayload = marketSellPayload;
exports.limitSellPayload = limitSellPayload;
exports.limitBuyPayload = limitBuyPayload;
exports.marketStopBuyPayload = marketStopBuyPayload;
exports.limitStopBuyPayload = limitStopBuyPayload;
exports.safeWhile = safeWhile;
