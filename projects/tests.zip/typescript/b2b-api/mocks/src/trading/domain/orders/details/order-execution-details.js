const { DateTime } = require('luxon');

class OrderExecutionDetails {
  constructor(quantity, unitPrice) {
    this.transactionQuantity = quantity;
    this.transactionAmountFilled = quantity;
    this.executionPrice = unitPrice;
    this.transactionAmount = quantity * unitPrice;

    this.lastExecutionTimestamp = undefined;
  }

  setLastExecutionTimestamp(lastExecutionTimestamp) {
    this.lastExecutionTimestamp = lastExecutionTimestamp;
  }

  toJSON() {
    return {
      transactionQuantity: this.transactionQuantity,
      transactionAmountFilled: this.transactionAmountFilled,
      executionPrice: this.executionPrice,
      transactionAmount: this.transactionAmount,
      lastExecutionTimestamp: this._formatOrderExecutionDate(this.lastExecutionTimestamp),
    };
  }

  _formatOrderExecutionDate(date) {
    return DateTime.fromJSDate(date, { zone: 'utc' }).toISO({ suppressMilliseconds: true });
  }
}

exports.OrderExecutionDetails = OrderExecutionDetails;
