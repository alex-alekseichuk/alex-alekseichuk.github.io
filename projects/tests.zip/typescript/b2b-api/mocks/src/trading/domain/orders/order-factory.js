const { BuyOrder } = require('./buy-order');
const { SellOrder } = require('./sell-order');

const { LimitOrderDecorator } = require('./decorators/limit-order-decorator');
const { StopOrderDecorator } = require('./decorators/stop-order-decorator');
const { orderCannotBeInstantiated } = require('../../../common/errors');

class OrderFactory {
  fromPayload(payload) {
    if (payload?.buyAmount) {
      return this.decorateOrder(new BuyOrder(payload), payload);
    }
    if (payload?.sellAmount) {
      return this.decorateOrder(new SellOrder(payload), payload);
    }
    throw orderCannotBeInstantiated();
  }

  decorateOrder(order, payload) {
    let result = order;
    if (this.isLimitOrder(payload)) {
      result = new LimitOrderDecorator(result, payload);
    }
    if (this.isStopOrder(payload)) {
      result = new StopOrderDecorator(result, payload);
    }
    result.setTradeOrderSubType(this.orderSubtypeFor(payload));
    return result;
  }

  orderSubtypeFor = payload => {
    if (this.isLimitOrder(payload) && this.isStopOrder(payload)) {
      return 'STOP_LIMIT';
    }
    if (this.isLimitOrder(payload)) {
      return 'LIMIT';
    }
    if (this.isStopOrder(payload)) {
      return 'STOP_LOSS';
    }
    return 'MARKET';
  };

  isLimitOrder = payload => !!(payload?.limitAmount && payload?.orderValidUntil);

  isStopOrder = payload => !!payload?.stopAmount;
}

exports.OrderFactory = OrderFactory;
