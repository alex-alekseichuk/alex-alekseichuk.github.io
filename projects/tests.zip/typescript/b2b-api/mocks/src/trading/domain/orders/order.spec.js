const { Order } = require('./order');

describe('Order', () => {
  it('should generate order execution timestamp when reaching execution state', () => {
    const order = new Order({});
    order.preExecute(1000);
    order.execute(new Date('2020-05-30'));

    const { lastExecutionTimestamp } = order.toJSON();
    expect(order.toJSON().lastExecutionTimestamp).toEqual(lastExecutionTimestamp);
  });
});
