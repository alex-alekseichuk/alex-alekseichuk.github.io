const { tradingOrderStates } = require('../../../../mockserver-configuration');
const { OrderFactory } = require('../order-factory');
const { buildSellOrderPayload } = require('./__test__/helpers');

describe('Sell Market Order', () => {
  let marketOrder;

  beforeEach(() => {
    marketOrder = new OrderFactory().fromPayload(
      buildSellOrderPayload({
        sellAmount: 10,
      })
    );
  });

  it('Has correct states transitions', () => {
    expect(marketOrder.availableStates()).toEqual(tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES);
    expect(marketOrder.canBeCancelled()).toEqual(false);
  });

  it('Passes correct initialData', () => {
    expect(marketOrder.toInitialJSON()).toEqual(
      expect.objectContaining({
        quantity: 10,
        cryptoCurrencyType: 'ETH',
        currency: 'CHF',
      })
    );
  });

  it('Creates correct basic JSON payload for non-executed orders', () => {
    const marketOrderPayload = marketOrder.toJSON();
    expect(marketOrderPayload.tradeOrderSubType).toEqual('MARKET');
    expect(marketOrderPayload.cryptoPosition.cryptoCurrencyType).toEqual('ETH');
    expect(marketOrderPayload.cryptoPosition.cryptoPositionUuid).toEqual('1a81bacf-bb2a-4786-a278-6eb230d14d7b');
    expect(marketOrderPayload.cryptoPosition.cryptoPositionType).toEqual('PLEDGED');
    expect(marketOrderPayload.debitOrCreditCustomerFiatAccount.customerFiatAccountUuid).toEqual('6abb6847-78bb-40d4-bd47-8e7fe5b7951f');
    expect(marketOrderPayload.debitOrCreditCustomerFiatAccount.currency).toEqual('CHF');
    expect(marketOrderPayload.debitOrCreditCustomerFiatAccount.iban).toEqual('CH46 8301 4840 0004 3455 9');
    expect(marketOrderPayload.orderType).toEqual('OM007_SELL_CRYPTO_CURRENCY');
  });

  it('Creates correct extended JSON payload for non-executed orders', () => {
    marketOrder.preExecute(1000);
    marketOrder.execute();
    const marketOrderExtendedPayload = marketOrder.toJSON();

    expect(marketOrderExtendedPayload.tradeOrderSubType).toEqual('MARKET');
    expect(marketOrderExtendedPayload.cryptoPosition.cryptoCurrencyType).toEqual('ETH');
    expect(marketOrderExtendedPayload.cryptoPosition.cryptoPositionUuid).toEqual('1a81bacf-bb2a-4786-a278-6eb230d14d7b');
    expect(marketOrderExtendedPayload.cryptoPosition.cryptoPositionType).toEqual('PLEDGED');
    expect(marketOrderExtendedPayload.debitOrCreditCustomerFiatAccount.customerFiatAccountUuid).toEqual('6abb6847-78bb-40d4-bd47-8e7fe5b7951f');
    expect(marketOrderExtendedPayload.debitOrCreditCustomerFiatAccount.currency).toEqual('CHF');
    expect(marketOrderExtendedPayload.debitOrCreditCustomerFiatAccount.iban).toEqual('CH46 8301 4840 0004 3455 9');
    expect(marketOrderExtendedPayload.orderType).toEqual('OM007_SELL_CRYPTO_CURRENCY');

    expect(Number.isFinite(marketOrderExtendedPayload.transactionAmount)).toBeTruthy();
    expect(Number.isFinite(marketOrderExtendedPayload.transactionAmountFilled)).toBeTruthy();
    expect(marketOrderExtendedPayload.transactionQuantity).toEqual(marketOrderExtendedPayload.transactionAmountFilled);

    expect(Number.isFinite(marketOrderExtendedPayload.executionPrice)).toBeTruthy();
    expect(() => new Date(marketOrderExtendedPayload.lastExecutionTimestamp)).not.toThrow();
  });
});
