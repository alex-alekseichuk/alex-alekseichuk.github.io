const { DateTime } = require('luxon');

class OrderDetails {
  constructor(orderData, timestampOrderReceived = new Date()) {
    this.tradeOrderSubType = orderData.tradeOrderSubType;
    this.cryptoCurrencyType = orderData.cryptoCurrencyType;
    this.cryptoPositionUuid = orderData.cryptoPositionUuid;
    this.cryptoPositionType = orderData.cryptoPositionType;
    this.customerFiatAccountUuid = orderData.customerFiatAccountUuid;
    this.currency = orderData.currency;
    this.iban = orderData.iban;
    this.orderType = orderData.orderType;
    this.timestampOrderReceived = this._formatOrderDetailsDate(timestampOrderReceived);
  }

  setTradeOrderSubType(tradeOrderSubType) {
    this.tradeOrderSubType = tradeOrderSubType;
  }

  toJSON() {
    return {
      tradeOrderSubType: this.tradeOrderSubType,
      cryptoPosition: {
        cryptoCurrencyType: this.cryptoCurrencyType,
        cryptoPositionUuid: this.cryptoPositionUuid,
        cryptoPositionType: this.cryptoPositionType,
      },
      debitOrCreditCustomerFiatAccount: {
        customerFiatAccountUuid: this.customerFiatAccountUuid,
        currency: this.currency,
        iban: this.iban,
      },
      orderType: this.orderType,
      timestampOrderReceived: this.timestampOrderReceived,
    };
  }

  _formatOrderDetailsDate(date) {
    return DateTime.fromJSDate(date, { zone: 'utc' }).toISO({ suppressMilliseconds: true });
  }
}

exports.OrderDetails = OrderDetails;
