const { tradingOrderStates } = require('../../../../mockserver-configuration');
const { OrderFactory } = require('../order-factory');
const { buildBuyOrderPayload } = require('./__test__/helpers');

describe('Buy Limit Order', () => {
  let limitOrder;

  beforeEach(() => {
    limitOrder = new OrderFactory().fromPayload(
      buildBuyOrderPayload({
        buyAmount: 1000,
        limitAmount: 2137,
        orderValidUntil: '2120-05-20',
      })
    );
  });

  it('should have correct states transitions', () => {
    expect(limitOrder.availableStates()).toEqual(tradingOrderStates.LIMIT_ORDER_PRE_EXECUTION_STATES);
    expect(limitOrder.canBeCancelled(tradingOrderStates.LIMIT_ORDER_PRE_EXECUTION_STATES[1])).toEqual(true);
    expect(limitOrder.canBeCancelled(tradingOrderStates.EXECUTION_STATES[1])).toEqual(false);
  });

  it('should pass correct initialData', () => {
    expect(limitOrder.toInitialJSON()).toEqual(
      expect.objectContaining({
        quantity: 1000,
        fixedPrice: 2137,
        cryptoCurrencyType: 'ETH',
        currency: 'CHF',
      })
    );
  });

  it('should create correct basic JSON payload for non-executed orders', () => {
    const limitOrderPayload = limitOrder.toJSON();
    expect(limitOrderPayload.tradeOrderSubType).toEqual('LIMIT');
    expect(limitOrderPayload.cryptoPosition.cryptoCurrencyType).toEqual('ETH');
    expect(limitOrderPayload.cryptoPosition.cryptoPositionUuid).toEqual('1a81bacf-bb2a-4786-a278-6eb230d14d7b');
    expect(limitOrderPayload.debitOrCreditCustomerFiatAccount.customerFiatAccountUuid).toEqual('6abb6847-78bb-40d4-bd47-8e7fe5b7951f');
    expect(limitOrderPayload.debitOrCreditCustomerFiatAccount.currency).toEqual('CHF');
    expect(limitOrderPayload.debitOrCreditCustomerFiatAccount.iban).toEqual('CH46 8301 4840 0004 3455 9');
    expect(limitOrderPayload.orderType).toEqual('OM006_BUY_CRYPTO_CURRENCY');

    expect(limitOrderPayload.expiryTimestamp).toEqual('2120-05-19T23:59:59Z');
    expect(limitOrderPayload.limitPrice).toEqual(2137);
  });

  it('should create correct extended JSON payload for executed orders and assign limitPrice as executionPrice', () => {
    limitOrder.preExecute(50);
    limitOrder.execute();
    const limitOrderExtendedPayload = limitOrder.toJSON();

    expect(limitOrderExtendedPayload.tradeOrderSubType).toEqual('LIMIT');
    expect(limitOrderExtendedPayload.cryptoPosition.cryptoCurrencyType).toEqual('ETH');
    expect(limitOrderExtendedPayload.cryptoPosition.cryptoPositionUuid).toEqual('1a81bacf-bb2a-4786-a278-6eb230d14d7b');
    expect(limitOrderExtendedPayload.debitOrCreditCustomerFiatAccount.customerFiatAccountUuid).toEqual('6abb6847-78bb-40d4-bd47-8e7fe5b7951f');
    expect(limitOrderExtendedPayload.debitOrCreditCustomerFiatAccount.currency).toEqual('CHF');
    expect(limitOrderExtendedPayload.debitOrCreditCustomerFiatAccount.iban).toEqual('CH46 8301 4840 0004 3455 9');
    expect(limitOrderExtendedPayload.orderType).toEqual('OM006_BUY_CRYPTO_CURRENCY');

    expect(limitOrderExtendedPayload.transactionAmount).toEqual(2137000);
    expect(limitOrderExtendedPayload.transactionAmountFilled).toEqual(1000);
    expect(limitOrderExtendedPayload.executionPrice).toEqual(2137);
    expect(limitOrderExtendedPayload.transactionQuantity).toEqual(1000);
    expect(limitOrderExtendedPayload.limitPrice).toEqual(2137);

    expect(() => new Date(limitOrderExtendedPayload.lastExecutionTimestamp)).not.toThrow();
    expect(limitOrderExtendedPayload.expiryTimestamp).toEqual('2120-05-19T23:59:59Z');
  });
});
