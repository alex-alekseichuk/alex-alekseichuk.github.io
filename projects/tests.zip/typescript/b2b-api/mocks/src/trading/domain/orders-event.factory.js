const { cannotInstantiateOrderEvent } = require('../../common/errors');
const { BUY_CRYPTO_ORDER_TYPE, SELL_CRYPTO_ORDER_TYPE } = require('./orders/order');

const { BuyOrderExecutedEvent, SellOrderExecutedEvent } = require('../../common/events/trading/order-executed.event');
const { BuyOrderRequestedEvent, SellOrderRequestedEvent } = require('../../common/events/trading/order-requested.event');
const { BuyOrderCancelledEvent, SellOrderCancelledEvent } = require('../../common/events/trading/order-cancelled.event');
const { BuyOrderRejectedEvent, SellOrderRejectedEvent } = require('../../common/events/trading/order-rejected.event');
const { BuyOrderExecutionRequestedEvent, SellOrderExecutionRequestedEvent } = require('../../common/events/trading/order-execution-requested.event');
const { BuyOrderExpiredEvent, SellOrderExpiredEvent } = require('../../common/events/trading/order-expired.event');

class OrdersEventFactory {
  requestedFromOrder(customerUuid, orderUuid, order) {
    if (order.orderType === BUY_CRYPTO_ORDER_TYPE) {
      return new BuyOrderRequestedEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    if (order.orderType === SELL_CRYPTO_ORDER_TYPE) {
      return new SellOrderRequestedEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    throw cannotInstantiateOrderEvent('Requested', order.orderType);
  }

  executedFromOrder(customerUuid, orderUuid, order) {
    if (order.orderType === BUY_CRYPTO_ORDER_TYPE) {
      return new BuyOrderExecutedEvent({
        ...this._fromExecutedOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    if (order.orderType === SELL_CRYPTO_ORDER_TYPE) {
      return new SellOrderExecutedEvent({
        ...this._fromExecutedOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    throw cannotInstantiateOrderEvent('Executed', order.orderType);
  }

  cancelledFromOrder(customerUuid, orderUuid, order) {
    if (order.orderType === BUY_CRYPTO_ORDER_TYPE) {
      return new BuyOrderCancelledEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    if (order.orderType === SELL_CRYPTO_ORDER_TYPE) {
      return new SellOrderCancelledEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    throw cannotInstantiateOrderEvent('Cancelled', order.orderType);
  }

  rejectedFromOrder(customerUuid, orderUuid, order) {
    if (order.orderType === BUY_CRYPTO_ORDER_TYPE) {
      return new BuyOrderRejectedEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    if (order.orderType === SELL_CRYPTO_ORDER_TYPE) {
      return new SellOrderRejectedEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    throw cannotInstantiateOrderEvent('Rejected', order.orderType);
  }

  executionRequestedFromOrder(customerUuid, orderUuid, order) {
    if (order.orderType === BUY_CRYPTO_ORDER_TYPE) {
      return new BuyOrderExecutionRequestedEvent({
        ...this._fromAboutToExecutedOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    if (order.orderType === SELL_CRYPTO_ORDER_TYPE) {
      return new SellOrderExecutionRequestedEvent({
        ...this._fromAboutToExecutedOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    throw cannotInstantiateOrderEvent('Executed', order.orderType);
  }

  expiredFromOrder(customerUuid, orderUuid, order) {
    if (order.orderType === BUY_CRYPTO_ORDER_TYPE) {
      return new BuyOrderExpiredEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    if (order.orderType === SELL_CRYPTO_ORDER_TYPE) {
      return new SellOrderExpiredEvent({
        ...this._fromInitialOrder(order),
        customerUuid,
        orderUuid,
      });
    }
    throw cannotInstantiateOrderEvent('Rejected', order.orderType);
  }

  _fromInitialOrder(order) {
    return {
      customerFiatAccountUuid: order.debitOrCreditCustomerFiatAccount?.customerFiatAccountUuid,
      cryptoPositionUuid: order.cryptoPosition?.cryptoPositionUuid,
      quantity: order.quantity,
      initialPrice: order.initialPrice,
    };
  }

  _fromAboutToExecutedOrder(order) {
    return {
      customerFiatAccountUuid: order.debitOrCreditCustomerFiatAccount?.customerFiatAccountUuid,
      cryptoPositionUuid: order.cryptoPosition?.cryptoPositionUuid,
      transactionAmount: order.transactionAmount,
      initialPrice: order.initialPrice,
    };
  }

  _fromExecutedOrder(order) {
    return {
      customerFiatAccountUuid: order.debitOrCreditCustomerFiatAccount?.customerFiatAccountUuid,
      cryptoPositionUuid: order.cryptoPosition?.cryptoPositionUuid,
      transactionQuantity: order.transactionQuantity,
      transactionAmount: order.transactionAmount,
      initialPrice: order.initialPrice,
    };
  }
}

exports.OrdersEventFactory = new OrdersEventFactory();
