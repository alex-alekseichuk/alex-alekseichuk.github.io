const { BUY_CRYPTO_ORDER_TYPE, SELL_CRYPTO_ORDER_TYPE } = require('./orders/order');
const { OrdersEventFactory } = require('./orders-event.factory');
const { BuyOrderExecutedEvent, SellOrderExecutedEvent } = require('../../common/events/trading/order-executed.event');
const { BuyOrderRequestedEvent, SellOrderRequestedEvent } = require('../../common/events/trading/order-requested.event');
const { BuyOrderCancelledEvent, SellOrderCancelledEvent } = require('../../common/events/trading/order-cancelled.event');
const { BuyOrderRejectedEvent, SellOrderRejectedEvent } = require('../../common/events/trading/order-rejected.event');
const { BuyOrderExecutionRequestedEvent, SellOrderExecutionRequestedEvent } = require('../../common/events/trading/order-execution-requested.event');
const { BuyOrderExpiredEvent, SellOrderExpiredEvent } = require('../../common/events/trading/order-expired.event');

describe('Orders Event Factory', () => {
  describe('Requested', () => {
    it('throws an error if invalid order type passed', () => {
      expect(() => OrdersEventFactory.requestedFromOrder('customer-uuid', 'order-uuid', { orderType: 'invalid' })).toThrow();
    });
    it('creates BuyOrderRequested event for buy order', () => {
      expect(OrdersEventFactory.requestedFromOrder('customer-uuid', 'order-uuid', { orderType: BUY_CRYPTO_ORDER_TYPE }, { quantity: 50, initialPrice: 100 })).toBeInstanceOf(BuyOrderRequestedEvent);
    });
    it('creates SellOrderRequested event for sell order', () => {
      expect(OrdersEventFactory.requestedFromOrder('customer-uuid', 'order-uuid', { orderType: SELL_CRYPTO_ORDER_TYPE }, { quantity: 50, initialPrice: 100 })).toBeInstanceOf(SellOrderRequestedEvent);
    });
  });

  describe('Executed', () => {
    it('throws an error if invalid order type passed', () => {
      expect(() => OrdersEventFactory.executedFromOrder('customer-uuid', 'order-uuid', { orderType: 'invalid' })).toThrow();
    });
    it('creates BuyOrderExecuted event for buy order', () => {
      expect(OrdersEventFactory.executedFromOrder('customer-uuid', 'order-uuid', { orderType: BUY_CRYPTO_ORDER_TYPE })).toBeInstanceOf(BuyOrderExecutedEvent);
    });
    it('creates SellOrderExecuted event for sell order', () => {
      expect(OrdersEventFactory.executedFromOrder('customer-uuid', 'order-uuid', { orderType: SELL_CRYPTO_ORDER_TYPE })).toBeInstanceOf(SellOrderExecutedEvent);
    });
  });

  describe('Cancelled', () => {
    it('throws an error if invalid order type passed', () => {
      expect(() => OrdersEventFactory.cancelledFromOrder('customer-uuid', 'order-uuid', { orderType: 'invalid' })).toThrow();
    });
    it('creates BuyOrderCancelled event for buy order', () => {
      expect(OrdersEventFactory.cancelledFromOrder('customer-uuid', 'order-uuid', { orderType: BUY_CRYPTO_ORDER_TYPE })).toBeInstanceOf(BuyOrderCancelledEvent);
    });
    it('creates SellOrderCancelled event for sell order', () => {
      expect(OrdersEventFactory.cancelledFromOrder('customer-uuid', 'order-uuid', { orderType: SELL_CRYPTO_ORDER_TYPE })).toBeInstanceOf(SellOrderCancelledEvent);
    });
  });

  describe('Rejected', () => {
    it('throws an error if invalid order type passed', () => {
      expect(() => OrdersEventFactory.rejectedFromOrder('customer-uuid', 'order-uuid', { orderType: 'invalid' })).toThrow();
    });
    it('creates BuyOrderCancelled event for buy order', () => {
      expect(OrdersEventFactory.rejectedFromOrder('customer-uuid', 'order-uuid', { orderType: BUY_CRYPTO_ORDER_TYPE })).toBeInstanceOf(BuyOrderRejectedEvent);
    });
    it('creates SellOrderCancelled event for sell order', () => {
      expect(OrdersEventFactory.rejectedFromOrder('customer-uuid', 'order-uuid', { orderType: SELL_CRYPTO_ORDER_TYPE })).toBeInstanceOf(SellOrderRejectedEvent);
    });
  });

  describe('ExecutionRequested', () => {
    it('throws an error if invalid order type passed', () => {
      expect(() => OrdersEventFactory.executionRequestedFromOrder('customer-uuid', 'order-uuid', { orderType: 'invalid' })).toThrow();
    });
    it('creates BuyOrderExecuted event for buy order', () => {
      expect(OrdersEventFactory.executionRequestedFromOrder('customer-uuid', 'order-uuid', { orderType: BUY_CRYPTO_ORDER_TYPE })).toBeInstanceOf(BuyOrderExecutionRequestedEvent);
    });
    it('creates SellOrderExecuted event for sell order', () => {
      expect(OrdersEventFactory.executionRequestedFromOrder('customer-uuid', 'order-uuid', { orderType: SELL_CRYPTO_ORDER_TYPE })).toBeInstanceOf(SellOrderExecutionRequestedEvent);
    });
  });

  describe('Expired', () => {
    it('throws an error if invalid order type passed', () => {
      expect(() => OrdersEventFactory.expiredFromOrder('customer-uuid', 'order-uuid', { orderType: 'invalid' })).toThrow();
    });
    it('creates BuyOrderExecuted event for buy order', () => {
      expect(OrdersEventFactory.expiredFromOrder('customer-uuid', 'order-uuid', { orderType: BUY_CRYPTO_ORDER_TYPE })).toBeInstanceOf(BuyOrderExpiredEvent);
    });
    it('creates SellOrderExecuted event for sell order', () => {
      expect(OrdersEventFactory.expiredFromOrder('customer-uuid', 'order-uuid', { orderType: SELL_CRYPTO_ORDER_TYPE })).toBeInstanceOf(SellOrderExpiredEvent);
    });
  });
});
