const buildBuyOrderPayload = data => ({
  exchangeCurrency: 'CHF',
  debitCustomerFiatAccount: {
    customerFiatAccountUuid: '6abb6847-78bb-40d4-bd47-8e7fe5b7951f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  creditCryptoPosition: {
    cryptoPositionUuid: '1a81bacf-bb2a-4786-a278-6eb230d14d7b',
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
  ...data,
});

const buildSellOrderPayload = data => ({
  exchangeCurrency: 'CHF',
  creditCustomerFiatAccount: {
    customerFiatAccountUuid: '6abb6847-78bb-40d4-bd47-8e7fe5b7951f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    accountId: '55800032731868080505',
    currency: 'CHF',
    iban: 'CH46 8301 4840 0004 3455 9',
    isDefault: false,
    isActive: true,
  },
  debitCryptoPosition: {
    cryptoPositionUuid: '1a81bacf-bb2a-4786-a278-6eb230d14d7b',
    logicalWalletUuid: 'cd6035bf-ce50-4ab5-9c38-8aae0e5832c8',
    cryptoPositionBundleUuid: '968e913f-b6e9-4f5d-b665-f52f253d1737',
    cryptoProductPositionUuid: 'dde971d3-8570-4e0c-9240-a494b6cabe5f',
    customerUuid: '09baf63b-1df4-46ce-9055-a1bbb9b49dd4',
    cryptoPositionType: 'PLEDGED',
    cryptoPositionBundleName: 'ETH Pledge',
    actions: ['READ'],
    cryptoCurrencyType: 'ETH',
    state: 'ACTIVE',
  },
  ...data,
});

exports.buildBuyOrderPayload = buildBuyOrderPayload;
exports.buildSellOrderPayload = buildSellOrderPayload;
