const { last } = require('lodash');
const { tradingOrderStates } = require('../../../../mockserver-configuration');
const { OrderFactory } = require('../order-factory');
const { buildSellOrderPayload } = require('./__test__/helpers');

describe('Buy Stop Loss Order', () => {
  let stopLossOrder;

  beforeEach(() => {
    stopLossOrder = new OrderFactory().fromPayload(
      buildSellOrderPayload({
        stopAmount: 1100,
        sellAmount: 2,
      })
    );
  });

  it('Has correct states transitions', () => {
    expect(stopLossOrder.availableStates()).toEqual(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES);
    expect(stopLossOrder.canBeCancelled()).toEqual(false);
  });

  it('Passes correct initialData', () => {
    expect(stopLossOrder.toInitialJSON()).toEqual(
      expect.objectContaining({
        quantity: 2,
        cryptoCurrencyType: 'ETH',
        currency: 'CHF',
      })
    );
  });

  it('Creates correct basic JSON payload for non-executed orders', () => {
    const payload = stopLossOrder.toJSON();
    expect(payload.tradeOrderSubType).toEqual('STOP_LOSS');
    expect(payload.cryptoPosition.cryptoCurrencyType).toEqual('ETH');
    expect(payload.cryptoPosition.cryptoPositionUuid).toEqual('1a81bacf-bb2a-4786-a278-6eb230d14d7b');
    expect(payload.cryptoPosition.cryptoPositionType).toEqual('PLEDGED');
    expect(payload.debitOrCreditCustomerFiatAccount.customerFiatAccountUuid).toEqual('6abb6847-78bb-40d4-bd47-8e7fe5b7951f');
    expect(payload.debitOrCreditCustomerFiatAccount.currency).toEqual('CHF');
    expect(payload.debitOrCreditCustomerFiatAccount.iban).toEqual('CH46 8301 4840 0004 3455 9');
    expect(payload.orderType).toEqual('OM007_SELL_CRYPTO_CURRENCY');
  });

  it('Creates correct extended JSON payload for non-executed orders', () => {
    stopLossOrder.preExecute(1000);
    stopLossOrder.execute();
    const payload = stopLossOrder.toJSON();

    expect(payload.tradeOrderSubType).toEqual('STOP_LOSS');
    expect(payload.cryptoPosition.cryptoCurrencyType).toEqual('ETH');
    expect(payload.cryptoPosition.cryptoPositionUuid).toEqual('1a81bacf-bb2a-4786-a278-6eb230d14d7b');
    expect(payload.cryptoPosition.cryptoPositionType).toEqual('PLEDGED');
    expect(payload.debitOrCreditCustomerFiatAccount.customerFiatAccountUuid).toEqual('6abb6847-78bb-40d4-bd47-8e7fe5b7951f');
    expect(payload.debitOrCreditCustomerFiatAccount.currency).toEqual('CHF');
    expect(payload.debitOrCreditCustomerFiatAccount.iban).toEqual('CH46 8301 4840 0004 3455 9');
    expect(payload.orderType).toEqual('OM007_SELL_CRYPTO_CURRENCY');

    expect(payload.transactionAmount).toEqual(2000);
    expect(payload.transactionAmountFilled).toEqual(2);
    expect(payload.transactionQuantity).toEqual(2);
    expect(payload.transactionAmountFilled).toEqual(2);

    expect(payload.executionPrice).toEqual(1000);

    expect(() => new Date(payload.lastExecutionTimestamp)).not.toThrow();
  });

  describe('Execution Strategy', () => {
    describe('Rising Strategy', () => {
      let risingTriggeredOrder;

      beforeEach(() => {
        risingTriggeredOrder = new OrderFactory().fromPayload(
          buildSellOrderPayload({
            stopAmount: 1100,
            sellAmount: 2,
          })
        );
        risingTriggeredOrder.setInitialMarketUnitPrice(1000);
      });

      const shouldRequestExecutionWithPrice = unitPrice => risingTriggeredOrder.shouldRequestExecution(last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES), unitPrice);

      it('should allow to execute an order if initialPrice was lower than stopAmount and rising price crosses the stopAmount', () => {
        expect(shouldRequestExecutionWithPrice(1101)).toEqual(true);
      });
      it('should not allow execute an order if initialPrice was lower than stopAmount and rising price does not cross the stopAmount', () => {
        expect(shouldRequestExecutionWithPrice(1099)).toEqual(false);
      });
      it('should not allow execute an order if initialPrice was lower than stopAmount and price drops', () => {
        expect(shouldRequestExecutionWithPrice(999)).toEqual(false);
      });
    });

    describe('Falling Strategy', () => {
      let fallingTriggeredOrder;

      beforeEach(() => {
        fallingTriggeredOrder = new OrderFactory().fromPayload(
          buildSellOrderPayload({
            stopAmount: 900,
            sellAmount: 2,
          })
        );
        fallingTriggeredOrder.setInitialMarketUnitPrice(1000);
      });

      const shouldRequestExecutionWithPrice = unitPrice => fallingTriggeredOrder.shouldRequestExecution(last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES), unitPrice);

      it('should allow to execute an order if initialPrice was higher than stopAmount and falling price crosses the stopAmount', () => {
        expect(shouldRequestExecutionWithPrice(899)).toEqual(true);
      });
      it('should not allow execute an order if initialPrice was higher than stopAmount and falling price does not cross the stopAmount', () => {
        expect(shouldRequestExecutionWithPrice(901)).toEqual(false);
      });
      it('should not allow execute an order if initialPrice was higher than stopAmount and price raises', () => {
        expect(shouldRequestExecutionWithPrice(1001)).toEqual(false);
      });
    });
  });
});
