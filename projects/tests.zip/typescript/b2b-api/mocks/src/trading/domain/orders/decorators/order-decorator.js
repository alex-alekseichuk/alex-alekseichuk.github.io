class OrderDecorator {
  constructor(order, _orderBody) {
    this.order = order;
  }

  setInitialMarketUnitPrice(initialPrice) {
    this.order.setInitialMarketUnitPrice(initialPrice);
  }

  setTradeOrderSubType(tradeOrderSubType) {
    this.order.setTradeOrderSubType(tradeOrderSubType);
  }

  canBeCancelled(state) {
    return this.order.canBeCancelled(state);
  }

  canBeExecuted(_state) {
    throw new Error('Not implemented');
  }

  shouldBeExpired(state, date) {
    return this.order.shouldBeExpired(state, date);
  }

  shouldBeRejected() {
    return this.order.shouldBeRejected();
  }

  shouldRequestExecution(_state) {
    throw new Error('Not implemented');
  }

  availableStates() {
    return this.order.availableStates();
  }

  preExecute(unitPrice) {
    return this.order.preExecute(unitPrice);
  }

  execute(executionTimestamp = new Date()) {
    return this.order.execute(executionTimestamp);
  }

  toInitialJSON() {
    return this.order.toInitialJSON();
  }

  toPreExecuteJSON() {
    return this.order.toPreExecuteJSON();
  }

  toJSON() {
    return this.order.toJSON();
  }
}

exports.OrderDecorator = OrderDecorator;
