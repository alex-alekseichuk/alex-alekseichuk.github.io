const { last } = require('lodash');
const { DateTime } = require('luxon');
const { tradingOrderStates, limitOrderPrices } = require('../../../../mockserver-configuration');
const { OrderDecorator } = require('./order-decorator');

class LimitOrderDecorator extends OrderDecorator {
  constructor(order, orderBody) {
    super(order);
    this.expiryDate = new Date(orderBody.orderValidUntil);
    this.expiryTimestamp = this._formatOrderExpiryTimestamp(this.expiryDate);
    this.limitPrice = orderBody.limitAmount;
  }

  canBeCancelled(state) {
    return tradingOrderStates.LIMIT_ORDER_CANCELLABLE_STATES.includes(state);
  }

  canBeExecuted(state) {
    return this.limitPrice === limitOrderPrices.LIMIT_ORDER_EXECUTION_PRICE && state === last(tradingOrderStates.LIMIT_ORDER_PRE_EXECUTION_STATES);
  }

  shouldBeExpired(state, date) {
    return tradingOrderStates.LIMIT_ORDER_PRE_EXECUTION_STATES.includes(state) && this._isExpired(date);
  }

  shouldBeRejected() {
    return this.limitPrice === limitOrderPrices.LIMIT_ORDER_REJECT_PRICE;
  }

  shouldRequestExecution(state, _unitPrice) {
    return this.canBeExecuted(state);
  }

  availableStates() {
    return tradingOrderStates.LIMIT_ORDER_PRE_EXECUTION_STATES;
  }

  preExecute(_unitPrice) {
    return this.order.preExecute(this.limitPrice);
  }

  toInitialJSON() {
    return {
      ...this.order.toInitialJSON(),
      fixedPrice: this.limitPrice,
    };
  }

  toJSON() {
    return {
      ...this.order.toJSON(),
      expiryTimestamp: this.expiryTimestamp,
      limitPrice: this.limitPrice,
    };
  }

  _formatOrderExpiryTimestamp(date) {
    return DateTime.fromJSDate(date, { zone: 'utc' }).minus({ seconds: 1 }).toISO({ suppressMilliseconds: true });
  }

  _isExpired(fetchDate) {
    return fetchDate.getTime() > this.expiryDate.getTime();
  }
}

exports.LimitOrderDecorator = LimitOrderDecorator;
