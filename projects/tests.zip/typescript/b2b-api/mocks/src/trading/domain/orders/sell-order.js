const { last } = require('lodash');
const { tradingOrderStates } = require('../../../mockserver-configuration');
const { Order, SELL_CRYPTO_ORDER_TYPE } = require('./order');

class SellOrder extends Order {
  constructor(sellOrderBody) {
    super({
      orderType: SELL_CRYPTO_ORDER_TYPE,
      quantity: sellOrderBody.sellAmount,
      cryptoCurrencyType: sellOrderBody?.debitCryptoPosition?.cryptoCurrencyType,
      cryptoPositionUuid: sellOrderBody?.debitCryptoPosition?.cryptoPositionUuid,
      cryptoPositionType: sellOrderBody?.debitCryptoPosition?.cryptoPositionType,
      customerFiatAccountUuid: sellOrderBody?.creditCustomerFiatAccount?.customerFiatAccountUuid,
      currency: sellOrderBody?.creditCustomerFiatAccount?.currency,
      iban: sellOrderBody?.creditCustomerFiatAccount?.iban,
    });
  }

  canBeExecuted(state) {
    return !this.isExecuted && state === last(tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES);
  }

  shouldRequestExecution(state, _unitPrice) {
    return this.canBeExecuted(state);
  }
}

exports.SellOrder = SellOrder;
