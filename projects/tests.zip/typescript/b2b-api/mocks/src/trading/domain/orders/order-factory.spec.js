const { BUY_CRYPTO_ORDER_TYPE, SELL_CRYPTO_ORDER_TYPE } = require('./order');
const { OrderFactory } = require('./order-factory');

describe('Order Factory', () => {
  const factory = new OrderFactory();

  it('throws an error if invalid payload passed', () => {
    expect(() => factory.fromPayload({})).toThrow();
  });

  describe('Market', () => {
    it('creates BuyOrder', () => {
      const order = factory.fromPayload({ buyAmount: 50 });
      expect(order.toJSON().tradeOrderSubType).toEqual('MARKET');
      expect(order.toJSON().orderType).toEqual(BUY_CRYPTO_ORDER_TYPE);
    });

    it('creates SellOrder', () => {
      const order = factory.fromPayload({ sellAmount: 50 });
      expect(order.toJSON().tradeOrderSubType).toEqual('MARKET');
      expect(order.toJSON().orderType).toEqual(SELL_CRYPTO_ORDER_TYPE);
    });
  });

  describe('Limit', () => {
    it('creates BuyLimitOrder', () => {
      const order = factory.fromPayload({ buyAmount: 50, limitAmount: 100, orderValidUntil: '2020-05-20' });
      expect(order.toJSON().tradeOrderSubType).toEqual('LIMIT');
      expect(order.toJSON().orderType).toEqual(BUY_CRYPTO_ORDER_TYPE);
    });

    it('creates SellLimitOrder', () => {
      const order = factory.fromPayload({ sellAmount: 50, limitAmount: 100, orderValidUntil: '2020-05-20' });
      expect(order.toJSON().tradeOrderSubType).toEqual('LIMIT');
      expect(order.toJSON().orderType).toEqual(SELL_CRYPTO_ORDER_TYPE);
    });
  });

  describe('Stop', () => {
    it('creates Buy Stop Loss Order', () => {
      const order = factory.fromPayload({ buyAmount: 50, stopAmount: 1000 });
      expect(order.toJSON().tradeOrderSubType).toEqual('STOP_LOSS');
      expect(order.toJSON().orderType).toEqual(BUY_CRYPTO_ORDER_TYPE);
    });

    it('creates Sell Stop Loss Order', () => {
      const order = factory.fromPayload({ sellAmount: 50, stopAmount: 1000 });
      expect(order.toJSON().tradeOrderSubType).toEqual('STOP_LOSS');
      expect(order.toJSON().orderType).toEqual(SELL_CRYPTO_ORDER_TYPE);
    });

    it('creates Buy Stop Limit Order', () => {
      const order = factory.fromPayload({ buyAmount: 50, limitAmount: 100, orderValidUntil: '2020-05-20', stopAmount: 1000 });
      expect(order.toJSON().tradeOrderSubType).toEqual('STOP_LIMIT');
      expect(order.toJSON().orderType).toEqual(BUY_CRYPTO_ORDER_TYPE);
    });

    it('creates Sell Stop Limit Order', () => {
      const order = factory.fromPayload({ sellAmount: 50, limitAmount: 100, orderValidUntil: '2020-05-20', stopAmount: 1000 });
      expect(order.toJSON().tradeOrderSubType).toEqual('STOP_LIMIT');
      expect(order.toJSON().orderType).toEqual(SELL_CRYPTO_ORDER_TYPE);
    });
  });
});
