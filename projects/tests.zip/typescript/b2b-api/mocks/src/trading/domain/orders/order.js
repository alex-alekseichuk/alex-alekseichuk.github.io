const { tradingOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const BUY_CRYPTO_ORDER_TYPE = 'OM006_BUY_CRYPTO_CURRENCY';
const SELL_CRYPTO_ORDER_TYPE = 'OM007_SELL_CRYPTO_CURRENCY';

class Order {
  constructor(orderData) {
    this.orderDetails = new OrderDetails(orderData);

    this.quantity = orderData.quantity;

    this.executionDetails = null;
    this.isExecuted = false;
  }

  setInitialMarketUnitPrice(_initialPrice) {}

  setTradeOrderSubType(tradeOrderSubType) {
    this.orderDetails.setTradeOrderSubType(tradeOrderSubType);
  }

  canBeCancelled(_state) {
    return false;
  }

  canBeExecuted(_state) {
    throw new Error('Not implemented');
  }

  shouldBeExpired(_state, _date) {
    return false;
  }

  shouldBeRejected() {
    return false;
  }

  shouldRequestExecution(_state, _unitPrice) {
    throw new Error('Not implemented');
  }

  availableStates() {
    return tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES;
  }

  preExecute(unitPrice) {
    this.executionDetails = new OrderExecutionDetails(this.quantity, unitPrice);
  }

  execute(executionTimestamp = new Date()) {
    this.executionDetails.setLastExecutionTimestamp(executionTimestamp);
    this.isExecuted = true;
  }

  toInitialJSON() {
    return {
      ...this.toJSON(),
      quantity: this.quantity,
      cryptoCurrencyType: this.orderDetails.cryptoCurrencyType,
      currency: this.orderDetails.currency,
    };
  }

  toPreExecuteJSON() {
    return {
      transactionAmount: this.executionDetails.transactionAmount,
    };
  }

  toJSON() {
    return {
      ...this.orderDetails.toJSON(),
      ...(this.isExecuted && this.executionDetails.toJSON()),
    };
  }
}

exports.Order = Order;
exports.BUY_CRYPTO_ORDER_TYPE = BUY_CRYPTO_ORDER_TYPE;
exports.SELL_CRYPTO_ORDER_TYPE = SELL_CRYPTO_ORDER_TYPE;
