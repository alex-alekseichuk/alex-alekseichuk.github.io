const { tradingOrderStates } = require('../../mockserver-configuration');
const { OrdersEventFactory } = require('./orders-event.factory');
const { StateMachine } = require('../../common/shared/state-machine/state-machine');

class TrackedOrder {
  constructor({ order, customerUuid, orderUuid, orderId, initialPrice, flushAt }) {
    this.order = order;
    this.stateMachine = new StateMachine(order.availableStates());

    this.customerUuid = customerUuid;
    this.orderUuid = orderUuid;
    this.orderId = orderId;
    this.initialPrice = initialPrice;

    this.flushAt = flushAt;

    this.cancelled = false;
    this.expired = false;
    this.markedAsRejected = false;
    this.rejected = false;
    this.executed = false;
  }

  setInitialMarketUnitPrice(unitPrice) {
    this.order.setInitialMarketUnitPrice(unitPrice);
  }

  state() {
    return {
      ...this.order.toJSON(),
      orderState: this.stateMachine.state,
      cancellable: this._isCancellable(),
      customerUuid: this.customerUuid,
      orderUuid: this.orderUuid,
      orderId: this.orderId,
    };
  }

  toInitialJSON() {
    return {
      ...this.order.toInitialJSON(),
      customerUuid: this.customerUuid,
      orderUuid: this.orderUuid,
      initialPrice: this.initialPrice,
    };
  }

  next(unitPrice, fetchDate = new Date()) {
    if (this._shouldBeRejected()) {
      return this._reject();
    }
    if (this._shouldBeExpired(fetchDate)) {
      return this._expire();
    }
    if (this._shouldRequestExecution(this.stateMachine.state, unitPrice)) {
      return this._requestExecution(unitPrice);
    }
    this.stateMachine.next();
  }

  cancel() {
    if (this._canBeCancelled()) {
      return this._cancel();
    }
  }

  execute(executionTimestamp = new Date()) {
    if (this._canBeExecuted(this.stateMachine.state)) {
      return this._execute(executionTimestamp);
    }
  }

  markAsRejected() {
    this.markedAsRejected = true;
  }

  forceReject() {
    return this._reject();
  }

  _requestExecution(unitPrice) {
    this.order.preExecute(unitPrice);

    return OrdersEventFactory.executionRequestedFromOrder(
      this.customerUuid,
      this.orderUuid,
      this._buildExecutionState({
        ...this.order.toPreExecuteJSON(),
      })
    );
  }

  _execute(executionTimestamp) {
    this.executed = true;
    this.order.execute(executionTimestamp);
    this.stateMachine = new StateMachine(tradingOrderStates.EXECUTION_STATES);
    return OrdersEventFactory.executedFromOrder(this.customerUuid, this.orderUuid, this._buildExecutionState());
  }

  _reject() {
    this.rejected = true;
    this.stateMachine = new StateMachine(tradingOrderStates.REJECTED_ORDER_STATES);
    return OrdersEventFactory.rejectedFromOrder(this.customerUuid, this.orderUuid, this.toInitialJSON());
  }

  _cancel() {
    this.cancelled = true;
    this.stateMachine = new StateMachine(tradingOrderStates.CANCELLED_ORDER_STATES);
    return OrdersEventFactory.cancelledFromOrder(this.customerUuid, this.orderUuid, this.toInitialJSON());
  }

  _expire() {
    this.expired = true;
    this.stateMachine = new StateMachine(tradingOrderStates.EXPIRED_ORDER_STATES);
    return OrdersEventFactory.expiredFromOrder(this.customerUuid, this.orderUuid, this.toInitialJSON());
  }

  _canBeCancelled = () => !this.markedAsRejected && this._isCancellable();

  _canBeExecuted = state => this._isOnTheMainTrack() && !this._shouldBeRejected() && this.order.canBeExecuted(state);

  _isCancellable = () => this._isOnTheMainTrack() && this.order.canBeCancelled(this.stateMachine.state);

  _shouldRequestExecution = (state, unitPrice) => this._isOnTheMainTrack() && !this._shouldBeRejected() && this.order.shouldRequestExecution(state, unitPrice);

  _shouldBeExpired = fetchDate => !this._shouldBeRejected() && this.order.shouldBeExpired(this.stateMachine.state, fetchDate);

  _shouldBeRejected = () => this._isOnTheMainTrack() && (this.markedAsRejected || this.order.shouldBeRejected());

  _isOnTheMainTrack = () => !this.executed && !this.rejected && !this.cancelled && !this.expired;

  _buildExecutionState(executionPricingData) {
    return {
      ...this.state(),
      ...executionPricingData,
      initialPrice: this.initialPrice,
    };
  }
}

exports.TrackedOrder = TrackedOrder;
