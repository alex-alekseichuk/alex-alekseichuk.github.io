const { last } = require('lodash');
const { tradingOrderStates } = require('../../../../mockserver-configuration');
const { OrderDecorator } = require('./order-decorator');

class StopOrderDecorator extends OrderDecorator {
  constructor(order, orderBody) {
    super(order);
    this.stopAmount = orderBody.stopAmount;
    this.initialPrice = null;
  }

  setInitialMarketUnitPrice(initialPrice) {
    this.initialPrice = initialPrice;
  }

  canBeExecuted(state) {
    return state === last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES);
  }

  shouldRequestExecution(state, unitPrice) {
    return this.canBeExecuted(state) && this.shouldTriggerExecutionFor(unitPrice);
  }

  availableStates() {
    return tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES;
  }

  toJSON() {
    return {
      ...this.order.toJSON(),
      stopPrice: this.stopAmount,
    };
  }

  shouldTriggerExecutionFor(unitPrice) {
    const isRisingStrategy = this.stopAmount >= this.initialPrice;
    const isFallingStrategy = this.stopAmount <= this.initialPrice;

    if (isRisingStrategy) {
      return unitPrice >= this.stopAmount;
    } else if (isFallingStrategy) {
      return unitPrice <= this.stopAmount;
    }

    return false;
  }
}

exports.StopOrderDecorator = StopOrderDecorator;
