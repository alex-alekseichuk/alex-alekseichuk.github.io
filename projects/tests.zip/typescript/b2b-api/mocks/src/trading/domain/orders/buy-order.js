const { last } = require('lodash');
const { tradingOrderStates } = require('../../../mockserver-configuration');
const { Order, BUY_CRYPTO_ORDER_TYPE } = require('./order');

class BuyOrder extends Order {
  constructor(buyOrderBody) {
    super({
      orderType: BUY_CRYPTO_ORDER_TYPE,
      quantity: buyOrderBody.buyAmount,
      cryptoCurrencyType: buyOrderBody?.creditCryptoPosition?.cryptoCurrencyType,
      cryptoPositionUuid: buyOrderBody?.creditCryptoPosition?.cryptoPositionUuid,
      cryptoPositionType: buyOrderBody?.creditCryptoPosition?.cryptoPositionType,
      customerFiatAccountUuid: buyOrderBody?.debitCustomerFiatAccount?.customerFiatAccountUuid,
      currency: buyOrderBody?.debitCustomerFiatAccount?.currency,
      iban: buyOrderBody?.debitCustomerFiatAccount?.iban,
    });
  }

  canBeExecuted(state) {
    return !this.isExecuted && state === last(tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES);
  }

  shouldRequestExecution(state, _unitPrice) {
    return this.canBeExecuted(state);
  }
}

exports.BuyOrder = BuyOrder;
