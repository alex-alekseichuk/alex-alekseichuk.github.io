const { BUY_CRYPTO_ORDER_TYPE } = require('./orders/order');
const { TrackedOrder } = require('./tracked-order');

const buildOrder = ({ availableStates = ['INITIAL', 'VALIDATED', 'DISPOSED'], cancellable = true, shouldBeRejected = false, canBeExecuted = false, shouldBeExpired = false } = {}) => ({
  canBeCancelled: jest.fn().mockImplementation(() => cancellable),
  canBeExecuted: jest.fn().mockImplementation(() => canBeExecuted),
  availableStates: jest.fn().mockImplementation(() => availableStates),
  shouldBeRejected: jest.fn().mockImplementation(() => shouldBeRejected),
  shouldRequestExecution: jest.fn().mockImplementation(() => canBeExecuted),
  shouldBeExpired: jest.fn().mockImplementation(() => shouldBeExpired),
  execute: jest.fn(),
  preExecute: jest.fn(),
  toInitialJSON: jest.fn().mockImplementation(() => ({ orderType: BUY_CRYPTO_ORDER_TYPE })),
  toPreExecuteJSON: jest.fn().mockImplementation(),
  toJSON: jest.fn().mockImplementation(() => ({ orderType: BUY_CRYPTO_ORDER_TYPE })),
});

const createTrackedOrder = ({ order = buildOrder() } = {}) => new TrackedOrder({ order, orderUuid: 'orderUuid', orderId: 'orderId', customerUuid: 'customerUuid', initialPrice: 1000 });

describe('Tracked Order', () => {
  describe('create()', () => {
    it('should bypass constructor data', () => {
      expect(createTrackedOrder().state().orderUuid).toEqual('orderUuid');
      expect(createTrackedOrder().state().orderId).toEqual('orderId');
      expect(createTrackedOrder().state().customerUuid).toEqual('customerUuid');
    });

    it('should delegate payload creation to Order status', () => {
      const order = buildOrder();
      createTrackedOrder({ order }).state();
      expect(order.toJSON).toBeCalled();
    });
  });

  describe('state()', () => {
    describe('orderState', () => {
      it('should step through available order states', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ availableStates: ['state-1', 'state-2'] }) });
        expect(trackedOrder.state().orderState).toEqual('state-1');
        trackedOrder.next(1000);
        expect(trackedOrder.state().orderState).toEqual('state-2');
        trackedOrder.next(1000);
      });
    });

    describe('cancellable property', () => {
      it('should be cancellable for cancellable orders', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });
        expect(trackedOrder.state().cancellable).toEqual(true);
      });
      it('should not be cancellable for non-cancellable orders', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: false }) });
        expect(trackedOrder.state().cancellable).toEqual(false);
      });
      it('should not be cancellable for already cancelled order', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });
        trackedOrder.cancel();
        expect(trackedOrder.state().cancellable).toEqual(false);
      });
      it('should be cancellable for order marked as rejected', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });
        trackedOrder.markAsRejected();
        expect(trackedOrder.state().cancellable).toEqual(true);
      });
      it('should not be cancellable for rejected order', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });
        trackedOrder.markAsRejected();
        trackedOrder.next(1000);
        expect(trackedOrder.state().cancellable).toEqual(false);
      });
      it('cancel event should be produced only once on state transition', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });

        expect(trackedOrder.cancel()).toEqual(expect.objectContaining({ type: expect.stringContaining('CANCELLED') }));
        expect(trackedOrder.cancel()).toEqual(undefined);
        expect(trackedOrder.next(1000)).toEqual(undefined);
        expect(trackedOrder.next(1000)).toEqual(undefined);
      });
    });
  });

  describe('next()', () => {
    describe('execution', () => {
      it('should produce ORDER_EXECUTION_REQUESTED event when order should be executed on transition with executionPrice based on cryptoCurrency value', () => {
        const order = buildOrder({ canBeExecuted: true });
        const trackedOrder = createTrackedOrder({ order });

        expect(trackedOrder.next(1000)).toEqual(expect.objectContaining({ type: expect.stringContaining('ORDER_EXECUTION_REQUESTED') }));

        expect(order.preExecute).toHaveBeenCalledWith(1000);
      });

      it('should execute an order that should be executed and produce an event', () => {
        const order = buildOrder({ canBeExecuted: true });
        const trackedOrder = createTrackedOrder({ order });

        expect(trackedOrder.execute('2020-05-20')).toEqual(expect.objectContaining({ type: expect.stringContaining('ORDER_EXECUTED') }));

        expect(trackedOrder.state().orderState).toEqual('EXECUTED');
        expect(order.execute).toBeCalledWith('2020-05-20');
      });

      it('should not execute already cancelled order', () => {
        const order = buildOrder({ cancellable: true });
        const trackedOrder = createTrackedOrder({ order });

        expect(trackedOrder.cancel()).toEqual(expect.objectContaining({ type: expect.stringContaining('CANCELLED') }));
        expect(trackedOrder.execute()).toEqual(undefined);

        expect(trackedOrder.state().orderState).not.toEqual('EXECUTED');
      });

      it('should not execute marked as rejected order', () => {
        const trackedOrder = createTrackedOrder({ canBeExecuted: true });

        trackedOrder.markAsRejected();
        expect(trackedOrder.execute()).toEqual(undefined);

        expect(trackedOrder.state().orderState).not.toEqual('EXECUTED');
      });

      it('should not execute already rejected order', () => {
        const trackedOrder = createTrackedOrder({ canBeExecuted: true });

        trackedOrder.markAsRejected();
        expect(trackedOrder.next(1000)).toEqual(expect.objectContaining({ type: expect.stringContaining('REJECTED') }));
        expect(trackedOrder.execute()).toEqual(undefined);

        expect(trackedOrder.state().orderState).not.toEqual('EXECUTED');
      });
    });

    describe('rejection', () => {
      it('should reject order and raise OrderRejectedEvent on state transition', () => {
        const trackedOrder = createTrackedOrder();

        trackedOrder.markAsRejected();
        expect(trackedOrder.next(1000)).toEqual(expect.objectContaining({ type: expect.stringContaining('REJECTED') }));

        expect(trackedOrder.state().orderState).toEqual('REJECTED');
      });

      it('should reject order if order internally should be rejected (limit order case)', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ shouldBeRejected: true }) });

        expect(trackedOrder.next(1000)).toEqual(expect.objectContaining({ type: expect.stringContaining('REJECTED') }));

        expect(trackedOrder.state().orderState).toEqual('REJECTED');
      });

      it('should not reject already cancelled orders', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });

        expect(trackedOrder.cancel()).toEqual(expect.objectContaining({ type: expect.stringContaining('CANCELLED') }));
        trackedOrder.markAsRejected();
        expect(trackedOrder.next(1000)).toEqual(undefined);

        expect(trackedOrder.state().orderState).not.toEqual('REJECTED');
      });

      it('should not reject already executed orders', () => {
        const trackedOrder = createTrackedOrder({ order: buildOrder({ canBeExecuted: true }) });

        expect(trackedOrder.execute()).toEqual(expect.objectContaining({ type: expect.stringContaining('BUY_ORDER_EXECUTED') }));
        trackedOrder.markAsRejected();
        expect(trackedOrder.next(1000)).toEqual(undefined);

        expect(trackedOrder.state().orderState).not.toEqual('REJECTED');
      });

      it('rejection event should be produced only once on state transition', () => {
        const trackedOrder = createTrackedOrder();

        trackedOrder.markAsRejected();
        trackedOrder.markAsRejected();

        expect(trackedOrder.next(1000)).toEqual(expect.objectContaining({ type: expect.stringContaining('REJECTED') }));
        expect(trackedOrder.next(1000)).toEqual(undefined);
      });
    });
  });

  describe('cancel()', () => {
    it('should cancel cancellable (limit) order', () => {
      const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });

      expect(trackedOrder.cancel()).toEqual(expect.objectContaining({ type: expect.stringContaining('CANCELLED') }));

      expect(trackedOrder.cancelled).toEqual(true);
      expect(trackedOrder.state().orderState).toEqual('CANCELLED');
    });

    it('should not cancel non-cancellable (market) order', () => {
      const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: false }) });

      expect(trackedOrder.cancel()).toEqual(undefined);

      expect(trackedOrder.cancelled).toEqual(false);
      expect(trackedOrder.state().orderState).not.toEqual('CANCELLED');
    });

    it('should not cancel marked as rejected order', () => {
      const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });

      trackedOrder.markAsRejected();

      expect(trackedOrder.cancel()).toEqual(undefined);

      expect(trackedOrder.cancelled).toEqual(false);
      expect(trackedOrder.state().orderState).not.toEqual('CANCELLED');
    });

    it('should not cancel rejected order', () => {
      const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true }) });

      trackedOrder.markAsRejected();

      expect(trackedOrder.next(1000)).toEqual(expect.objectContaining({ type: expect.stringContaining('REJECTED') }));
      expect(trackedOrder.cancel()).toEqual(undefined);

      expect(trackedOrder.cancelled).toEqual(false);
      expect(trackedOrder.state().orderState).not.toEqual('CANCELLED');
    });

    it('should not cancel executed order', () => {
      const trackedOrder = createTrackedOrder({ order: buildOrder({ cancellable: true, canBeExecuted: true }) });

      expect(trackedOrder.execute()).toEqual(expect.objectContaining({ type: expect.stringContaining('EXECUTED') }));
      expect(trackedOrder.cancel()).toEqual(undefined);

      expect(trackedOrder.cancelled).toEqual(false);
      expect(trackedOrder.state().orderState).not.toEqual('CANCELLED');
    });
  });
});
