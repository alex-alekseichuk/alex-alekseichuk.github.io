const { OrdersEventFactory } = require('../domain/orders-event.factory');
const { Duration } = require('luxon');

class TradingService {
  constructor(exchange, orderRepository, eventPublisher) {
    this.exchange = exchange;
    this.orderRepository = orderRepository;
    this.eventPublisher = eventPublisher;
  }

  async create(customerUuid, payload) {
    const order = await this.orderRepository.create(customerUuid, payload);
    order.setInitialMarketUnitPrice(await this._getMarketUnitPriceFor(order.toInitialJSON()));
    this.eventPublisher.publish(OrdersEventFactory.requestedFromOrder(order.customerUuid, order.orderUuid, order.toInitialJSON()));
    return order;
  }

  async step(orderUuid, fetchDate = new Date()) {
    const order = this.orderRepository.findOne(orderUuid);
    if (order) {
      const snapshot = order.state();
      const unitPrice = await this._getMarketUnitPriceFor(order.toInitialJSON());
      this.eventPublisher.publish(order.next(unitPrice, fetchDate));
      return snapshot;
    }
  }

  cancel(orderUuid) {
    const order = this.orderRepository.findOne(orderUuid);
    if (order) {
      this.eventPublisher.publish(order.cancel());
    }
  }

  async getCustomerOrders(customerUuid) {
    const customerOrders = this.orderRepository.findManyByCustomerUuid(customerUuid);
    const result = customerOrders.map(order => order.state());
    const prices = await this.exchange.getBulkUnitPriceFor(customerOrders.map(order => order.toInitialJSON()));
    customerOrders.forEach((order, i) => this.eventPublisher.publish(order.next(prices[i])));
    return result;
  }

  toJSON() {
    return {
      dataRetencyTime: `${Duration.fromMillis(this.orderRepository.dataRetencyTime).as('hours')} hours`,
      orders: this.orderRepository.findAll().map(order => order.state()),
    };
  }

  toFilteredJSON(filter) {
    return this.orderRepository
      .findAll()
      .map(order => order.state())
      .filter(filter);
  }

  async _getMarketUnitPriceFor({ fixedPrice, ...pricingData }) {
    return this.exchange.getUnitPriceFor(pricingData);
  }
}

exports.TradingService = TradingService;
