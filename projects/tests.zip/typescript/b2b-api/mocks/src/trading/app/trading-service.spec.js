const { TradingService } = require('./trading-service');
const { marketBuyPayload, limitBuyPayload } = require('../../__test__/helpers');
const { CryptoCurrencyExchange } = require('../../exchange/__test__/crypto-currency-exchange');
const { EventPublisher } = require('../../common/infrastructure/pubsub/event-publisher');
const { TradingOrderRepository } = require('../infrastructure/repositories/in-memory/trading-order-repository');

describe('TradingService', () => {
  let tradingService;
  let tradingEventPublisher;
  let exchange;

  beforeEach(() => {
    tradingEventPublisher = new EventPublisher();
    exchange = new CryptoCurrencyExchange();
    orderRepository = new TradingOrderRepository(exchange);
    tradingService = new TradingService(exchange, orderRepository, tradingEventPublisher);
  });

  describe('static cache', () => {
    describe('create()', () => {
      it('should start tracking an order by emitting outbound ORDER_REQUESTED event', async () => {
        const outboundPublisherSpy = jest.spyOn(tradingEventPublisher, 'publish');
        const trackedOrder = await tradingService.create('customer-uuid', marketBuyPayload());
        expect(outboundPublisherSpy).toBeCalledWith(
          expect.objectContaining({
            type: expect.stringContaining('ORDER_REQUESTED'),
            orderUuid: trackedOrder.orderUuid,
          })
        );
      });
    });

    describe('step()', () => {
      it('should return undefined if order not exists', async () => {
        const snapshotResponse = await tradingService.step('order-uuid');
        expect(snapshotResponse).not.toBeDefined();
      });

      it('should return order snapshot and step internally forward if order exists', async () => {
        const order = await tradingService.create('customer-uuid', marketBuyPayload());

        const snapshotResponse = await tradingService.step(order.orderUuid);

        expect(snapshotResponse.orderState).toEqual('INITIAL');
      });
    });

    describe('cancel()', () => {
      it('should propagate cancel to an existing order', async () => {
        const order = await tradingService.create('customer-uuid', marketBuyPayload());
        const storedOrder = orderRepository.findOne(order.orderUuid);
        const cancellationSpy = spyOn(storedOrder, 'cancel');

        tradingService.cancel(order.orderUuid);

        expect(cancellationSpy).toBeCalled();
      });
    });

    describe('getCustomerOrders()', () => {
      it('should propagate reject to an existing order', async () => {
        const customer1OrderUuids = await Promise.all([
          tradingService.create('customer-1', marketBuyPayload()),
          tradingService.create('customer-1', marketBuyPayload()),
          tradingService.create('customer-1', marketBuyPayload()),
        ]).then(orders => orders.map(order => order.orderUuid));

        const customer2OrderUuids = await Promise.all([
          tradingService.create('customer-2', marketBuyPayload()),
          tradingService.create('customer-2', marketBuyPayload()),
          tradingService.create('customer-2', marketBuyPayload()),
        ]).then(orders => orders.map(order => order.orderUuid));

        const customer1Orders = await tradingService.getCustomerOrders('customer-1');
        expect(Array.isArray(customer1Orders)).toBeTruthy();
        customer1Orders.forEach(order => {
          expect(customer1OrderUuids.includes(order.orderUuid)).toEqual(true);
          expect(order.customerUuid).toEqual('customer-1');
        });

        const customer2Orders = await tradingService.getCustomerOrders('customer-2');
        expect(Array.isArray(customer2Orders)).toBeTruthy();
        customer2Orders.forEach(order => {
          expect(customer2OrderUuids.includes(order.orderUuid)).toEqual(true);
          expect(order.customerUuid).toEqual('customer-2');
        });
      });
    });
  });
});
