const { OrderCommand } = require('../common/commands/order.command');
const { REJECT_ORDER_COMMAND, EXECUTE_ORDER_COMMAND, FORCE_REJECT_ORDER_COMMAND } = require('../common/commands/order-command.types');

class TradingCommandHandler {
  constructor(orderRepository, eventPublisher) {
    this.orderRepository = orderRepository;
    this.eventPublisher = eventPublisher;
  }

  apply(command) {
    if (command instanceof OrderCommand) {
      this.eventPublisher.publish(this._applyOrderCommand(command));
    }
  }

  subscribe(eventPublisher) {
    eventPublisher.addListener(this);
  }

  _applyOrderCommand(command) {
    const order = this.orderRepository.findOne(command.orderUuid);
    if (!order) {
      return;
    }
    if (command.type === REJECT_ORDER_COMMAND) {
      return order.markAsRejected();
    }
    if (command.type === EXECUTE_ORDER_COMMAND) {
      return order.execute();
    }
    if (command.type === FORCE_REJECT_ORDER_COMMAND) {
      return order.forceReject();
    }
  }
}

exports.TradingCommandHandler = TradingCommandHandler;
