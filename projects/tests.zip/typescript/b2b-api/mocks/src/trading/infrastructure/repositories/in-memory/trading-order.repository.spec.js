const { marketBuyPayload } = require('../../../../__test__/helpers');
const { TradingOrderRepository } = require('./trading-order-repository');
const { CryptoCurrencyExchange } = require('../../../../exchange/__test__/crypto-currency-exchange');

describe('TradingOrderRepository', () => {
  it('applies data retency policy on flush triggered', async () => {
    const oneHour = 60 * 60 * 1000;
    const twoHours = 2 * oneHour;
    const exchange = new CryptoCurrencyExchange();
    const repository = new TradingOrderRepository(exchange, twoHours);

    const flushDate = new Date('Tue May 25 2021 10:56:01 GMT+0200 (Central European Summer Time)');
    const disposableDate = new Date(flushDate.getTime() - twoHours);
    const validDate = new Date(flushDate.getTime() - oneHour);

    const disposedOrder = await repository.create('customer-uuid', marketBuyPayload(), disposableDate);
    const validOrder = await repository.create('customer-uuid', marketBuyPayload(), validDate);

    const flushedOrders = repository.flush(flushDate);

    expect(flushedOrders).toEqual([disposedOrder.orderUuid]);
    expect([...repository.orders.keys()]).toEqual([validOrder.orderUuid]);
  });
});
