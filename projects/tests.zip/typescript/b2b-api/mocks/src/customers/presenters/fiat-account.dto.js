exports.toJSON = data => ({
  customerFiatAccountUuid: data.customerFiatAccountUuid,
  balance: data.balance.toNumber(),
  blockedBalance: data.blockedBalance.toNumber(),
  currency: data.currency,
  accountId: data.accountId,
  iban: data.iban,
});

exports.toFiatAccountJSON = data => ({
  customerFiatAccountUuid: data.customerFiatAccountUuid,
  currency: data.currency,
  accountId: data.accountId,
  iban: data.iban,
  isActive: 'true',
  isDefault: 'true',
});

exports.toFiatBalancesJSON = data => ({
  [data.customerFiatAccountUuid]: data.balance.toNumber(),
});

exports.toBankFiatAccountsJSON = data => ({
  customerFiatAccountUuid: data.customerFiatAccountUuid,
  currency: data.currency,
  accountId: data.accountId,
  iban: data.iban,
  isActive: 'true',
  isDefault: 'true',
  balance: data.balance.toNumber(),
});
