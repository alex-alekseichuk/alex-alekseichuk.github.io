exports.toSettingsJSON = customers => ({
  customers: customers.map(customer => ({ customerUuid: customer.customerUuid, alias: customer.alias, type: customer.type })),
});
