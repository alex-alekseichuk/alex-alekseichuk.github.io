exports.toCryptoProduct = data => {
  return {
    availableWalletTypes: ['SEGREGATED'],
    cryptoProductPositions: [
      {
        cryptoAssetConfig: {
          cryptoAssetUuid: data.cryptoPositionData.cryptoProductPositionUuid,
          decimalSettings: {
            decimals: 0,
            displayDecimals: 0,
          },
        },
        cryptoProductPositionUuid: data.cryptoPositionData.cryptoProductPositionUuid,
        isVisible: true,
      },
    ],
    cryptoProductUuid: data.cryptoPositionData.cryptoProductPositionUuid,
    distributedLedgerTechnologyType: data.cryptoCurrencyType === 'ETH' ? 'ETHEREUM' : 'BITCOIN',
    isActive: true,
    isAmlRequired: true,
    isCombinable: true,
    isOmnibusSupported: true,
    isTempWalletUsed: data.cryptoCurrencyType === 'ETH',
    maxDefaultPledgedInstances: 0,
    maxDefaultSegregatedInstances: 0,
    maxDefaultVaultInstances: 0,
    name: 'TempWalletAvailable',
  };
};
