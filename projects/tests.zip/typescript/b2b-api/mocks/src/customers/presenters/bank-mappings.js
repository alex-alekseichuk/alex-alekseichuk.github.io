exports.hydrateCryptoPosition = bankCryptoPostionJSON => ({
  customerCryptoPositionDetail: {
    cryptoPositionUuid: bankCryptoPostionJSON.cryptoPositionUuid,
    cryptoCurrencyType: bankCryptoPostionJSON.cryptoCurrencyType,
    availableToTradeBalance: bankCryptoPostionJSON.availableBalance,
    balance: {
      _bigDecimal: bankCryptoPostionJSON.availableBalance,
    },
    amountDisposed: {
      _bigDecimal: '0',
    },
    amountTempWallet: {
      _bigDecimal: '0',
    },
    balanceCustomerReferenceCurrency: {
      _bigDecimal: '34.45350',
    },
    balanceBankReferenceCurrency: {
      _bigDecimal: '34.45350',
    },
  },
  cryptoPosition: {
    cryptoPositionUuid: bankCryptoPostionJSON.cryptoPositionUuid,
    logicalWalletUuid: 'ebc75cfe-8dc0-435a-8673-91912e461532',
    cryptoCurrencyType: bankCryptoPostionJSON.cryptoCurrencyType,
    cryptoPositionBundleUuid: '5384a345-c7c9-47f6-a5f3-a2d5d53b11f6',
    cryptoProductPositionUuid: '1a8b23c2-513c-4db8-b400-1a054a996ef7',
    customerUuid: bankCryptoPostionJSON.customerUuid,
    state: 'ACTIVE',
    omnibusMasterCryptoPositionBundleUuid: '67a98643-8a86-467e-98a3-aea5e2f65a76',
    cryptoPositionType: 'SEGREGATED',
    ...(bankCryptoPostionJSON.cryptoPositionBundleName && { cryptoPositionBundleName: bankCryptoPostionJSON.cryptoPositionBundleName }),
    actions: ['READ'],
  },
});

exports.hydrateFiatAccount = customerFiatAccountsJSON => ({
  customerFiatAccountDetail: {
    customerFiatAccountUuid: customerFiatAccountsJSON.customerFiatAccountUuid,
    standInLimits: {},
    usedStandInLimits: {
      DAY: {
        _bigDecimal: '0',
      },
      MONTH: {
        _bigDecimal: '0',
      },
    },
    availableStandInLimits: {
      DAY: {
        _bigDecimal: '0',
      },
      MONTH: {
        _bigDecimal: '0',
      },
    },
    amountDisposed: {
      _bigDecimal: '0',
    },
  },
  customerFiatAccount: {
    customerFiatAccountUuid: customerFiatAccountsJSON.customerFiatAccountUuid,
    customerUuid: customerFiatAccountsJSON.customerUuid,
    accountId: customerFiatAccountsJSON.accountId,
    currency: customerFiatAccountsJSON.currency,
    iban: customerFiatAccountsJSON.iban,
    isDefault: customerFiatAccountsJSON.isDefault,
    isActive: customerFiatAccountsJSON.isActive,
  },
});
