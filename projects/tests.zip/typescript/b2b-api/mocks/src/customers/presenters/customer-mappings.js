const { CLOSE_CRYPTO_POSITION_TYPE } = require('../domain/orders/close-cryptoposition.order');
const { CREATE_CRYPTO_POSITION_TYPE } = require('../domain/orders/create-cryptoposition.order');
const { CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE } = require('../domain/orders/create-cryptoposition-temp-address.order');
const { SEND_CRYPTO_TYPE } = require('../domain/orders/send-crypto.order');
const { TRANSFER_CRYPTO_TYPE } = require('../domain/orders/transfer-crypto.order');
const { UPDATE_CRYPTO_POSITION_TYPE } = require('../domain/orders/update-cryptoposition.order');

const { toCryptoPositionsJSON } = require('./crypto-position.dto');
const { MANUAL_BUY_TYPE } = require('../domain/orders/manual-buy.order');
const { MANUAL_SELL_TYPE } = require('../domain/orders/manual-sell.order');

const CRYPTO_POSITION_ORDERS = [CREATE_CRYPTO_POSITION_TYPE, CLOSE_CRYPTO_POSITION_TYPE, UPDATE_CRYPTO_POSITION_TYPE];
const MANUAL_TRADE_ORDERS = [MANUAL_BUY_TYPE, MANUAL_SELL_TYPE];

const mapCommon = orderJSON => ({
  orderType: orderJSON.orderType,
  orderState: orderJSON.orderState,
  customerUuid: orderJSON.customerUuid,
  orderUuid: orderJSON.orderUuid,
  orderId: orderJSON.orderId,
  cancellable: orderJSON.cancellable,
  timestampOrderReceived: orderJSON.timestampOrderReceived,
});

const mapCryptoPositionOrder = orderJSON => ({
  ...mapCommon(orderJSON),
  ...(orderJSON.cryptoPosition && { cryptoPosition: toCryptoPositionsJSON(orderJSON.cryptoPosition) }),
  ...(orderJSON.lastExecutionTimestamp && { lastExecutionTimestamp: orderJSON.lastExecutionTimestamp }),
  ...(orderJSON.lastExecutionTimestamp && { lastExecutionTimestamp: orderJSON.lastExecutionTimestamp }),
});

const mapTransferOrder = orderJSON => ({
  ...mapCommon(orderJSON),
  cryptoPosition: toCryptoPositionsJSON(orderJSON.sourceCryptoPosition),
  debitOrCreditCryptoPosition: toCryptoPositionsJSON(orderJSON.destinationCryptoPosition),
  transactionAmount: orderJSON.quantity,
  feePaymentModelType: orderJSON.feePaymentModelType,
  feePriorityType: orderJSON.feePriorityType,
  ...(orderJSON.lastExecutionTimestamp && { lastExecutionTimestamp: orderJSON.lastExecutionTimestamp, transactionAmountFilled: orderJSON.quantity }),
});

const mapSendOrder = orderJSON => ({
  ...mapCommon(orderJSON),
  cryptoPosition: toCryptoPositionsJSON(orderJSON.sourceCryptoPosition),
  destinationPublicAddress: orderJSON.destinationPublicAddress,
  transactionAmount: orderJSON.quantity,
  feePaymentModelType: orderJSON.feePaymentModelType,
  feePriorityType: orderJSON.feePriorityType,
  ...(orderJSON.lastExecutionTimestamp && { lastExecutionTimestamp: orderJSON.lastExecutionTimestamp, transactionAmountFilled: orderJSON.quantity }),
});

const mapCreateTemporaryAddress = orderJSON => {
  return {
    ...mapCommon(orderJSON),
    cryptoPosition: toCryptoPositionsJSON(orderJSON.cryptoPosition),
    ...(orderJSON.lastExecutionTimestamp && { lastExecutionTimestamp: orderJSON.lastExecutionTimestamp }),
  };
};

const mapManualTradeOrder = orderJSON => {
  return {
    ...orderJSON,
  };
};

exports.mapCustomerOrder = orderJSON => {
  if (!orderJSON) {
    return;
  }

  const { orderType } = orderJSON;

  if (CRYPTO_POSITION_ORDERS.includes(orderType)) {
    return mapCryptoPositionOrder(orderJSON);
  }

  if (orderType === TRANSFER_CRYPTO_TYPE) {
    return mapTransferOrder(orderJSON);
  }

  if (orderType === SEND_CRYPTO_TYPE) {
    return mapSendOrder(orderJSON);
  }

  if (orderType === CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE) {
    return mapCreateTemporaryAddress(orderJSON);
  }

  if (MANUAL_TRADE_ORDERS.includes(orderType)) {
    return mapManualTradeOrder(orderJSON);
  }

  return mapCommon(orderJSON);
};
