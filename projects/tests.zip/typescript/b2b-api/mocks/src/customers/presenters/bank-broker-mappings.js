exports.hydrateBrokerCryptoPosition = bankCryptoPostionJSON => ({
  balance: {
    availableBalance: {
      _bigDecimal: bankCryptoPostionJSON.availableBalance,
    },
    bookedBalance: {
      _bigDecimal: '0',
    },
    bookingUuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    cryptoPositionBundleUuid: '5384a345-c7c9-47f6-a5f3-a2d5d53b11f6',
    cryptoPositionUuid: bankCryptoPostionJSON.cryptoPositionUuid,
    disposedBalance: {
      _bigDecimal: '0',
    },
    receivedBalance: {
      _bigDecimal: '0',
    },
    receivedClosedCustomerBalance: {
      _bigDecimal: '0',
    },
    receivedClosedWalletBalance: {
      _bigDecimal: '0',
    },
    receivedUnexpectedBalance: {
      _bigDecimal: '0',
    },
    tempReservedBalance: {
      _bigDecimal: '0',
    },
    timestamp: Date.now(),
  },
  customerCryptoPositionView: {
    cryptoCurrencyType: bankCryptoPostionJSON.cryptoCurrencyType,
    ...(bankCryptoPostionJSON.cryptoPositionBundleName && { cryptoPositionBundleName: bankCryptoPostionJSON.cryptoPositionBundleName }),
    cryptoPositionBundleUuid: '5384a345-c7c9-47f6-a5f3-a2d5d53b11f6',
    cryptoPositionType: 'SEGREGATED',
    cryptoProductPositionUuid: '1a8b23c2-513c-4db8-b400-1a054a996ef7',
    cryptoPositionUuid: bankCryptoPostionJSON.cryptoPositionUuid,
    customerUuid: bankCryptoPostionJSON.customerUuid,
    logicalWalletUuid: 'ebc75cfe-8dc0-435a-8673-91912e461532',
    omnibusMasterCryptoPositionBundleUuid: '67a98643-8a86-467e-98a3-aea5e2f65a76',
    state: 'ACTIVE',
  },
});

exports.hydrateBrokerFiatAccount = customerFiatAccountsJSON => ({
  customerFiatAccountUuid: customerFiatAccountsJSON.customerFiatAccountUuid,
  customerUuid: customerFiatAccountsJSON.customerUuid,
  accountId: customerFiatAccountsJSON.accountId,
  currency: customerFiatAccountsJSON.currency,
  iban: customerFiatAccountsJSON.iban,
  isDefault: customerFiatAccountsJSON.isDefault,
  isActive: customerFiatAccountsJSON.isActive,
});
