exports.toJSON = data => ({
  cryptoPositionUuid: data.cryptoPositionUuid,
  cryptoCurrencyType: data.cryptoCurrencyType,
  cryptoPositionBundleName: data.cryptoPositionBundleName,
  availableBalance: data.availableBalance.toNumber(),
  blockedAvailableBalance: data.blockedAvailableBalance.toNumber(),
  ...data.cryptoPositionData.toJSON(),
});

exports.toCryptoPositionsJSON = data => ({
  cryptoPositionUuid: data.cryptoPositionUuid,
  cryptoCurrencyType: data.cryptoCurrencyType,
  cryptoPositionBundleName: data.cryptoPositionBundleName,
  availableBalance: data.availableBalance.toNumber(),
  blockedAvailableBalance: data.blockedAvailableBalance.toNumber(),
  ...data.cryptoPositionData.toJSON(),
});

exports.toCryptoBalancesJSON = data => ({
  cryptoPositionUuid: data.cryptoPositionUuid,
  cryptoPositionBundleName: data.cryptoPositionBundleName,
  availableBalance: {
    _bigDecimal: data.availableBalance.toNumber(),
  },
});

exports.toBankCryptoPositionsJSON = data => ({
  cryptoPositionUuid: data.cryptoPositionUuid,
  cryptoCurrencyType: data.cryptoCurrencyType,
  cryptoPositionBundleName: data.cryptoPositionBundleName,
  availableBalance: data.availableBalance.toNumber(),
});

exports.toPublicAddress = data => ({
  publicAddress: data.cryptoPositionData.publicAddress,
});
