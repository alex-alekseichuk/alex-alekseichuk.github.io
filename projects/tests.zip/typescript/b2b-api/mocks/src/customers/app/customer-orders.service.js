const { Duration } = require('luxon');

class CustomerOrdersService {
  constructor(orderRepository, eventPublisher) {
    this.orderRepository = orderRepository;
    this.eventPublisher = eventPublisher;
  }

  async step(orderUuid) {
    const order = this.orderRepository.findOne(orderUuid);
    if (order) {
      const snapshot = order.state();
      this.eventPublisher.publish(order.next());
      return snapshot;
    }
  }

  async getCustomerOrders(customerUuid) {
    const customerOrders = this.orderRepository.findManyByCustomerUuid(customerUuid);
    const result = customerOrders.map(order => order.state());
    customerOrders.forEach(order => this.eventPublisher.publish(order.next()));
    return result;
  }

  toJSON() {
    return {
      dataRetencyTime: `${Duration.fromMillis(this.orderRepository.dataRetencyTime).as('hours')} hours`,
      orders: this.orderRepository.findAll().map(order => order.state()),
    };
  }
}

exports.CustomerOrdersService = CustomerOrdersService;
