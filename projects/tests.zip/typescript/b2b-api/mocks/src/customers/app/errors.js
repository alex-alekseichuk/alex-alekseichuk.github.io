class DeserializationError extends Error {
  constructor(validationErrors) {
    super(validationErrors.map(error => `JSON Deserialization error: ${error.property} ${error.message}`));
  }
}

class CustomerNotFoundError extends Error {
  constructor(customerUuid) {
    super(`Customer with customerUuid: ${customerUuid} not found`);
  }
}

class CryptoPositionNotFound extends Error {
  constructor(cryptoPositionUuid) {
    super(`CryptoPosition with cryptoPositionUuid: ${cryptoPositionUuid} not found`);
  }
}

class FiatAccountNotFound extends Error {
  constructor(fiatAccountUuid) {
    super(`FiatAccount with fiatAccountUuid: ${fiatAccountUuid} not found`);
  }
}

exports.cannotDeserialize = validationErrors => new DeserializationError(validationErrors);
exports.customerNotFound = customerUuid => new CustomerNotFoundError(customerUuid);
exports.cryptoPositionNotFound = cryptoPositionUuid => new CryptoPositionNotFound(cryptoPositionUuid);
exports.fiatAccountNotFound = fiatAccountUuid => new FiatAccountNotFound(fiatAccountUuid);
