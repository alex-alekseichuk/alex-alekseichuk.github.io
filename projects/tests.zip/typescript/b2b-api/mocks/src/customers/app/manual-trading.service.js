const { OrdersEventFactory } = require('../domain/order-event-factory');
const { ManualBuyOrder } = require('../domain/orders/manual-buy.order');
const { ManualSellOrder } = require('../domain/orders/manual-sell.order');
const { cryptoPositionNotFound, fiatAccountNotFound } = require('./errors');

class ManualTradingService {
  constructor(customerRepository, cryptoPositionRepository, fiatAccountRepository, orderRepository, eventPublisher) {
    this.customerRepository = customerRepository;
    this.cryptoPositionRepository = cryptoPositionRepository;
    this.fiatAccountRepository = fiatAccountRepository;
    this.orderRepository = orderRepository;
    this.eventPublisher = eventPublisher;
  }

  registerManualTradeOrder(dto) {
    this._assertFiatAccount(dto.brokerCustomerFiatAccount.customerFiatAccountUuid, dto.brokerCustomerUuid);
    this._assertCryptoPosition(dto.brokerCryptoPosition.cryptoPositionUuid, dto.brokerCustomerUuid);
    const clientFiat = this._assertFiatAccount(dto.clientCustomerFiatAccount.customerFiatAccountUuid);
    const clientPosition = this._assertCryptoPosition(dto.clientCryptoPosition.cryptoPositionUuid);

    if (dto.tradeOrderType === 'BUY') {
      const order = this.orderRepository.create(clientFiat.customerUuid, new ManualBuyOrder(dto));
      this.eventPublisher.publish(OrdersEventFactory.requestedFromOrder(order.state()));
      return order;
    }
    if (dto.tradeOrderType === 'SELL') {
      const order = this.orderRepository.create(clientPosition.customerUuid, new ManualSellOrder(dto));
      this.eventPublisher.publish(OrdersEventFactory.requestedFromOrder(order.state()));
      return order;
    }
    throw new Error('Invalid Order Type');
  }

  _assertCryptoPosition(cryptoPositionUuid, ownerUuid) {
    const position = this.cryptoPositionRepository.findOne(cryptoPositionUuid);
    if (!position || (ownerUuid && position.customerUuid !== ownerUuid)) {
      throw cryptoPositionNotFound(cryptoPositionUuid);
    }
    return position;
  }

  _assertFiatAccount(fiatAccountUuid, ownerUuid) {
    const account = this.fiatAccountRepository.findOne(fiatAccountUuid);
    if (!account || (ownerUuid && account.customerUuid !== ownerUuid)) {
      throw fiatAccountNotFound(fiatAccountUuid);
    }
    return account;
  }
}

exports.ManualTradingService = ManualTradingService;
