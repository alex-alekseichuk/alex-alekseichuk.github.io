const { OrdersEventFactory } = require('../domain/order-event-factory');
const { CloseCryptoPositionOrder } = require('../domain/orders/close-cryptoposition.order');
const { CreateCryptoPositionTemporaryAddressOrder } = require('../domain/orders/create-cryptoposition-temp-address.order');
const { CreateCryptoPositionOrder } = require('../domain/orders/create-cryptoposition.order');
const { SendCryptoOrder } = require('../domain/orders/send-crypto.order');
const { TransferCryptoOrder } = require('../domain/orders/transfer-crypto.order');
const { UpdateCryptoPositionOrder } = require('../domain/orders/update-cryptoposition.order');
const { customerNotFound, cryptoPositionNotFound } = require('./errors');

class CryptoPositionService {
  constructor(customerRepository, cryptoPositionRepository, orderRepository, eventPublisher) {
    this.customerRepository = customerRepository;
    this.cryptoPositionRepository = cryptoPositionRepository;
    this.orderRepository = orderRepository;
    this.eventPublisher = eventPublisher;
  }

  getByLogicalWalletUuidAndCryptoCurrencyType(customerUuid, logicalWalletUuid, cryptoCurrencyType) {
    this._assertCustomer(customerUuid);
    const position = this.cryptoPositionRepository.findOneByLogicalWalletUuid(logicalWalletUuid);
    if (!position || position.customerUuid !== customerUuid || position.cryptoCurrencyType !== cryptoCurrencyType) {
      return null;
    }
    return position;
  }

  create(customerUuid, cryptoPositionData) {
    this._assertCustomer(customerUuid);
    return this.orderRepository.create(customerUuid, new CreateCryptoPositionOrder(cryptoPositionData));
  }

  createTemporaryAddress(customerUuid, cryptoPositionUuid) {
    this._assertCustomer(customerUuid);
    const position = this._assertCryptoPosition(customerUuid, cryptoPositionUuid);
    return this.orderRepository.create(customerUuid, new CreateCryptoPositionTemporaryAddressOrder(position));
  }

  update(customerUuid, cryptoPositionUuid, cryptoPositionBundleName) {
    this._assertCustomer(customerUuid);
    const position = this._assertCryptoPosition(customerUuid, cryptoPositionUuid);
    this.orderRepository.create(customerUuid, new UpdateCryptoPositionOrder(position));
    position.setBundleName(cryptoPositionBundleName);
  }

  close(customerUuid, cryptoPositionUuid) {
    this._assertCustomer(customerUuid);
    const position = this._assertCryptoPosition(customerUuid, cryptoPositionUuid);
    this.orderRepository.create(customerUuid, new CloseCryptoPositionOrder(position));
    this.cryptoPositionRepository.removeOne(cryptoPositionUuid);
  }

  transfer(customerUuid, sourceCryptoPositionUuid, destinationCryptoPositionUuid, details) {
    this._assertCustomer(customerUuid);
    const sourceCryptoPosition = this._assertCryptoPosition(customerUuid, sourceCryptoPositionUuid);
    const destinationCryptoPosition = this.cryptoPositionRepository.findOne(destinationCryptoPositionUuid);
    if (!destinationCryptoPosition) {
      throw cryptoPositionNotFound(cryptoPositionUuid);
    }
    const order = this.orderRepository.create(
      customerUuid,
      new TransferCryptoOrder({
        sourceCryptoPosition,
        destinationCryptoPosition,
        ...details,
      })
    );
    this.eventPublisher.publish(OrdersEventFactory.requestedFromOrder(order.state()));
    return order;
  }

  send(customerUuid, sourceCryptoPositionUuid, details) {
    this._assertCustomer(customerUuid);
    const sourceCryptoPosition = this._assertCryptoPosition(customerUuid, sourceCryptoPositionUuid);
    const order = this.orderRepository.create(
      customerUuid,
      new SendCryptoOrder({
        sourceCryptoPosition,
        ...details,
      })
    );
    this.eventPublisher.publish(OrdersEventFactory.requestedFromOrder(order.state()));
    return order;
  }

  _assertCustomer(customerUuid) {
    const customer = this.customerRepository.findOne(customerUuid);
    if (!customer) {
      throw customerNotFound(customerUuid);
    }
    return customer;
  }

  _assertCryptoPosition(customerUuid, cryptoPositionUuid) {
    const cryptoPosition = this.cryptoPositionRepository.findOneByCustomerUuid(customerUuid, cryptoPositionUuid);
    if (!cryptoPosition) {
      throw cryptoPositionNotFound(cryptoPositionUuid);
    }
    return cryptoPosition;
  }
}

exports.CryptoPositionService = CryptoPositionService;
