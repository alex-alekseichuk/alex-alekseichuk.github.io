const { cryptoPositionNotFound } = require('./errors');

class CustomerService {
  constructor(customerRepository, cryptoPositionRepository, fiatAccountRepository) {
    this.customerRepository = customerRepository;
    this.cryptoPositionRepository = cryptoPositionRepository;
    this.fiatAccountRepository = fiatAccountRepository;
  }

  getCustomers() {
    return this.customerRepository.findAll();
  }

  getClientCryptoPositions(customerUuid) {
    this._assertCustomer(customerUuid);
    return this.cryptoPositionRepository.findManyByCustomerUuid(customerUuid);
  }

  getClientCryptoBalance(customerUuid, cryptoPositionUuid) {
    this._assertCustomer(customerUuid);
    const position = this.cryptoPositionRepository.findOneByCustomerUuid(customerUuid, cryptoPositionUuid);
    if (!position) {
      throw cryptoPositionNotFound(cryptoPositionUuid);
    }
    return position;
  }

  getClientFiatAccounts(customerUuid) {
    this._assertCustomer(customerUuid);
    return this.fiatAccountRepository.findManyByCustomerUuid(customerUuid);
  }

  getClientFiatBalances(customerUuid, fiatAccountUuids = []) {
    this._assertCustomer(customerUuid);
    return this.fiatAccountRepository.findManyByFiatAccountUuids(customerUuid, fiatAccountUuids);
  }

  getBankPositionDetails(customerUuid) {
    this._assertCustomer(customerUuid);
    const accounts = this.fiatAccountRepository.findManyByCustomerUuid(customerUuid);
    const positions = this.cryptoPositionRepository.findManyByCustomerUuid(customerUuid);
    return {
      accounts,
      positions,
    };
  }

  toJSON() {
    const customers = this.customerRepository.findAll();
    return customers.map(({ customerUuid, ...data }) => ({
      ...data,
      accounts: this.fiatAccountRepository.findManyByCustomerUuid(customerUuid),
      positions: this.cryptoPositionRepository.findManyByCustomerUuid(customerUuid),
    }));
  }

  _assertCustomer(customerUuid) {
    const customer = this.customerRepository.findOne(customerUuid);
    if (!customer) {
      throw customerNotFound(customerUuid);
    }
    return customer;
  }
}

exports.CustomerService = CustomerService;
