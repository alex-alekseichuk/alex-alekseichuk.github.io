const fs = require('fs');
const { cacheOptions } = require('../mockserver-configuration');
const { CustomerRepository } = require('./infrastructure/in-memory/customer.repository');
const { FiatAccountRepository } = require('./infrastructure/in-memory/fiat-account.repository');
const { CryptoPositionRepository } = require('./infrastructure/in-memory/crypto-position.repository');
const { CustomerOrderRepository } = require('./infrastructure/in-memory/customer-order-repository');
const { CustomerDeserializer } = require('./infrastructure/io/customer-deserializer');
const { CustomerService } = require('./app/customer.service');
const { CryptoPositionService } = require('./app/crypto-position.service');
const { CustomerOrdersService } = require('./app/customer-orders.service');
const { CustomersCommandHandler } = require('./customers-command-handler');

exports.CustomerRepository = CustomerRepository;
exports.FiatAccountRepository = FiatAccountRepository;
exports.CryptoPositionRepository = CryptoPositionRepository;
exports.CustomerOrderRepository = CustomerOrderRepository;

exports.CustomerService = CustomerService;
exports.CryptoPositionService = CryptoPositionService;
exports.CustomersCommandHandler = CustomersCommandHandler;
exports.CustomerOrdersService = CustomerOrdersService;

exports.loadCachedData = (customerRepository, fiatAccountRepository, cryptoPositionRepository, data = JSON.parse(fs.readFileSync(cacheOptions.CUSTOMERS_SETUP_FILE, 'utf-8'))) =>
  new CustomerDeserializer(customerRepository, fiatAccountRepository, cryptoPositionRepository).fromJSON(data);
