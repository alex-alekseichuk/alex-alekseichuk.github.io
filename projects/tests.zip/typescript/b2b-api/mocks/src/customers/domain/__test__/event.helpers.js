const { BuyOrderExecutedEvent, SellOrderExecutedEvent } = require('../../../common/events/trading/order-executed.event');
const { BuyOrderRequestedEvent, SellOrderRequestedEvent } = require('../../../common/events/trading/order-requested.event');
const { BuyOrderCancelledEvent, SellOrderCancelledEvent } = require('../../../common/events/trading/order-cancelled.event');
const { BuyOrderRejectedEvent, SellOrderRejectedEvent } = require('../../../common/events/trading/order-rejected.event');
const { BuyOrderExecutionRequestedEvent, SellOrderExecutionRequestedEvent } = require('../../../common/events/trading/order-execution-requested.event');
const { BuyOrderExpiredEvent, SellOrderExpiredEvent } = require('../../../common/events/trading/order-expired.event');

const buyExecutionRequested = ({
  cryptoAmount = 50,
  finalPrice = 500,
  cryptoUuid = 'crypto-position-uuid',
  fiatUuid = 'fiat-account-uuid',
  customerUuid = 'customer-uuid',
  orderUuid = 'order-uuid',
  initialPrice = 500,
} = {}) =>
  new BuyOrderExecutionRequestedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    transactionQuantity: cryptoAmount,
    transactionAmount: finalPrice,
  });

const sellExecutionRequested = ({
  cryptoAmount = 50,
  finalPrice = 500,
  cryptoUuid = 'crypto-position-uuid',
  fiatUuid = 'fiat-account-uuid',
  customerUuid = 'customer-uuid',
  orderUuid = 'order-uuid',
  initialPrice = 500,
} = {}) =>
  new SellOrderExecutionRequestedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    transactionQuantity: cryptoAmount,
    transactionAmount: finalPrice,
  });

const buyExecuted = ({
  cryptoAmount = 50,
  finalPrice = 500,
  cryptoUuid = 'crypto-position-uuid',
  fiatUuid = 'fiat-account-uuid',
  customerUuid = 'customer-uuid',
  orderUuid = 'order-uuid',
  initialPrice = 500,
} = {}) =>
  new BuyOrderExecutedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    transactionQuantity: cryptoAmount,
    transactionAmount: finalPrice,
  });

const sellExecuted = ({
  cryptoAmount = 50,
  finalPrice = 500,
  cryptoUuid = 'crypto-position-uuid',
  fiatUuid = 'fiat-account-uuid',
  customerUuid = 'customer-uuid',
  orderUuid = 'order-uuid',
  initialPrice = 500,
} = {}) =>
  new SellOrderExecutedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    transactionQuantity: cryptoAmount,
    transactionAmount: finalPrice,
  });

const buyRequested = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new BuyOrderRequestedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const sellRequested = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new SellOrderRequestedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const buyCancelled = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new BuyOrderCancelledEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const sellCancelled = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new SellOrderCancelledEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const buyRejected = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new BuyOrderRejectedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const sellRejected = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new SellOrderRejectedEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const buyExpired = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new BuyOrderExpiredEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

const sellExpired = ({ cryptoAmount = 50, initialPrice = 500, cryptoUuid = 'crypto-position-uuid', fiatUuid = 'fiat-account-uuid', customerUuid = 'customer-uuid', orderUuid = 'order-uuid' } = {}) =>
  new SellOrderExpiredEvent({
    customerUuid,
    orderUuid,
    initialPrice,
    cryptoPositionUuid: cryptoUuid,
    customerFiatAccountUuid: fiatUuid,
    quantity: cryptoAmount,
  });

exports.buyExecutionRequested = buyExecutionRequested;
exports.sellExecutionRequested = sellExecutionRequested;
exports.buyExecuted = buyExecuted;
exports.sellExecuted = sellExecuted;
exports.buyRequested = buyRequested;
exports.sellRequested = sellRequested;
exports.buyCancelled = buyCancelled;
exports.sellCancelled = sellCancelled;
exports.buyRejected = buyRejected;
exports.sellRejected = sellRejected;
exports.buyExpired = buyExpired;
exports.sellExpired = sellExpired;
