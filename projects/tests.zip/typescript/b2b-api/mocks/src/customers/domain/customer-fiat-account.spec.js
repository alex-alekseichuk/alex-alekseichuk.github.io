const { CustomerFiatAccount } = require('./customer-fiat-account');

const { buyExecutionRequested, buyExecuted, sellExecuted, buyRequested, sellRequested, buyCancelled, buyRejected, buyExpired } = require('./__test__/event.helpers');

const createFiatAccount = ({ balance } = {}) => new CustomerFiatAccount({ customerFiatAccountUuid: 'fiat-account-uuid', balance });

describe('Customer Fiat Account', () => {
  describe('Order Execution Request', () => {
    it('should call ORDER_EXECUTION_COMMAND for BUY_ORDER_EXECUTION_REQUESTED event if can afford the new price', () => {
      const fiatAccount = createFiatAccount({ balance: 500 });

      const event = fiatAccount.apply(buyExecutionRequested({ initialPrice: 500, finalPrice: 500, orderUuid: 'affordable' }));

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'affordable', type: expect.stringContaining('EXECUTE_ORDER_COMMAND') }));
    });
    it('should call a REJECT_ORDER_COMMAND for BUY_ORDER_EXECUTION_REQUESTED if cannot afford the new price', () => {
      const fiatAccount = createFiatAccount({ balance: 99 });

      const event = fiatAccount.apply(buyExecutionRequested({ initialPrice: 500, finalPrice: 600, orderUuid: 'non-affordable' }));

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'non-affordable', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));
    });
    it('should call a REJECT_ORDER_COMMAND if is not affordable including blocked amount', () => {
      const fiatAccount = createFiatAccount({ balance: 500 });

      fiatAccount.apply(buyRequested({ initialPrice: 500 }));
      const event = fiatAccount.apply(buyExecutionRequested({ initialPrice: 500, finalPrice: 501, orderUuid: 'non-affordable' }));

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'non-affordable', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));
    });
  });

  describe('Order Execution', () => {
    it('should decrease customer fiat balance on BUY_ORDER_EXECUTED', () => {
      const fiatAccount = createFiatAccount({ balance: 1000 });

      fiatAccount.apply(buyExecuted({ initialPrice: 500 }));

      expect(fiatAccount.balance.toNumber()).toEqual(500);
    });

    it('should increase customer fiat balance on SELL_ORDER_EXECUTED', () => {
      const fiatAccount = createFiatAccount({ balance: 1000 });

      fiatAccount.apply(sellExecuted({ finalPrice: 500 }));

      expect(fiatAccount.balance.toNumber()).toEqual(1500);
    });

    it('should unblock amount on BuyOrder execution', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 50 }));
      fiatAccount.apply(buyExecuted({ finalPrice: 45.55, initialPrice: 50 }));

      expect(fiatAccount.balance.toNumber()).toEqual(54.45);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(0);
    });
  });

  describe('Blocking', () => {
    it('should internally block certain amount of fiat on BuyOrder request', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 50 }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(50);
    });

    it('should not block fiat account for SellOrder request', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(sellRequested({ initialPrice: 50 }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(0);
    });

    it('should not allow to place BuyOrder even if is affordable but has blocked amount before on BuyOrder rejection', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 90, orderUuid: 'affordable' }));
      const failedEvent = fiatAccount.apply(buyRequested({ initialPrice: 50, orderUuid: 'non-affordable' }));

      expect(failedEvent).toEqual(expect.objectContaining({ orderUuid: 'non-affordable', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      const successEvent = fiatAccount.apply(buyRequested({ initialPrice: 10, orderUuid: 'affordable-after-rejection' }));

      expect(successEvent).toEqual(expect.objectContaining({ orderUuid: 'affordable-after-rejection', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      fiatAccount.apply(buyRejected({ initialPrice: 50, orderUuid: 'non-affordable' }));
      fiatAccount.apply(buyRejected({ initialPrice: 10, orderUuid: 'affordable-after-rejection' }));

      fiatAccount.apply(buyRequested({ initialPrice: 10, orderUuid: 'affordable-after-rejection' }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(100);
    });

    it('should not allow to place BuyOrder even if is affordable but has blocked amount before on BuyOrder cancellation', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 90, orderUuid: 'affordable' }));

      const failedEvent = fiatAccount.apply(buyRequested({ initialPrice: 50, orderUuid: 'non-affordable' }));
      expect(failedEvent).toEqual(expect.objectContaining({ orderUuid: 'non-affordable', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      const successEvent = fiatAccount.apply(buyRequested({ initialPrice: 10, orderUuid: 'affordable-after-rejection' }));
      expect(successEvent).toEqual(expect.objectContaining({ orderUuid: 'affordable-after-rejection', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      fiatAccount.apply(buyCancelled({ initialPrice: 50, orderUuid: 'non-affordable' }));
      fiatAccount.apply(buyCancelled({ initialPrice: 10, orderUuid: 'affordable-after-rejection' }));

      fiatAccount.apply(buyRequested({ initialPrice: 10, orderUuid: 'affordable-after-rejection' }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(100);
    });
  });

  describe('Cancellation Logic', () => {
    it('should unblock amount on BuyOrder cancellation', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 50 }));
      fiatAccount.apply(buyCancelled({ initialPrice: 50 }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(0);
    });
  });

  describe('Rejection Logic', () => {
    it('should call RejectOrderCommand if order with price greater than balance was requested', () => {
      const fiatAccount = createFiatAccount({ balance: 10 });

      const event = fiatAccount.apply(buyRequested({ initialPrice: 500 }));

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'order-uuid', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));
    });

    it('should call RejectOrderCommand if order with price greater than available balance (with block) was requested', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 90 }));
      const event = fiatAccount.apply(buyRequested({ initialPrice: 50 }));

      expect(fiatAccount.blockedBalance.toNumber()).toEqual(140);

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'order-uuid', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));
    });

    it('should unblock amount on BuyOrder rejection', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 50 }));
      fiatAccount.apply(buyRejected({ initialPrice: 50 }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(0);
    });
  });

  describe('Expiration Logic', () => {
    it('should unblock amount on BuyOrder rejection', () => {
      const fiatAccount = createFiatAccount({ balance: 100 });

      fiatAccount.apply(buyRequested({ initialPrice: 50 }));
      fiatAccount.apply(buyExpired({ initialPrice: 50 }));

      expect(fiatAccount.balance.toNumber()).toEqual(100);
      expect(fiatAccount.blockedBalance.toNumber()).toEqual(0);
    });
  });
});
