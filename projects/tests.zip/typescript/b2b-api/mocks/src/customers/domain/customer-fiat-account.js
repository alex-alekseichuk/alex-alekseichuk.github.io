const { BigNumber } = require('bignumber.js');
const { RejectOrderCommand } = require('../../common/commands/reject-order.command');
const { ForceRejectOrderCommand } = require('../../common/commands/force-reject-order.command');
const { ExecuteOrderCommand } = require('../../common/commands/execute-order.command');
const {
  BUY_ORDER_EXECUTED,
  SELL_ORDER_EXECUTED,
  BUY_ORDER_REQUESTED,
  BUY_ORDER_CANCELLED,
  BUY_ORDER_REJECTED,
  BUY_ORDER_EXECUTION_REQUESTED,
  BUY_ORDER_EXPIRED,
} = require('../../common/events/trading/order-event.types');

class CustomerFiatAccount {
  constructor({ customerUuid, customerFiatAccountUuid, balance, currency, accountId, iban }) {
    this.customerUuid = customerUuid;
    this.customerFiatAccountUuid = customerFiatAccountUuid;
    this.balance = BigNumber(balance);
    this.blockedBalance = BigNumber(0);
    this.currency = currency;
    this.accountId = accountId;
    this.iban = iban;
  }

  apply(event) {
    let result = null;
    if (event.type === BUY_ORDER_REQUESTED) {
      if (!this._canAfford(event.initialPrice)) {
        result = new RejectOrderCommand(event.orderUuid);
      }
      this._block(event.initialPrice);
    }
    if (event.type === BUY_ORDER_EXECUTION_REQUESTED) {
      if (this._canAfford(safeDifference(event.transactionAmount, event.initialPrice))) {
        result = new ExecuteOrderCommand(event.orderUuid);
      } else {
        result = new ForceRejectOrderCommand(event.orderUuid);
      }
    }
    if (event.type === BUY_ORDER_EXECUTED) {
      this._charge(event.transactionAmount);
      this._unblock(event.initialPrice);
    }
    if (event.type === SELL_ORDER_EXECUTED) {
      this._gain(event.transactionAmount);
    }
    if (this._shouldUnblock(event.type)) {
      this._unblock(event.initialPrice);
    }
    return result;
  }

  toJSON() {
    return {
      customerFiatAccountUuid: this.customerFiatAccountUuid,
      balance: this.balance.toNumber(),
      blockedBalance: this.blockedBalance.toNumber(),
      currency: this.currency,
      accountId: this.accountId,
      iban: this.iban,
    };
  }

  _canAfford(amount) {
    return this.balance.minus(this.blockedBalance).isGreaterThanOrEqualTo(amount);
  }

  _shouldUnblock(eventType) {
    return [BUY_ORDER_CANCELLED, BUY_ORDER_REJECTED, BUY_ORDER_EXPIRED].includes(eventType);
  }

  _block(amount) {
    this.blockedBalance = this.blockedBalance.plus(amount);
  }

  _unblock(amount) {
    this.blockedBalance = this.blockedBalance.minus(amount);
  }

  _gain(amount) {
    this.balance = this.balance.plus(amount);
  }

  _charge(amount) {
    this.balance = this.balance.minus(amount);
  }
}

const safeDifference = (minuend, subtrahend) => BigNumber(minuend).minus(subtrahend);

exports.CustomerFiatAccount = CustomerFiatAccount;
