const { CustomerCryptoPosition } = require('./customer-crypto-position');

const { sellExecutionRequested, sellRequested, buyExecuted, sellExecuted, sellCancelled, sellRejected, sellExpired } = require('./__test__/event.helpers');

const createCryptoPosition = ({ availableBalance, cryptoPositionBundleName } = {}) =>
  new CustomerCryptoPosition({ availableBalance, cryptoPositionBundleName, cryptoPositionUuid: 'crypto-position-uuid', cryptoCurrencyType: 'ETH' });

describe('Customer Crypto Position', () => {
  describe('CryptoPosition ReadModel', () => {
    it('should assign cryptoPositionUuid to cryptoPositionBundleName if cryptoPositionBundleName is not present', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 10 });
      expect(cryptoPosition.toJSON()).toEqual({
        cryptoPositionBundleName: undefined,
        cryptoPositionUuid: 'crypto-position-uuid',
        cryptoCurrencyType: 'ETH',
        availableBalance: 10,
        blockedAvailableBalance: 0,
      });
    });
  });

  describe('Order Execution Request', () => {
    it('should call ORDER_EXECUTION_COMMAND for SELL_ORDER_EXECUTION_REQUESTED', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 10 });

      const event = cryptoPosition.apply(sellExecutionRequested());

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'order-uuid', type: expect.stringContaining('EXECUTE_ORDER_COMMAND') }));
    });
  });

  describe('Order Execution', () => {
    it('should increase customer crypto balance on BUY_ORDER_EXECUTED', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 50 });

      cryptoPosition.apply(buyExecuted({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
    });
    it('should decrease customer crypto balance on SELL_ORDER_EXECUTED', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 50 });

      cryptoPosition.apply(sellExecuted({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(0);
    });
    it('should unblock amount on SellOrder execution', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));
      cryptoPosition.apply(sellExecuted({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(50);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(0);
    });
    it('should publish ExecuteOrderCommand on SELL_ORDER_EXECUTION_REQUESTED event', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      const event = cryptoPosition.apply(sellExecutionRequested({ cryptoAmount: 50 }));

      expect(event).toEqual(expect.objectContaining({ type: expect.stringMatching('EXECUTE_ORDER_COMMAND') }));
    });
  });

  describe('Blocking', () => {
    it('should internally block certain amount of cryptocurrency on SellOrder request', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(50);
    });
    it('should not block crypto balance on BuyOrder request', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(50);
    });
    it('should not allow to place SellOrder even if is affordable but has blocked amount before on SellOrder rejection', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 90, orderUuid: 'affordable' }));

      const firstRejectEvent = cryptoPosition.apply(sellRequested({ cryptoAmount: 50, orderUuid: 'non-affordable' }));
      expect(firstRejectEvent).toEqual(expect.objectContaining({ orderUuid: 'non-affordable', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      const secondRejectEvent = cryptoPosition.apply(sellRequested({ cryptoAmount: 10, orderUuid: 'affordable-after-rejection' }));
      expect(secondRejectEvent).toEqual(expect.objectContaining({ orderUuid: 'affordable-after-rejection', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      cryptoPosition.apply(sellRejected({ cryptoAmount: 50, orderUuid: 'non-affordable' }));
      cryptoPosition.apply(sellRejected({ cryptoAmount: 10, orderUuid: 'affordable-after-rejection' }));

      cryptoPosition.apply(sellRequested({ cryptoAmount: 10, orderUuid: 'affordable-after-rejection' }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(100);
    });
    it('should not allow to place SellOrder even if is affordable but has blocked amount before on SellOrder cancellation', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 90, orderUuid: 'affordable' }));

      const firstRejectEvent = cryptoPosition.apply(sellRequested({ cryptoAmount: 50, orderUuid: 'non-affordable' }));
      expect(firstRejectEvent).toEqual(expect.objectContaining({ orderUuid: 'non-affordable', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      const secondRejectEvent = cryptoPosition.apply(sellRequested({ cryptoAmount: 10, orderUuid: 'affordable-after-rejection' }));
      expect(secondRejectEvent).toEqual(expect.objectContaining({ orderUuid: 'affordable-after-rejection', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));

      cryptoPosition.apply(sellCancelled({ cryptoAmount: 50, orderUuid: 'non-affordable' }));
      cryptoPosition.apply(sellCancelled({ cryptoAmount: 10, orderUuid: 'affordable-after-rejection' }));

      cryptoPosition.apply(sellRequested({ cryptoAmount: 10, orderUuid: 'affordable-after-rejection' }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(100);
    });
  });

  describe('Cancellation Logic', () => {
    it('should unblock amount on SellOrder cancellation', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));
      cryptoPosition.apply(sellCancelled({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(0);
    });
  });

  describe('Rejection Logic', () => {
    it('should call RejectOrderCommand if order with price greater than balance was requested', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 10 });

      const event = cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));

      expect(event).toEqual(expect.objectContaining({ orderUuid: 'order-uuid', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));
    });

    it('should call RejectOrderCommand if order with price greater than available balance (with block) was requested and should ignore new blocking amount', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 55 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));
      const rejectEvent = cryptoPosition.apply(sellRequested({ cryptoAmount: 10 }));

      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(60);

      expect(rejectEvent).toEqual(expect.objectContaining({ orderUuid: 'order-uuid', type: expect.stringContaining('REJECT_ORDER_COMMAND') }));
    });
    it('should unblock amount on SellOrder rejection', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));
      cryptoPosition.apply(sellRejected({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(0);
    });
  });

  describe('Expiration Logic', () => {
    it('should unblock amount on SellOrder rejection', () => {
      const cryptoPosition = createCryptoPosition({ availableBalance: 100 });

      cryptoPosition.apply(sellRequested({ cryptoAmount: 50 }));
      cryptoPosition.apply(sellExpired({ cryptoAmount: 50 }));

      expect(cryptoPosition.availableBalance.toNumber()).toEqual(100);
      expect(cryptoPosition.blockedAvailableBalance.toNumber()).toEqual(0);
    });
  });
});
