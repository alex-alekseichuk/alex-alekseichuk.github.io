const { last } = require('lodash');
const { customerOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE = 'PM007_GENERATE_TEMP_ADDRESS';

class CreateCryptoPositionTemporaryAddressOrder {
  constructor(cryptoPosition) {
    this.cryptoPosition = cryptoPosition;

    this.orderDetails = new OrderDetails();

    this.executionDetails = null;
    this.isExecuted = false;
  }

  canBeExecuted(state) {
    return !this.isExecuted && state === last(customerOrderStates.CREATE_POSITION_TEMP_WALLET_PRE_EXECUTION_STATES);
  }

  availableStates() {
    return customerOrderStates.CREATE_POSITION_TEMP_WALLET_PRE_EXECUTION_STATES;
  }

  executedStates() {
    return customerOrderStates.CREATE_POSITION_TEMP_WALLET_EXECUTION_STATES;
  }

  execute(executionTimestamp = new Date()) {
    this.executionDetails = new OrderExecutionDetails(executionTimestamp);
    this.isExecuted = true;
  }

  toJSON() {
    return {
      orderType: CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE,
      cryptoPosition: this.cryptoPosition,
      ...this.orderDetails.toJSON(),
      ...(this.isExecuted && this.executionDetails.toJSON()),
    };
  }
}

exports.CreateCryptoPositionTemporaryAddressOrder = CreateCryptoPositionTemporaryAddressOrder;
exports.CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE = CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE;
