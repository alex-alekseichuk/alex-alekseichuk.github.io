const { StateMachine } = require('../../common/shared/state-machine/state-machine');
const { OrdersEventFactory } = require('./order-event-factory');

class TrackedOrder {
  constructor({ order, customerUuid, orderUuid, orderId, flushAt }) {
    this.order = order;
    this.stateMachine = new StateMachine(order.availableStates());
    this.customFields = {};

    this.customerUuid = customerUuid;
    this.orderUuid = orderUuid;
    this.orderId = orderId;

    this.flushAt = flushAt;

    this.markedAsRejected = false;
    this.rejected = false;
    this.executed = false;
  }

  state() {
    return {
      ...this.order.toJSON(),
      orderState: this.stateMachine.state,
      customerUuid: this.customerUuid,
      orderUuid: this.orderUuid,
      orderId: this.orderId,
      cancellable: false,
      ...this.customFields,
    };
  }

  addCustomFields(customFields) {
    this.customFields = {
      ...this.customFields,
      ...customFields,
    };
  }

  next(executionTimestamp = new Date()) {
    if (this._shouldBeRejected()) {
      return this._reject();
    }
    if (this._canBeExecuted(this.stateMachine.state)) {
      return this._execute(executionTimestamp);
    }
    this.stateMachine.next();
  }

  markAsRejected() {
    this.markedAsRejected = true;
  }

  _execute(executionTimestamp) {
    this.executed = true;
    this.order.execute(executionTimestamp);
    this.stateMachine = new StateMachine(this.order.executedStates());
    return OrdersEventFactory.executedFromOrder(this.state());
  }

  _reject() {
    this.rejected = true;
    this.stateMachine = new StateMachine(this.order.rejectedStates());
    return OrdersEventFactory.rejectedFromOrder(this.state());
  }

  _canBeExecuted = state => this._isOnTheMainTrack() && this.order.canBeExecuted(state);
  _shouldBeRejected = () => this._isOnTheMainTrack() && this.markedAsRejected;
  _isOnTheMainTrack = () => !this.executed && !this.rejected;
}

exports.TrackedOrder = TrackedOrder;
