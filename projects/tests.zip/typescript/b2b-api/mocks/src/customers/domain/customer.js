class Customer {
  constructor(customerUuid, alias = 'customer-alias', type = 'PRIVATE_CUSTOMER') {
    this.customerUuid = customerUuid;
    this.alias = alias;
    this.type = type;
  }
}

exports.Customer = Customer;
