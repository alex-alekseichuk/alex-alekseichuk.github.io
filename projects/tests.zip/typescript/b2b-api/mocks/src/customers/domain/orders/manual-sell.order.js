const { ManualOrder } = require('./manual.order');

const MANUAL_SELL_TYPE = 'OM112_MANUAL_TRADE_ORDER_SELL';

class ManualSellOrder extends ManualOrder {
  constructor(data) {
    super(data);
  }

  toJSON() {
    return {
      ...super.toJSON(),
      orderType: MANUAL_SELL_TYPE,
    };
  }
}

exports.ManualSellOrder = ManualSellOrder;
exports.MANUAL_SELL_TYPE = MANUAL_SELL_TYPE;
