const { CreateCryptopositionRequestedEvent } = require('../../common/events/customer/create-crypto-position-requested-event');
const { CreateCryptopositionTemporaryAddressExecutedEvent } = require('../../common/events/customer/create-crypto-position-temp-address-executed-event');
const { TransferOrderExecutedEvent, SendOrderExecutedEvent } = require('../../common/events/withdraw/withdraw-order-executed.event');
const { TransferOrderRejectedEvent, SendOrderRejectedEvent } = require('../../common/events/withdraw/withdraw-rejected.event');
const { TransferOrderRequestedEvent, SendOrderRequestedEvent } = require('../../common/events/withdraw/withdraw-requested.event');
const { CREATE_CRYPTO_POSITION_TYPE } = require('./orders/create-cryptoposition.order');
const { CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE } = require('./orders/create-cryptoposition-temp-address.order');
const { SEND_CRYPTO_TYPE } = require('./orders/send-crypto.order');
const { TRANSFER_CRYPTO_TYPE } = require('./orders/transfer-crypto.order');
const { MANUAL_SELL_TYPE } = require('./orders/manual-sell.order');
const { MANUAL_BUY_TYPE } = require('./orders/manual-buy.order');
const { ManualTradeRequestEvent, ManualTradeExecutedEvent, ManualTradeRejectedEvent } = require('../../common/events/customer/manual-trade-event');

class OrdersEventFactory {
  requestedFromOrder(orderJSON) {
    if (orderJSON.orderType === TRANSFER_CRYPTO_TYPE) {
      return new TransferOrderRequestedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sourceCryptoPositionUuid: orderJSON.sourceCryptoPosition.cryptoPositionUuid,
        destinationCryptoPositionUuid: orderJSON.destinationCryptoPosition.cryptoPositionUuid,
        quantity: orderJSON.quantity,
      });
    }
    if (orderJSON.orderType === SEND_CRYPTO_TYPE) {
      return new SendOrderRequestedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sourceCryptoPositionUuid: orderJSON.sourceCryptoPosition.cryptoPositionUuid,
        quantity: orderJSON.quantity,
      });
    }
    if (orderJSON.orderType === MANUAL_BUY_TYPE) {
      return new ManualTradeRequestEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sponsorFiatAccountUuid: orderJSON.clientCustomerFiatAccount.customerFiatAccountUuid,
        beneficientFiatAccountUuid: orderJSON.brokerCustomerFiatAccount.customerFiatAccountUuid,
        sponsorCryptoPositionUuid: orderJSON.brokerCryptoPosition.cryptoPositionUuid,
        beneficientCryptoPositionUuid: orderJSON.clientCryptoPosition.cryptoPositionUuid,
        transactionAmount: orderJSON.transactionAmount,
        transactionQuantity: orderJSON.transactionQuantity,
      });
    }
    if (orderJSON.orderType === MANUAL_SELL_TYPE) {
      return new ManualTradeRequestEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sponsorFiatAccountUuid: orderJSON.brokerCustomerFiatAccount.customerFiatAccountUuid,
        beneficientFiatAccountUuid: orderJSON.clientCustomerFiatAccount.customerFiatAccountUuid,
        sponsorCryptoPositionUuid: orderJSON.clientCryptoPosition.cryptoPositionUuid,
        beneficientCryptoPositionUuid: orderJSON.brokerCryptoPosition.cryptoPositionUuid,
        transactionAmount: orderJSON.transactionAmount,
        transactionQuantity: orderJSON.transactionQuantity,
      });
    }
  }

  executedFromOrder(orderJSON) {
    if (orderJSON.orderType === TRANSFER_CRYPTO_TYPE) {
      return new TransferOrderExecutedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sourceCryptoPositionUuid: orderJSON.sourceCryptoPosition.cryptoPositionUuid,
        destinationCryptoPositionUuid: orderJSON.destinationCryptoPosition.cryptoPositionUuid,
        quantity: orderJSON.quantity,
      });
    }
    if (orderJSON.orderType === SEND_CRYPTO_TYPE) {
      return new SendOrderExecutedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sourceCryptoPositionUuid: orderJSON.sourceCryptoPosition.cryptoPositionUuid,
        quantity: orderJSON.quantity,
      });
    }
    if (orderJSON.orderType === CREATE_CRYPTO_POSITION_TYPE) {
      return new CreateCryptopositionRequestedEvent(orderJSON);
    }
    if (orderJSON.orderType === CREATE_CRYPTO_POSITION_TEMPORARY_ADDRESS_TYPE) {
      return new CreateCryptopositionTemporaryAddressExecutedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        cryptoPositionUuid: orderJSON.cryptoPosition.cryptoPositionUuid,
      });
    }
    if (orderJSON.orderType === MANUAL_BUY_TYPE) {
      return new ManualTradeExecutedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sponsorFiatAccountUuid: orderJSON.clientCustomerFiatAccount.customerFiatAccountUuid,
        beneficientFiatAccountUuid: orderJSON.brokerCustomerFiatAccount.customerFiatAccountUuid,
        sponsorCryptoPositionUuid: orderJSON.brokerCryptoPosition.cryptoPositionUuid,
        beneficientCryptoPositionUuid: orderJSON.clientCryptoPosition.cryptoPositionUuid,
        transactionAmount: orderJSON.transactionAmount,
        transactionQuantity: orderJSON.transactionQuantity,
      });
    }
    if (orderJSON.orderType === MANUAL_SELL_TYPE) {
      return new ManualTradeExecutedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sponsorFiatAccountUuid: orderJSON.brokerCustomerFiatAccount.customerFiatAccountUuid,
        beneficientFiatAccountUuid: orderJSON.clientCustomerFiatAccount.customerFiatAccountUuid,
        sponsorCryptoPositionUuid: orderJSON.clientCryptoPosition.cryptoPositionUuid,
        beneficientCryptoPositionUuid: orderJSON.brokerCryptoPosition.cryptoPositionUuid,
        transactionAmount: orderJSON.transactionAmount,
        transactionQuantity: orderJSON.transactionQuantity,
      });
    }
  }

  rejectedFromOrder(orderJSON) {
    if (orderJSON.orderType === TRANSFER_CRYPTO_TYPE) {
      return new TransferOrderRejectedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sourceCryptoPositionUuid: orderJSON.sourceCryptoPosition.cryptoPositionUuid,
        destinationCryptoPositionUuid: orderJSON.destinationCryptoPosition.cryptoPositionUuid,
        quantity: orderJSON.quantity,
      });
    }
    if (orderJSON.orderType === SEND_CRYPTO_TYPE) {
      return new SendOrderRejectedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sourceCryptoPositionUuid: orderJSON.sourceCryptoPosition.cryptoPositionUuid,
        quantity: orderJSON.quantity,
      });
    }
    if (orderJSON.orderType === MANUAL_BUY_TYPE) {
      return new ManualTradeRejectedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sponsorFiatAccountUuid: orderJSON.clientCustomerFiatAccount.customerFiatAccountUuid,
        beneficientFiatAccountUuid: orderJSON.brokerCustomerFiatAccount.customerFiatAccountUuid,
        sponsorCryptoPositionUuid: orderJSON.brokerCryptoPosition.cryptoPositionUuid,
        beneficientCryptoPositionUuid: orderJSON.clientCryptoPosition.cryptoPositionUuid,
        transactionAmount: orderJSON.transactionAmount,
        transactionQuantity: orderJSON.transactionQuantity,
      });
    }
    if (orderJSON.orderType === MANUAL_SELL_TYPE) {
      return new ManualTradeRejectedEvent({
        orderUuid: orderJSON.orderUuid,
        customerUuid: orderJSON.customerUuid,
        sponsorFiatAccountUuid: orderJSON.brokerCustomerFiatAccount.customerFiatAccountUuid,
        beneficientFiatAccountUuid: orderJSON.clientCustomerFiatAccount.customerFiatAccountUuid,
        sponsorCryptoPositionUuid: orderJSON.clientCryptoPosition.cryptoPositionUuid,
        beneficientCryptoPositionUuid: orderJSON.brokerCryptoPosition.cryptoPositionUuid,
        transactionAmount: orderJSON.transactionAmount,
        transactionQuantity: orderJSON.transactionQuantity,
      });
    }
  }
}

exports.OrdersEventFactory = new OrdersEventFactory();
