const { DateTime } = require('luxon');

class OrderDetails {
  constructor(timestampOrderReceived = new Date()) {
    this.timestampOrderReceived = this._formatOrderDetailsDate(timestampOrderReceived);
  }

  setTradeOrderSubType(tradeOrderSubType) {
    this.tradeOrderSubType = tradeOrderSubType;
  }

  toJSON() {
    return {
      timestampOrderReceived: this.timestampOrderReceived,
    };
  }

  _formatOrderDetailsDate(date) {
    return DateTime.fromJSDate(date, { zone: 'utc' }).toISO({ suppressMilliseconds: true });
  }
}

exports.OrderDetails = OrderDetails;
