const { customerOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const UPDATE_CRYPTO_POSITION_TYPE = 'PM009_UPDATE_CRYPTO_POSITION';

class UpdateCryptoPositionOrder {
  isExecuted = true;

  constructor(cryptoPosition, executionTimestamp = new Date()) {
    this.cryptoPosition = cryptoPosition;

    this.orderDetails = new OrderDetails();
    this.executionDetails = new OrderExecutionDetails(executionTimestamp);
  }

  canBeExecuted(_state) {
    return false;
  }

  availableStates() {
    return customerOrderStates.UPDATE_POSITION_EXECUTION_STATES;
  }

  executedStates() {
    return customerOrderStates.UPDATE_POSITION_EXECUTION_STATES;
  }

  execute(_executionTimestamp) {}

  toJSON() {
    return {
      orderType: UPDATE_CRYPTO_POSITION_TYPE,
      cryptoPosition: this.cryptoPosition,
      ...this.orderDetails.toJSON(),
      ...this.executionDetails.toJSON(),
    };
  }
}

exports.UpdateCryptoPositionOrder = UpdateCryptoPositionOrder;
exports.UPDATE_CRYPTO_POSITION_TYPE = UPDATE_CRYPTO_POSITION_TYPE;
