const { last } = require('lodash');
const { customerOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const TRANSFER_CRYPTO_TYPE = 'OM209_TRANSFER_CRYPTO_CURRENCY';

class TransferCryptoOrder {
  constructor({ sourceCryptoPosition, destinationCryptoPosition, quantity, feePaymentModelType, feePriorityType }) {
    if (!feePaymentModelType || !feePriorityType || !quantity) {
      throw new Error('Transfer Order cannot be instantiated');
    }

    this.sourceCryptoPosition = sourceCryptoPosition;
    this.destinationCryptoPosition = destinationCryptoPosition;
    this.feePaymentModelType = feePaymentModelType;
    this.feePriorityType = feePriorityType;
    this.quantity = quantity;

    this.orderDetails = new OrderDetails();

    this.executionDetails = null;
    this.isExecuted = false;
  }

  execute(executionTimestamp = new Date()) {
    this.executionDetails = new OrderExecutionDetails(executionTimestamp);
    this.isExecuted = true;
  }

  toJSON() {
    return {
      orderType: TRANSFER_CRYPTO_TYPE,
      sourceCryptoPosition: this.sourceCryptoPosition,
      destinationCryptoPosition: this.destinationCryptoPosition,
      feePaymentModelType: this.feePaymentModelType,
      feePriorityType: this.feePriorityType,
      quantity: this.quantity,
      ...this.orderDetails.toJSON(),
      ...(this.isExecuted && this.executionDetails.toJSON()),
    };
  }

  canBeExecuted = state => !this.isExecuted && state === last(customerOrderStates.TRANSFER_CRYPTO_PRE_EXECUTION_STATES);

  availableStates = () => customerOrderStates.TRANSFER_CRYPTO_PRE_EXECUTION_STATES;
  executedStates = () => customerOrderStates.TRANSFER_CRYPTO_EXECUTION_STATES;
  cancellableStates = () => customerOrderStates.TRANSFER_CRYPTO_CANCELLABLE_STATES;
  cancelledStates = () => customerOrderStates.TRANSFER_CRYPTO_CANCELLED_STATES;
  rejectedStates = () => customerOrderStates.TRANSFER_CRYPTO_REJECTED_STATES;
}

exports.TransferCryptoOrder = TransferCryptoOrder;
exports.TRANSFER_CRYPTO_TYPE = TRANSFER_CRYPTO_TYPE;
