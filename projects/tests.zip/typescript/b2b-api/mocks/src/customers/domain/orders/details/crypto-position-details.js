class CryptoPositionDetails {}
