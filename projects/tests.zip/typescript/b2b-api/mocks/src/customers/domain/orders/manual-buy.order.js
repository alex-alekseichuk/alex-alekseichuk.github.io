const { ManualOrder } = require('./manual.order');

const MANUAL_BUY_TYPE = 'OM111_MANUAL_TRADE_ORDER_BUY';

class ManualBuyOrder extends ManualOrder {
  constructor(data) {
    super(data);
  }

  toJSON() {
    return {
      ...super.toJSON(),
      orderType: MANUAL_BUY_TYPE,
    };
  }
}

exports.ManualBuyOrder = ManualBuyOrder;
exports.MANUAL_BUY_TYPE = MANUAL_BUY_TYPE;
