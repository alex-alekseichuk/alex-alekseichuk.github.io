const { customerOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const CLOSE_CRYPTO_POSITION_TYPE = 'PM004_CLOSE_CRYPTO_POSITION';

class CloseCryptoPositionOrder {
  isExecuted = true;

  constructor(cryptoPosition, executionTimestamp = new Date()) {
    this.cryptoPosition = cryptoPosition;
    this.orderDetails = new OrderDetails();
    this.executionDetails = new OrderExecutionDetails(executionTimestamp);
  }

  canBeExecuted(_state) {
    return false;
  }

  availableStates() {
    return customerOrderStates.CLOSE_POSITION_EXECUTION_STATES;
  }

  executedStates() {
    return customerOrderStates.CLOSE_POSITION_EXECUTION_STATES;
  }

  execute(_executionTimestamp = new Date()) {}

  toJSON() {
    return {
      orderType: CLOSE_CRYPTO_POSITION_TYPE,
      cryptoPosition: this.cryptoPosition,
      ...this.orderDetails.toJSON(),
      ...this.executionDetails.toJSON(),
    };
  }
}

exports.CloseCryptoPositionOrder = CloseCryptoPositionOrder;
exports.CLOSE_CRYPTO_POSITION_TYPE = CLOSE_CRYPTO_POSITION_TYPE;
