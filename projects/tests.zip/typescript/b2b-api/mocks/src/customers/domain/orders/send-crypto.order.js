const { last } = require('lodash');
const { customerOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const SEND_CRYPTO_TYPE = 'OM206_SEND_CRYPTO_CURRENCY';

class SendCryptoOrder {
  constructor({ sourceCryptoPosition, destinationPublicAddress, quantity, feePaymentModelType, feePriorityType }) {
    if (!feePaymentModelType || !feePriorityType || !quantity || !destinationPublicAddress) {
      throw new Error('Send Order cannot be instantiated');
    }

    this.sourceCryptoPosition = sourceCryptoPosition;
    this.destinationPublicAddress = destinationPublicAddress;
    this.feePaymentModelType = feePaymentModelType;
    this.feePriorityType = feePriorityType;
    this.quantity = quantity;

    this.orderDetails = new OrderDetails();

    this.executionDetails = null;
    this.isExecuted = false;
  }

  execute(executionTimestamp = new Date()) {
    this.executionDetails = new OrderExecutionDetails(executionTimestamp);
    this.isExecuted = true;
  }

  toJSON() {
    return {
      orderType: SEND_CRYPTO_TYPE,
      sourceCryptoPosition: this.sourceCryptoPosition,
      destinationPublicAddress: this.destinationPublicAddress,
      feePaymentModelType: this.feePaymentModelType,
      feePriorityType: this.feePriorityType,
      quantity: this.quantity,
      ...this.orderDetails.toJSON(),
      ...(this.isExecuted && this.executionDetails.toJSON()),
    };
  }

  canBeExecuted = state => !this.isExecuted && state === last(customerOrderStates.SEND_CRYPTO_PRE_EXECUTION_STATES);

  availableStates = () => customerOrderStates.SEND_CRYPTO_PRE_EXECUTION_STATES;
  executedStates = () => customerOrderStates.SEND_CRYPTO_EXECUTION_STATES;
  cancellableStates = () => customerOrderStates.SEND_CRYPTO_CANCELLABLE_STATES;
  cancelledStates = () => customerOrderStates.SEND_CRYPTO_CANCELLED_STATES;
  rejectedStates = () => customerOrderStates.SEND_CRYPTO_REJECTED_STATES;
}

exports.SendCryptoOrder = SendCryptoOrder;
exports.SEND_CRYPTO_TYPE = SEND_CRYPTO_TYPE;
