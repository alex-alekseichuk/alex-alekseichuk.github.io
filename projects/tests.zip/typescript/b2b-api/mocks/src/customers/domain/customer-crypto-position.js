const { BigNumber } = require('bignumber.js');
const { v4 } = require('uuid');
const { ExecuteOrderCommand } = require('../../common/commands/execute-order.command');
const { RejectOrderCommand } = require('../../common/commands/reject-order.command');
const {
  SELL_ORDER_EXECUTED,
  BUY_ORDER_EXECUTED,
  SELL_ORDER_REQUESTED,
  SELL_ORDER_CANCELLED,
  SELL_ORDER_REJECTED,
  SELL_ORDER_EXECUTION_REQUESTED,
  SELL_ORDER_EXPIRED,
} = require('../../common/events/trading/order-event.types');
const {
  SEND_ORDER_REQUESTED,
  TRANSFER_ORDER_REQUESTED,
  TRANSFER_ORDER_EXECUTED,
  TRANSFER_ORDER_REJECTED,
  SEND_ORDER_EXECUTED,
  SEND_ORDER_REJECTED,
} = require('../../common/events/withdraw/withdraw-event-types');
const { CryptoPositionData } = require('./crypto-position.data');

class CustomerCryptoPosition {
  constructor({ customerUuid, cryptoPositionUuid, cryptoCurrencyType, cryptoPositionBundleName, logicalWalletUuid, availableBalance = 0, ...data }) {
    this.customerUuid = customerUuid;
    this.cryptoPositionUuid = cryptoPositionUuid;
    this.cryptoCurrencyType = cryptoCurrencyType;
    this.cryptoPositionBundleName = cryptoPositionBundleName;
    this.availableBalance = BigNumber(availableBalance);
    this.logicalWalletUuid = logicalWalletUuid;
    this.blockedAvailableBalance = BigNumber(0);
    this.cryptoPositionData = new CryptoPositionData(data);
    this.temporaryAddresses = [];
  }

  apply(event) {
    return this.applyTradingEvent(event) ?? this.applyWithdrawEvent(event);
  }

  applyTradingEvent(event) {
    let result = null;
    if (event.type === SELL_ORDER_REQUESTED) {
      if (!this._canAfford(event.quantity)) {
        result = new RejectOrderCommand(event.orderUuid);
      }
      this._block(event.quantity);
    }
    if (event.type === SELL_ORDER_EXECUTION_REQUESTED) {
      result = new ExecuteOrderCommand(event.orderUuid);
    }
    if (event.type === SELL_ORDER_EXECUTED) {
      this._charge(event.transactionQuantity);
      this._unblock(event.transactionQuantity);
    }
    if (event.type === BUY_ORDER_EXECUTED) {
      this._gain(event.transactionQuantity);
    }
    if (this._shouldUnblock(event.type)) {
      this._unblock(event.quantity);
    }
    return result;
  }

  applyWithdrawEvent(event) {
    let result = null;
    if (event.type === TRANSFER_ORDER_REQUESTED || event.type === SEND_ORDER_REQUESTED) {
      if (event.sourceCryptoPositionUuid === this.cryptoPositionUuid) {
        if (!this._canAfford(event.quantity)) {
          result = new RejectOrderCommand(event.orderUuid);
        }
        this._block(event.quantity);
      }
    }
    if (event.type === TRANSFER_ORDER_EXECUTED || event.type === SEND_ORDER_EXECUTED) {
      if (event.sourceCryptoPositionUuid === this.cryptoPositionUuid) {
        this._charge(event.quantity);
        this._unblock(event.quantity);
      }
      if (event.destinationCryptoPositionUuid === this.cryptoPositionUuid) {
        this._gain(event.quantity);
      }
    }
    if (event.type === TRANSFER_ORDER_REJECTED || event.type === SEND_ORDER_REJECTED) {
      if (event.sourceCryptoPositionUuid === this.cryptoPositionUuid) {
        this._unblock(event.quantity);
      }
    }
    return result;
  }

  setBundleName(cryptoPositionBundleName) {
    this.cryptoPositionBundleName = cryptoPositionBundleName;
  }

  addTemporaryAddress(orderUuid) {
    this.temporaryAddresses.push({
      publicAddress: `tempAddress_${v4()}`,
      orderUuid,
    });
  }

  toJSON() {
    return {
      cryptoPositionUuid: this.cryptoPositionUuid,
      cryptoCurrencyType: this.cryptoCurrencyType,
      cryptoPositionBundleName: this.cryptoPositionBundleName,
      logicalWalletUuid: this.logicalWalletUuid,
      availableBalance: this.availableBalance.toNumber(),
      blockedAvailableBalance: this.blockedAvailableBalance.toNumber(),
      ...this.cryptoPositionData.toJSON(),
    };
  }

  _canAfford = amount => this.availableBalance.minus(this.blockedAvailableBalance).isGreaterThanOrEqualTo(amount);

  _shouldUnblock = eventType => [SELL_ORDER_CANCELLED, SELL_ORDER_REJECTED, SELL_ORDER_EXPIRED].includes(eventType);

  _block = amount => (this.blockedAvailableBalance = this.blockedAvailableBalance.plus(amount));

  _unblock = amount => (this.blockedAvailableBalance = this.blockedAvailableBalance.minus(amount));

  _gain = amount => (this.availableBalance = this.availableBalance.plus(amount));

  _charge = amount => (this.availableBalance = this.availableBalance.minus(amount));
}

exports.CustomerCryptoPosition = CustomerCryptoPosition;
