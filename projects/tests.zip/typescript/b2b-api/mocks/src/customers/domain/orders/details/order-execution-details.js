const { DateTime } = require('luxon');

class OrderExecutionDetails {
  constructor(lastExecutionTimestamp) {
    this.lastExecutionTimestamp = lastExecutionTimestamp;
  }

  toJSON() {
    return {
      lastExecutionTimestamp: this._formatOrderExecutionDate(this.lastExecutionTimestamp),
    };
  }

  _formatOrderExecutionDate(date) {
    return DateTime.fromJSDate(date, { zone: 'utc' }).toISO({ suppressMilliseconds: true });
  }
}

exports.OrderExecutionDetails = OrderExecutionDetails;
