class ManualOrderDetails {
  constructor(data) {
    this.data = data;
  }

  toJSON() {
    return {
      brokerCryptoPosition: {
        cryptoCurrencyType: this.data.brokerCryptoPosition.cryptoCurrencyType,
        cryptoPositionBundleUuid: this.data.brokerCryptoPosition.cryptoPositionBundleUuid,
        cryptoPositionUuid: this.data.brokerCryptoPosition.cryptoPositionUuid,
        cryptoProductPositionUuid: this.data.brokerCryptoPosition.cryptoProductPositionUuid,
        customerUuid: this.data.brokerCryptoPosition.customerUuid,
        logicalWalletUuid: this.data.brokerCryptoPosition.logicalWalletUuid,
        omnibusMasterCryptoPositionBundleUuid: this.data.brokerCryptoPosition.omnibusMasterCryptoPositionBundleUuid,
        state: this.data.brokerCryptoPosition.state,
      },
      brokerCustomerFiatAccount: {
        accountId: this.data.brokerCustomerFiatAccount.accountId,
        currency: this.data.brokerCustomerFiatAccount.currency,
        customerFiatAccountUuid: this.data.brokerCustomerFiatAccount.customerFiatAccountUuid,
        customerUuid: this.data.brokerCustomerFiatAccount.customerUuid,
        iban: this.data.brokerCustomerFiatAccount.iban,
        isActive: this.data.brokerCustomerFiatAccount.isActive,
        isDefault: this.data.brokerCustomerFiatAccount.isDefault,
      },
      clientCryptoPosition: {
        cryptoCurrencyType: this.data.clientCryptoPosition.cryptoCurrencyType,
        cryptoPositionBundleUuid: this.data.clientCryptoPosition.cryptoPositionBundleUuid,
        cryptoPositionUuid: this.data.clientCryptoPosition.cryptoPositionUuid,
        cryptoProductPositionUuid: this.data.clientCryptoPosition.cryptoProductPositionUuid,
        customerUuid: this.data.clientCryptoPosition.customerUuid,
        logicalWalletUuid: this.data.clientCryptoPosition.logicalWalletUuid,
        omnibusMasterCryptoPositionBundleUuid: this.data.clientCryptoPosition.omnibusMasterCryptoPositionBundleUuid,
        state: this.data.clientCryptoPosition.state,
      },
      clientCustomerFiatAccount: {
        accountId: this.data.clientCustomerFiatAccount.accountId,
        currency: this.data.clientCustomerFiatAccount.currency,
        customerFiatAccountUuid: this.data.clientCustomerFiatAccount.customerFiatAccountUuid,
        customerUuid: this.data.clientCustomerFiatAccount.customerUuid,
        iban: this.data.clientCustomerFiatAccount.iban,
        isActive: this.data.clientCustomerFiatAccount.isActive,
        isDefault: this.data.clientCustomerFiatAccount.isDefault,
      },
      brokerCustomerUuid: this.data.brokerCustomerUuid,
      cBSAction: this.data.cBSAction,
      comment: this.data.comment,
      exchangeCurrency: this.data.exchangeCurrency,
      limitAmount: this.data.limitAmount,
      price: this.data.price,
      timestampOrderExecuted: this.data.timestampOrderExecuted,
      timestampOrderReceived: this.data.timestampOrderReceived,
      tradeOrderSubType: this.data.tradeOrderSubType,
      tradeOrderType: this.data.tradeOrderType,
      trader: this.data.trader,
      transactionAmount: this.data.transactionAmount,
      transactionQuantity: this.data.transactionQuantity,
      cancellable: false,
    };
  }
}

exports.ManualOrderDetails = ManualOrderDetails;
