const { last } = require('lodash');
const { manualOrderStates } = require('../../../mockserver-configuration');
const { ManualOrderDetails } = require('./details/manual-order-details');

class ManualOrder {
  constructor(data) {
    this.orderDetails = new ManualOrderDetails(data);
    this.isExecuted = false;
  }

  canBeExecuted(state) {
    return !this.isExecuted && state === last(manualOrderStates.MANUAL_TRADE_PRE_EXECUTION_STATES);
  }

  availableStates() {
    return manualOrderStates.MANUAL_TRADE_PRE_EXECUTION_STATES;
  }

  executedStates() {
    return manualOrderStates.MANUAL_TRADE_EXECUTION_STATES;
  }

  rejectedStates() {
    return manualOrderStates.MANUAL_TRADE_REJECTED_STATES;
  }

  execute() {
    this.isExecuted = true;
  }

  toJSON() {
    return {
      ...this.orderDetails.toJSON(),
    };
  }
}

exports.ManualOrder = ManualOrder;
