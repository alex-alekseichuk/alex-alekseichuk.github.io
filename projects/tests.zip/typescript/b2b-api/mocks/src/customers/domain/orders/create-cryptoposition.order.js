const { last } = require('lodash');
const { customerOrderStates } = require('../../../mockserver-configuration');
const { OrderDetails } = require('./details/order-details');
const { OrderExecutionDetails } = require('./details/order-execution-details');

const CREATE_CRYPTO_POSITION_TYPE = 'PM001_CREATE_CRYPTO_POSITION';

class CreateCryptoPositionOrder {
  constructor(data) {
    this.cryptoPositionBundleUuid = data.cryptoPositionBundleUuid;
    this.cryptoCurrencyType = data.cryptoCurrencyType;
    this.cryptoPositionType = data.cryptoPositionType;
    this.cryptoProductUuid = data.cryptoProductUuid;
    this.distributedLedgerTechnologyType = data.distributedLedgerTechnologyType;
    this.logicalWalletUuid = data.logicalWalletUuid;
    this.cryptoPositionBundleName = data.cryptoPositionBundleName;

    this.orderDetails = new OrderDetails();

    this.executionDetails = null;
    this.isExecuted = false;
  }

  canBeExecuted(state) {
    return !this.isExecuted && state === last(customerOrderStates.CREATE_POSITION_PRE_EXECUTION_STATES);
  }

  availableStates() {
    return customerOrderStates.CREATE_POSITION_PRE_EXECUTION_STATES;
  }

  executedStates() {
    return customerOrderStates.CREATE_POSITION_EXECUTION_STATES;
  }

  execute(executionTimestamp = new Date()) {
    this.executionDetails = new OrderExecutionDetails(executionTimestamp);
    this.isExecuted = true;
  }

  toJSON() {
    return {
      orderType: CREATE_CRYPTO_POSITION_TYPE,
      cryptoPositionBundleUuid: this.cryptoPositionBundleUuid,
      cryptoCurrencyType: this.cryptoCurrencyType,
      cryptoPositionType: this.cryptoPositionType,
      cryptoProductUuid: this.cryptoProductUuid,
      distributedLedgerTechnologyType: this.distributedLedgerTechnologyType,
      logicalWalletUuid: this.logicalWalletUuid,
      cryptoPositionBundleName: this.cryptoPositionBundleName,
      state: 'CREATED',
      ...this.orderDetails.toJSON(),
      ...(this.isExecuted && this.executionDetails.toJSON()),
    };
  }
}

exports.CreateCryptoPositionOrder = CreateCryptoPositionOrder;
exports.CREATE_CRYPTO_POSITION_TYPE = CREATE_CRYPTO_POSITION_TYPE;
