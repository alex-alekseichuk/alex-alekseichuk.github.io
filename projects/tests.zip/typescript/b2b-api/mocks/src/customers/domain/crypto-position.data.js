class CryptoPositionData {
  constructor({ cryptoPositionBundleUuid, cryptoProductPositionUuid, omnibusMasterCryptoPositionBundleUuid, cryptoPositionType, publicAddress, state }) {
    this.cryptoPositionBundleUuid = cryptoPositionBundleUuid;
    this.cryptoProductPositionUuid = cryptoProductPositionUuid;
    this.publicAddress = publicAddress;
    this.omnibusMasterCryptoPositionBundleUuid = omnibusMasterCryptoPositionBundleUuid;
    this.cryptoPositionType = cryptoPositionType;
    this.state = state;
  }

  toJSON() {
    return {
      cryptoPositionBundleUuid: this.cryptoPositionBundleUuid,
      cryptoProductPositionUuid: this.cryptoProductPositionUuid,
      publicAddress: this.publicAddress,
      omnibusMasterCryptoPositionBundleUuid: this.omnibusMasterCryptoPositionBundleUuid,
      cryptoPositionType: this.cryptoPositionType,
      state: this.state,
    };
  }
}

exports.CryptoPositionData = CryptoPositionData;
