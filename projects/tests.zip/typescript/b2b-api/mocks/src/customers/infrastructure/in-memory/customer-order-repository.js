const uuid = require('uuid');
const { cacheOptions } = require('../../../mockserver-configuration');
const { TrackedOrder } = require('../../domain/tracked-order');

class CustomerOrderRepository {
  orders = new Map();

  constructor(dataRetencyTime = cacheOptions.ORDERS_CACHE_RETENTION_TIMEOUT) {
    this.dataRetencyTime = dataRetencyTime;
  }

  findOne(orderUuid) {
    const order = this.orders.get(orderUuid);
    if (!order) {
      return null;
    }
    return order;
  }

  findManyByCustomerUuid(customerUuid) {
    return this.findAll().filter(order => order.customerUuid === customerUuid);
  }

  findAll() {
    return [...this.orders.values()];
  }

  create(customerUuid, order, createdAt = new Date()) {
    const orderUuid = uuid.v4();
    const orderId = `${Math.random()}`.slice(-9);
    const trackedOrder = new TrackedOrder({
      customerUuid,
      orderId,
      orderUuid,
      order,
      flushAt: createdAt.getTime() + this.dataRetencyTime,
    });
    this.orders.set(orderUuid, trackedOrder);
    return trackedOrder;
  }

  save(order) {
    this.orders.set(order.orderUuid, order);
  }

  flush(currentDate) {
    const flushedOrders = new Set();
    for (const [orderUuid, trackedOrder] of this.orders.entries()) {
      if (currentDate.getTime() >= trackedOrder.flushAt) {
        flushedOrders.add(orderUuid);
        this.orders.delete(orderUuid);
      }
    }
    return [...flushedOrders];
  }
}

exports.CustomerOrderRepository = CustomerOrderRepository;
