class CustomerRepository {
  customers = new Map();

  findAll() {
    return [...this.customers.values()];
  }

  findOne(customerUuid) {
    return this.customers.get(customerUuid);
  }

  save(customer) {
    this.customers.set(customer.customerUuid, customer);
  }
}

exports.CustomerRepository = CustomerRepository;
