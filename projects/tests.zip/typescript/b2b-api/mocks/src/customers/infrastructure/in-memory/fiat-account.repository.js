class FiatAccountRepository {
  fiatAccounts = new Map();

  findOne(fiatAccountUuid) {
    const account = this.fiatAccounts.get(fiatAccountUuid);
    if (!account) {
      return null;
    }
    return account;
  }

  findManyByCustomerUuid(customerUuid) {
    const accounts = [...this.fiatAccounts.values()];
    if (!accounts) {
      return [];
    }
    return accounts.filter(account => account.customerUuid === customerUuid);
  }

  findManyByFiatAccountUuids(customerUuid, fiatAccountUuids = []) {
    const accounts = [...this.fiatAccounts.values()];
    if (!accounts) {
      return [];
    }
    return accounts.filter(account => fiatAccountUuids.includes(account.customerFiatAccountUuid) && account.customerUuid === customerUuid);
  }

  save(fiatAccount) {
    this.fiatAccounts.set(fiatAccount.customerFiatAccountUuid, fiatAccount);
  }
}

exports.FiatAccountRepository = FiatAccountRepository;
