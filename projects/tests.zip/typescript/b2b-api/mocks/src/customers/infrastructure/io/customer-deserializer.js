const Validator = require('jsonschema').Validator;
const { customerSchema } = require('./customer.schema');
const { Customer } = require('../../domain/customer');
const { CustomerFiatAccount } = require('../../domain/customer-fiat-account');
const { CustomerCryptoPosition } = require('../../domain/customer-crypto-position');
const { cannotDeserialize } = require('../../app/errors');

class CustomerDeserializer {
  constructor(customerRepository, fiatAccountRepository, cryptoPositionRepository) {
    this.customerRepository = customerRepository;
    this.fiatAccountRepository = fiatAccountRepository;
    this.cryptoPositionRepository = cryptoPositionRepository;
  }

  fromJSON(content) {
    content.forEach(customerEntry => {
      const customerData = this._validate(customerEntry);
      this.customerRepository.save(new Customer(customerData.customerUuid, customerData.alias, customerData.type));
      customerData.fiatAccounts.forEach(fiatData => this.fiatAccountRepository.save(new CustomerFiatAccount(fiatData)));
      customerData.cryptoPositions.forEach(cryptoData => this.cryptoPositionRepository.save(new CustomerCryptoPosition(cryptoData)));
    });
  }

  _validate(content) {
    const result = new Validator().validate(content, customerSchema);
    if (result.errors.length) {
      throw cannotDeserialize(result.errors);
    }
    return result.instance;
  }
}

exports.CustomerDeserializer = CustomerDeserializer;
