const { CustomerOrderRepository } = require('./customer-order-repository');
const { CloseCryptoPositionOrder } = require('../../domain/orders/close-cryptoposition.order');

describe('TradingOrderRepository', () => {
  it('applies data retency policy on flush triggered', async () => {
    const oneHour = 60 * 60 * 1000;
    const twoHours = 2 * oneHour;
    const repository = new CustomerOrderRepository(twoHours);

    const flushDate = new Date('Tue May 25 2021 10:56:01 GMT+0200 (Central European Summer Time)');
    const disposableDate = new Date(flushDate.getTime() - twoHours);
    const validDate = new Date(flushDate.getTime() - oneHour);

    const disposedOrder = await repository.create('customer-uuid', new CloseCryptoPositionOrder(), disposableDate);
    const validOrder = await repository.create('customer-uuid', new CloseCryptoPositionOrder(), validDate);

    const flushedOrders = repository.flush(flushDate);

    expect(flushedOrders).toEqual([disposedOrder.orderUuid]);
    expect([...repository.orders.keys()]).toEqual([validOrder.orderUuid]);
  });
});
