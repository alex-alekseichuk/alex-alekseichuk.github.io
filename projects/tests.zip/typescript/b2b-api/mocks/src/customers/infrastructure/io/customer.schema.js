const customerSchema = {
  id: '/Customer',
  type: 'object',
  properties: {
    customerUuid: { type: 'string' },
    alias: { type: 'string' },
    type: { type: 'string' },
    fiatAccounts: {
      id: '/FiatAccount',
      type: 'array',
      items: {
        type: 'object',
        properties: {
          customerUuid: { type: 'string' },
          customerFiatAccountUuid: { type: 'string' },
          accountId: { type: 'string' },
          iban: { type: 'string' },
          currency: { type: 'string' },
          balance: { type: 'number' },
        },
        required: ['customerUuid', 'customerFiatAccountUuid', 'balance', 'currency'],
      },
    },
    cryptoPositions: {
      id: '/CryptoPosition',
      type: 'array',
      items: {
        type: 'object',
        properties: {
          customerUuid: { type: 'string' },
          cryptoPositionBundleName: { type: 'string' },
          cryptoPositionUuid: { type: 'string' },
          cryptoCurrencyType: { type: 'string' },
          availableBalance: { type: 'number' },
          publicAddress: { type: 'string' },
        },
        required: ['customerUuid', 'cryptoPositionUuid', 'availableBalance', 'cryptoCurrencyType'],
      },
    },
  },
  required: ['customerUuid', 'alias', 'type', 'fiatAccounts', 'cryptoPositions'],
};

exports.customerSchema = customerSchema;
