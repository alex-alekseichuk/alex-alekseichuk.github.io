const { CustomerCryptoPosition } = require('../../domain/customer-crypto-position');

class CryptoPositionRepository {
  cryptoPositions = new Map();

  findOne(cryptoPositionUuid) {
    const position = this.cryptoPositions.get(cryptoPositionUuid);
    if (!position) {
      return null;
    }
    return position;
  }

  findOneByCustomerUuid(customerUuid, cryptoPositionUuid) {
    const positions = [...this.cryptoPositions.values()];
    return positions.find(position => position.cryptoPositionUuid === cryptoPositionUuid && position.customerUuid === customerUuid);
  }

  findOneByLogicalWalletUuid(logicalWalletUuid) {
    const positions = [...this.cryptoPositions.values()];
    return positions.find(position => position.logicalWalletUuid === logicalWalletUuid);
  }

  findManyByCustomerUuid(customerUuid) {
    const positions = [...this.cryptoPositions.values()];
    return positions.filter(position => position.customerUuid === customerUuid);
  }

  create(customerUuid, cryptoPositionUuid, cryptoPositionData) {
    const position = new CustomerCryptoPosition({
      customerUuid,
      cryptoPositionUuid,
      ...cryptoPositionData,
    });
    this.save(position);
    return position;
  }

  save(cryptoPosition) {
    this.cryptoPositions.set(cryptoPosition.cryptoPositionUuid, cryptoPosition);
  }

  removeOne(cryptoPositionUuid) {
    return this.cryptoPositions.delete(cryptoPositionUuid);
  }
}

exports.CryptoPositionRepository = CryptoPositionRepository;
