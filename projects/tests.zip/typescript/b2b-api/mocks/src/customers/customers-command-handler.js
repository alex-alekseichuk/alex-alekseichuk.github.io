const uuid = require('uuid');
const { TradingOrderEvent } = require('../common/events/trading/trading-order-event');
const { WithdrawOrderEvent } = require('../common/events/withdraw/withdraw-order-event');
const { CREATE_CRYPTOPOSITION_REQUESTED, CREATE_CRYPTOPOSITION_TEMP_ADDRESS_EXECUTED } = require('../common/events/customer/customer-order-event.types');
const { REJECT_ORDER_COMMAND } = require('../common/commands/order-command.types');
const { OrderCommand } = require('../common/commands/order.command');
const { ManualTradeEvent } = require('../common/events/customer/manual-trade-event');
const { BuyOrderRequestedEvent, SellOrderRequestedEvent } = require('../common/events/trading/order-requested.event');
const { ManualOrderEventMapper } = require('../common/events/customer/manual-trate-event.mapper');

class CustomersCommandHandler {
  constructor(cryptoPositionRepository, fiatAccountRepository, orderRepository, eventPublisher) {
    this.cryptoPositionRepository = cryptoPositionRepository;
    this.fiatAccountRepository = fiatAccountRepository;
    this.orderRepository = orderRepository;
    this.eventPublisher = eventPublisher;
  }

  apply(event) {
    if (event instanceof TradingOrderEvent) {
      return this._applyTradingEvent(event);
    }
    if (event instanceof ManualTradeEvent) {
      return this._applyManualTradingEvent(event);
    }
    if (event instanceof WithdrawOrderEvent) {
      return this._applyWithdrawEvent(event);
    }
    if (event instanceof OrderCommand) {
      return this.eventPublisher?.publish(this._applyOrderCommand(event));
    }
    if (event.type === CREATE_CRYPTOPOSITION_REQUESTED) {
      const cryptoPosition = this.cryptoPositionRepository.create(event.customerUuid, uuid.v4(), event.cryptoPositionData);

      const order = this.orderRepository.findOne(event.orderUuid);
      if (order) {
        order.addCustomFields({ cryptoPosition });
      }
    }
    if (event.type === CREATE_CRYPTOPOSITION_TEMP_ADDRESS_EXECUTED) {
      this.cryptoPositionRepository.findOne(event.cryptoPositionUuid)?.addTemporaryAddress(event.orderUuid);
    }
  }

  subscribe(eventPublisher) {
    eventPublisher.addListener(this);
  }

  _applyTradingEvent(event) {
    const account = this.fiatAccountRepository.findOne(event.customerFiatAccountUuid);
    if (account) {
      this.eventPublisher?.publish(account.apply(event));
    }
    const position = this.cryptoPositionRepository.findOne(event.cryptoPositionUuid);
    if (position) {
      this.eventPublisher?.publish(position.apply(event));
    }
  }

  _applyManualTradingEvent(event) {
    const [buyEvent, sellEvent] = ManualOrderEventMapper.forEvent(event);

    const fiatSponsor = this.fiatAccountRepository.findOne(event.sponsorFiatAccountUuid);
    const cryptoBeneficient = this.cryptoPositionRepository.findOne(event.beneficientCryptoPositionUuid);

    this.eventPublisher?.publish(fiatSponsor?.apply(buyEvent));
    this.eventPublisher?.publish(cryptoBeneficient?.apply(buyEvent));

    const cryptoSponsor = this.cryptoPositionRepository.findOne(event.sponsorCryptoPositionUuid);
    const fiatBeneficient = this.fiatAccountRepository.findOne(event.beneficientFiatAccountUuid);

    this.eventPublisher?.publish(cryptoSponsor?.apply(sellEvent));
    this.eventPublisher?.publish(fiatBeneficient?.apply(sellEvent));
  }

  _applyWithdrawEvent(event) {
    if (event.sourceCryptoPositionUuid) {
      const position = this.cryptoPositionRepository.findOne(event.sourceCryptoPositionUuid);
      this.eventPublisher?.publish(position?.apply(event));
    }
    if (event.destinationCryptoPositionUuid) {
      const position = this.cryptoPositionRepository.findOne(event.destinationCryptoPositionUuid);
      this.eventPublisher?.publish(position?.apply(event));
    }
  }

  _applyOrderCommand(command) {
    const order = this.orderRepository.findOne(command.orderUuid);
    if (!order) {
      return;
    }
    if (command.type === REJECT_ORDER_COMMAND) {
      return order.markAsRejected();
    }
  }
}

exports.CustomersCommandHandler = CustomersCommandHandler;
