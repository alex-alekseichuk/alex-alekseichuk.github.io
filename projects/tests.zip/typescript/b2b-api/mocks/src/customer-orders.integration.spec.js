const { last } = require('lodash');
const { safeWhile } = require('./__test__/helpers');
const { limitOrderPrices, tradingOrderStates } = require('./mockserver-configuration');
const { TradingOrderRepository, TradingCommandHandler, TradingService } = require('./trading');
const { FiatAccountRepository, CustomerRepository, CryptoPositionRepository, CustomersCommandHandler, loadCachedData, CustomerOrderRepository } = require('./customers');
const { marketBuyPayload, marketSellPayload, limitSellPayload, limitBuyPayload, marketStopBuyPayload, limitStopBuyPayload } = require('./__test__/helpers');
const { integrationTestData } = require('./__test__/integration-data');
const { EventPublisher } = require('./common/infrastructure/pubsub/event-publisher');
const { CryptoCurrencyExchange } = require('./exchange/__test__/crypto-currency-exchange');

const emptyFiat = 'fiat-account-0-uuid';
const fiatWith10k = 'fiat-account-1-uuid';
const emptyWallet = 'crypto-position-0-uuid';
const walletWith100 = 'crypto-position-1-uuid';

describe('Customer x Order balance integration test', () => {
  let fiatAccountRepository;
  let customerRepository;
  let cryptoPositionRepository;
  let customersCommandHandler;
  let tradingOrderRepository;
  let tradingService;
  let tradingCommandHandler;
  let cryptoCurrencyExchange;

  const nextState = async (order, fetchDate = new Date()) => (await tradingService.step(order.orderUuid, fetchDate)).orderState;
  const untilReached = async (order, desiredState) => safeWhile(async () => (await nextState(order)) !== desiredState);
  const trackOrder = async payload => tradingService.create('customer-1-uuid', payload);
  const getFiatAccount = ({ fiatAccountUuid = fiatWith10k } = {}) => fiatAccountRepository.findOne(fiatAccountUuid).toJSON();
  const getCryptoPosition = ({ cryptoPositionUuid = walletWith100 } = {}) => cryptoPositionRepository.findOne(cryptoPositionUuid).toJSON();

  const init = () => {
    cryptoCurrencyExchange = new CryptoCurrencyExchange();

    const customersEventPublisher = new EventPublisher();
    fiatAccountRepository = new FiatAccountRepository();
    customerRepository = new CustomerRepository();
    cryptoPositionRepository = new CryptoPositionRepository();
    customerOrderRepository = new CustomerOrderRepository();
    customersCommandHandler = new CustomersCommandHandler(cryptoPositionRepository, fiatAccountRepository, customerOrderRepository, customersEventPublisher);

    const tradingEventPublisher = new EventPublisher();
    tradingOrderRepository = new TradingOrderRepository(cryptoCurrencyExchange);
    tradingService = new TradingService(cryptoCurrencyExchange, tradingOrderRepository, tradingEventPublisher);
    tradingCommandHandler = new TradingCommandHandler(tradingOrderRepository, tradingEventPublisher);

    customersCommandHandler.subscribe(tradingEventPublisher);
    tradingCommandHandler.subscribe(customersEventPublisher);
  };

  beforeEach(() => {
    init();
    loadCachedData(customerRepository, fiatAccountRepository, cryptoPositionRepository, integrationTestData);
  });

  describe('State Transition', () => {
    it('should pass through all possible states for market order', async () => {
      const allStates = [...tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES, ...tradingOrderStates.EXECUTION_STATES];

      const order = await trackOrder(marketSellPayload({ sellAmount: 1 }));

      for (const state of allStates) {
        expect(await nextState(order)).toEqual(state);
      }
    });
  });

  describe('Balance manipulation', () => {
    describe('Buy Order', () => {
      it('should block Fiat Balance if BuyOrder was requested', async () => {
        await trackOrder(marketBuyPayload({ buyAmount: 1 }));
        expect(getFiatAccount().blockedBalance).toEqual(1000);
      });
    });

    describe('Sell Order', () => {
      it('should block Crypto Balance if SellOrder was requested', async () => {
        await trackOrder(marketSellPayload({ sellAmount: 1 }));
        expect(getCryptoPosition().blockedAvailableBalance).toEqual(1);
      });
    });
  });

  describe('Order rejection', () => {
    describe('BuyOrder', () => {
      it('should Reject a non-affordable Market BuyOrder and Release Blocked Amount', async () => {
        const order = await trackOrder(
          marketBuyPayload({
            buyAmount: 10,
            customerFiatAccountUuid: emptyFiat,
          })
        );

        expect(await nextState(order)).toEqual('INITIAL');
        expect(await nextState(order)).toEqual('REJECTED');

        expect(getFiatAccount().balance).toEqual(10000);
        expect(getCryptoPosition().availableBalance).toEqual(100);
        expect(getFiatAccount().blockedBalance).toEqual(0);
      });

      it('should Reject a Limit BuyOrder when specific LimitAmount was provided', async () => {
        const order = await trackOrder(
          limitBuyPayload({
            buyAmount: 1,
            limitAmount: limitOrderPrices.LIMIT_ORDER_REJECT_PRICE,
          })
        );

        expect(await nextState(order)).toEqual('INITIAL');
        expect(await nextState(order)).toEqual('REJECTED');

        expect(getFiatAccount().balance).toEqual(10000);
        expect(getCryptoPosition().availableBalance).toEqual(100);
        expect(getFiatAccount().blockedBalance).toEqual(0);
      });

      it('should Reject a Market BuyOrder if Market Price changed and Customer cannot afford it', async () => {
        const order = await trackOrder(
          marketBuyPayload({
            buyAmount: 1,
          })
        );

        jest.spyOn(cryptoCurrencyExchange, 'getUnitPriceFor').mockImplementation(() => 10001);

        await untilReached(order, last(tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES));

        expect(await nextState(order)).toEqual('REJECTED');

        expect(getFiatAccount().balance).toEqual(10000);
        expect(getCryptoPosition().availableBalance).toEqual(100);
        expect(getFiatAccount().blockedBalance).toEqual(0);
      });
    });

    describe('SellOrder', () => {
      it('should Reject a non-affordable Market SellOrder and Release Blocked Crypto Amount', async () => {
        const order = await trackOrder(
          marketSellPayload({
            sellAmount: 10,
            cryptoPositionUuid: emptyWallet,
          })
        );

        expect(await nextState(order)).toEqual('INITIAL');
        expect(await nextState(order)).toEqual('REJECTED');

        expect(getFiatAccount().balance).toEqual(10000);
        expect(getCryptoPosition().availableBalance).toEqual(100);
        expect(getCryptoPosition().blockedAvailableBalance).toEqual(0);
      });

      it('should Reject a Limit SellOrder when specific LimitAmount was provided', async () => {
        const order = await trackOrder(
          limitSellPayload({
            sellAmount: 1,
            limitAmount: limitOrderPrices.LIMIT_ORDER_REJECT_PRICE,
          })
        );

        expect(await nextState(order)).toEqual('INITIAL');
        expect(await nextState(order)).toEqual('REJECTED');

        expect(getFiatAccount().balance).toEqual(10000);
        expect(getCryptoPosition().availableBalance).toEqual(100);
        expect(getCryptoPosition().blockedAvailableBalance).toEqual(0);
      });
    });
  });

  describe('Order Execution', () => {
    describe('Buy Order', () => {
      it('should increase Crypto Balance, reduce Fiat Balance and release Block Amount if BuyOrder was executed', async () => {
        const order = await trackOrder(marketBuyPayload({ buyAmount: 1 }));

        await untilReached(order, 'EXECUTED');

        expect(getFiatAccount().balance).toEqual(9000);
        expect(getCryptoPosition().availableBalance).toEqual(101);
        expect(getFiatAccount().blockedBalance).toEqual(0);
      });

      it('should execute Limit BuyOrder when specific LimitAmount was provided', async () => {
        const order = await trackOrder(
          limitBuyPayload({
            buyAmount: 1,
            limitAmount: limitOrderPrices.LIMIT_ORDER_EXECUTION_PRICE,
          })
        );

        await untilReached(order, 'EXECUTED');

        expect(getFiatAccount().balance).toEqual(999);
        expect(getCryptoPosition().availableBalance).toEqual(101);
        expect(getFiatAccount().blockedBalance).toEqual(0);
      });
    });

    describe('Sell Order', () => {
      it('should increase Fiat Balance, reduce Crypto Balance and release Block Amount if BuyOrder was executed', async () => {
        const order = await trackOrder(marketSellPayload({ sellAmount: 1 }));

        await untilReached(order, 'EXECUTED');

        expect(getFiatAccount().balance).toEqual(11000);
        expect(getCryptoPosition().availableBalance).toEqual(99);
        expect(getCryptoPosition().blockedAvailableBalance).toEqual(0);
      });

      it('should execute Limit SellOrder when specific LimitAmount was provided', async () => {
        const order = await trackOrder(
          limitSellPayload({
            sellAmount: 1,
            limitAmount: limitOrderPrices.LIMIT_ORDER_EXECUTION_PRICE,
          })
        );

        await untilReached(order, 'EXECUTED');

        expect(getFiatAccount().balance).toEqual(19001);
        expect(getCryptoPosition().availableBalance).toEqual(99);
        expect(getFiatAccount().blockedBalance).toEqual(0);
      });
    });

    describe('Stop Order', () => {
      it('should not trigger execution if market price did not changed', async () => {
        const order = await trackOrder(marketStopBuyPayload({ buyAmount: 1, stopAmount: 900 }));

        await untilReached(order, last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES));
        expect(await nextState(order)).not.toEqual('EXECUTED');

        expect(getFiatAccount().balance).toEqual(10000);
        expect(getFiatAccount().blockedBalance).toEqual(1000);
      });

      describe('Stop Loss', () => {
        it('should execute Stop Order if Market Price drops below Stop Amount with price specified by Exchange', async () => {
          const order = await trackOrder(marketStopBuyPayload({ buyAmount: 1, stopAmount: 900 }));

          jest.spyOn(cryptoCurrencyExchange, 'getUnitPriceFor').mockImplementation(() => 899);
          await untilReached(order, last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES));

          expect(await nextState(order)).toEqual('EXECUTED');

          expect(getFiatAccount().balance).toEqual(10000 - 899);
          expect(getFiatAccount().blockedBalance).toEqual(0);
        });

        it('should execute Stop Order if Market Price raises above Stop Amount with price specified by Exchange', async () => {
          const order = await trackOrder(marketStopBuyPayload({ buyAmount: 1, stopAmount: 1100 }));

          jest.spyOn(cryptoCurrencyExchange, 'getUnitPriceFor').mockImplementation(() => 1101);
          await untilReached(order, last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES));

          expect(await nextState(order)).toEqual('EXECUTED');

          expect(getFiatAccount().balance).toEqual(10000 - 1101);
          expect(getFiatAccount().blockedBalance).toEqual(0);
        });
      });

      describe('Stop Limit', () => {
        it('should pass correct fixed limit and initial market price and blocked account balance with limit amount', async () => {
          const order = await trackOrder(limitStopBuyPayload({ buyAmount: 1, stopAmount: 900, limitAmount: 875 }));

          expect(order.order.initialPrice).toEqual(1000);
          expect(getFiatAccount().blockedBalance).toEqual(875);
        });

        it('should execute Stop Order if Market Price drops below Stop Amount with price specified in Limit Amount', async () => {
          const order = await trackOrder(limitStopBuyPayload({ buyAmount: 1, stopAmount: 900, limitAmount: 875 }));

          jest.spyOn(cryptoCurrencyExchange, 'getUnitPriceFor').mockImplementation(() => 850);
          await untilReached(order, last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES));

          expect(await nextState(order)).toEqual('EXECUTED');
          expect(getFiatAccount().balance).toEqual(10000 - 875);
          expect(getFiatAccount().blockedBalance).toEqual(0);
        });

        it('should execute Stop Order if Market Price raises above Stop Amount with price specified in Limit Amount', async () => {
          const order = await trackOrder(limitStopBuyPayload({ buyAmount: 1, stopAmount: 1100, limitAmount: 1150 }));

          jest.spyOn(cryptoCurrencyExchange, 'getUnitPriceFor').mockImplementation(() => 1101);
          await untilReached(order, last(tradingOrderStates.STOP_ORDER_PRE_EXECUTION_STATES));

          expect(await nextState(order)).toEqual('EXECUTED');
          expect(getFiatAccount().balance).toEqual(10000 - 1150);
          expect(getFiatAccount().blockedBalance).toEqual(0);
        });
      });
    });
  });

  describe('Order Cancellation', () => {
    it('should be able to cancel Limit Order', async () => {
      const order = await trackOrder(limitBuyPayload());
      tradingService.cancel(order.orderUuid);
      expect(await nextState(order)).toEqual('CANCELLED');
    });

    it('should not be able to cancel Market Order', async () => {
      const order = await trackOrder(marketBuyPayload());
      tradingService.cancel(order.orderUuid);
      expect(await nextState(order)).not.toEqual('CANCELLED');
    });
  });

  describe('Order Expiration', () => {
    const currentDate = '2020-05-30';
    const expiredDate = '2020-05-29';

    it('should Expire Limit BuyOrder if orderValidUntil is older than fetchDate', async () => {
      const order = await trackOrder(
        limitBuyPayload({
          orderValidUntil: expiredDate,
        })
      );

      expect(await nextState(order, new Date(currentDate))).toEqual('INITIAL');
      expect(await nextState(order, new Date(currentDate))).toEqual('EXPIRED');
    });
  });
});
