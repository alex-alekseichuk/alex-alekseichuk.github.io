const { invalidArgumentList, invalidArgumentType, invalidArgumentValue } = require('./errors');

const getMapEntries = (argumentName, source, defaultValue) => {
  if (!source[argumentName]) {
    return defaultValue;
  }
  try {
    const values = JSON.parse(source[argumentName]);
    new Map(values);
    return values;
  } catch (_error) {
    return defaultValue;
  }
};

const getArgumentList = (argumentName, source) => {
  if (!source[argumentName]) {
    return;
  }
  const result = source[argumentName].split(',').map(status => status.trim());
  if (result.length === 0) {
    throw invalidArgumentList(argumentName);
  }
  return result;
};

const getInteger = (integerName, source, defaultValue = 0, minimumValue = 0) => {
  if (!source[integerName]) {
    return defaultValue;
  }
  const result = Number(source[integerName]);
  if (!Number.isSafeInteger(result)) {
    throw invalidArgumentType(integerName, 'Integer');
  }
  if (minimumValue && result < minimumValue) {
    throw invalidArgumentValue(integerName, `greater than ${minimumValue}`);
  }
  return result;
};

const getBoolean = (booleanName, source, defaultValue = false) => {
  if (!source[booleanName]) {
    return defaultValue;
  }
  return !!source[booleanName];
};

exports.getMapEntries = getMapEntries;
exports.getArgumentList = getArgumentList;
exports.getInteger = getInteger;
exports.getBoolean = getBoolean;
