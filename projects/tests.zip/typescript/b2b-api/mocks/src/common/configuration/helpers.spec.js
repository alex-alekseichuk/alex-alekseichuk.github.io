const { getArgumentList, getInteger } = require('./helpers');

describe('Configuration Helpers', () => {
  describe('getArgumentList()', () => {
    it('parses comma separated argument list correctly', () => {
      expect(getArgumentList('ARGLIST', { ARGLIST: 'Value, AnotherValue' })).toEqual(['Value', 'AnotherValue']);
    });
    it('works for single argument', () => {
      expect(getArgumentList('ARGLIST', { ARGLIST: 'Value' })).toEqual(['Value']);
    });
    it('returns undefined for missing value', () => {
      expect(getArgumentList('ARGLIST', {})).toEqual(undefined);
      expect(getArgumentList('ARGLIST', { ARGLIST: '' })).toEqual(undefined);
    });
  });
  describe('getInteger()', () => {
    it('parses integer argument list correctly', () => {
      expect(getInteger('ARGLIST', { ARGLIST: '15' })).toEqual(15);
    });
    it('returns default value for missing value or return 0 if no value passed', () => {
      expect(getInteger('ARGLIST', {})).toEqual(0);
      expect(getInteger('ARGLIST', {}, 10)).toEqual(10);
      expect(getInteger('ARGLIST', { ARGLIST: '' })).toEqual(0);
      expect(getInteger('ARGLIST', { ARGLIST: '' }, 10)).toEqual(10);
    });
    it('throws an error if invalid number passed', () => {
      expect(() => getInteger('ARGLIST', { ARGLIST: 'NaN' })).toThrowError();
    });
  });
});
