class InvalidArgumentList extends Error {
  constructor(argumentName) {
    super(`${argumentName} argument doesn't match the comma-separated pattern: ENV_VAR=Value1, Value2`);
  }
}

class InvalidArgumentType extends Error {
  constructor(argumentName, argumentType) {
    super(`${argumentName} argument should be a type of ${argumentType}`);
  }
}

class InvalidArgumentValue extends Error {
  constructor(argumentName, reason) {
    super(`${argumentName} argument should be ${reason}`);
  }
}

exports.invalidArgumentList = argumentName => new InvalidArgumentList(argumentName);
exports.invalidArgumentType = (argumentName, argumentType) => new InvalidArgumentType(argumentName, argumentType);
exports.invalidArgumentValue = (argumentName, argumentType) => new InvalidArgumentValue(argumentName, argumentType);
