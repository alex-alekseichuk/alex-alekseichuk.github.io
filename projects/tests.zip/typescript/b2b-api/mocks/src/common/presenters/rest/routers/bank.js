const { Router } = require('express');

const { withCatch } = require('./middlewares/withCatch');

const { toBankCryptoPositionsJSON } = require('../../../../customers/presenters/crypto-position.dto');
const { toBankFiatAccountsJSON } = require('../../../../customers/presenters/fiat-account.dto');
const { hydrateCryptoPosition, hydrateFiatAccount } = require('../../../../customers/presenters/bank-mappings');
const { hydrateBrokerCryptoPosition, hydrateBrokerFiatAccount } = require('../../../../customers/presenters/bank-broker-mappings');

const { customerService, manualTradingService } = require('../../../../bootstrap-modules');

const BANK_API_PREFIX = '/syg/api/bank/v1';
const bankRouter = new Router();

// GET Customer positions
bankRouter.get(
  '/positions/:customerUuid',
  withCatch(async (req, res) => {
    const { accounts, positions } = customerService.getBankPositionDetails(req.params.customerUuid);
    return res.json({
      customerCryptoPositionDetailDto: positions.map(position => hydrateCryptoPosition(toBankCryptoPositionsJSON(position))),
      fiatAccountDetailsDto: accounts.map(account => hydrateFiatAccount(toBankFiatAccountsJSON(account))),
    });
  })
);

bankRouter.get(
  '/brokers/:brokerUuid',
  withCatch(async (req, res) => {
    const { accounts, positions } = customerService.getBankPositionDetails(req.params.brokerUuid);
    return res.json({
      brokerConfig: 'unsupported',
      brokerCryptoPositions: positions.map(position => hydrateBrokerCryptoPosition(toBankCryptoPositionsJSON(position))),
      cryptoPositions: positions.map(position => hydrateBrokerCryptoPosition(toBankCryptoPositionsJSON(position))),
      customer: 'unsupported',
      customerFiatAccounts: accounts.map(account => hydrateBrokerFiatAccount(toBankFiatAccountsJSON(account))),
    });
  })
);

// Manual Trade Order
bankRouter.post(
  '/orders/manual/trade',
  withCatch(async (req, res) => {
    const trackedOrder = manualTradingService.registerManualTradeOrder(req.body);
    res.json({ orderUuid: trackedOrder.orderUuid, orderId: trackedOrder.orderId });
  })
);

exports.bankRouter = bankRouter;
exports.BANK_API_PREFIX = BANK_API_PREFIX;
