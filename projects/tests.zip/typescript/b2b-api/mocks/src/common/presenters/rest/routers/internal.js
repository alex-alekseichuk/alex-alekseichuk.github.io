const { Router } = require('express');

const { customerService, tradingService, customerOrdersService, exchange } = require('../../../../bootstrap-modules');

const internalRouter = new Router();

internalRouter.get('/', (_req, res) => {
  res.json({ tradingService, exchange, customerService, customerOrdersService });
});

internalRouter.get(`/orders`, (_req, res) => {
  res.json({ tradingService, customerOrdersService });
});

internalRouter.get(`/customers`, (_req, res) => {
  res.json(customerService);
});

internalRouter.get(`/exchange`, (_req, res) => {
  res.json(exchange);
});

internalRouter.patch('/exchange', (req, res) => {
  const { allowMarketPrices, fallbackRate } = req.body;
  if (Number.isFinite(fallbackRate) && fallbackRate > 0) {
    exchange.setFallbackRate(fallbackRate);
  }
  if (typeof allowMarketPrices === 'boolean') {
    exchange.setAllowMarketPrices(allowMarketPrices);
  }
  res.json(exchange);
});

internalRouter.put('/exchange/rates', (req, res) => {
  const [ticker] = Object.keys(req.body);
  const value = req.body[ticker];

  if (Number.isFinite(value) && value > 0) {
    exchange.setRate(ticker, value);
  }

  res.json(exchange.toJSON().fixedPriceExchange.exchangeRates);
});

exports.internalRouter = internalRouter;
