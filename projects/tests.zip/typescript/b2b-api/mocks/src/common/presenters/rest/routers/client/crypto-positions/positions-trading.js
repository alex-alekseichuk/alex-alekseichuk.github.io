const { Router } = require('express');

const { tradingService } = require('../../../../../../bootstrap-modules');
const { withCatch } = require('../../middlewares/withCatch');

const positionsTrading = new Router();

// POST Place Order - buy
positionsTrading.post(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/buy',
  withCatch(async (req, res) => {
    const trackedOrder = await tradingService.create(req.params.customerUuid, req.body);
    res.json({ orderUuid: trackedOrder.orderUuid });
  })
);

// POST Place Order - sell
positionsTrading.post(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/sell',
  withCatch(async (req, res) => {
    const trackedOrder = await tradingService.create(req.params.customerUuid, req.body);
    res.json({ orderUuid: trackedOrder.orderUuid });
  })
);

exports.positionsTrading = positionsTrading;
