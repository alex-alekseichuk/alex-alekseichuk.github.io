const { Router } = require('express');

const { tradingService, customerOrdersService } = require('../../../../../bootstrap-modules');
const { withCatch } = require('../middlewares/withCatch');

const { mapCustomerOrder } = require('../../../../../customers/presenters/customer-mappings');

const orders = new Router();

// GET Customer order
orders.get(
  '/customers/:customerUuid/orders/:orderUuid/details',
  withCatch(async (req, res) => {
    const { orderUuid } = req.params;
    const cachedOrderState = (await tradingService.step(orderUuid)) || mapCustomerOrder(await customerOrdersService.step(orderUuid));
    if (cachedOrderState) {
      return res.json({
        order: cachedOrderState,
      });
    }
    return res.status(404).send();
  })
);

// GET Customer orders
orders.get(
  '/customers/:customerUuid/orders',
  withCatch(async (req, res) => {
    const { customerUuid } = req.params;
    const rows = [...(await tradingService.getCustomerOrders(customerUuid)), ...(await customerOrdersService.getCustomerOrders(customerUuid)).map(entry => mapCustomerOrder(entry))];
    res.json({ rows, total: rows.length });
  })
);

// DELETE Place order - cancel
orders.delete(
  '/customer/:customerUuid/orders/:orderUuid',
  withCatch(async (req, res) => {
    tradingService.cancel(req.params.orderUuid);
    res.sendStatus(200);
  })
);

exports.orders = orders;
