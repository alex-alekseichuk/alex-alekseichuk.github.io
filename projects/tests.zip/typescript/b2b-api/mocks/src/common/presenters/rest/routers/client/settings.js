const { Router } = require('express');

const { customerService } = require('../../../../../bootstrap-modules');
const { withCatch } = require('../middlewares/withCatch');

const { toSettingsJSON } = require('../../../../../customers/presenters/settings.dto');
const settings = new Router();

// GET client-ui
settings.get(
  '/settings/client-ui',
  withCatch(async (_req, res) => {
    console.log('settings-ui');
    const customers = customerService.getCustomers();
    res.json(toSettingsJSON(customers));
  })
);

exports.settings = settings;
