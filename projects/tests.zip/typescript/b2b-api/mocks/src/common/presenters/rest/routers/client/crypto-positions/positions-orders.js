const { Router } = require('express');

const { cryptoPositionService, customerService, customerOrdersService } = require('../../../../../../bootstrap-modules');
const { withCatch } = require('../../middlewares/withCatch');

const { toPublicAddress } = require('../../../../../../customers/presenters/crypto-position.dto');

const positionsOrders = new Router();

positionsOrders.get(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/pub-address',
  withCatch(async (req, res) => {
    const { customerUuid, cryptoPositionUuid } = req.params;
    const position = customerService.getClientCryptoBalance(customerUuid, cryptoPositionUuid);
    return res.json(toPublicAddress(position));
  })
);

positionsOrders.post(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/temp-address',
  withCatch(async (req, res) => {
    const { customerUuid, cryptoPositionUuid } = req.params;
    const order = cryptoPositionService.createTemporaryAddress(customerUuid, cryptoPositionUuid);
    return res.json(order);
  })
);

positionsOrders.get(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/orders/:orderUuid/temp-address',
  withCatch(async (req, res) => {
    const { customerUuid, cryptoPositionUuid, orderUuid } = req.params;
    const orderState = await customerOrdersService.step(orderUuid);
    if (!orderState) {
      return res.status(404).send();
    }

    const position = customerService.getClientCryptoBalance(customerUuid, cryptoPositionUuid);
    const orderTempAddress = position.temporaryAddresses.find(address => address.orderUuid === orderUuid);
    if (!orderTempAddress) {
      return res.status(204).send();
    }

    return res.json({
      publicAddress: orderTempAddress.publicAddress,
    });
  })
);

exports.positionsOrders = positionsOrders;
