const { Router } = require('express');
const { cryptoPositionService } = require('../../../../../../bootstrap-modules');
const { toCryptoPositionsJSON } = require('../../../../../../customers/presenters/crypto-position.dto');

const { withCatch } = require('../../middlewares/withCatch');

const positionsTransfer = new Router();

positionsTransfer.get(
  '/customers/:customerUuid/can-transfer-to/:destinationUuid',
  withCatch(async (req, res) => {
    const position = cryptoPositionService.getByLogicalWalletUuidAndCryptoCurrencyType(req.params.customerUuid, req.params.destinationUuid, req.query.cryptoCurrencyType);
    if (!position) {
      return res.status(204).send();
    }
    return res.status(200).json(toCryptoPositionsJSON(position));
  })
);

positionsTransfer.post(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/transfer',
  withCatch(async (req, res) => {
    const {
      feePaymentModelType,
      feePriorityType,
      sourceCryptoPosition: { cryptoPositionUuid: sourceCryptoPositionUuid },
      destinationCryptoPosition: { cryptoPositionUuid: destinationCryptoPositionUuid },
      amount: quantity,
    } = req.body;
    if (sourceCryptoPositionUuid !== req.params.cryptoPositionUuid) {
      return res.status(500).send();
    }
    const { orderId, orderUuid } = cryptoPositionService.transfer(req.params.customerUuid, sourceCryptoPositionUuid, destinationCryptoPositionUuid, {
      feePaymentModelType,
      feePriorityType,
      quantity,
    });
    res.status(200).json({ orderId, orderUuid });
  })
);

positionsTransfer.post(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/send',
  withCatch(async (req, res) => {
    const {
      feePaymentModelType,
      feePriorityType,
      cryptoPosition: { cryptoPositionUuid: sourceCryptoPositionUuid },
      destinationPublicAddress,
      amount: quantity,
    } = req.body;
    if (sourceCryptoPositionUuid !== req.params.cryptoPositionUuid) {
      return res.status(500).send();
    }
    const { orderId, orderUuid } = cryptoPositionService.send(req.params.customerUuid, sourceCryptoPositionUuid, {
      feePaymentModelType,
      feePriorityType,
      quantity,
      destinationPublicAddress,
    });
    res.status(200).json({ orderId, orderUuid });
  })
);

exports.positionsTransfer = positionsTransfer;
