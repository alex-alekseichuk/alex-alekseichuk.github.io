const { Router } = require('express');
const { customerService } = require('../../../../../bootstrap-modules');
const { toCryptoProduct } = require('../../../../../customers/presenters/crypto-product.dto');

const { withCatch } = require('../middlewares/withCatch');

const availableAssets = new Router();

availableAssets.get(
  '/customers/:customerUuid/available-assets',
  withCatch(async (req, res) => {
    const cryptoPositions = customerService.getClientCryptoPositions(req.params.customerUuid);

    const uniqueProductsPositions = cryptoPositions.reduce((positions, position) => {
      if (positions.find(p => p.cryptoCurrencyType === position.cryptoCurrencyType)) {
        return positions;
      }
      return [...positions, position];
    }, []);

    const assets = uniqueProductsPositions.map(toCryptoProduct);
    res.json(assets);
  })
);

exports.availableAssets = availableAssets;
