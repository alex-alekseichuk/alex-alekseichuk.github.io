const { Router } = require('express');

const { customerService } = require('../../../../../bootstrap-modules');
const { withCatch } = require('../middlewares/withCatch');

const { toFiatAccountJSON, toFiatBalancesJSON } = require('../../../../../customers/presenters/fiat-account.dto');

const fiatAccounts = new Router();

// GET Fiat Accounts
fiatAccounts.get(
  '/customers/:customerUuid/fiat-accounts',
  withCatch(async (req, res) => {
    const accounts = customerService.getClientFiatAccounts(req.params.customerUuid);
    return res.json(accounts.map(account => toFiatAccountJSON(account)));
  })
);

// GET Fiat Balances
fiatAccounts.get(
  '/customers/:customerUuid/fiat-accounts/balances',
  withCatch(async (req, res) => {
    const { customerUuid } = req.params;
    const { fiatAccount } = req.query;
    const accounts = customerService.getClientFiatBalances(customerUuid, fiatAccount);
    const response = accounts.reduce((result, account) => ({ ...result, ...toFiatBalancesJSON(account) }), {});
    return res.json(response);
  })
);

// GET Fiat Balances
// fiat.get('/customers/:customerUuid/fiatAccounts/availableBalance', (req, res) => {
//   const { customerUuid } = req.params;
//   const { fiatAccount } = req.query;
//   const balances = fiatBalances[customerUuid];
//   console.log('balances', balances);
//   res.json(pick(balances, fiatAccount || []));
// });

exports.fiatAccounts = fiatAccounts;
