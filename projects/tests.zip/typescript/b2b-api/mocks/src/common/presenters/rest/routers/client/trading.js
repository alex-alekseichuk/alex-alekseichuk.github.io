const { Router } = require('express');

const tradingPairsList = require('../../../../../../generated/trading-pairs.json');

const { exchange } = require('../../../../../bootstrap-modules');
const { withCatch } = require('../middlewares/withCatch');
const { mapExchangePriceDto } = require('../../../../../exchange/helpers/mapExchangePriceDto');

const trading = new Router();

trading.get(
  '/orders/trade/trading-pairs/:currency',
  withCatch(async (req, res) => {
    const tradingPairs = tradingPairsList[req.params.currency];
    if (!tradingPairs) {
      return res.status(404).send();
    }
    return res.send(tradingPairs);
  })
);

trading.get(
  '/exchange-rates/:priceType/:base/:quote',
  withCatch(async (req, res) => {
    const { base, quote, priceType } = req.params;
    if (priceType === 'BID') {
      const { bid } = await exchange.getCurrentPricing(base, quote);
      return res.send(mapExchangePriceDto({ bid, base, quote }));
    }
    if (priceType === 'ASK') {
      const { ask } = await exchange.getCurrentPricing(base, quote);
      return res.send(mapExchangePriceDto({ ask, base, quote }));
    }
    throw new Error(`Not supported priceType: ${priceType}!`);
  })
);

exports.trading = trading;
