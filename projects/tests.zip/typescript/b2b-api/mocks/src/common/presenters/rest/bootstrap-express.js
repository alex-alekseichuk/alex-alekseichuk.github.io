const express = require('express');

const { internalRouter } = require('./routers/internal');
const { clientRouter, CLIENT_API_PREFIX } = require('./routers/client');
const { bankRouter, BANK_API_PREFIX } = require('./routers/bank');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// logger middleware
app.use((req, res, next) => {
  const message = `${req.method} ${req.originalUrl}`;
  if (process.env.NODE_ENV !== 'test') {
    console.log(message, process.env.NODE_ENV);
  }
  next();
});

app.use(CLIENT_API_PREFIX, clientRouter);
app.use(BANK_API_PREFIX, bankRouter);
app.use('/internal', internalRouter);

app.use('*', function (req, res) {
  console.log(`Path ${req.url} does not exist.`);
  res.sendStatus(404);
});

app.use((err, _req, res) => {
  console.error(err);
  res.status(200).send({
    message: `MockServer Error: ${err.message}`,
  });
});

exports.app = app;
exports.CLIENT_API_PREFIX = CLIENT_API_PREFIX;
exports.BANK_API_PREFIX = BANK_API_PREFIX;
