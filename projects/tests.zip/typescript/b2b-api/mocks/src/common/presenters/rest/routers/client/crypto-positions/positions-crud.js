const { Router } = require('express');

const { cryptoPositionService, customerService } = require('../../../../../../bootstrap-modules');
const { withCatch } = require('../../middlewares/withCatch');

const { toCryptoPositionsJSON, toCryptoBalancesJSON } = require('../../../../../../customers/presenters/crypto-position.dto');

const positionsCRUD = new Router();

// GET Crypto Positions
positionsCRUD.get(
  '/customers/:customerUuid/crypto-positions',
  withCatch(async (req, res) => {
    const positions = customerService.getClientCryptoPositions(req.params.customerUuid);
    return res.json(positions.map(position => toCryptoPositionsJSON(position)));
  })
);

// GET Crypto Balance for Customer
positionsCRUD.get(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid/balance',
  withCatch(async (req, res) => {
    const { customerUuid, cryptoPositionUuid } = req.params;
    const position = customerService.getClientCryptoBalance(customerUuid, cryptoPositionUuid);
    return res.json(toCryptoBalancesJSON(position));
  })
);

// POST Crypto Position - create
positionsCRUD.post(
  '/customers/:customerUuid/crypto-positions',
  withCatch(async (req, res) => {
    const cryptoPositionData = req.body;
    const transformCryptoPositionType = cryptoPositionData => {
      if (!cryptoPositionData.distributedLedgerTechnologyType) {
        return null;
      }

      switch (cryptoPositionData.distributedLedgerTechnologyType) {
        case 'ETHEREUM':
          return 'ETH';
        case 'LITECOIN':
          return 'LTC';
        case 'XRP_LEDGER':
          return 'XRP';
        case 'BITCOIN':
        case 'BITCOIN_CASH':
        default:
          return 'BTC';
      }
    };

    cryptoPositionData.cryptoCurrencyType = transformCryptoPositionType(cryptoPositionData) ?? cryptoPositionData.cryptoCurrencyType;
    cryptoPositionData.cryptoPositionBundleName = cryptoPositionData.name;

    const order = await cryptoPositionService.create(req.params.customerUuid, cryptoPositionData);
    return res.json({
      orderId: order.orderId,
      orderUuid: order.orderUuid,
    });
  })
);

// UPDATE Crypto Position - update bundle name
positionsCRUD.put(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid',
  withCatch(async (req, res) => {
    const { customerUuid, cryptoPositionUuid } = req.params;
    const { bundleName } = req.body;
    cryptoPositionService.update(customerUuid, cryptoPositionUuid, bundleName);
    res.sendStatus(200);
  })
);

// DELETE Crypto Position - delete
positionsCRUD.delete(
  '/customers/:customerUuid/crypto-positions/:cryptoPositionUuid',
  withCatch(async (req, res) => {
    const { customerUuid, cryptoPositionUuid } = req.params;
    cryptoPositionService.close(customerUuid, cryptoPositionUuid);
    res.sendStatus(201);
  })
);

exports.positionsCRUD = positionsCRUD;
