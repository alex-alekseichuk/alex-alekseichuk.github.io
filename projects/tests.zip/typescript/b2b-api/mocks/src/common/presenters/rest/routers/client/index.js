const { Router } = require('express');
const { settings } = require('./settings');
const { orders } = require('./orders');
const { fiatAccounts } = require('./fiat-accounts');
const { trading } = require('./trading');
const { positionsCRUD } = require('./crypto-positions/positions-crud');
const { positionsTrading } = require('./crypto-positions/positions-trading');
const { positionsTransfer } = require('./crypto-positions/positions-transfer');
const { availableAssets } = require('./available-assets');
const { positionsOrders } = require('./crypto-positions/positions-orders');

const CLIENT_API_PREFIX = '/syg/api/client/v1';

exports.clientRouter = [settings, orders, fiatAccounts, trading, positionsCRUD, positionsTrading, positionsTransfer, availableAssets, positionsOrders];
exports.CLIENT_API_PREFIX = CLIENT_API_PREFIX;
