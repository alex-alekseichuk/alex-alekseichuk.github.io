const { cloneDeep } = require('lodash');
const { CustomerOrderEvent } = require('./customer-order-event');
const { CREATE_CRYPTOPOSITION_TEMP_ADDRESS_EXECUTED } = require('./customer-order-event.types');

class CreateCryptopositionTemporaryAddressExecutedEvent extends CustomerOrderEvent {
  type = CREATE_CRYPTOPOSITION_TEMP_ADDRESS_EXECUTED;

  constructor({ cryptoPositionUuid, ...data }) {
    super(data);
    this.cryptoPositionUuid = cryptoPositionUuid;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      cryptoPositionUuid: this.cryptoPositionUuid,
    };
  }
}

exports.CreateCryptopositionTemporaryAddressExecutedEvent = CreateCryptopositionTemporaryAddressExecutedEvent;
