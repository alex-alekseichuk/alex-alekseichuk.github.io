const { OrderEvent } = require('../order-event');
const { MANUAL_TRADE_REQUESTED, MANUAL_TRADE_EXECUTED, MANUAL_TRADE_REJECTED } = require('./customer-order-event.types');

class ManualTradeEvent extends OrderEvent {
  constructor({
    customerUuid,
    transactionAmount,
    transactionQuantity,
    sponsorCryptoPositionUuid,
    beneficientCryptoPositionUuid,
    sponsorFiatAccountUuid,
    beneficientFiatAccountUuid,
    ...orderEventData
  }) {
    super(orderEventData);
    this.customerUuid = customerUuid;
    this.transactionAmount = transactionAmount;
    this.transactionQuantity = transactionQuantity;
    this.sponsorCryptoPositionUuid = sponsorCryptoPositionUuid;
    this.beneficientCryptoPositionUuid = beneficientCryptoPositionUuid;
    this.sponsorFiatAccountUuid = sponsorFiatAccountUuid;
    this.beneficientFiatAccountUuid = beneficientFiatAccountUuid;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      customerUuid: this.customerUuid,
      transactionAmount: this.transactionAmount,
      transactionQuantity: this.transactionQuantity,
      sponsorCryptoPositionUuid: this.sponsorCryptoPositionUuid,
      beneficientCryptoPositionUuid: this.beneficientCryptoPositionUuid,
      sponsorFiatAccountUuid: this.sponsorFiatAccountUuid,
      beneficientFiatAccountUuid: this.beneficientFiatAccountUuid,
    };
  }
}

class ManualTradeRequestEvent extends ManualTradeEvent {
  type = MANUAL_TRADE_REQUESTED;
}

class ManualTradeExecutedEvent extends ManualTradeEvent {
  type = MANUAL_TRADE_EXECUTED;
}

class ManualTradeRejectedEvent extends ManualTradeEvent {
  type = MANUAL_TRADE_REJECTED;
}

exports.ManualTradeEvent = ManualTradeEvent;
exports.ManualTradeRequestEvent = ManualTradeRequestEvent;
exports.ManualTradeExecutedEvent = ManualTradeExecutedEvent;
exports.ManualTradeRejectedEvent = ManualTradeRejectedEvent;
