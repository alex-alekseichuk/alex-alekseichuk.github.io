const { BUY_ORDER_REJECTED, SELL_ORDER_REJECTED } = require('./order-event.types');
const { TradingOrderEvent } = require('./trading-order-event');

class BuyOrderRejectedEvent extends TradingOrderEvent {
  type = BUY_ORDER_REJECTED;
}

class SellOrderRejectedEvent extends TradingOrderEvent {
  type = SELL_ORDER_REJECTED;
}

exports.BuyOrderRejectedEvent = BuyOrderRejectedEvent;
exports.SellOrderRejectedEvent = SellOrderRejectedEvent;
