const { OrderEvent } = require('../order-event');

/*abstract*/ class CustomerOrderEvent extends OrderEvent {
  constructor({ customerUuid, ...orderEventData }) {
    super(orderEventData);
    this.customerUuid = customerUuid;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      customerUuid: this.customerUuid,
    };
  }
}

exports.CustomerOrderEvent = CustomerOrderEvent;
