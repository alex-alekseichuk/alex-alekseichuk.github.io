const { BuyOrderRequestedEvent, SellOrderRequestedEvent } = require('../trading/order-requested.event');
const { BuyOrderRejectedEvent, SellOrderRejectedEvent } = require('../trading/order-rejected.event');
const { BuyOrderExecutedEvent, SellOrderExecutedEvent } = require('../trading/order-executed.event');
const { MANUAL_TRADE_REJECTED, MANUAL_TRADE_EXECUTED, MANUAL_TRADE_REQUESTED } = require('./customer-order-event.types');

class ManualOrderEventMapper {
  forEvent(event) {
    const buyData = this._getBuyLegData(event);
    const sellData = this._getSellLegData(event);
    if (event.type === MANUAL_TRADE_REQUESTED) {
      return [new BuyOrderRequestedEvent(buyData), new SellOrderRequestedEvent(sellData)];
    }
    if (event.type === MANUAL_TRADE_REJECTED) {
      return [new BuyOrderRejectedEvent(buyData), new SellOrderRejectedEvent(sellData)];
    }
    if (event.type === MANUAL_TRADE_EXECUTED) {
      return [new BuyOrderExecutedEvent(buyData), new SellOrderExecutedEvent(sellData)];
    }
    return [];
  }

  _getBuyLegData(event) {
    return {
      orderUuid: event.orderUuid,
      customerUuid: event.customerUuid,
      cryptoPositionUuid: event.beneficientCryptoPositionUuid,
      customerFiatAccountUuid: event.sponsorFiatAccountUuid,
      initialPrice: event.transactionAmount,
      quantity: event.transactionQuantity,
      transactionAmount: event.transactionAmount,
      transactionQuantity: event.transactionQuantity,
    };
  }

  _getSellLegData(event) {
    return {
      orderUuid: event.orderUuid,
      customerUuid: event.customerUuid,
      cryptoPositionUuid: event.sponsorCryptoPositionUuid,
      customerFiatAccountUuid: event.beneficientFiatAccountUuid,
      initialPrice: event.transactionAmount,
      quantity: event.transactionQuantity,
      transactionAmount: event.transactionAmount,
      transactionQuantity: event.transactionQuantity,
    };
  }
}

exports.ManualOrderEventMapper = new ManualOrderEventMapper();
