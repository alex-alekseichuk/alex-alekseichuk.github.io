const { OrderEvent } = require('../order-event');

/*abstract*/ class WithdrawOrderEvent extends OrderEvent {
  constructor({ customerUuid, sourceCryptoPositionUuid, destinationCryptoPositionUuid, quantity, ...orderEventData }) {
    super(orderEventData);
    this.customerUuid = customerUuid;
    this.sourceCryptoPositionUuid = sourceCryptoPositionUuid;
    this.destinationCryptoPositionUuid = destinationCryptoPositionUuid;
    this.quantity = quantity;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      customerUuid: this.customerUuid,
      sourceCryptoPositionUuid: this.sourceCryptoPositionUuid,
      destinationCryptoPositionUuid: this.destinationCryptoPositionUuid,
      quantity: this.quantity,
    };
  }
}

exports.WithdrawOrderEvent = WithdrawOrderEvent;
