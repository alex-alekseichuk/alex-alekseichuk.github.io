const uuid = require('uuid');

/*abstract*/ class OrderEvent {
  type = 'UNKNOWN';

  constructor({ orderUuid }) {
    this.eventUuid = uuid.v4();
    this.orderUuid = orderUuid;
    this.timestamp = new Date();
  }

  toJSON() {
    return {
      type: this.type,
      eventUuid: this.eventUuid,
      orderUuid: this.orderUuid,
      timestamp: this.timestamp,
    };
  }
}

exports.OrderEvent = OrderEvent;
