const { BUY_ORDER_CANCELLED, SELL_ORDER_CANCELLED } = require('./order-event.types');
const { TradingOrderEvent } = require('./trading-order-event');

class BuyOrderCancelledEvent extends TradingOrderEvent {
  type = BUY_ORDER_CANCELLED;
}

class SellOrderCancelledEvent extends TradingOrderEvent {
  type = SELL_ORDER_CANCELLED;
}

exports.BuyOrderCancelledEvent = BuyOrderCancelledEvent;
exports.SellOrderCancelledEvent = SellOrderCancelledEvent;
