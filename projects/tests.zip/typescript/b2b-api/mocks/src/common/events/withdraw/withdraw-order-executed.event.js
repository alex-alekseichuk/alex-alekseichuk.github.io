const { SEND_ORDER_EXECUTED, TRANSFER_ORDER_EXECUTED } = require('./withdraw-event-types');
const { WithdrawOrderEvent } = require('./withdraw-order-event');

class SendOrderExecutedEvent extends WithdrawOrderEvent {
  type = SEND_ORDER_EXECUTED;
}

class TransferOrderExecutedEvent extends WithdrawOrderEvent {
  type = TRANSFER_ORDER_EXECUTED;
}

exports.SendOrderExecutedEvent = SendOrderExecutedEvent;
exports.TransferOrderExecutedEvent = TransferOrderExecutedEvent;
