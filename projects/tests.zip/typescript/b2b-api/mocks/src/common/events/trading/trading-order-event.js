const { OrderEvent } = require('../order-event');

/*abstract*/ class TradingOrderEvent extends OrderEvent {
  constructor({ customerUuid, customerFiatAccountUuid, cryptoPositionUuid, initialPrice, quantity, ...orderEventData }) {
    super(orderEventData);
    this.customerUuid = customerUuid;
    this.customerFiatAccountUuid = customerFiatAccountUuid;
    this.cryptoPositionUuid = cryptoPositionUuid;
    this.initialPrice = initialPrice;
    this.quantity = quantity;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      customerUuid: this.customerUuid,
      customerFiatAccountUuid: this.customerFiatAccountUuid,
      cryptoPositionUuid: this.cryptoPositionUuid,
      initialPrice: this.initialPrice,
      quantity: this.quantity,
    };
  }
}

exports.TradingOrderEvent = TradingOrderEvent;
