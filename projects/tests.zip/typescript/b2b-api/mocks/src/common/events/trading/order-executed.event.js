const { BUY_ORDER_EXECUTED, SELL_ORDER_EXECUTED } = require('./order-event.types');
const { TradingOrderEvent } = require('./trading-order-event');

/*abstract*/ class OrderExecutedEvent extends TradingOrderEvent {
  constructor({ transactionQuantity, transactionAmount, ...orderEventData }) {
    super(orderEventData);
    this.transactionAmount = transactionAmount;
    this.transactionQuantity = transactionQuantity;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      transactionAmount: this.transactionAmount,
      transactionQuantity: this.transactionQuantity,
    };
  }
}

class BuyOrderExecutedEvent extends OrderExecutedEvent {
  type = BUY_ORDER_EXECUTED;
}

class SellOrderExecutedEvent extends OrderExecutedEvent {
  type = SELL_ORDER_EXECUTED;
}

exports.BuyOrderExecutedEvent = BuyOrderExecutedEvent;
exports.SellOrderExecutedEvent = SellOrderExecutedEvent;
