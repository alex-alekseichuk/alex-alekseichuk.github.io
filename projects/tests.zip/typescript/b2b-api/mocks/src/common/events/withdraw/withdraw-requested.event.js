const { SEND_ORDER_REQUESTED, TRANSFER_ORDER_REQUESTED } = require('./withdraw-event-types');
const { WithdrawOrderEvent } = require('./withdraw-order-event');

class SendOrderRequestedEvent extends WithdrawOrderEvent {
  type = SEND_ORDER_REQUESTED;
}

class TransferOrderRequestedEvent extends WithdrawOrderEvent {
  type = TRANSFER_ORDER_REQUESTED;
}

exports.SendOrderRequestedEvent = SendOrderRequestedEvent;
exports.TransferOrderRequestedEvent = TransferOrderRequestedEvent;
