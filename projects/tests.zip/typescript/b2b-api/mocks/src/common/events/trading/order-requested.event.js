const { BUY_ORDER_REQUESTED, SELL_ORDER_REQUESTED } = require('./order-event.types');
const { TradingOrderEvent } = require('./trading-order-event');

class BuyOrderRequestedEvent extends TradingOrderEvent {
  type = BUY_ORDER_REQUESTED;
}

class SellOrderRequestedEvent extends TradingOrderEvent {
  type = SELL_ORDER_REQUESTED;
}

exports.BuyOrderRequestedEvent = BuyOrderRequestedEvent;
exports.SellOrderRequestedEvent = SellOrderRequestedEvent;
