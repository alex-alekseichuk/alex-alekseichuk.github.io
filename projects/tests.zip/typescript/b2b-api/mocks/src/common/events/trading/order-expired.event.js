const { BUY_ORDER_EXPIRED, SELL_ORDER_EXPIRED } = require('./order-event.types');
const { TradingOrderEvent } = require('./trading-order-event');

class BuyOrderExpiredEvent extends TradingOrderEvent {
  type = BUY_ORDER_EXPIRED;
}

class SellOrderExpiredEvent extends TradingOrderEvent {
  type = SELL_ORDER_EXPIRED;
}

exports.BuyOrderExpiredEvent = BuyOrderExpiredEvent;
exports.SellOrderExpiredEvent = SellOrderExpiredEvent;
