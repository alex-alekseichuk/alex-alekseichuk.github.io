const { cloneDeep } = require('lodash');
const { CustomerOrderEvent } = require('./customer-order-event');
const { CREATE_CRYPTOPOSITION_REQUESTED } = require('./customer-order-event.types');

class CreateCryptopositionRequestedEvent extends CustomerOrderEvent {
  type = CREATE_CRYPTOPOSITION_REQUESTED;

  constructor(cryptoPositionData) {
    super(cryptoPositionData);
    this.cryptoPositionData = cloneDeep(cryptoPositionData);
  }

  toJSON() {
    return {
      ...super.toJSON(),
      cryptoPositionData: this.cryptoPositionData,
    };
  }
}

exports.CreateCryptopositionRequestedEvent = CreateCryptopositionRequestedEvent;
