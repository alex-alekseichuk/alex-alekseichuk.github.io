const { SEND_ORDER_REJECTED, TRANSFER_ORDER_REJECTED } = require('./withdraw-event-types');
const { WithdrawOrderEvent } = require('./withdraw-order-event');

class SendOrderRejectedEvent extends WithdrawOrderEvent {
  type = SEND_ORDER_REJECTED;
}

class TransferOrderRejectedEvent extends WithdrawOrderEvent {
  type = TRANSFER_ORDER_REJECTED;
}

exports.SendOrderRejectedEvent = SendOrderRejectedEvent;
exports.TransferOrderRejectedEvent = TransferOrderRejectedEvent;
