const { BUY_ORDER_EXECUTION_REQUESTED, SELL_ORDER_EXECUTION_REQUESTED } = require('./order-event.types');
const { TradingOrderEvent } = require('./trading-order-event');

/*abstract*/ class OrderExecutionRequestedEvent extends TradingOrderEvent {
  constructor({ transactionQuantity, transactionAmount, ...orderEventData }) {
    super(orderEventData);
    this.transactionAmount = transactionAmount;
    this.transactionQuantity = transactionQuantity;
  }

  toJSON() {
    return {
      ...super.toJSON(),
      transactionAmount: this.transactionAmount,
      transactionQuantity: this.transactionQuantity,
    };
  }
}

class BuyOrderExecutionRequestedEvent extends OrderExecutionRequestedEvent {
  type = BUY_ORDER_EXECUTION_REQUESTED;
}

class SellOrderExecutionRequestedEvent extends OrderExecutionRequestedEvent {
  type = SELL_ORDER_EXECUTION_REQUESTED;
}

exports.BuyOrderExecutionRequestedEvent = BuyOrderExecutionRequestedEvent;
exports.SellOrderExecutionRequestedEvent = SellOrderExecutionRequestedEvent;
