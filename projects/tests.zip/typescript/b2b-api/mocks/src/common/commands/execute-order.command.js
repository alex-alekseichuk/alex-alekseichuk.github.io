const { EXECUTE_ORDER_COMMAND } = require('./order-command.types');
const { OrderCommand } = require('./order.command');

class ExecuteOrderCommand extends OrderCommand {
  type = EXECUTE_ORDER_COMMAND;
}

exports.ExecuteOrderCommand = ExecuteOrderCommand;
