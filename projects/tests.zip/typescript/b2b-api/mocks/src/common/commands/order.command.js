const uuid = require('uuid');
const { UNKNOWN } = require('./order-command.types');

class OrderCommand {
  type = UNKNOWN;

  constructor(orderUuid) {
    this.orderUuid = orderUuid;
    this.eventUuid = uuid.v4();
    this.timestamp = new Date();
  }

  toJSON() {
    return {
      type: this.type,
      orderUuid: this.orderUuid,
      eventUuid: this.eventUuid,
      timestamp: this.timestamp,
    };
  }
}

exports.OrderCommand = OrderCommand;
