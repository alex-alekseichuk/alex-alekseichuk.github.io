const { FORCE_REJECT_ORDER_COMMAND } = require('./order-command.types');
const { OrderCommand } = require('./order.command');

class ForceRejectOrderCommand extends OrderCommand {
  type = FORCE_REJECT_ORDER_COMMAND;
}

exports.ForceRejectOrderCommand = ForceRejectOrderCommand;
