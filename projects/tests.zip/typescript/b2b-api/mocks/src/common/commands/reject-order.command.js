const { REJECT_ORDER_COMMAND } = require('./order-command.types');
const { OrderCommand } = require('./order.command');

class RejectOrderCommand extends OrderCommand {
  type = REJECT_ORDER_COMMAND;
}

exports.RejectOrderCommand = RejectOrderCommand;
