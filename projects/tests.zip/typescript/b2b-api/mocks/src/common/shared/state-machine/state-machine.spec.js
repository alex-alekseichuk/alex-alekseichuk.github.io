const { StateMachine } = require('./state-machine');

describe('Orders State Machine Test', () => {
  describe('next', () => {
    it('transits through declared values and stays in final state', () => {
      const availableStates = ['Validated', 'Disposed'];
      const stateMachine = new StateMachine(availableStates);
      expect(stateMachine.state).toEqual('Validated');

      stateMachine.next();
      expect(stateMachine.state).toEqual('Disposed');

      stateMachine.next();
      expect(stateMachine.state).toEqual('Disposed');
    });
  });
});
