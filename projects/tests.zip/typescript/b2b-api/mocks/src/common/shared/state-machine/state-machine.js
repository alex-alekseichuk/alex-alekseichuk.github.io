class StateMachine {
  constructor(availableStates, state = availableStates[0]) {
    this.availableStates = availableStates;
    this.state = state;
  }

  next() {
    const currentPosition = this.availableStates.indexOf(this.state);
    if (currentPosition >= this.availableStates.length - 1) {
      return;
    }

    this.state = this.availableStates[currentPosition + 1];
  }
}

exports.StateMachine = StateMachine;
