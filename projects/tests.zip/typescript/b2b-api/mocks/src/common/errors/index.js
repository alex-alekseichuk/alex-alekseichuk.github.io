class InvalidMachineStateError extends Error {
  constructor(state, availableStates) {
    super(`State ${state} not specified in ${JSON.stringify(availableStates)}`);
  }
}

class OrderCannotBeInstantiated extends Error {
  constructor() {
    super(`Order cannot be instantiated`);
  }
}

class OrderEventCannotBeInstantiated extends Error {
  constructor(eventType, orderType) {
    super(`OrderEvent: ${eventType} cannot be instantiated for orderType: ${orderType}`);
  }
}

class ComponentDoesNotExist extends Error {
  constructor(name, details = '') {
    super(`Component: "${name}" does not exist. Reason: ${details}`);
  }
}

const invalidMachineState = (state, availableStates) => {
  return new InvalidMachineStateError(state, availableStates);
};

const orderCannotBeInstantiated = () => new OrderCannotBeInstantiated();

const cannotInstantiateOrderEvent = (eventType, orderType) => new OrderEventCannotBeInstantiated(eventType, orderType);

const cannotFindComponent = (name, details) => new ComponentDoesNotExist(name, details);

exports.invalidMachineState = invalidMachineState;
exports.orderCannotBeInstantiated = orderCannotBeInstantiated;
exports.cannotInstantiateOrderEvent = cannotInstantiateOrderEvent;
exports.cannotFindComponent = cannotFindComponent;
