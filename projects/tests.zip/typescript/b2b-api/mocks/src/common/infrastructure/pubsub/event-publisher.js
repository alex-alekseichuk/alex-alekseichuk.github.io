class EventPublisher {
  listeners = [];

  constructor(logger) {
    this.logger = logger;
  }

  addListener(listener) {
    this.listeners.push(listener);
  }

  publish(event) {
    if (event) {
      this.eventStore?.save(event);
      this.logger?.log(event);
      this.listeners.forEach(listener => listener.apply(event));
    }
  }

  attachEventStore(eventStore) {
    this.eventStore = eventStore;
  }
}

exports.EventPublisher = EventPublisher;
