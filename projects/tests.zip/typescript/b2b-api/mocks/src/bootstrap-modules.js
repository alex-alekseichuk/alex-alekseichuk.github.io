const { exchange } = require('./exchange');
const { cacheOptions } = require('./mockserver-configuration');
const { EventPublisher } = require('./common/infrastructure/pubsub/event-publisher');
const { TradingOrderRepository, TradingCommandHandler, TradingService } = require('./trading');
const {
  FiatAccountRepository,
  CustomerRepository,
  CryptoPositionRepository,
  CustomerOrderRepository,
  CustomersCommandHandler,
  CryptoPositionService,
  CustomerService,
  CustomerOrdersService,
  loadCachedData,
} = require('./customers');
const { ManualTradingService } = require('./customers/app/manual-trading.service');

// Customers Module
const customersEventPublisher = new EventPublisher(console);
const fiatAccountRepository = new FiatAccountRepository();
const customerRepository = new CustomerRepository();
const cryptoPositionRepository = new CryptoPositionRepository();
const customerOrderRepository = new CustomerOrderRepository();

const cryptoPositionService = new CryptoPositionService(customerRepository, cryptoPositionRepository, customerOrderRepository, customersEventPublisher);
const customerService = new CustomerService(customerRepository, cryptoPositionRepository, fiatAccountRepository);
const customerOrdersService = new CustomerOrdersService(customerOrderRepository, customersEventPublisher);
const manualTradingService = new ManualTradingService(customerRepository, cryptoPositionRepository, fiatAccountRepository, customerOrderRepository, customersEventPublisher);

const customersCommandHandler = new CustomersCommandHandler(cryptoPositionRepository, fiatAccountRepository, customerOrderRepository, customersEventPublisher);

// Trading Module
const tradingEventPublisher = new EventPublisher();
const tradingOrderRepository = new TradingOrderRepository(exchange);
const tradingService = new TradingService(exchange, tradingOrderRepository, tradingEventPublisher);
const tradingCommandHandler = new TradingCommandHandler(tradingOrderRepository, tradingEventPublisher);

// Loading cache data
loadCachedData(customerRepository, fiatAccountRepository, cryptoPositionRepository);

// Inter-Modular connections
customersCommandHandler.subscribe(tradingEventPublisher);
customersCommandHandler.subscribe(customersEventPublisher);
tradingCommandHandler.subscribe(customersEventPublisher);

if (cacheOptions.ORDERS_CACHE_FLUSH_TIMEOUT) {
  console.info('Orders cache flush set. Orders would be cleaned each', cacheOptions.ORDERS_CACHE_FLUSH_TIMEOUT, 'milliseconds');
  console.info('Orders cache retention is set to', cacheOptions.ORDERS_CACHE_RETENTION_TIMEOUT, 'milliseconds');
  setInterval(() => {
    const flushDate = new Date();
    const flushedOrders = [...tradingOrderRepository.flush(flushDate), ...customerOrderRepository.flush(flushDate)];
    console.log('Orders flushed.', flushedOrders.length ? `Following orders deleted: ${flushedOrders}.` : 'No orders deleted.');
  }, cacheOptions.ORDERS_CACHE_FLUSH_TIMEOUT);
}

exports.cryptoPositionService = cryptoPositionService;
exports.customerService = customerService;
exports.customerOrdersService = customerOrdersService;
exports.tradingService = tradingService;
exports.exchange = exchange;
exports.manualTradingService = manualTradingService;
