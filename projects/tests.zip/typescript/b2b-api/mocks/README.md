# MockServer

This document contains example B2B REST payloads that allows to visualise the C-Vault MockServer behavior.

Each order placed in MockServer transits through its internal set of states.

## Market Order

Market Orders are that takes the price from the Current Market price.

Customers are **not able to cancel** the Market Order.

Market Order has blocking logic based on passed Market Price such as:

1. For Buy Order the Fiat Account Balance will be blocked with the Market Price times Buy Crypto Amount.
2. For Sell Order the Crypto Position Balance will be blocked with the specified Sell Crypto Amount.

### Order Executed

This is the default transition through all the states **for affordable** Market Order. Both **Initial Price** and **Execution Price** are fetched from Crypto Currency Exchange. See [Market and Fixed Exchange Rates](#Market-and-Fixed-Exchange-Rates) section for more details.

##### Buy

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderType": "MARKET"
}
```

##### Sell

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderType": "MARKET"
}
```

### Order Rejected

The Market Order Should enter the **INITIAL** state on first Order Details fetch and then should transit to **REJECTED** state.

#### Order rejected due to non-affordable price:

Fiat Account / Crypto Position should call the `REJECT_ORDER_COMMAND` on corresponding `orderUuid`.

##### Buy

We'd try to buy crypto for **2000 CHF** but the Debit Fiat Account has **1000 CHF**.

```json
{
  "buyAmount": 2,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "bc8d34d5-c732-401a-9015-95a34c206881",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderType": "MARKET"
}
```

##### Sell

We'd try to sell **21 ETH** but the Debit Crypto Position has **20 ETH**.

```json
{
  "sellAmount": 21,
  "cryptoPositionUuid": "9466d382-18a3-4ba7-90db-835d976a8904",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderType": "MARKET"
}
```

## Limit Order

Limit Orders are types of orders that allows the Customer to specity the **limitPrice** and **orderValidUntil** parameters.

Customers are able to **cancel** the Limit Order.

Limit Order has blocking logic based on passed Limit Price such as:

1. For Buy Order the Fiat Account Balance will be blocked with the specified Limit Price times Buy Crypto Amount.
2. For Sell Order the Crypto Position Balance will be blocked with the specified Sell Crypto Amount.

Limit Order state transition behaviour would vary based on the specified Limit Price.

### Order Placed

For Limit Order **PLACED** is the default final state for affordable Limit Order after fetching the Limit Order Details.

##### Buy

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 1200,
  "orderType": "LIMIT"
}
```

##### Sell

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 1200,
  "orderType": "LIMIT"
}
```

### Order Rejected

The Limit Order Should enter the **INITIAL** state on first Order Details fetch and then should transit to **REJECTED** state.

#### Order rejected due to non-affordable price:

Fiat Account / Crypto Position should call the `REJECT_ORDER_COMMAND` on corresponding `orderUuid`.

##### Buy

We'd try to buy crypto for **2001 CHF** but the Debit Fiat Account has **2000 CHF**.

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "1610f6a7-4748-4458-8576-ddd9cbda21e1",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 2001,
  "orderType": "LIMIT"
}
```

##### Sell

We'd try to sell **21 ETH** but the Debit Crypto Position has **20 ETH**.

```json
{
  "sellAmount": 21,
  "cryptoPositionUuid": "9466d382-18a3-4ba7-90db-835d976a8904",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 1200,
  "orderType": "LIMIT"
}
```

#### Order rejected on transition

For an Limit Order requested with **Limit Price set to 9000** order will be rejected on fetching order details.

##### Buy

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 9000,
  "orderType": "LIMIT"
}
```

##### Sell

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 9000,
  "orderType": "LIMIT"
}
```

### Order Executed

For an Limit Order requested with **Limit Price set to 9001** order will be executed

##### Buy

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 9001,
  "orderType": "LIMIT"
}
```

##### Sell

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 9001,
  "orderType": "LIMIT"
}
```

### Order Expired

The Limit Order Should enter the **INITIAL** state on first Order Details fetch and then should transit to **EXPIRED** state for orders with exceeded validity date.

#### Order expired due to exceeding the validity date:

##### Buy

We'd try to buy crypto with `orderValidUntil` set to 20th May 2020

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2020-05-20",
  "limitPrice": 1200,
  "orderType": "LIMIT"
}
```

##### Sell

We'd try to sell crypto with `orderValidUntil` set to 20th May 2020

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2020-05-20",
  "limitPrice": 1200,
  "orderType": "LIMIT"
}
```

## Stop Orders

Stop Orders are simply triggered to execution when exchange reaches unit price specified in `stopPrice`.
The Crypto asset unit price is fetched on order creation and Mock server can apply two execution stategies for market exchange price reaching the specified `stopPrice`:

- Rising strategy: applies when _initial unitPrice_ **is higher** than passed `stopPrice`
- Falling strategy: applies when _initial unitPrice_ **is lower** than passed `stopPrice`

Execution strategies are triggering orders execution on constantly monitored market exchange price watching to cross the `stopPrice` in following way:

- Rising strategy: executes order _current unitPrice_ **is higher** than `stopPrice`
- Falling strategy: executes order _current unitPrice_ **is lower** than `stopPrice`

### Stop Loss Orders

Stop loss have the same physics as Market orders. The only difference is the price trigger specified in `stopPrice` parameter. Order's execution price is assigned to the current market exchange price on applying execution strategy.

##### Buy

Placing an Stop Loss Buy Order:

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderType": "STOP_LOSS",
  "stopPrice": 1500
}
```

Applying Exchange rate change **above** specified `stopPrice`:

```json
curl -X PUT -H "Content-Type: application/json" -d '{"ETH_CHF":1500}' localhost:3030/internal/exchange/rates
```

##### Sell

Placing an Stop Loss Sell Order:

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderType": "STOP_LOSS",
  "stopPrice": 1500
}
```

Applying Exchange rate change **above** specified `stopPrice`:

```json
curl -X PUT -H "Content-Type: application/json" -d '{"ETH_CHF":1500}' localhost:3030/internal/exchange/rates
```

### Stop Limit Orders

Stop loss have the same physics as Limit orders. The only difference is the price trigger specified in `stopPrice` parameter. Order's execution price is assigned to the specified `limitPrice` during order creation.

##### Buy

Placing an Stop Limit Buy Order:

```json
{
  "buyAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 1200,
  "orderType": "STOP_LIMIT",
  "stopPrice": 1500
}
```

Applying Exchange rate change **above** specified `stopPrice`:

```json
curl -X PUT -H "Content-Type: application/json" -d '{"ETH_CHF":1500}' localhost:3030/internal/exchange/rates
```

##### Sell

Placing an Stop Limit Sell Order:

```json
{
  "sellAmount": 1,
  "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
  "customerFiatAccountUuid": "98c79218-c2b5-431d-88c8-b74f9f0aad87",
  "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
  "orderValidUntil": "2120-05-20",
  "limitPrice": 1200,
  "orderType": "STOP_LIMIT",
  "stopPrice": 1500
}
```

Applying Exchange rate change **above** specified `stopPrice`:

```json
curl -X PUT -H "Content-Type: application/json" -d '{"ETH_CHF":1500}' localhost:3030/internal/exchange/rates
```

## Market and Fixed Exchange Rates

Mock server allows to fetch live exchange rates from the real market and react to price changes.

First, if Market Exchange URL **was provided in configuration** and MockServer **allows to fetch market data**, the **market rate** would be returned.

If **market rate** it's missing or an error occured, Fixed Exchange will find corresponding **fixed rate** for specified pair.

Eventually if the **fixed rate** is missing, Fixed exchange returns the **fallback rate**.

### Placing orders based on market data

1. Start MockServer with `MOCK_SERVER_EXCHANGE_MARKET_EXCHANGE_URL`

   ```bash
   MOCK_SERVER_EXCHANGE_MARKET_EXCHANGE_URL=http://localhost:3001 yarn mock
   ```

2. Place and BuyOrder with `BTC_USD` pair:

   ```json
   {
     "buyAmount": 2,
     "cryptoPositionUuid": "ff008383-5b63-4bae-8abf-e814a5a1d510",
     "customerFiatAccountUuid": "61f3340a-6f8b-463d-941c-111559d0122e",
     "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
     "orderType": "MARKET"
   }
   ```

3. Pass the order throughout state transition

4. **GET** http://localhost:3030/internal/customers to see customer status change

### Simulating Order Rejection on Execution

If order was placed and the price of requested amount changed during Order Transition, the order that is not able to afford for customer Fiat Account should be rejected. To simulate that kind of situation apply following steps:

1. Stop Market Exchange rates fetch (if turned on):

   ```bash
   curl -X PATCH -H "Content-Type: application/json" -d '{"allowMarketPrices":false}' localhost:3030/internal/exchange
   ```

2. Place a BuyOrder for CHF account that is capable to buy 1 ETH:

   ```json
   {
     "buyAmount": 1,
     "cryptoPositionUuid": "411ed778-fa3f-4486-a2b4-854fe0c90d22",
     "customerFiatAccountUuid": "bc8d34d5-c732-401a-9015-95a34c206881",
     "customerUuid": "8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4",
     "orderType": "MARKET"
   }
   ```

3. Increase the price of CHF / ETH pair:

   ```json
   curl -X PUT -H "Content-Type: application/json" -d '{"ETH_CHF":10000}' localhost:3030/internal/exchange/rates
   ```

4. Pass the order throughout state transition

## Internal URLs

1. **GET** http://localhost:3030/internal - returns entire mock server internal state (**customers**, **orders**, **exchange** settings, published _events_ and _commands_)
2. **GET** http://localhost:3030/internal/orders - returns **orders** internal state,
3. **GET** http://localhost:3030/internal/orders/events - returns published **order** _events_,
   1. Query: `orderUuid` - filters Order Events against provided orderUuid
4. **GET** http://localhost:3030/internal/customers - returns **customers** internal state,
5. **GET** http://localhost:3030/internal/customers/commands - displays _commands_ applied to **orders**
   1. Query: `orderUuid` - filters Order Events against provided orderUuid
6. **GET** http://localhost:3030/internal/exchange - displays **exchange** settings,
7. **PATCH** http://localhost:3030/internal/exchange - allows to set up **exchange**,
   1. `"Content-Type: application/json"`
   2. `{"fallbackRate":9000}` - sets default fallback rate (for missing market and fixed exchange rates)
   3. `{"allowMarketPrices":true}` - toggles market exchange fetch
8. **GET** http://localhost:3030/internal/exchange/rates - displays current **fixed exchange** rates,

## Mock Server configuration

Mock server can be configured with following environmental variables

### Order States

Following variables allow to customise the set of Order States.

1. `MOCK_SERVER_MARKET_ORDER_PRE_EXECUTION_STATES` \
   Comma - separated set of states that **Market Order** would transit through **before** Order Execution \
   Default value: \
   `INITIAL, VALIDATED, DISPOSED, EXCHANGE_TRIGGERED, PARTIALLY_TRADED, PREPARE_TO_SEND`

2. `MOCK_SERVER_LIMIT_ORDER_PRE_EXECUTION_STATES` \
   Comma - separated set of states that **Limit Order** would transit through **before** Order Execution \
   Default value: \
   `INITIAL, VALIDATED, PLACED`

3. `MOCK_SERVER_EXECUTION_STATES` \
    Comma - separated set of states that **Limit and Market Orders** would transit through **after** Order Execution \
    Default value: \
   `EXECUTED, WAIT_FOR_DELIVERY, FINALIZED`

4. `MOCK_SERVER_LIMIT_ORDER_CANCELLABLE_STATES` \
   Comma - separated set of states that allows to cancel the **Limit Order** \
   Default value: \
   `INITIAL, VALIDATED, PLACED`

### Limit Order Prices

Follwing variables allow to customise Limit Order Prices to trigger specific Limit Order behaviour.

1.  `MOCK_SERVER_LIMIT_ORDER_REJECT_PRICE` \
    The value o Limit Price that Customer passes in Order Request. This value **Rejects** the Limit Order on state transition. \
    Should be an Integer. \
    Default value: \
    `9000`

2.  `MOCK_SERVER_LIMIT_ORDER_EXECUTION_PRICE` \
    The value o Limit Price that Customer passes in Order Request. This value **Executes** the Limit Order on state transition. \
    Should be an Integer. \
    Default value: \
    `9001`

### Cache Options

Following values customizes the settings of Orders and Customers Cache.

1. `MOCK_SERVER_ORDERS_CACHE_RETENTION_TIMEOUT` \
   Timeout in milliseconds after witch Order would be removed from the Orders Cache on Cleanup Phase \
   Should be an Integer. \
   Default value: \
   `172800000`

2. `MOCK_SERVER_ORDERS_CACHE_FLUSH_TIMEOUT` \
   Timeout in milliseconds after witch Orders Cache executes the Cleanup Phase \
   Should be an Integer. \
   \
   Default value: \
   **Not set (cache wouldn't execute the Cleanup Phase)**

3. `MOCK_SERVER_CUSTOMERS_SETUP_FILE` \
   Path to JSON file that describes Customers data with correspoding Fiat Accounts and Crypto Positions. \
   See `$B2B_PATH/src/customers/__test__/assets/customers.json` file for more details. \
   \
   Default value: \
   `$B2B_PATH/src/customers/__test__/assets/customers.json`

4. `MOCK_SERVER_EVENT_STORE_ENABLED` \
   Boolean value that allows to store events that occurs in the Mock Server
   \
   Default value: \
   `false`

### Exchange Options

1. `MOCK_SERVER_EXCHANGE_MARKET_EXCHANGE_URL` \
   URL to CoinApi - based microservice to fetch live cryptocurrency rates \
   If passed, exchange rates can be fetched from given URL. \
   For missing pairs, Fixed Exchange rates would be returned
2. `MOCK_SERVER_EXCHANGE_FIXED_RATES` \
   JSON value for Fixed Exchange initialisation. Holds list of values for exchange pairs \
   \
   Default value: \
   `"[["ECH_CHF", 1000]]"`
3. `MOCK_SERVER_EXCHANGE_FIXED_FALLBACK_RATE` \
   Fallback exchange rate for crypto currency pair not listed in Market nor Fixed Exchange \
   \
   Default value: \
   `500`
