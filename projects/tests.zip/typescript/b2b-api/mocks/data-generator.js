const faker = require('faker');
const fs = require('fs');
const { flatten } = require('lodash');
const _ = require('lodash');

const ALLOWED_CUSTOMER_TYPES = ['PRIVATE_CUSTOMER', 'ORGANIZATION', 'CORPORATE_CUSTOMER'];
const ALLOWED_FIAT_CURRENCIES = ['CHF', 'USD', 'EUR', 'SGD'];
const ALLOWED_CRYPTO_CURRENCIES = ['BTC', 'ETH', 'XRP', 'BCH'];
const ALLOWED_CRYPTO_POSITION_TYPES = ['SEGREGATED', 'TRADING', 'VAULT', 'PLEDGED', 'OMNIBUS'];
const FORBIDDEN_CRYPTO_CURRENCIES = ['AAVE', 'ADA', 'BAL', 'LSK', 'OMG', 'OXT', 'YFI'];
const ALLOWED_CRYPTO_STATES = ['CREATING', 'ACTIVE', 'CLOSED', 'TEMPORARY'];
const FORBIDDEN_CRYPTO_STATES = ['INITIALIZING', 'CLOSED', 'BLOCKED'];
const ORDER_STATES = ['INITIAL', 'REGISTERED', 'VALIDATED', 'REJECTED', 'PREPARED', 'SAVED', 'CREATED'];
const ORDER_TYPES = ['OM006_BUY_CRYPTO_CURRENCY', 'OM007_SELL_CRYPTO_CURRENCY'];

//Note: Faker -> uuid V4

const generateCustomer = () => ({
  customerUuid: faker.random.uuid(),
  alias: `${faker.name.firstName()} ${faker.name.lastName()}`,
  type: faker.random.arrayElement(ALLOWED_CUSTOMER_TYPES),
});

const generateCustomers = count => {
  const customers = [];
  for (let i = 0; i < count; i++) {
    customers.push(generateCustomer());
  }
  return customers;
};

const generateFiatAccount = (customerUuid, currencyOptions) => ({
  accountId: faker.helpers.replaceSymbolWithNumber('#####-#####-#####-#####'),
  currency: generateFiatCurrency(currencyOptions),
  customerFiatAccountUuid: faker.random.uuid(),
  customerUuid,
  iban: faker.finance.iban(true),
});

const generateCryptoPosition = (customerUuid, cryptoCurrencyOptions) => ({
  customerUuid,
  cryptoPositionBundleName: faker.random.uuid(),
  cryptoPositionBundleUuid: faker.random.uuid(),
  cryptoPositionUuid: faker.random.uuid(),
  cryptoProductPositionUuid: faker.random.uuid(),
  logicalWalletUuid: faker.random.uuid(),
  omnibusMasterCryptoPositionBundleUuid: faker.random.uuid(),
  cryptoPositionType: generateCryptoPositionType(cryptoCurrencyOptions),
  cryptoCurrencyType: generateCryptoCurrency(cryptoCurrencyOptions),
  state: generateCryptoCurrencyState(cryptoCurrencyOptions),
  availableBalance: generateBalance(cryptoCurrencyOptions),
});

const generateCryptoCurrencyState = ({ state }) => {
  return faker.random.arrayElement(state === 'allowed' ? ALLOWED_CRYPTO_STATES : FORBIDDEN_CRYPTO_STATES);
};

const generateCryptoPositionType = () => {
  return faker.random.arrayElement(ALLOWED_CRYPTO_POSITION_TYPES);
};

/**
 * @param {*} cryptoCurrencyOptions
 * {
 *      type: allowed | random | concrete --> allowed: random element from allowed crypto currencies, random: random ISO currency code, concrete: particular code to set
 *      value: string --> optional, crypto ISO code when type set to concrete
 *      state: allowed | forbidden
 *      isBalanceNegative: boolean
 * }
 */
const generateCryptoCurrency = ({ type, value }) => {
  switch (type) {
    case 'allowed':
      return faker.random.arrayElement(ALLOWED_CRYPTO_CURRENCIES);
    case 'random':
      return faker.random.arrayElement(FORBIDDEN_CRYPTO_CURRENCIES);
    case 'concrete':
      if (!value) throw new Error('ISO code not provided');
      return value;
    default:
      throw new Error('Unsupported crypto currency type');
  }
};

/**
 * @param {*} currencyOptions
 * {
 *     type: allowed | random | concrete --> allowed: random element from allowed Fiat currencies, random: random ISO currency code, concrete: particular code to set
 *     value: string, --> optional, currency ISO code when type set to concrete
 *     isBalanceNegative: boolean --> generate +/- balance
 * }
 */
const generateFiatCurrency = ({ type, value }) => {
  switch (type) {
    case 'allowed':
      return faker.random.arrayElement(ALLOWED_FIAT_CURRENCIES);
    case 'random':
      return faker.finance.currencyCode();
    case 'concrete':
      if (!value) throw new Error('ISO code not provided');
      return value;
    default:
      throw new Error('Unsupported fiat currency type');
  }
};

//Test cases getBalances
// 1. User: 1 Fiats, 0 Wallets
// 2. User: 3 Fiat (at least 1 EUR, at least 2 USD), 0 Wallets
// 3. User: 0 Fiats, 1 Wallets
// 4. User: 0 Fiats, 3 Wallets (at least 1 BTC, at least 2 ETH)
// 5. User: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH)
// 6. User: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH), at least 1 negative balance
// 7. User: 3 Fiat (1 EUR, 2 USD), 3 Wallets (1 BTC, 2 ETH), at least 1 balance = 0.00
// 8. User: 0 Fiat, 0 Wallets
// 9. -- not covered
// 10. -- not covered

const generateFiatAccounts = customers => {
  const fiatAccounts = [];
  // 1.
  fiatAccounts.push(generateFiatAccount(customers[0].customerUuid, { type: 'allowed' }));
  // 2.
  fiatAccounts.push(generateFiatAccount(customers[1].customerUuid, { type: 'concrete', value: 'EUR' }));
  fiatAccounts.push(generateFiatAccount(customers[1].customerUuid, { type: 'concrete', value: 'USD' }));
  fiatAccounts.push(generateFiatAccount(customers[1].customerUuid, { type: 'concrete', value: 'USD' }));
  // 3.
  // 4.
  // 5.
  fiatAccounts.push(generateFiatAccount(customers[4].customerUuid, { type: 'concrete', value: 'EUR' }));
  fiatAccounts.push(generateFiatAccount(customers[4].customerUuid, { type: 'concrete', value: 'USD' }));
  fiatAccounts.push(generateFiatAccount(customers[4].customerUuid, { type: 'concrete', value: 'USD' }));
  // 6.
  fiatAccounts.push(generateFiatAccount(customers[5].customerUuid, { type: 'concrete', value: 'EUR' }));
  fiatAccounts.push(generateFiatAccount(customers[5].customerUuid, { type: 'concrete', value: 'USD' }));
  fiatAccounts.push(generateFiatAccount(customers[5].customerUuid, { type: 'concrete', value: 'USD' }));
  // 7.
  fiatAccounts.push(generateFiatAccount(customers[6].customerUuid, { type: 'concrete', value: 'EUR' }));
  fiatAccounts.push(generateFiatAccount(customers[6].customerUuid, { type: 'concrete', value: 'USD' }));
  fiatAccounts.push(generateFiatAccount(customers[6].customerUuid, { type: 'concrete', value: 'USD' }));
  return fiatAccounts;
};

const generateCryptoPositions = customers => {
  const cryptoPositions = [];
  //1.
  //2.
  //3.
  cryptoPositions.push(generateCryptoPosition(customers[2].customerUuid, { type: 'allowed', state: 'allowed' }));
  // 4.
  cryptoPositions.push(generateCryptoPosition(customers[3].customerUuid, { type: 'concrete', value: 'BTC', state: 'allowed' }));
  cryptoPositions.push(generateCryptoPosition(customers[3].customerUuid, { type: 'concrete', value: 'ETH', state: 'allowed' }));
  cryptoPositions.push(generateCryptoPosition(customers[3].customerUuid, { type: 'concrete', value: 'ETH', state: 'allowed' }));
  // 5.
  cryptoPositions.push(generateCryptoPosition(customers[4].customerUuid, { type: 'concrete', value: 'BTC', state: 'allowed' }));
  cryptoPositions.push(generateCryptoPosition(customers[4].customerUuid, { type: 'concrete', value: 'ETH', state: 'allowed' }));
  cryptoPositions.push(generateCryptoPosition(customers[4].customerUuid, { type: 'concrete', value: 'ETH', state: 'allowed' }));
  // 6.
  cryptoPositions.push(
    generateCryptoPosition(customers[5].customerUuid, {
      type: 'concrete',
      value: 'BTC',
      state: 'allowed',
      isBalanceNegative: true,
    })
  );
  cryptoPositions.push(
    generateCryptoPosition(customers[5].customerUuid, {
      type: 'concrete',
      value: 'ETH',
      state: 'allowed',
      isBalanceNegative: true,
    })
  );
  cryptoPositions.push(generateCryptoPosition(customers[5].customerUuid, { type: 'concrete', value: 'ETH', state: 'allowed' }));
  // 7.
  cryptoPositions.push(generateCryptoPosition(customers[6].customerUuid, { type: 'concrete', value: 'BTC', state: 'allowed' }));
  cryptoPositions.push(generateCryptoPosition(customers[6].customerUuid, { type: 'concrete', value: 'ETH', state: 'allowed' }));
  cryptoPositions.push(
    generateCryptoPosition(customers[6].customerUuid, {
      type: 'concrete',
      value: 'ETH',
      state: 'allowed',
      amount: 0.0,
    })
  );
  // 8.
  return cryptoPositions;
};

const generateFiatBalances = fiatAccounts => {
  return (
    _.chain(fiatAccounts)
      .groupBy('customerUuid')
      //'value' is the array of objects 'key' is group's name --> customerUuid,
      .reduce((result, accounts, customerUuid) => {
        const balances = _.reduce(
          accounts,
          (acc, account) => {
            acc[account.customerFiatAccountUuid] = generateBalance({ isBalanceNegative: false });
            return acc;
          },
          {}
        );
        result[customerUuid] = balances;
        return result;
      }, {})
      .value()
  );
};

/**
 * @param {{ isBalanceNegative?: boolean, amount?: number }} param
 */
const generateBigDecimal = ({ isBalanceNegative, amount } = {}) => {
  if (typeof amount === 'number') {
    return amount;
  }
  if (isBalanceNegative) {
    return Number(faker.finance.amount(-5000, -1, 2));
  }
  return Number(faker.finance.amount(0.00000015, 1000, 10));
};

/**
 * @param {{ isBalanceNegative?: boolean, amount?: number }} param
 */
const generateBalance = ({ isBalanceNegative, amount } = {}) => ({ _bigDecimal: String(generateBigDecimal({ isBalanceNegative, amount })) });

const generateCryptoBalances = cryptoPositions => {
  return cryptoPositions.map(({ cryptoPositionUuid, availableBalance }) => ({
    cryptoPositionUuid,
    availableBalance,
  }));
};

const generateOrders = customers => flatten(customers.map(({ customerUuid }) => generateOrdersForCustomer(customerUuid)));

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const generateOrdersForCustomer = customerUuid =>
  [...new Array(getRandomInt(2, 10)).keys()].map(() => ({
    orderUuid: faker.random.uuid(),
    orderId: getRandomInt(100000000, 999999999),
    orderState: faker.random.arrayElement(ORDER_STATES),
    customerUuid,
    cancellable: faker.random.boolean(),
    expiryTimestamp: faker.date.soon().getTime(),
    cryptoCurrencyType: faker.random.arrayElement(ALLOWED_CRYPTO_CURRENCIES),
    cryptoPositionUuid: faker.random.uuid(),
    currency: faker.finance.currencyCode(),
    iban: faker.finance.iban(),
    transactionAmount: generateBalance(),
    transactionAmountFilled: generateBalance(),
    executionPrice: generateBalance(),
    lastExecutionTimestamp: generateBalance(),
    transactionQuantity: generateBalance(),
    limitPrice: generateBalance(),
    orderType: faker.random.arrayElement(ORDER_TYPES),
    timestampOrderReceived: faker.date.past().getTime(),
  }));

const generatedCustomers = generateCustomers(7);
const generatedFiatAccounts = generateFiatAccounts(generatedCustomers);
const generatedFiatBalances = generateFiatBalances(generatedFiatAccounts);
const generatedCryptoPositions = generateCryptoPositions(generatedCustomers);
const generatedCryptoBalances = generateCryptoBalances(generatedCryptoPositions);
const generatedOrders = generateOrders(generatedCustomers);

//customer positions - BANK API
/**
 * { customerUuid: {
 *      customerCryptoPositionDetailDto: [
 *        {
 *          customerCryptoPositionDetail: {
 *            balance: {
 *              _bigDecimal: '123123123.123'
 *            }
 *          },
 *          cryptoPosition: {}
 *        }
 *      ],
 *      fiatAccountDetailsDto: [
 *        {
 *           customerFiatAccountDetail: {},
 *           customerFiatAccount: {}
 *        }
 *      ]
 *   }
 * }
 *
 *
 */

const getWalletBalance = (wallet, cryptoBalances) => {
  const balance = cryptoBalances.find(cryptoBalance => cryptoBalance.cryptoPositionUuid === wallet.cryptoPositionUuid);
  return balance.availableBalance;
};

const getWalletDetails = (customer, cryptoPositions, cryptoBalances) => {
  const customerWallets = cryptoPositions.filter(w => w.customerUuid === customer.customerUuid);
  return customerWallets.map(wallet => ({
    customerCryptoPositionDetail: {
      balance: getWalletBalance(wallet, cryptoBalances),
    },
    cryptoPosition: wallet,
  }));
};

const generateCustomerPositions = (customers, fiatAccounts, cryptoPositions, cryptoBalances) => {
  return customers.reduce((accumulator, customer) => {
    accumulator[customer.customerUuid] = {
      customerCryptoPositionDetailDto: getWalletDetails(customer, cryptoPositions, cryptoBalances),
      fiatAccountDetailsDto: (() => {
        const customerFiatAccounts = fiatAccounts.filter(acc => acc.customerUuid === customer.customerUuid);
        return customerFiatAccounts.map(acc => ({
          customerFiatAccountDetail: {},
          customerFiatAccount: acc,
        }));
      })(),
    };
    return accumulator;
  }, {});
};

const generatedCustomerPositions = generateCustomerPositions(generatedCustomers, generatedFiatAccounts, generatedCryptoPositions, generatedCryptoBalances);

const cryptoCurrencies = ['BTC', 'ETH', 'XRP', 'XTZ', 'BCH', 'ETH2', 'LTC', 'ATOM', 'BNT', 'USDC', 'UNI', 'AAVE', 'SNX', 'MKR', '1INCH', 'CRV', 'ANT', 'ICP', 'MATIC', 'LINK', 'COMP', 'SUSHI'];

const generateCurrencies = () => [...new Set(faker.random.arrayElements(Array.from(Array(2), () => faker.finance.currencyCode()))), 'USD', 'EUR', 'CHF', 'SGD'];

const generateTradingPairs = () => cryptoCurrencies.reduce((pairs, symbol) => ({ ...pairs, [symbol]: generateCurrencies() }), {});

const generatedTradingPairs = generateTradingPairs();

const saveFile = (fileName, fileData) => {
  fs.writeFile(`./mocks/generated/${fileName}.json`, JSON.stringify(fileData, null, 2), error => {
    if (error) throw error;
    console.log(`${fileName} saved`);
  });
};

saveFile('settings-ui', { customers: generatedCustomers });
saveFile('fiat-accounts', generatedFiatAccounts);
saveFile('fiat-accounts-balances', generatedFiatBalances);
saveFile('crypto-positions', generatedCryptoPositions);
saveFile('crypto-positions-balances', generatedCryptoBalances);
saveFile('orders', generatedOrders);
saveFile('customer-positions', generatedCustomerPositions);
saveFile('trading-pairs', generatedTradingPairs);

// optionally you can pull generated mocks as POJSO
// NOTE: everytime you start mock server it'll have freshly generated set of data!
module.exports = {
  bankData: { customers: generatedCustomers },
  fiatAccounts: generatedFiatAccounts,
  fiatBalances: generatedFiatBalances,
  order: generatedOrders,
  cryptoPositions: generatedCryptoPositions,
  cryptoBalances: generatedCryptoBalances,
  tradingPairs: generatedTradingPairs,
};
