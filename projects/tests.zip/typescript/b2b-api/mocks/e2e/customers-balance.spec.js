const request = require('supertest');
const { app, CLIENT_API_PREFIX } = require('../src/common/presenters/rest/bootstrap-express');
const { marketBuyPayload, marketSellPayload, safeWhile } = require('../src/__test__/helpers');

const clientUrl = resource => `${CLIENT_API_PREFIX}/${resource}`;

const customerUuid = '8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4';
const buildGetOrderUrl = orderUuid => clientUrl(`customers/${customerUuid}/orders/${orderUuid}/details`);

const buildBuyOrderUrl = cryptoPositionUuid => clientUrl(`customers/${customerUuid}/crypto-positions/${cryptoPositionUuid}/buy`);
const buildSellOrderUrl = cryptoPositionUuid => clientUrl(`customers/${customerUuid}/crypto-positions/${cryptoPositionUuid}/sell`);

const buildFiatAccountBalanceUrl = () => clientUrl(`customers/${customerUuid}/fiat-accounts/balances`);
const buildCryptoBalanceUrl = cryptoPositionUuid => clientUrl(`customers/${customerUuid}/crypto-positions/${cryptoPositionUuid}/balance`);

const customerCryptoPositions = ['155f6555-4b2c-4491-96f0-50866d6205fe', '9466d382-18a3-4ba7-90db-835d976a8904', '71a3f9ac-d06f-4a13-91af-ba966e643a24', '86b2224e-c7a7-460b-95cd-c2e3a92a5a4a'];
const customerFiatAccounts = ['bc8d34d5-c732-401a-9015-95a34c206881', '1610f6a7-4748-4458-8576-ddd9cbda21e1', '1d3a09eb-f119-450a-b616-c365e0ff83b1', '2b70cf8a-9e5d-48bf-a0f7-640fcee0454c'];

const getOrder = async orderUuid => {
  const {
    body: { order },
  } = await request(app).get(buildGetOrderUrl(orderUuid));
  return order;
};

const getOrderState = async orderUuid => {
  const { orderState } = await getOrder(orderUuid);
  return orderState;
};

describe('CustomerBalance Suite', () => {
  describe('Changing balance', () => {
    it('should reduce fiat balance and increase crypto balance on BuyOrder', async () => {
      const { body: newOrder } = await request(app)
        .post(buildBuyOrderUrl(customerCryptoPositions[1])) // balance: 20
        .send(marketBuyPayload({ buyAmount: 1, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[1], customerFiatAccountUuid: customerFiatAccounts[1] /* balance: 1000 */ }));

      // pass the state to 'EXECUTED'
      await safeWhile(async () => (await getOrderState(newOrder.orderUuid)) !== 'EXECUTED');

      // check the fiat account balance decrease
      await request(app)
        .get(buildFiatAccountBalanceUrl())
        .query({ fiatAccount: [customerFiatAccounts[1]] })
        .then(({ body: { [customerFiatAccounts[1]]: balance } }) => {
          expect(balance).toBeLessThanOrEqual(2000);
          expect(balance).toBeGreaterThanOrEqual(0);
        });

      // check the crypto position balance increase
      await request(app)
        .get(buildCryptoBalanceUrl(customerCryptoPositions[1]))
        .then(
          ({
            body: {
              availableBalance: { _bigDecimal: cryptoBalance },
            },
          }) => {
            expect(cryptoBalance).toEqual(21);
          }
        );
    });

    it('should increase fiat balance and redyce crypto balance on SellOrder', async () => {
      const { body: newOrder } = await request(app)
        .post(buildSellOrderUrl(customerCryptoPositions[2])) // balance: 30
        .send(marketSellPayload({ sellAmount: 10, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[2], customerFiatAccountUuid: customerFiatAccounts[2] /* balance: 3000 */ }));

      // pass the state to 'EXECUTED'
      await safeWhile(async () => (await getOrderState(newOrder.orderUuid)) !== 'EXECUTED');

      // check the crypto position balance decrease
      await request(app)
        .get(buildCryptoBalanceUrl(customerCryptoPositions[2]))
        .then(
          ({
            body: {
              availableBalance: { _bigDecimal: cryptoBalance },
            },
          }) => {
            expect(cryptoBalance).toEqual(20);
          }
        );

      // check the fiat account balance increase
      await request(app)
        .get(buildFiatAccountBalanceUrl())
        .query({ fiatAccount: [customerFiatAccounts[2]] })
        .then(({ body: { [customerFiatAccounts[2]]: balance } }) => {
          expect(balance).toBeGreaterThan(3000);
        });
    });
  });
  describe('Order rejection', () => {
    it('should reject BuyOrder if customer has not enough fiat balance', async () => {
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildBuyOrderUrl(customerCryptoPositions[0])) // balance: 1000
        .send(marketBuyPayload({ buyAmount: 2, /* price: 2000 */ cryptoPositionUuid: customerCryptoPositions[0], customerFiatAccountUuid: customerFiatAccounts[0] /* balance: 1000 */ }));

      expect(await getOrderState(orderUuid)).toEqual('INITIAL');
      expect(await getOrderState(orderUuid)).toEqual('REJECTED');
    });

    it('should reject SellOrder if customer has not enough crypto balance', async () => {
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildSellOrderUrl(customerCryptoPositions[0])) // balance: 10
        .send(marketSellPayload({ sellAmount: 11, /* customer has 10 */ cryptoPositionUuid: customerCryptoPositions[0], customerFiatAccountUuid: customerFiatAccounts[0] }));

      expect(await getOrderState(orderUuid)).toEqual('INITIAL');
      expect(await getOrderState(orderUuid)).toEqual('REJECTED');
    });
  });
  describe('Order blocking', () => {
    it('should reject BuyOrder if customer already placed an order and has blocked Fiat Balance', async () => {
      const { body: _firstOrder } = await request(app)
        .post(buildBuyOrderUrl(customerCryptoPositions[3])) // balance: 4000
        .send(marketBuyPayload({ buyAmount: 2, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[3], customerFiatAccountUuid: customerFiatAccounts[3] /* balance: 4000 */ }));

      const { body: secondOrder } = await request(app)
        .post(buildBuyOrderUrl(customerCryptoPositions[3])) // balance: 4000 (blocked 3000)
        .send(marketBuyPayload({ buyAmount: 3, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[3], customerFiatAccountUuid: customerFiatAccounts[3] /* balance: 4000 */ }));

      // second order should be rejected
      expect(await getOrderState(secondOrder.orderUuid)).toEqual('INITIAL');
      expect(await getOrderState(secondOrder.orderUuid)).toEqual('REJECTED');

      // check the fiat account balance shouldn't be changed after rejection
      await request(app)
        .get(buildFiatAccountBalanceUrl())
        .query({ fiatAccount: [customerFiatAccounts[3]] })
        .then(({ body: { [customerFiatAccounts[3]]: balance } }) => {
          expect(balance).toEqual(4000);
        });

      // order with available balance should be placed
      const { body: thirdOrder } = await request(app)
        .post(buildBuyOrderUrl(customerCryptoPositions[3])) // balance: 4000 (blocked 3000)
        .send(marketBuyPayload({ buyAmount: 2, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[3], customerFiatAccountUuid: customerFiatAccounts[3] /* balance: 4000 */ }));

      // third order should be rejected
      expect(await getOrderState(thirdOrder.orderUuid)).toEqual('INITIAL');
      expect(await getOrderState(thirdOrder.orderUuid)).not.toEqual('REJECTED');
    });
    it('should reject SellOrder if customer already placed an order and has blocked Crypto Balance', async () => {
      const { body: _firstOrder } = await request(app)
        .post(buildSellOrderUrl(customerCryptoPositions[3])) // balance: 40
        .send(marketSellPayload({ sellAmount: 30, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[3], customerFiatAccountUuid: customerFiatAccounts[3] /* balance: 4000 */ }));

      const { body: secondOrder } = await request(app)
        .post(buildSellOrderUrl(customerCryptoPositions[3])) // balance: 40 (blocked 30 from previous call)
        .send(marketSellPayload({ sellAmount: 15, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[3], customerFiatAccountUuid: customerFiatAccounts[3] /* balance: 4000 */ }));

      // second order should be rejected
      expect(await getOrderState(secondOrder.orderUuid)).toEqual('INITIAL');
      expect(await getOrderState(secondOrder.orderUuid)).toEqual('REJECTED');

      // crypto position balance shouldn't be changed after rejection
      await request(app)
        .get(buildCryptoBalanceUrl(customerCryptoPositions[3]))
        .then(
          ({
            body: {
              availableBalance: { _bigDecimal: cryptoBalance },
            },
          }) => {
            expect(cryptoBalance).toEqual(40);
          }
        );

      // order with available balance should be placed
      const { body: thirdOrder } = await request(app)
        .post(buildSellOrderUrl(customerCryptoPositions[3])) // balance: 40 (blocked 30 from previous call)
        .send(marketSellPayload({ sellAmount: 5, /* price: 1000 */ cryptoPositionUuid: customerCryptoPositions[3], customerFiatAccountUuid: customerFiatAccounts[3] /* balance: 4000 */ }));

      // third order should be rejected
      expect(await getOrderState(thirdOrder.orderUuid)).toEqual('INITIAL');
      expect(await getOrderState(thirdOrder.orderUuid)).not.toEqual('REJECTED');
    });
  });
});
