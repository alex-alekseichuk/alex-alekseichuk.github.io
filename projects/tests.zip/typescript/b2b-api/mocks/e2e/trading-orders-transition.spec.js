const request = require('supertest');
const { app, CLIENT_API_PREFIX } = require('../src/common/presenters/rest/bootstrap-express');
const { tradingOrderStates } = require('../src/mockserver-configuration');
const { limitBuyPayload, marketBuyPayload, limitSellPayload, marketSellPayload } = require('../src/__test__/helpers');

const clientUrl = resource => `${CLIENT_API_PREFIX}/${resource}`;

const customerUuid = '8f8e4d7a-2f0d-4e83-8b9b-aa564e10a8b4';
const buildGetOrderUrl = orderUuid => clientUrl(`customers/${customerUuid}/orders/${orderUuid}/details`);

const buildBuyOrderUrl = cryptoPositionUuid => clientUrl(`customers/${customerUuid}/crypto-positions/${cryptoPositionUuid}/buy`);
const buildSellOrderUrl = cryptoPositionUuid => clientUrl(`customers/${customerUuid}/crypto-positions/${cryptoPositionUuid}/sell`);

const buildCancelOrderUrl = orderUuid => clientUrl(`customer/${customerUuid}/orders/${orderUuid}`);

const getOrder = async orderUuid => {
  const {
    body: { order },
  } = await request(app).get(buildGetOrderUrl(orderUuid));
  return order;
};

const getOrderState = async orderUuid => {
  const { orderState } = await getOrder(orderUuid);
  return orderState;
};

describe('OrdersTransition Suite', () => {
  describe('Market order', () => {
    it('will generate market order with non-cancellable status', async () => {
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildBuyOrderUrl('cryptoposition-uuid'))
        .send(marketBuyPayload({ cryptoPositionUuid: 'cryptoposition-uuid' }));

      const newOrder = await getOrder(orderUuid);

      expect(newOrder.orderUuid).toBeDefined();
      expect(newOrder.customerUuid).toBeDefined();

      expect(newOrder.orderState).toEqual('INITIAL');
      expect(newOrder.cancellable).toEqual(false);

      expect(newOrder.customerUuid).toEqual(customerUuid);
      expect(newOrder.cryptoPosition.cryptoPositionUuid).toEqual('cryptoposition-uuid');
    });

    it('returns INITIAL status and transits to VALIDATED status after second call', async () => {
      const {
        body: { orderUuid },
      } = await request(app).post(buildBuyOrderUrl('cryptoposition-uuid')).send(marketBuyPayload());

      const firstCallState = await getOrderState(orderUuid);
      expect(firstCallState).toEqual('INITIAL');

      const secondCallState = await getOrderState(orderUuid);
      expect(secondCallState).toEqual('VALIDATED');
    });

    it('transits through entire possible statuses and stays in DONE', async () => {
      const marketOrderStates = [...tradingOrderStates.MARKET_ORDER_PRE_EXECUTION_STATES, ...tradingOrderStates.EXECUTION_STATES];
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildSellOrderUrl('cryptoposition-uuid'))
        .send(marketSellPayload({ sellAmount: 1, customerFiatAccountUuid: '98c79218-c2b5-431d-88c8-b74f9f0aad87', cryptoPositionUuid: '411ed778-fa3f-4486-a2b4-854fe0c90d22' }));

      for (orderStatus of marketOrderStates) {
        const currentStatus = await getOrderState(orderUuid);
        expect(currentStatus).toEqual(orderStatus);
      }

      const orderAfterDone = await getOrder(orderUuid);
      expect(orderAfterDone.orderState).toEqual('DONE');
      expect(orderAfterDone.lastExecutionTimestamp).toBeDefined();
      expect(orderAfterDone.transactionAmount).toBeDefined();
      expect(orderAfterDone.transactionAmountFilled).toBeDefined();
      expect(orderAfterDone.executionPrice).toBeDefined();
      expect(orderAfterDone.transactionQuantity).toBeDefined();
    });

    it('should not affect when cancellation executed', async () => {
      const {
        body: { orderUuid },
      } = await request(app).post(buildBuyOrderUrl('cryptoposition-uuid')).send(marketBuyPayload());

      await request(app).delete(buildCancelOrderUrl(orderUuid));

      const status = await getOrderState(orderUuid);
      expect(status).toEqual('INITIAL');
    });
  });

  describe('Limit order', () => {
    it('will generate market order with cancellable status', async () => {
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildBuyOrderUrl('cryptoposition-uuid'))
        .send(limitBuyPayload({ cryptoPositionUuid: 'cryptoposition-uuid' }));

      const newOrder = await getOrder(orderUuid);

      expect(newOrder.orderUuid).toBeDefined();
      expect(newOrder.customerUuid).toBeDefined();

      expect(newOrder.orderState).toEqual('INITIAL');
      expect(newOrder.cancellable).toEqual(true);

      expect(newOrder.customerUuid).toEqual(customerUuid);
      expect(newOrder.cryptoPosition.cryptoPositionUuid).toEqual('cryptoposition-uuid');
    });

    it('returns INITIAL status and transits to VALIDATED status after second call', async () => {
      const {
        body: { orderUuid },
      } = await request(app).post(buildBuyOrderUrl('cryptoposition-uuid')).send(limitBuyPayload());

      const firstCallState = await getOrderState(orderUuid);
      expect(firstCallState).toEqual('INITIAL');

      const secondCallState = await getOrderState(orderUuid);
      expect(secondCallState).toEqual('VALIDATED');
    });

    it('transits through entire possible statuses and stays in PLACED', async () => {
      const limitOrderStates = [...tradingOrderStates.LIMIT_ORDER_PRE_EXECUTION_STATES];
      const {
        body: { orderUuid },
      } = await request(app).post(buildSellOrderUrl('cryptoposition-uuid')).send(limitBuyPayload());

      for (orderStatus of limitOrderStates) {
        const currentStatus = await getOrderState(orderUuid);
        expect(currentStatus).toEqual(orderStatus);
      }

      const status = await getOrderState(orderUuid);
      expect(status).toEqual('PLACED');
    });

    it('should cancel an order when cancellation executed', async () => {
      const {
        body: { orderUuid },
      } = await request(app).post(buildBuyOrderUrl('cryptoposition-uuid')).send(limitBuyPayload());

      await request(app).delete(buildCancelOrderUrl(orderUuid));

      const status = await getOrderState(orderUuid);
      expect(status).toEqual('CANCELLED');
    });
  });

  describe('Rejection on Transit', () => {
    it('should transit through INITIAL to REJECTED state for BuyOrder when limitPrice = 9000', async () => {
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildBuyOrderUrl('cryptoposition-uuid'))
        .send(limitBuyPayload({ limitAmount: 9000 }));

      const initialStatus = await getOrderState(orderUuid);
      expect(initialStatus).toEqual('INITIAL');

      const rejectedStatus = await getOrderState(orderUuid);
      expect(rejectedStatus).toEqual('REJECTED');
    });

    it('should transit through INITIAL to REJECTED state for SellOrder when limitPrice = 9000', async () => {
      const {
        body: { orderUuid },
      } = await request(app)
        .post(buildSellOrderUrl('cryptoposition-uuid'))
        .send(limitSellPayload({ limitAmount: 9000 }));

      const initialStatus = await getOrderState(orderUuid);
      expect(initialStatus).toEqual('INITIAL');

      const rejectedStatus = await getOrderState(orderUuid);
      expect(rejectedStatus).toEqual('REJECTED');
    });
  });
});
