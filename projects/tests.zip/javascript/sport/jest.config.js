const tsconfig = require('./tsconfig');

module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  cacheDirectory: '<rootDir>/.cache/jest',
  testPathIgnorePatterns: ['<rootDir>/dist/'],
};
