import { getEntityId, MemoryQueueAdapter, QueueAdapter, SportDto } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateSport,
  CreateSportOutputDto,
  GetSportsList,
  GetSportsListOutputDto
} from '../../../../../src/application';
import { EntityPrefix, SportProps } from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

describe('GetSportsListUseCase', () => {
  test('should get entities list from repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createUseCase: CreateSport = new CreateSport(repository, queue);
    const createOutput: CreateSportOutputDto = await createUseCase.execute(SPORT_PROPS);
    expect(createOutput.isRight()).toBe(true);

    const getListUseCase: GetSportsList = new GetSportsList(repository);
    const getListOutput: GetSportsListOutputDto = await getListUseCase.execute();
    expect(getListOutput.isRight()).toBe(true);
    const sportsDtoList: SportDto[] = getListOutput.value as SportDto[];
    expect(Array.isArray(sportsDtoList)).toBe(true);
    expect(sportsDtoList.length).toBe(1);
    expect(sportsDtoList[0].id).toBe(SPORT_PROPS.id);
  });
});
