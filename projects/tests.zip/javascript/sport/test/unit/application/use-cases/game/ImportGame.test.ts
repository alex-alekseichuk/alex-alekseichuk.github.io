import { describe, expect, test } from '@jest/globals';
import {
  DataNotFoundGatewayError,
  DtoValidationApplicationError,
  Either,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueChampionshipDto,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter,
  TeamDto
} from 'core';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID,
  GetLeagueById,
  GetLeagueByIdOutputDto,
  GetTeamsList,
  GetTeamsListOutputDto,
  ImportAthlete,
  ImportAthleteOutputDto,
  ImportGame,
  ImportGameOutputDto,
  ImportLeague,
  ImportLeagueOutputDto,
  ImportTeam,
  ImportTeamOutputDto,
  SportFeedHistoryGatewayFactory
} from '../../../../../src/application';
import { EntityPrefix, League, LeagueProps, SportFeedProps, SportProps } from '../../../../../src/domain';
import {
  AthleteInMemoryRepository,
  ExternalRefInMemoryGateway,
  GameInMemoryRepository,
  ImportingInMemoryGateway,
  LeagueInMemoryRepository,
  SportFeedHistoryGatewayFactoryImpl,
  SportInMemoryRepository,
  TeamInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerSportFeed',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: 'sport_feed_league_epl',
};

const CHAMPIONSHIPS_LIST: LeagueChampionshipDto[] = [
  {
    championshipRefId: 'sport_feed_championship_1',
    enabled: true,
    name: 'Championship 1',
    nameShort: 'Champ 1',
  },
  {
    championshipRefId: 'sport_feed_championship_2',
    enabled: true,
    name: 'Championship 2',
    nameShort: 'Champ 2',
  },
];

describe('ImportGameUseCase', () => {
  test('should import game', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const athleteRepository: AthleteInMemoryRepository = new AthleteInMemoryRepository();
    const gameRepository: GameInMemoryRepository = new GameInMemoryRepository();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    let leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importLeagueUseCase: ImportLeague = new ImportLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importLeagueOutput: ImportLeagueOutputDto = await importLeagueUseCase.execute({
      leagueId: leagueDto.id,
      championships: CHAMPIONSHIPS_LIST,
    });
    expect(importLeagueOutput.isRight()).toBe(true);

    const getLeagueByIdUseCase: GetLeagueById = new GetLeagueById(externalRefGateway, leagueRepository);
    const getLeagueByIdOutput: GetLeagueByIdOutputDto = await getLeagueByIdUseCase.execute(leagueDto.id);
    expect(getLeagueByIdOutput.isRight()).toBe(true);
    leagueDto = getLeagueByIdOutput.value as LeagueDto;
    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    let importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);
    importTeamOutput = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_2',
    });
    expect(importTeamOutput.isRight()).toBe(true);

    const getTeamsListUseCase: GetTeamsList = new GetTeamsList(teamRepository);
    const getTeamsListOutput: GetTeamsListOutputDto = await getTeamsListUseCase.execute();
    expect(getTeamsListOutput.isRight()).toBe(true);
    const teamsDtoList: TeamDto[] = getTeamsListOutput.value as TeamDto[];
    expect(teamsDtoList.length).toBe(2);
    const team1Dto: TeamDto = teamsDtoList[0];
    const team2Dto: TeamDto = teamsDtoList[0];

    const importAthleteUseCase: ImportAthlete = new ImportAthlete(
      athleteRepository,
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    let importAthleteOutput: ImportAthleteOutputDto = await importAthleteUseCase.execute({
      leagueId: leagueDto.id,
      teamId: team1Dto.id,
      athleteRefId: 'sport_feed_athlete_1',
    });
    expect(importAthleteOutput.isRight()).toBe(true);
    importAthleteOutput = await importAthleteUseCase.execute({
      leagueId: leagueDto.id,
      teamId: team2Dto.id,
      athleteRefId: 'sport_feed_athlete_2',
    });
    expect(importAthleteOutput.isRight()).toBe(true);

    const getLeagueResult: Either<EntityNotFoundRepositoryError, League> = await leagueRepository.getById(
      leagueDto.id
    );
    expect(getLeagueResult.isRight()).toBe(true);
    const league: League = getLeagueResult.value as League;

    const importGameUseCase: ImportGame = new ImportGame(
      externalRefGateway,
      gameRepository,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGameOutput: ImportGameOutputDto = await importGameUseCase.execute({
      leagueId: league.id,
      seasonId: league.seasons[0].id,
      championshipId: league.seasons[0].championships[0].id,
      gameRefId: 'sport_feed_game_1',
    });
    expect(importGameOutput.isRight()).toBe(true);
  });

  test('should return error in case leagueId not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const gameRepository: GameInMemoryRepository = new GameInMemoryRepository();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();

    const importGameUseCase: ImportGame = new ImportGame(
      externalRefGateway,
      gameRepository,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGameOutput: ImportGameOutputDto = await importGameUseCase.execute({
      leagueId: 123 as any,
      seasonId: '123456789',
      championshipId: '123456789',
      gameRefId: 'sport_feed_game_1',
    });
    expect(importGameOutput.isLeft()).toBe(true);
    expect(importGameOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case league not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const gameRepository: GameInMemoryRepository = new GameInMemoryRepository();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();

    const importGameUseCase: ImportGame = new ImportGame(
      externalRefGateway,
      gameRepository,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGameOutput: ImportGameOutputDto = await importGameUseCase.execute({
      leagueId: '123456789',
      seasonId: '123456789',
      championshipId: '123456789',
      gameRefId: 'sport_feed_game_1',
    });
    expect(importGameOutput.isLeft()).toBe(true);
    expect(importGameOutput.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case season not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const gameRepository: GameInMemoryRepository = new GameInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importGameUseCase: ImportGame = new ImportGame(
      externalRefGateway,
      gameRepository,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGameOutput: ImportGameOutputDto = await importGameUseCase.execute({
      leagueId: leagueDto.id,
      seasonId: '123456789',
      championshipId: '123456789',
      gameRefId: 'sport_feed_game_1',
    });
    expect(importGameOutput.isLeft()).toBe(true);
    expect(importGameOutput.value).toBeInstanceOf(DataNotFoundGatewayError);
  });

  test('should return error in case championship not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const gameRepository: GameInMemoryRepository = new GameInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importLeagueUseCase: ImportLeague = new ImportLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importLeagueOutput: ImportLeagueOutputDto = await importLeagueUseCase.execute({
      leagueId: leagueDto.id,
      championships: CHAMPIONSHIPS_LIST,
    });
    expect(importLeagueOutput.isRight()).toBe(true);

    const getLeagueResult: Either<EntityNotFoundRepositoryError, League> = await leagueRepository.getById(
      leagueDto.id
    );
    expect(getLeagueResult.isRight()).toBe(true);
    const league: League = getLeagueResult.value as League;

    const importGameUseCase: ImportGame = new ImportGame(
      externalRefGateway,
      gameRepository,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGameOutput: ImportGameOutputDto = await importGameUseCase.execute({
      leagueId: league.id,
      seasonId: league.seasons[0].id,
      championshipId: '123456789',
      gameRefId: 'sport_feed_game_1',
    });
    expect(importGameOutput.isLeft()).toBe(true);
    expect(importGameOutput.value).toBeInstanceOf(DataNotFoundGatewayError);
  });

  test('should return error in case game not exists in gateway', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const gameRepository: GameInMemoryRepository = new GameInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importLeagueUseCase: ImportLeague = new ImportLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importLeagueOutput: ImportLeagueOutputDto = await importLeagueUseCase.execute({
      leagueId: leagueDto.id,
      championships: CHAMPIONSHIPS_LIST,
    });
    expect(importLeagueOutput.isRight()).toBe(true);

    const getLeagueResult: Either<EntityNotFoundRepositoryError, League> = await leagueRepository.getById(
      leagueDto.id
    );
    expect(getLeagueResult.isRight()).toBe(true);
    const league: League = getLeagueResult.value as League;

    const importGameUseCase: ImportGame = new ImportGame(
      externalRefGateway,
      gameRepository,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGameOutput: ImportGameOutputDto = await importGameUseCase.execute({
      leagueId: league.id,
      seasonId: league.seasons[0].id,
      championshipId: league.seasons[0].championships[0].id,
      gameRefId: '123456789',
    });
    expect(importGameOutput.isLeft()).toBe(true);
    expect(importGameOutput.value).toBeInstanceOf(DataNotFoundGatewayError);
  });
});
