import { describe, expect, test } from '@jest/globals';
import { getEntityId, LeagueDto, MemoryQueueAdapter, QueueAdapter, QueueCallbackType } from 'core';
import {
  CheckLeaguesNextGames,
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID
} from '../../../../../src/application';
import {
  EntityPrefix,
  ImportGamesEvent,
  LeagueProps,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  LeagueInMemoryRepository,
  SportInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerSportFeed',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: 'sport_feed_league_epl',
};

describe('CheckLeaguesNextGames', () => {
  test('publish events to import games', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const callbackData: { callback: QueueCallbackType } = {
      callback: () => {},
    };
    const spy: jest.SpyInstance = jest.spyOn(callbackData, 'callback');
    queue.consume(ImportGamesEvent.name, callbackData.callback);

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);

    const checkLeaguesNextGamesUseCase: CheckLeaguesNextGames = new CheckLeaguesNextGames(
      leagueRepository,
      queue
    );
    await checkLeaguesNextGamesUseCase.execute();

    expect(spy).toHaveBeenCalled();
  });
});
