import {
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  SportDto,
  ValidationType
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateSport,
  CreateSportOutputDto,
  UpdateSport,
  UpdateSportOutputDto
} from '../../../../../src/application';
import { EntityPrefix, SportProps } from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

describe('UpdateSportUseCase', () => {
  test('should update entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const updateUseCase: UpdateSport = new UpdateSport(repository);
    const newEnabled: boolean = !SPORT_PROPS.enabled;
    const newName: string = 'New Name';
    const updateOutput: UpdateSportOutputDto = await updateUseCase.execute({
      sportId: SPORT_PROPS.id,
      update: {
        enabled: newEnabled,
        name: newName,
      },
    });
    expect(updateOutput.isRight()).toBe(true);
    const dto: SportDto = updateOutput.value as SportDto;
    expect(dto.id).toBe(SPORT_PROPS.id);
    expect(dto.enabled).toBe(newEnabled);
    expect(dto.name).toBe(newName);
  });

  test('should return error in case entity not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: UpdateSport = new UpdateSport(repository);
    const output: UpdateSportOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      update: {
        enabled: false,
        name: 'New Name',
      },
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case name not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const updateUseCase: UpdateSport = new UpdateSport(repository);
    const newName: string = '1';
    const updateOutput: UpdateSportOutputDto = await updateUseCase.execute({
      sportId: SPORT_PROPS.id,
      update: {
        name: newName,
      },
    });
    expect(updateOutput.isLeft()).toBe(true);
    expect(updateOutput.value).toBeInstanceOf(DtoValidationApplicationError);
    const errorData: DtoValidationApplicationError = updateOutput.value as DtoValidationApplicationError;
    expect(Array.isArray(errorData.errors)).toBe(true);
    expect(errorData.errors?.length).toBe(1);
    expect(errorData.errors![0].type).toBe(ValidationType.MinLength);
  });
});
