import { getEntityId, LeagueDto, MemoryQueueAdapter, QueueAdapter } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  GetLeaguesList,
  GetLeaguesListOutputDto
} from '../../../../../src/application';
import { EntityPrefix, LeagueProps, SportFeedProps, SportProps } from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  LeagueInMemoryRepository,
  SportInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: '123456789',
};

describe('GetLeaguesListUseCase', () => {
  test('should get entities list from repository', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);

    const getListUseCase: GetLeaguesList = new GetLeaguesList(leagueRepository);
    const getListOutput: GetLeaguesListOutputDto = await getListUseCase.execute();
    expect(getListOutput.isRight()).toBe(true);
    const leaguesDtoList: LeagueDto[] = getListOutput.value as LeagueDto[];
    expect(Array.isArray(leaguesDtoList)).toBe(true);
    expect(leaguesDtoList.length).toBe(1);
    expect(leaguesDtoList[0].name).toBe(LEAGUE_PROPS.name);
  });
});
