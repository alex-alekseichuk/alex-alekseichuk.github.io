import {
  AthleteAttributeDto,
  DtoValidationApplicationError,
  EntityAlreadyExistsDomainError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateAthleteAttribute,
  CreateAthleteAttributeOutputDto,
  CreateSport,
  CreateSportOutputDto
} from '../../../../../src/application';
import {
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  SportProps
} from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

describe('CreateAthleteAttributeUseCase', () => {
  test('should create entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);
    const dto: AthleteAttributeDto = createAthleteAttributeOutput.value as AthleteAttributeDto;
    expect(dto.dataFormat).toBe(ATHLETE_ATTRIBUTE_PROPS.dataFormat);
    expect(dto.name).toBe(ATHLETE_ATTRIBUTE_PROPS.name);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const output: CreateAthleteAttributeOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      data: ATHLETE_ATTRIBUTE_PROPS,
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case name is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: {
          ...ATHLETE_ATTRIBUTE_PROPS,
          name: '1',
        },
      });
    expect(createAthleteAttributeOutput.isLeft()).toBe(true);
    expect(createAthleteAttributeOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case entitity already exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    let createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);
    createAthleteAttributeOutput = await createAthleteAttributeUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: ATHLETE_ATTRIBUTE_PROPS,
    });
    expect(createAthleteAttributeOutput.isLeft()).toBe(true);
    expect(createAthleteAttributeOutput.value).toBeInstanceOf(EntityAlreadyExistsDomainError);
  });
});
