import {
  AthleteAttributeDto,
  DtoValidationApplicationError,
  EntityNotFoundDomainError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateAthleteAttribute,
  CreateAthleteAttributeOutputDto,
  CreateSport,
  CreateSportOutputDto,
  UpdateAthleteAttributes,
  UpdateAthleteAttributesOutputDto
} from '../../../../../src/application';
import {
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  SportProps
} from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

describe('UpdateAthleteAttributesUseCase', () => {
  test('should update entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);
    const dto: AthleteAttributeDto = createAthleteAttributeOutput.value as AthleteAttributeDto;

    const updateAthleteAttributesUseCase: UpdateAthleteAttributes = new UpdateAthleteAttributes(repository);
    const newName: string = 'New Name';
    const updateAthleteAttributesOutput: UpdateAthleteAttributesOutputDto =
      await updateAthleteAttributesUseCase.execute({
        sportId: SPORT_PROPS.id,
        updates: [
          {
            athleteAttributeId: dto.id,
            data: {
              name: newName,
            },
          },
        ],
      });
    expect(updateAthleteAttributesOutput.isRight()).toBe(true);
    const dtoList: AthleteAttributeDto[] = updateAthleteAttributesOutput.value as AthleteAttributeDto[];
    expect(Array.isArray(dtoList)).toBe(true);
    expect(dtoList.length).toBe(1);
    expect(dtoList[0].name).toBe(newName);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: UpdateAthleteAttributes = new UpdateAthleteAttributes(repository);
    const output: UpdateAthleteAttributesOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      updates: [
        {
          athleteAttributeId: '1234567',
          data: {
            name: ATHLETE_ATTRIBUTE_PROPS.name,
          },
        },
      ],
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case entity not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const updateAthleteAttributesUseCase: UpdateAthleteAttributes = new UpdateAthleteAttributes(repository);
    const updateAthleteAttributesOutput: UpdateAthleteAttributesOutputDto =
      await updateAthleteAttributesUseCase.execute({
        sportId: SPORT_PROPS.id,
        updates: [
          {
            athleteAttributeId: '1234567',
            data: {
              name: ATHLETE_ATTRIBUTE_PROPS.name,
            },
          },
        ],
      });
    expect(updateAthleteAttributesOutput.isLeft()).toBe(true);
    expect(updateAthleteAttributesOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case name is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);
    let dto: AthleteAttributeDto = createAthleteAttributeOutput.value as AthleteAttributeDto;

    const updateAthleteAttributesUseCase: UpdateAthleteAttributes = new UpdateAthleteAttributes(repository);
    const updateAthleteAttributesOutput: UpdateAthleteAttributesOutputDto =
      await updateAthleteAttributesUseCase.execute({
        sportId: SPORT_PROPS.id,
        updates: [
          {
            athleteAttributeId: dto.id,
            data: {
              name: '1',
            },
          },
        ],
      });
    expect(updateAthleteAttributesOutput.isLeft()).toBe(true);
    expect(updateAthleteAttributesOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });
});
