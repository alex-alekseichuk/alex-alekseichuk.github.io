import {
  EntityAlreadyExistsApplicationError,
  EntityValidationDomainError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  QueueCallbackType,
  SportDto
} from 'core';
import { describe, expect, test } from '@jest/globals';
import { CreateSport, CreateSportOutputDto } from '../../../../../src/application';
import { EntityPrefix, SportCreatedEvent, SportProps } from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

describe('CreateSportUseCase', () => {
  test('should create entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const useCase: CreateSport = new CreateSport(repository, queue);
    const output: CreateSportOutputDto = await useCase.execute(SPORT_PROPS);
    expect(output.isRight()).toBe(true);
    const dto: SportDto = output.value as SportDto;
    expect(dto.id).toBe(SPORT_PROPS.id);
  });

  test('should trigger created event in queue', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const callbackData: { callback: QueueCallbackType } = {
      callback: () => {},
    };
    const spy: jest.SpyInstance = jest.spyOn(callbackData, 'callback');
    queue.consume(SportCreatedEvent.name, callbackData.callback);

    const useCase: CreateSport = new CreateSport(repository, queue);
    const output: CreateSportOutputDto = await useCase.execute(SPORT_PROPS);
    expect(output.isRight()).toBe(true);

    expect(spy).toHaveBeenCalled();
  });

  test('should return error in case name is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const useCase: CreateSport = new CreateSport(repository, queue);
    const output: CreateSportOutputDto = await useCase.execute({
      ...SPORT_PROPS,
      name: '1',
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityValidationDomainError);
  });

  test('should return error in case entity already exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const useCase: CreateSport = new CreateSport(repository, queue);
    let output: CreateSportOutputDto = await useCase.execute(SPORT_PROPS);
    expect(output.isRight()).toBe(true);
    output = await useCase.execute(SPORT_PROPS);
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityAlreadyExistsApplicationError);
  });
});
