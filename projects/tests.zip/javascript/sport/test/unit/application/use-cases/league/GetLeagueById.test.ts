import {
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  GetLeagueById,
  GetLeagueByIdOutputDto
} from '../../../../../src/application';
import { EntityPrefix, League, LeagueProps, SportFeedProps, SportProps } from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  LeagueInMemoryRepository,
  SportInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: '123456789',
};

describe('GetLeagueByIdUseCase', () => {
  test('should get entity by id from repository', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const createdLeagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const getByIdUseCase: GetLeagueById = new GetLeagueById(externalRefGateway, leagueRepository);
    const getByIdOutput: GetLeagueByIdOutputDto = await getByIdUseCase.execute(createdLeagueDto.id);
    expect(getByIdOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = getByIdOutput.value as LeagueDto;
    expect(leagueDto.id).toBe(createdLeagueDto.id);
  });

  test('should return error in case id not valid', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const repository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const useCase: GetLeagueById = new GetLeagueById(externalRefGateway, repository);

    const output: GetLeagueByIdOutputDto = await useCase.execute(111 as any);
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case entity not exists in repository', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const repository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const useCase: GetLeagueById = new GetLeagueById(externalRefGateway, repository);

    const output: GetLeagueByIdOutputDto = await useCase.execute('123456789');
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });
});
