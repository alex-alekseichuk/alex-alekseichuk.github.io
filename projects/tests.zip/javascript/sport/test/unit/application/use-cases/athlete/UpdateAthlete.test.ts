import { describe, expect, test } from '@jest/globals';
import {
  AthleteDto,
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter,
  TeamDto,
  ValidationType
} from 'core';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID,
  GetAthletesList,
  GetAthletesListOutputDto,
  GetTeamsList,
  GetTeamsListOutputDto,
  ImportAthlete,
  ImportAthleteOutputDto,
  ImportTeam,
  ImportTeamOutputDto,
  SportFeedHistoryGatewayFactory,
  UpdateAthlete,
  UpdateAthleteOutputDto
} from '../../../../../src/application';
import { EntityPrefix, LeagueProps, SportFeedProps, SportProps } from '../../../../../src/domain';
import {
  AthleteInMemoryRepository,
  ExternalRefInMemoryGateway,
  ImportingInMemoryGateway,
  LeagueInMemoryRepository,
  SportFeedHistoryGatewayFactoryImpl,
  SportInMemoryRepository,
  TeamInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerSportFeed',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: 'sport_feed_league_epl',
};

describe('UpdateAthleteUseCase', () => {
  test('should update entity in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const athleteRepository: AthleteInMemoryRepository = new AthleteInMemoryRepository();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);

    const getTeamsListUseCase: GetTeamsList = new GetTeamsList(teamRepository);
    const getTeamsListOutput: GetTeamsListOutputDto = await getTeamsListUseCase.execute();
    expect(getTeamsListOutput.isRight()).toBe(true);
    const teamsDtoList: TeamDto[] = getTeamsListOutput.value as TeamDto[];
    expect(Array.isArray(teamsDtoList)).toBe(true);
    expect(teamsDtoList.length).toBe(1);
    const teamDto: TeamDto = teamsDtoList[0];

    const importAthleteUseCase: ImportAthlete = new ImportAthlete(
      athleteRepository,
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthleteOutput: ImportAthleteOutputDto = await importAthleteUseCase.execute({
      leagueId: leagueDto.id,
      teamId: teamDto.id,
      athleteRefId: 'sport_feed_athlete_1',
    });
    expect(importAthleteOutput.isRight()).toBe(true);

    const getAthletesListUseCase: GetAthletesList = new GetAthletesList(athleteRepository);
    let getAthletesListOutput: GetAthletesListOutputDto = await getAthletesListUseCase.execute();
    expect(getAthletesListOutput.isRight()).toBe(true);
    let athletesDtoList: AthleteDto[] = getAthletesListOutput.value as AthleteDto[];
    expect(Array.isArray(athletesDtoList)).toBe(true);
    expect(athletesDtoList.length).toBe(1);
    let athleteDto: AthleteDto = athletesDtoList[0];

    const updateAthleteUseCase: UpdateAthlete = new UpdateAthlete(athleteRepository);
    const newName: string = 'New Name';
    const updateAthleteOutput: UpdateAthleteOutputDto = await updateAthleteUseCase.execute({
      athleteId: athleteDto.id,
      update: {
        data: {
          name: newName,
        },
      },
    });
    expect(updateAthleteOutput.isRight()).toBe(true);

    getAthletesListOutput = await getAthletesListUseCase.execute();
    expect(getAthletesListOutput.isRight()).toBe(true);
    athletesDtoList = getAthletesListOutput.value as AthleteDto[];
    expect(Array.isArray(athletesDtoList)).toBe(true);
    expect(athletesDtoList.length).toBe(1);
    athleteDto = athletesDtoList[0];

    expect(athleteDto.name).toBe(newName);
  });

  test('should return error in case entity not exists in repository', async function () {
    const repository: AthleteInMemoryRepository = new AthleteInMemoryRepository();

    const useCase: UpdateAthlete = new UpdateAthlete(repository);
    const output: UpdateAthleteOutputDto = await useCase.execute({
      athleteId: '123456789',
      update: {
        data: {
          name: 'New Name',
        },
      },
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case name not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const athleteRepository: AthleteInMemoryRepository = new AthleteInMemoryRepository();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);

    const getTeamsListUseCase: GetTeamsList = new GetTeamsList(teamRepository);
    const getTeamsListOutput: GetTeamsListOutputDto = await getTeamsListUseCase.execute();
    expect(getTeamsListOutput.isRight()).toBe(true);
    const teamsDtoList: TeamDto[] = getTeamsListOutput.value as TeamDto[];
    expect(Array.isArray(teamsDtoList)).toBe(true);
    expect(teamsDtoList.length).toBe(1);
    const teamDto: TeamDto = teamsDtoList[0];

    const importAthleteUseCase: ImportAthlete = new ImportAthlete(
      athleteRepository,
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthleteOutput: ImportAthleteOutputDto = await importAthleteUseCase.execute({
      leagueId: leagueDto.id,
      teamId: teamDto.id,
      athleteRefId: 'sport_feed_athlete_1',
    });
    expect(importAthleteOutput.isRight()).toBe(true);

    const getAthletesListUseCase: GetAthletesList = new GetAthletesList(athleteRepository);
    const getAthletesListOutput: GetAthletesListOutputDto = await getAthletesListUseCase.execute();
    expect(getAthletesListOutput.isRight()).toBe(true);
    const athletesDtoList: AthleteDto[] = getAthletesListOutput.value as AthleteDto[];
    expect(Array.isArray(athletesDtoList)).toBe(true);
    expect(athletesDtoList.length).toBe(1);
    const athleteDto: AthleteDto = athletesDtoList[0];

    const updateAthleteUseCase: UpdateAthlete = new UpdateAthlete(athleteRepository);
    const newName: string = '1';
    const updateAthleteOutput: UpdateAthleteOutputDto = await updateAthleteUseCase.execute({
      athleteId: athleteDto.id,
      update: {
        data: {
          name: newName,
        },
      },
    });
    expect(updateAthleteOutput.isLeft()).toBe(true);
    const errorData: DtoValidationApplicationError =
      updateAthleteOutput.value as DtoValidationApplicationError;
    expect(Array.isArray(errorData.errors)).toBe(true);
    expect(errorData.errors?.length).toBe(1);
    expect(errorData.errors![0].type).toBe(ValidationType.MinLength);
  });
});
