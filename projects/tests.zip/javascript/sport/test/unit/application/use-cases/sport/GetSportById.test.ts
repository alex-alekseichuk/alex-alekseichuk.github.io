import {
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  SportDto
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateSport,
  CreateSportOutputDto,
  GetSportById,
  GetSportByIdOutputDto
} from '../../../../../src/application';
import { EntityPrefix, SportProps } from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

describe('GetSportByIdUseCase', () => {
  test('should get entity by id from repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createUseCase: CreateSport = new CreateSport(repository, queue);
    const createOutput: CreateSportOutputDto = await createUseCase.execute(SPORT_PROPS);
    expect(createOutput.isRight()).toBe(true);

    const getByIdUseCase: GetSportById = new GetSportById(repository);
    const getByIdOutput: GetSportByIdOutputDto = await getByIdUseCase.execute(SPORT_PROPS.id);
    expect(getByIdOutput.isRight()).toBe(true);
    const dto: SportDto = getByIdOutput.value as SportDto;
    expect(dto.id).toBe(SPORT_PROPS.id);
  });

  test('should return error in case id not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const useCase: GetSportById = new GetSportById(repository);

    const output: GetSportByIdOutputDto = await useCase.execute(111 as any);
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case entity not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const useCase: GetSportById = new GetSportById(repository);

    const output: GetSportByIdOutputDto = await useCase.execute('123456789');
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });
});
