import { describe, expect, test } from '@jest/globals';
import {
  DataNotFoundGatewayError,
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter,
  QueueCallbackType,
  TeamDto
} from 'core';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID,
  GetTeamsList,
  GetTeamsListOutputDto,
  ImportAthletes,
  ImportAthletesOutputDto,
  ImportTeam,
  ImportTeamOutputDto,
  SportFeedHistoryGatewayFactory
} from '../../../../../src/application';
import {
  EntityPrefix,
  ImportAthleteEvent,
  LeagueProps,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  ImportingInMemoryGateway,
  LeagueInMemoryRepository,
  SportFeedHistoryGatewayFactoryImpl,
  SportInMemoryRepository,
  TeamInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerSportFeed',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: 'sport_feed_league_epl',
};

describe('ImportAthletesUseCase', () => {
  test('should import athletes', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);

    const getTeamsListUseCase: GetTeamsList = new GetTeamsList(teamRepository);
    const getTeamsListOutput: GetTeamsListOutputDto = await getTeamsListUseCase.execute();
    expect(getTeamsListOutput.isRight()).toBe(true);
    const teamsDtoList: TeamDto[] = getTeamsListOutput.value as TeamDto[];
    expect(Array.isArray(teamsDtoList)).toBe(true);
    expect(teamsDtoList.length).toBe(1);
    const teamDto: TeamDto = teamsDtoList[0];

    const importAthletesUseCase: ImportAthletes = new ImportAthletes(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthletesOutput: ImportAthletesOutputDto = await importAthletesUseCase.execute({
      leagueId: leagueDto.id,
      teamId: teamDto.id,
    });
    expect(importAthletesOutput.isRight()).toBe(true);
  });

  test('should trigger import event in queue', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const callbackData: { callback: QueueCallbackType } = {
      callback: () => {},
    };
    const spy: jest.SpyInstance = jest.spyOn(callbackData, 'callback');
    queue.consume(ImportAthleteEvent.name, callbackData.callback);

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);

    const getTeamsListUseCase: GetTeamsList = new GetTeamsList(teamRepository);
    const getTeamsListOutput: GetTeamsListOutputDto = await getTeamsListUseCase.execute();
    expect(getTeamsListOutput.isRight()).toBe(true);
    const teamsDtoList: TeamDto[] = getTeamsListOutput.value as TeamDto[];
    expect(Array.isArray(teamsDtoList)).toBe(true);
    expect(teamsDtoList.length).toBe(1);
    const teamDto: TeamDto = teamsDtoList[0];

    const importAthletesUseCase: ImportAthletes = new ImportAthletes(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthletesOutput: ImportAthletesOutputDto = await importAthletesUseCase.execute({
      leagueId: leagueDto.id,
      teamId: teamDto.id,
    });
    expect(importAthletesOutput.isRight()).toBe(true);

    expect(spy).toHaveBeenCalled();
  });

  test('should return error in case leagueId not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importAthletesUseCase: ImportAthletes = new ImportAthletes(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthletesOutput: ImportAthletesOutputDto = await importAthletesUseCase.execute({
      leagueId: 123 as any,
      teamId: '123456789',
    });
    expect(importAthletesOutput.isLeft()).toBe(true);
    expect(importAthletesOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case league not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importAthletesUseCase: ImportAthletes = new ImportAthletes(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthletesOutput: ImportAthletesOutputDto = await importAthletesUseCase.execute({
      leagueId: '123456789',
      teamId: '123456789',
    });
    expect(importAthletesOutput.isLeft()).toBe(true);
    expect(importAthletesOutput.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case teamId not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importAthletesUseCase: ImportAthletes = new ImportAthletes(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthletesOutput: ImportAthletesOutputDto = await importAthletesUseCase.execute({
      leagueId: leagueDto.id,
      teamId: 123 as any,
    });
    expect(importAthletesOutput.isLeft()).toBe(true);
    expect(importAthletesOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case team not exists', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importAthletesUseCase: ImportAthletes = new ImportAthletes(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importAthletesOutput: ImportAthletesOutputDto = await importAthletesUseCase.execute({
      leagueId: leagueDto.id,
      teamId: '123456789',
    });
    expect(importAthletesOutput.isLeft()).toBe(true);
    expect(importAthletesOutput.value).toBeInstanceOf(DataNotFoundGatewayError);
  });
});
