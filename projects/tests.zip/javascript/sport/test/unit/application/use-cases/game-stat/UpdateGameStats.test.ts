import {
  DtoValidationApplicationError,
  EntityNotFoundDomainError,
  EntityNotFoundRepositoryError,
  GameStatDto,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateGameStat,
  CreateGameStatOutputDto,
  CreateSport,
  CreateSportOutputDto,
  UpdateGameStats,
  UpdateGameStatsOutputDto
} from '../../../../../src/application';
import { EntityPrefix, GameStatProps, SportProps } from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

describe('UpdateGameStatsUseCase', () => {
  test('should update entities in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);
    const dto: GameStatDto = createGameStatOutput.value as GameStatDto;

    const updateGameStatsUseCase: UpdateGameStats = new UpdateGameStats(repository);
    const newName: string = 'New Name';
    const updateGameStatsOutput: UpdateGameStatsOutputDto = await updateGameStatsUseCase.execute({
      sportId: SPORT_PROPS.id,
      updates: [
        {
          gameStatId: dto.id,
          data: {
            name: newName,
          },
        },
      ],
    });
    expect(updateGameStatsOutput.isRight()).toBe(true);
    const dtoList: GameStatDto[] = updateGameStatsOutput.value as GameStatDto[];
    expect(Array.isArray(dtoList)).toBe(true);
    expect(dtoList.length).toBe(1);
    expect(dtoList[0].name).toBe(newName);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: UpdateGameStats = new UpdateGameStats(repository);
    const output: UpdateGameStatsOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      updates: [
        {
          gameStatId: '1234567',
          data: {
            name: GAME_STAT_PROPS.name,
          },
        },
      ],
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case entity not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const updateGameStatsUseCase: UpdateGameStats = new UpdateGameStats(repository);
    const updateGameStatsOutput: UpdateGameStatsOutputDto = await updateGameStatsUseCase.execute({
      sportId: SPORT_PROPS.id,
      updates: [
        {
          gameStatId: '1234567',
          data: {
            name: GAME_STAT_PROPS.name,
          },
        },
      ],
    });
    expect(updateGameStatsOutput.isLeft()).toBe(true);
    expect(updateGameStatsOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case name is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);
    const dto: GameStatDto = createGameStatOutput.value as GameStatDto;

    const updateGameStatsUseCase: UpdateGameStats = new UpdateGameStats(repository);
    const updateGameStatsOutput: UpdateGameStatsOutputDto = await updateGameStatsUseCase.execute({
      sportId: SPORT_PROPS.id,
      updates: [
        {
          gameStatId: dto.id,
          data: {
            name: '1',
          },
        },
      ],
    });
    expect(updateGameStatsOutput.isLeft()).toBe(true);
    expect(updateGameStatsOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });
});
