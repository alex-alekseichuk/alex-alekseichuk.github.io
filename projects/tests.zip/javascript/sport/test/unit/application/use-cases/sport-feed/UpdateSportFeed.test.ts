import {
  DtoValidationApplicationError,
  EntityNotFoundDomainError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  SportFeedAthleteAttributeDto,
  SportFeedDto,
  SportFeedGameStatDto
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateAthleteAttribute,
  CreateAthleteAttributeOutputDto,
  CreateGameStat,
  CreateGameStatOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedAthleteAttribute,
  CreateSportFeedAthleteAttributeOutputDto,
  CreateSportFeedGameStat,
  CreateSportFeedGameStatOutputDto,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  UpdateSportFeed,
  UpdateSportFeedOutputDto
} from '../../../../../src/application';
import {
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  GameStatProps,
  SportFeedAthleteAttributeProps,
  SportFeedGameStatProps,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

const SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS: SportFeedAthleteAttributeProps = {
  athleteAttributeId: ATHLETE_ATTRIBUTE_PROPS.id,
  enabled: true,
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

const SPORT_FEED_GAME_STAT_PROPS: SportFeedGameStatProps = {
  gameStatId: GAME_STAT_PROPS.id!,
  enabled: true,
  weight: 1,
};

describe('UpdateSportFeedUseCase', () => {
  test('should update entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    let dto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const newName: string = 'New Name';
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: dto.id,
      update: {
        data: {
          name: newName,
        },
      },
    });
    expect(updateSportFeedOutput.isRight()).toBe(true);
    dto = updateSportFeedOutput.value as SportFeedDto;
    expect(dto.name).toBe(newName);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const useCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const output: UpdateSportFeedOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: '1234567',
      update: {
        data: {
          name: SPORT_FEED_PROPS.name,
        },
      },
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case entity not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: '1234567',
      update: {
        data: {
          name: SPORT_FEED_PROPS.name,
        },
      },
    });
    expect(updateSportFeedOutput.isLeft()).toBe(true);
    expect(updateSportFeedOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case name is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const dto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: dto.id,
      update: {
        data: {
          name: '1',
        },
      },
    });
    expect(updateSportFeedOutput.isLeft()).toBe(true);
    expect(updateSportFeedOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should update sport feed athlete attribute in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    let sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    const createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createSportFeedAthleteAttributeOutput.isRight()).toBe(true);
    const dto: SportFeedAthleteAttributeDto =
      createSportFeedAthleteAttributeOutput.value as SportFeedAthleteAttributeDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const newEnabled: boolean = !SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS.enabled;
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      update: {
        sportFeedAthleteAttributeUpdates: [
          {
            sportFeedAthleteAttributeId: dto.id,
            data: {
              enabled: newEnabled,
            },
          },
        ],
      },
    });
    expect(updateSportFeedOutput.isRight()).toBe(true);
    sportFeedDto = updateSportFeedOutput.value as SportFeedDto;
    expect(Array.isArray(sportFeedDto.sportFeedAthleteAttributes)).toBe(true);
    expect(sportFeedDto.sportFeedAthleteAttributes!.length).toBe(1);
    expect(sportFeedDto.sportFeedAthleteAttributes![0].enabled).toBe(newEnabled);
  });

  test('return error in case sport feed athlete attribute not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const newEnabled: boolean = !SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS.enabled;
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      update: {
        sportFeedAthleteAttributeUpdates: [
          {
            sportFeedAthleteAttributeId: '1234567',
            data: {
              enabled: newEnabled,
            },
          },
        ],
      },
    });
    expect(updateSportFeedOutput.isLeft()).toBe(true);
    expect(updateSportFeedOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case enabled field of sport feed athlete attribute not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    const createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createSportFeedAthleteAttributeOutput.isRight()).toBe(true);
    const dto: SportFeedAthleteAttributeDto =
      createSportFeedAthleteAttributeOutput.value as SportFeedAthleteAttributeDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      update: {
        sportFeedAthleteAttributeUpdates: [
          {
            sportFeedAthleteAttributeId: dto.id,
            data: {
              enabled: null as any,
            },
          },
        ],
      },
    });
    expect(updateSportFeedOutput.isLeft()).toBe(true);
    expect(updateSportFeedOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should update sport feed game stat in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    let sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_GAME_STAT_PROPS,
      });
    expect(createSportFeedGameStatOutput.isRight()).toBe(true);
    const dto: SportFeedGameStatDto = createSportFeedGameStatOutput.value as SportFeedGameStatDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const newEnabled: boolean = !SPORT_FEED_GAME_STAT_PROPS.enabled;
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      update: {
        sportFeedGameStatUpdates: [
          {
            sportFeedGameStatId: dto.id,
            data: {
              enabled: newEnabled,
            },
          },
        ],
      },
    });
    expect(updateSportFeedOutput.isRight()).toBe(true);
    sportFeedDto = updateSportFeedOutput.value as SportFeedDto;
    expect(Array.isArray(sportFeedDto.sportFeedGameStats)).toBe(true);
    expect(sportFeedDto.sportFeedGameStats!.length).toBe(1);
    expect(sportFeedDto.sportFeedGameStats![0].enabled).toBe(newEnabled);
  });

  test('return error in case sport feed game stat not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const newEnabled: boolean = !SPORT_FEED_GAME_STAT_PROPS.enabled;
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      update: {
        sportFeedGameStatUpdates: [
          {
            sportFeedGameStatId: '1234567',
            data: {
              enabled: newEnabled,
            },
          },
        ],
      },
    });
    expect(updateSportFeedOutput.isLeft()).toBe(true);
    expect(updateSportFeedOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case enabled field of sport feed game stat not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_GAME_STAT_PROPS,
      });
    expect(createSportFeedGameStatOutput.isRight()).toBe(true);
    const dto: SportFeedGameStatDto = createSportFeedGameStatOutput.value as SportFeedGameStatDto;

    const updateSportFeedUseCase: UpdateSportFeed = new UpdateSportFeed(repository, queue);
    const updateSportFeedOutput: UpdateSportFeedOutputDto = await updateSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      update: {
        sportFeedGameStatUpdates: [
          {
            sportFeedGameStatId: dto.id,
            data: {
              enabled: null as any,
            },
          },
        ],
      },
    });
    expect(updateSportFeedOutput.isLeft()).toBe(true);
    expect(updateSportFeedOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });
});
