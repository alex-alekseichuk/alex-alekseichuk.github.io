import {
  DtoValidationApplicationError,
  EntityAlreadyExistsDomainError,
  EntityNotFoundDomainError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  SportFeedAthleteAttributeDto,
  SportFeedDto
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateAthleteAttribute,
  CreateAthleteAttributeOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedAthleteAttribute,
  CreateSportFeedAthleteAttributeOutputDto,
  CreateSportFeedOutputDto,
  CreateSportOutputDto
} from '../../../../../src/application';
import {
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  SportFeedAthleteAttribute,
  SportFeedAthleteAttributeProps,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

const SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS: SportFeedAthleteAttributeProps = {
  athleteAttributeId: ATHLETE_ATTRIBUTE_PROPS.id,
  enabled: true,
};

describe('CreateSportFeedAthleteAttributeUseCase', () => {
  test('should create entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    const createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createSportFeedAthleteAttributeOutput.isRight()).toBe(true);
    const dto: SportFeedAthleteAttributeDto =
      createSportFeedAthleteAttributeOutput.value as SportFeedAthleteAttribute;

    expect(dto.athleteAttributeId).toBe(SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS.athleteAttributeId);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: CreateSportFeedAthleteAttribute = new CreateSportFeedAthleteAttribute(repository);
    const output: CreateSportFeedAthleteAttributeOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: '1234567',
      data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case sport feed not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    const createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: '1234567',
        data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createSportFeedAthleteAttributeOutput.isLeft()).toBe(true);
    expect(createSportFeedAthleteAttributeOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case athlete attribute not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    const createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createSportFeedAthleteAttributeOutput.isLeft()).toBe(true);
    expect(createSportFeedAthleteAttributeOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case enabled is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    const createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: {
          ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
          enabled: null as any,
        },
      });
    expect(createSportFeedAthleteAttributeOutput.isLeft()).toBe(true);
    expect(createSportFeedAthleteAttributeOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case entity already exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createAthleteAttributeUseCase: CreateAthleteAttribute = new CreateAthleteAttribute(repository);
    const createAthleteAttributeOutput: CreateAthleteAttributeOutputDto =
      await createAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        data: ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createAthleteAttributeOutput.isRight()).toBe(true);

    const createSportFeedAthleteAttributeUseCase: CreateSportFeedAthleteAttribute =
      new CreateSportFeedAthleteAttribute(repository);
    let createSportFeedAthleteAttributeOutput: CreateSportFeedAthleteAttributeOutputDto =
      await createSportFeedAthleteAttributeUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
      });
    expect(createSportFeedAthleteAttributeOutput.isRight()).toBe(true);
    createSportFeedAthleteAttributeOutput = await createSportFeedAthleteAttributeUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      data: SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
    });
    expect(createSportFeedAthleteAttributeOutput.isLeft()).toBe(true);
    expect(createSportFeedAthleteAttributeOutput.value).toBeInstanceOf(EntityAlreadyExistsDomainError);
  });
});
