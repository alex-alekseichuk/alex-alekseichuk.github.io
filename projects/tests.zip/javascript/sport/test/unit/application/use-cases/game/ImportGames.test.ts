import {
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueChampionshipDto,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter,
  QueueCallbackType
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID,
  ImportGames,
  ImportGamesOutputDto,
  ImportLeague,
  ImportLeagueOutputDto,
  SportFeedHistoryGatewayFactory
} from '../../../../../src/application';
import {
  EntityPrefix,
  ImportGameEvent,
  LeagueProps,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  LeagueInMemoryRepository,
  SportFeedHistoryGatewayFactoryImpl,
  SportInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerSportFeed',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: 'sport_feed_league_epl',
};

const CHAMPIONSHIPS_LIST: LeagueChampionshipDto[] = [
  {
    championshipRefId: 'sport_feed_championship_1',
    enabled: true,
    name: 'Championship 1',
    nameShort: 'Champ 1',
  },
  {
    championshipRefId: 'sport_feed_championship_2',
    enabled: true,
    name: 'Championship 2',
    nameShort: 'Champ 2',
  },
];

describe('ImportGamesUseCase', () => {
  test('should import games', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importLeagueUseCase: ImportLeague = new ImportLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importLeagueOutput: ImportLeagueOutputDto = await importLeagueUseCase.execute({
      leagueId: leagueDto.id,
      championships: CHAMPIONSHIPS_LIST,
    });
    expect(importLeagueOutput.isRight()).toBe(true);

    const importGamesUseCase: ImportGames = new ImportGames(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGamesOutput: ImportGamesOutputDto = await importGamesUseCase.execute({
      leagueId: leagueDto.id,
    });
    expect(importGamesOutput.isRight()).toBe(true);
  });

  test('should trigger import event in queue', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const callbackData: { callback: QueueCallbackType } = {
      callback: () => {},
    };
    const spy: jest.SpyInstance = jest.spyOn(callbackData, 'callback');
    queue.consume(ImportGameEvent.name, callbackData.callback);

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importLeagueUseCase: ImportLeague = new ImportLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importLeagueOutput: ImportLeagueOutputDto = await importLeagueUseCase.execute({
      leagueId: leagueDto.id,
      championships: CHAMPIONSHIPS_LIST,
    });
    expect(importLeagueOutput.isRight()).toBe(true);

    const importGamesUseCase: ImportGames = new ImportGames(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGamesOutput: ImportGamesOutputDto = await importGamesUseCase.execute({
      leagueId: leagueDto.id,
    });
    expect(importGamesOutput.isRight()).toBe(true);

    expect(spy).toHaveBeenCalled();
  });

  test('should return error in case leagueId not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importGamesUseCase: ImportGames = new ImportGames(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGamesOutput: ImportGamesOutputDto = await importGamesUseCase.execute({
      leagueId: 123 as any,
    });
    expect(importGamesOutput.isLeft()).toBe(true);
    expect(importGamesOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case league not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importGamesUseCase: ImportGames = new ImportGames(
      externalRefGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const importGamesOutput: ImportGamesOutputDto = await importGamesUseCase.execute({
      leagueId: '123456789',
    });
    expect(importGamesOutput.isLeft()).toBe(true);
    expect(importGamesOutput.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });
});
