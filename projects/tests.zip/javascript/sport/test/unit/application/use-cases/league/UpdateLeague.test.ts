import {
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter,
  ValidationType
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  UpdateLeague,
  UpdateLeagueOutputDto
} from '../../../../../src/application';
import { EntityPrefix, LeagueProps, SportFeedProps, SportProps } from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  LeagueInMemoryRepository,
  SportInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: '123456789',
};

describe('UpdateLeagueUseCase', () => {
  test('should update entity in repository', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    let dto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const updateUseCase: UpdateLeague = new UpdateLeague(externalRefGateway, leagueRepository, queue);
    const newEnabled: boolean = !LEAGUE_PROPS.enabled;
    const newName: string = 'New Name';
    const updateOutput: UpdateLeagueOutputDto = await updateUseCase.execute({
      leagueId: dto.id,
      update: {
        data: {
          enabled: newEnabled,
          name: newName,
        },
      },
    });
    expect(updateOutput.isRight()).toBe(true);
    dto = updateOutput.value as LeagueDto;
    expect(dto.enabled).toBe(newEnabled);
    expect(dto.name).toBe(newName);
  });

  test('should return error in case entity not exists in repository', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const useCase: UpdateLeague = new UpdateLeague(externalRefGateway, leagueRepository, queue);
    const output: UpdateLeagueOutputDto = await useCase.execute({
      leagueId: '123456789',
      update: {},
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case name not valid', async function () {
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    let dto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const updateLeagueUseCase: UpdateLeague = new UpdateLeague(externalRefGateway, leagueRepository, queue);
    const newName: string = '1';
    const updateOutput: UpdateLeagueOutputDto = await updateLeagueUseCase.execute({
      leagueId: dto.id,
      update: {
        data: {
          name: newName,
        },
      },
    });
    expect(updateOutput.isLeft()).toBe(true);
    expect(updateOutput.value).toBeInstanceOf(DtoValidationApplicationError);
    const errorData: DtoValidationApplicationError = updateOutput.value as DtoValidationApplicationError;
    expect(Array.isArray(errorData.errors)).toBe(true);
    expect(errorData.errors?.length).toBe(1);
    expect(errorData.errors![0].type).toBe(ValidationType.MinLength);
  });
});
