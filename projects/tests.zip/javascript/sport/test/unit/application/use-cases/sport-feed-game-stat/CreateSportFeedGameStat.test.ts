import {
  DtoValidationApplicationError,
  EntityAlreadyExistsDomainError,
  EntityNotFoundDomainError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  SportFeedDto,
  SportFeedGameStatDto
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateGameStat,
  CreateGameStatOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedGameStat,
  CreateSportFeedGameStatOutputDto,
  CreateSportFeedOutputDto,
  CreateSportOutputDto
} from '../../../../../src/application';
import {
  EntityPrefix,
  GameStatProps,
  SportFeedGameStatProps,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

const SPORT_FEED_GAME_STAT_PROPS: SportFeedGameStatProps = {
  gameStatId: GAME_STAT_PROPS.id!,
  enabled: true,
  weight: 1,
};

describe('CreateSportFeedGameStatUseCase', () => {
  test('should create entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_GAME_STAT_PROPS,
      });
    expect(createSportFeedGameStatOutput.isRight()).toBe(true);
    const dto: SportFeedGameStatDto = createSportFeedGameStatOutput.value as SportFeedGameStatDto;

    expect(dto.gameStatId).toBe(SPORT_FEED_GAME_STAT_PROPS.gameStatId);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const output: CreateSportFeedGameStatOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: '1234567',
      data: SPORT_FEED_GAME_STAT_PROPS,
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case sport feed not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: '1234567',
        data: SPORT_FEED_GAME_STAT_PROPS,
      });
    expect(createSportFeedGameStatOutput.isLeft()).toBe(true);
    expect(createSportFeedGameStatOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case game stat not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_GAME_STAT_PROPS,
      });
    expect(createSportFeedGameStatOutput.isLeft()).toBe(true);
    expect(createSportFeedGameStatOutput.value).toBeInstanceOf(EntityNotFoundDomainError);
  });

  test('should return error in case weight is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    const createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: {
          ...SPORT_FEED_GAME_STAT_PROPS,
          weight: 999999999,
        },
      });
    expect(createSportFeedGameStatOutput.isLeft()).toBe(true);
    expect(createSportFeedGameStatOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case entity already exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(repository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);
    const sportFeedDto: SportFeedDto = createSportFeedOutput.value as SportFeedDto;

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);

    const createSportFeedGameStatUseCase: CreateSportFeedGameStat = new CreateSportFeedGameStat(repository);
    let createSportFeedGameStatOutput: CreateSportFeedGameStatOutputDto =
      await createSportFeedGameStatUseCase.execute({
        sportId: SPORT_PROPS.id,
        sportFeedId: sportFeedDto.id,
        data: SPORT_FEED_GAME_STAT_PROPS,
      });
    expect(createSportFeedGameStatOutput.isRight()).toBe(true);
    createSportFeedGameStatOutput = await createSportFeedGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: sportFeedDto.id,
      data: SPORT_FEED_GAME_STAT_PROPS,
    });
    expect(createSportFeedGameStatOutput.isLeft()).toBe(true);
    expect(createSportFeedGameStatOutput.value).toBeInstanceOf(EntityAlreadyExistsDomainError);
  });
});
