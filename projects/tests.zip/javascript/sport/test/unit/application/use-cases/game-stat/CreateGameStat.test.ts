import {
  DtoValidationApplicationError,
  EntityAlreadyExistsDomainError,
  EntityNotFoundRepositoryError,
  EntityValidationDomainError,
  GameStatDto,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateGameStat,
  CreateGameStatOutputDto,
  CreateSport,
  CreateSportOutputDto
} from '../../../../../src/application';
import { EntityPrefix, GameStatProps, SportProps } from '../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

describe('CreateGameStatUseCase', () => {
  test('should create entity in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);
    const dto: GameStatDto = createGameStatOutput.value as GameStatDto;
    expect(dto.name).toBe(GAME_STAT_PROPS.name);
  });

  test('should return error in case sport not exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: CreateGameStat = new CreateGameStat(repository);
    const output: CreateGameStatOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case name is not valid', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    const createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: {
        ...GAME_STAT_PROPS,
        name: '1',
      },
    });
    expect(createGameStatOutput.isLeft()).toBe(true);
    expect(createGameStatOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case entitity already exists in repository', async function () {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(repository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createGameStatUseCase: CreateGameStat = new CreateGameStat(repository);
    let createGameStatOutput: CreateGameStatOutputDto = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isRight()).toBe(true);
    createGameStatOutput = await createGameStatUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: GAME_STAT_PROPS,
    });
    expect(createGameStatOutput.isLeft()).toBe(true);
    expect(createGameStatOutput.value).toBeInstanceOf(EntityAlreadyExistsDomainError);
  });
});
