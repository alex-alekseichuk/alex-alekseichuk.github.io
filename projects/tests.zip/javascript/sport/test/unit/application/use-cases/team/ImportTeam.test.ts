import { describe, expect, test } from '@jest/globals';
import {
  DataNotFoundGatewayError,
  DtoValidationApplicationError,
  EntityNotFoundRepositoryError,
  getEntityId,
  LeagueDto,
  MemoryQueueAdapter,
  QueueAdapter,
  QueueCallbackType
} from 'core';
import {
  CreateLeague,
  CreateLeagueInputDto,
  CreateLeagueOutputDto,
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID,
  ImportTeam,
  ImportTeamOutputDto,
  SportFeedHistoryGatewayFactory
} from '../../../../../src/application';
import {
  EntityPrefix,
  LeagueProps,
  SportFeedProps,
  SportProps,
  TeamImportedEvent
} from '../../../../../src/domain';
import {
  ExternalRefInMemoryGateway,
  ImportingInMemoryGateway,
  LeagueInMemoryRepository,
  SportFeedHistoryGatewayFactoryImpl,
  SportInMemoryRepository,
  TeamInMemoryRepository
} from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerSportFeed',
};

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: SPORT_PROPS.id,
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: SPORT_FEED_PROPS.id,
  },
};

const CREATE_LEAGUE_INPUT_DTO: CreateLeagueInputDto = {
  data: LEAGUE_PROPS,
  championships: [],
  leagueRefId: 'sport_feed_league_epl',
};

describe('ImportTeamUseCase', () => {
  test('should import team', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);
  });

  test('should trigger imported event in queue', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const callbackData: { callback: QueueCallbackType } = {
      callback: () => {},
    };
    const spy: jest.SpyInstance = jest.spyOn(callbackData, 'callback');
    queue.consume(TeamImportedEvent.name, callbackData.callback);

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isRight()).toBe(true);

    expect(spy).toHaveBeenCalled();
  });

  test('should return error in case leagueId not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: 123 as any,
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isLeft()).toBe(true);
    expect(importTeamOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case league not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: '123456789',
      teamRefId: 'sport_feed_team_1',
    });
    expect(importTeamOutput.isLeft()).toBe(true);
    expect(importTeamOutput.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error in case teamRefId not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: '123456789',
      teamRefId: 123 as any,
    });
    expect(importTeamOutput.isLeft()).toBe(true);
    expect(importTeamOutput.value).toBeInstanceOf(DtoValidationApplicationError);
  });

  test('should return error in case team not exists', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const externalRefGateway: ExternalRefInMemoryGateway = new ExternalRefInMemoryGateway();
    const importingGateway: ImportingInMemoryGateway = new ImportingInMemoryGateway();
    const leagueRepository: LeagueInMemoryRepository = new LeagueInMemoryRepository();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const teamRepository: TeamInMemoryRepository = new TeamInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const createLeagueUseCase: CreateLeague = new CreateLeague(
      externalRefGateway,
      leagueRepository,
      queue,
      sportRepository
    );
    const createLeagueOutput: CreateLeagueOutputDto = await createLeagueUseCase.execute(
      CREATE_LEAGUE_INPUT_DTO
    );
    expect(createLeagueOutput.isRight()).toBe(true);
    const leagueDto: LeagueDto = createLeagueOutput.value as LeagueDto;

    const importTeamUseCase: ImportTeam = new ImportTeam(
      externalRefGateway,
      importingGateway,
      leagueRepository,
      queue,
      sportFeedHistoryGatewayFactory,
      sportRepository,
      teamRepository
    );
    const importTeamOutput: ImportTeamOutputDto = await importTeamUseCase.execute({
      leagueId: leagueDto.id,
      teamRefId: '123456789',
    });
    expect(importTeamOutput.isLeft()).toBe(true);
    expect(importTeamOutput.value).toBeInstanceOf(DataNotFoundGatewayError);
  });
});
