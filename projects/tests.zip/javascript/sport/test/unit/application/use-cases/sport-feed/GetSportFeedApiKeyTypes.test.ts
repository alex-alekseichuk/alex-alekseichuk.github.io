import {
  EntityNotFoundDomainError,
  EntityNotFoundRepositoryError,
  getEntityId,
  MemoryQueueAdapter,
  QueueAdapter,
  SportFeedApiKeyTypeDetailsDto
} from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  CreateSport,
  CreateSportFeed,
  CreateSportFeedOutputDto,
  CreateSportOutputDto,
  FAKE_SOCCER_SPORT_FEED_ID,
  GetSportFeedApiKeyTypes,
  GetSportFeedApiKeyTypesOutputDto,
  SportFeedHistoryGatewayFactory
} from '../../../../../src/application';
import { EntityPrefix, SportFeedProps, SportProps } from '../../../../../src/domain';
import { SportFeedHistoryGatewayFactoryImpl, SportInMemoryRepository } from '../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: FAKE_SOCCER_SPORT_FEED_ID,
  name: 'FakeSoccerFeed',
};

describe('GetSportFeedApiKeyTypes', () => {
  test('should get api key types by sport feed', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const useCase: GetSportFeedApiKeyTypes = new GetSportFeedApiKeyTypes(
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const output: GetSportFeedApiKeyTypesOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: SPORT_FEED_PROPS.id,
    });
    expect(output.isRight()).toBe(true);
    const apiKeyTypes: SportFeedApiKeyTypeDetailsDto[] = output.value as SportFeedApiKeyTypeDetailsDto[];
    expect(Array.isArray(apiKeyTypes)).toBe(true);
    expect(apiKeyTypes.length).toBeGreaterThan(0);
  });

  test('should return error if sport not exists in repository', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();

    const useCase: GetSportFeedApiKeyTypes = new GetSportFeedApiKeyTypes(
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const output: GetSportFeedApiKeyTypesOutputDto = await useCase.execute({
      sportId: '123456789',
      sportFeedId: '123456789',
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should return error if sport feed id is not valid', async function () {
    const sportFeedHistoryGatewayFactory: SportFeedHistoryGatewayFactory =
      new SportFeedHistoryGatewayFactoryImpl();
    const sportRepository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue: QueueAdapter = new MemoryQueueAdapter();

    const createSportUseCase: CreateSport = new CreateSport(sportRepository, queue);
    const createSportOutput: CreateSportOutputDto = await createSportUseCase.execute(SPORT_PROPS);
    expect(createSportOutput.isRight()).toBe(true);

    const createSportFeedUseCase: CreateSportFeed = new CreateSportFeed(sportRepository);
    const createSportFeedOutput: CreateSportFeedOutputDto = await createSportFeedUseCase.execute({
      sportId: SPORT_PROPS.id,
      data: SPORT_FEED_PROPS,
    });
    expect(createSportFeedOutput.isRight()).toBe(true);

    const useCase: GetSportFeedApiKeyTypes = new GetSportFeedApiKeyTypes(
      sportFeedHistoryGatewayFactory,
      sportRepository
    );
    const output: GetSportFeedApiKeyTypesOutputDto = await useCase.execute({
      sportId: SPORT_PROPS.id,
      sportFeedId: '123456789',
    });
    expect(output.isLeft()).toBe(true);
    expect(output.value).toBeInstanceOf(EntityNotFoundDomainError);
  });
});
