import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { GameAthlete, GameAthleteProps } from '../../../../../src/domain';

const GAME_ATHLETE_PROPS: GameAthleteProps = {
  athleteId: '123456789',
  position: 'center',
};

describe('GameAthlete', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> =
      GameAthlete.create(GAME_ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameAthlete = entityOrError.value as GameAthlete;
    expect(entity.athleteId).toBe(GAME_ATHLETE_PROPS.athleteId);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if athleteId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      athleteId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if athleteId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      athleteId: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if athleteId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      athleteId: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if athleteId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      athleteId:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if position is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      position: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if position is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      position: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if position is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      position:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if starter is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> = GameAthlete.create({
      ...GAME_ATHLETE_PROPS,
      starter: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> =
      GameAthlete.create(GAME_ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameAthlete = entityOrError.value as GameAthlete;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ position: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.position).toBe(newValue);
  });

  test('should return an error from update if position not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, GameAthlete> =
      GameAthlete.create(GAME_ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameAthlete = entityOrError.value as GameAthlete;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ position: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
