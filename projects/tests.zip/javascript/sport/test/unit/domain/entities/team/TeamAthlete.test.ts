import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { TeamAthlete, TeamAthleteProps, TeamAthleteStatus } from '../../../../../src/domain';

const TEAM_ATHLETE_PROPS: TeamAthleteProps = {
  athleteId: '123456789',
  avatar: 'https://website.com/1.png',
  default: true,
  status: TeamAthleteStatus.Active,
};

describe('TeamAthlete', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> =
      TeamAthlete.create(TEAM_ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: TeamAthlete = entityOrError.value as TeamAthlete;
    expect(entity.athleteId).toBe(TEAM_ATHLETE_PROPS.athleteId);
    expect(entity.avatar).toBe(TEAM_ATHLETE_PROPS.avatar);
    expect(entity.default).toBe(TEAM_ATHLETE_PROPS.default);
    expect(entity.status).toBe(TEAM_ATHLETE_PROPS.status);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if athleteId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      athleteId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if athleteId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      athleteId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if athleteId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      athleteId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if athleteId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      athleteId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if default not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      default: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if default is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      default: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should return an error if status not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      status: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if status is not enum', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> = TeamAthlete.create({
      ...TEAM_ATHLETE_PROPS,
      status: '123123123' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> =
      TeamAthlete.create(TEAM_ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: TeamAthlete = entityOrError.value as TeamAthlete;
    const newValue: TeamAthleteStatus = TeamAthleteStatus.NotActive;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ status: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.status).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, TeamAthlete> =
      TeamAthlete.create(TEAM_ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: TeamAthlete = entityOrError.value as TeamAthlete;
    const newValue: TeamAthleteStatus = '1' as TeamAthleteStatus;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ status: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });
});
