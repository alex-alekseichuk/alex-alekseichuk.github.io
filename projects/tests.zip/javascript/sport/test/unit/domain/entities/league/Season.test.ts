import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  Championship,
  ChampionshipProps,
  ChampionshipStatus,
  Season,
  SeasonProps,
  SeasonStatus
} from '../../../../../src/domain';

const SEASON_PROPS: SeasonProps = {
  endDate: new Date(2023, 6, 30),
  name: 'EPL Season 2022/2023',
  startDate: new Date(2022, 9, 1),
  status: SeasonStatus.InProgress,
  year: 2022,
};

const CHAMPIONSHIP_PROPS: ChampionshipProps = {
  enabled: true,
  endDate: new Date(2023, 6, 30),
  name: 'EPL Championship 2022/2023',
  nameShort: 'EPL 22/23',
  repeated: false,
  startDate: new Date(2022, 9, 1),
  status: ChampionshipStatus.InProgress,
};

describe('Season', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create(SEASON_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Season = entityOrError.value as Season;
    expect(entity.endDate).toBe(SEASON_PROPS.endDate);
    expect(entity.name).toBe(SEASON_PROPS.name);
    expect(entity.startDate).toBe(SEASON_PROPS.startDate);
    expect(entity.status).toBe(SEASON_PROPS.status);
    expect(entity.year).toBe(SEASON_PROPS.year);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if year not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      year: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if year is not number', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      year: '1992' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsNumber);
  });

  test('should return an error if status not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      status: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if status is not enum', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      status: '123123123' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });

  test('should return an error if startDate not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      startDate: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if startDate is not date', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      startDate: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsDate);
  });

  test('should return an error if endDate not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      endDate: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if endDate is not date', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create({
      ...SEASON_PROPS,
      endDate: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsDate);
  });

  test('should allow to add championship', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create(SEASON_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Season = entityOrError.value as Season;
    const championshipOrError: Either<EntityValidationDomainError, Championship> =
      Championship.create(CHAMPIONSHIP_PROPS);
    expect(championshipOrError.isRight()).toBe(true);
    const championship: Championship = championshipOrError.value as Championship;
    entity.addChampionship(championship);
    expect(entity.championships).toBeDefined();
    expect(entity.championships.length).toEqual(1);
    expect(entity.championships[0]).toEqual(championship);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create(SEASON_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Season = entityOrError.value as Season;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, Season> = Season.create(SEASON_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Season = entityOrError.value as Season;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
