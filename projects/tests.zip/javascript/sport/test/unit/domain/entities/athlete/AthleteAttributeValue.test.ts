import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { AthleteAttributeValue, AthleteAttributeValueProps } from '../../../../../src/domain';

const ATHLETE_ATTRIBUTE_VALUE_PROPS: AthleteAttributeValueProps = {
  athleteAttributeId: '123456789',
  value: 'Right',
};

describe('AthleteAttributeValue', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create(ATHLETE_ATTRIBUTE_VALUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: AthleteAttributeValue = entityOrError.value as AthleteAttributeValue;
    expect(entity.athleteAttributeId).toBe(ATHLETE_ATTRIBUTE_VALUE_PROPS.athleteAttributeId);
    expect(entity.value).toBe(ATHLETE_ATTRIBUTE_VALUE_PROPS.value);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        id: 123456 as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        id: '123456',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if athleteAttributeId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        athleteAttributeId: null as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if athleteAttributeId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        athleteAttributeId: 123 as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if athleteAttributeId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        athleteAttributeId: '12',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if athleteAttributeId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        athleteAttributeId:
          'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if value not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        value: null as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if value is not number or string', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create({
        ...ATHLETE_ATTRIBUTE_VALUE_PROPS,
        value: (() => {}) as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.HasType);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create(ATHLETE_ATTRIBUTE_VALUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: AthleteAttributeValue = entityOrError.value as AthleteAttributeValue;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ value: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.value).toBe(newValue);
  });

  test('should return an error from update if value not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create(ATHLETE_ATTRIBUTE_VALUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: AthleteAttributeValue = entityOrError.value as AthleteAttributeValue;
    const newValue: string = (() => {}) as any;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ value: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.HasType);
  });
});
