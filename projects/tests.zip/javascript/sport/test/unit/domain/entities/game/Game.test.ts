import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { Game, GameProps, GameStatus, GameTeam, GameTeamProps } from '../../../../../src/domain';

const GAME_PROPS: GameProps = {
  championshipId: '123456789',
  endDateTime: new Date('2022-12-09T10:00:00.000Z'),
  leagueId: '123456789',
  name: 'Arsenal vs Chelsea',
  nameShort: 'ARS vs CHE',
  seasonId: '123456789',
  sportId: '123456789',
  startDateTime: new Date('2022-12-09T08:00:00.000Z'),
  status: GameStatus.Closed,
};

const GAME_TEAM_PROPS: GameTeamProps = {
  teamId: '123456789',
};

describe('Game', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create(GAME_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Game = entityOrError.value as Game;
    expect(entity.championshipId).toBe(GAME_PROPS.championshipId);
    expect(entity.endDateTime).toBe(GAME_PROPS.endDateTime);
    expect(entity.name).toBe(GAME_PROPS.name);
    expect(entity.nameShort).toBe(GAME_PROPS.nameShort);
    expect(entity.startDateTime).toBe(GAME_PROPS.startDateTime);
    expect(entity.status).toBe(GAME_PROPS.status);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if championshipId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      championshipId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if championshipId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      championshipId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if championshipId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      championshipId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if championshipId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      championshipId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if endDateTime is not date', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      endDateTime: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsDate);
  });

  test('should return an error if leagueId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      leagueId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if leagueId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      leagueId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if leagueId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      leagueId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if leagueId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      leagueId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if nameShort not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      nameShort: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if nameShort is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      nameShort: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if nameShort is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      nameShort: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if nameShort is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      nameShort:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if seasonId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      seasonId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if seasonId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      seasonId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if seasonId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      seasonId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if seasonId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      seasonId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if sportId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      sportId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if leagueId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      sportId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if leagueId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      sportId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if leagueId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      sportId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if startDateTime not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      startDateTime: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if startDateTime is not date', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      startDateTime: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsDate);
  });

  test('should return an error if status not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      status: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if status is not enum', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create({
      ...GAME_PROPS,
      status: '123' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });

  test('should allow to add game team', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create(GAME_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Game = entityOrError.value as Game;
    const gameTeamOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create(GAME_TEAM_PROPS);
    expect(gameTeamOrError.isRight()).toBe(true);
    const gameTeam: GameTeam = gameTeamOrError.value as GameTeam;
    entity.addGameTeam(gameTeam);
    expect(entity.gameTeams).toBeDefined();
    expect(entity.gameTeams.length).toEqual(1);
    expect(entity.gameTeams[0]).toEqual(gameTeam);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create(GAME_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Game = entityOrError.value as Game;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if name not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, Game> = Game.create(GAME_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Game = entityOrError.value as Game;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
