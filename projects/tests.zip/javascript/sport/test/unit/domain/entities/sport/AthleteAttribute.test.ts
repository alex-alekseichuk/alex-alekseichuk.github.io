import { Either, EntityValidationDomainError, getEntityId, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  AthleteAttribute,
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix
} from '../../../../../src/domain';

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

describe('AthleteAttribute', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> =
      AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: AthleteAttribute = entityOrError.value as AthleteAttribute;
    expect(entity.id).toBe(ATHLETE_ATTRIBUTE_PROPS.id);
    expect(entity.dataFormat).toBe(ATHLETE_ATTRIBUTE_PROPS.dataFormat);
    expect(entity.name).toBe(ATHLETE_ATTRIBUTE_PROPS.name);
  });

  test('should return an error if id not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      id: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if data format not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      dataFormat: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if data format is not from enum', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      dataFormat: '123' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not string', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> = AthleteAttribute.create({
      ...ATHLETE_ATTRIBUTE_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> =
      AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: AthleteAttribute = entityOrError.value as AthleteAttribute;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, AthleteAttribute> =
      AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: AthleteAttribute = entityOrError.value as AthleteAttribute;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
