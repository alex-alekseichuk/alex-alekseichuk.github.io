import { Either, EntityValidationDomainError, getEntityId, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  AthleteAttribute,
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  GameStat,
  GameStatProps,
  Sport,
  SportFeed,
  SportFeedProps,
  SportProps
} from '../../../../../src/domain';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Soccer',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

describe('Sport', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Sport = entityOrError.value as Sport;
    expect(entity.id).toBe(SPORT_PROPS.id);
    expect(entity.enabled).toBe(SPORT_PROPS.enabled);
    expect(entity.name).toBe(SPORT_PROPS.name);
  });

  test('should return an error if id not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      id: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if enabled not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      enabled: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if enabled is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      enabled: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should return an error if gameAthletePositions not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      gameAthletePositions: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if gameAthletePositions is not array', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      gameAthletePositions: 123 as any,
    });
    
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsArray);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not string', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create({
      ...SPORT_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should allow to add athlete attribute', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Sport = entityOrError.value as Sport;
    const athleteAttributeOrError: Either<EntityValidationDomainError, AthleteAttribute> =
      AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(athleteAttributeOrError.isRight()).toBe(true);
    const athleteAttribute: AthleteAttribute = athleteAttributeOrError.value as AthleteAttribute;
    entity.addAthleteAttribute(athleteAttribute);
    expect(entity.athleteAttributes).toBeDefined();
    expect(entity.athleteAttributes.length).toEqual(1);
    expect(entity.athleteAttributes[0]).toEqual(athleteAttribute);
  });

  test('should allow to add game stat', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Sport = entityOrError.value as Sport;
    const gameStatOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create(GAME_STAT_PROPS);
    expect(gameStatOrError.isRight()).toBe(true);
    const gameStat: GameStat = gameStatOrError.value as GameStat;
    entity.addGameStat(gameStat);
    expect(entity.gameStats).toBeDefined();
    expect(entity.gameStats.length).toEqual(1);
    expect(entity.gameStats[0]).toEqual(gameStat);
  });

  test('should allow to add sport feed', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Sport = entityOrError.value as Sport;
    const sportFeedOrError: Either<EntityValidationDomainError, SportFeed> =
      SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);
    const sportFeed: SportFeed = sportFeedOrError.value as SportFeed;
    entity.addSportFeed(sportFeed);
    expect(entity.sportFeeds).toBeDefined();
    expect(entity.sportFeeds.length).toEqual(1);
    expect(entity.sportFeeds[0]).toEqual(sportFeed);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Sport = entityOrError.value as Sport;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, Sport> = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Sport = entityOrError.value as Sport;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
