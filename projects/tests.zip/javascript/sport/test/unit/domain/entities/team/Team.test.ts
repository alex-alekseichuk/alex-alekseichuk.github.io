import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { Team, TeamAthlete, TeamAthleteProps, TeamAthleteStatus, TeamProps } from '../../../../../src/domain';

const TEAM_PROPS: TeamProps = {
  alias: 'ARS',
  avatar: 'https://someurl.com/avatar.png',
  leagueId: '123456789',
  market: 'Los Angeles',
  name: 'Arsenal FC',
  nameShort: 'Arsenal',
  sportId: '123456789',
};

const TEAM_ATHLETE_PROPS: TeamAthleteProps = {
  athleteId: '123456789',
  avatar: 'https://website.com/1.png',
  default: true,
  status: TeamAthleteStatus.Active,
};

describe('Team', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create(TEAM_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Team = entityOrError.value as Team;
    expect(entity.alias).toBe(TEAM_PROPS.alias);
    expect(entity.avatar).toBe(TEAM_PROPS.avatar);
    expect(entity.leagueId).toBe(TEAM_PROPS.leagueId);
    expect(entity.name).toBe(TEAM_PROPS.name);
    expect(entity.nameShort).toBe(TEAM_PROPS.nameShort);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if alias not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      alias: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if alias is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      alias: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if alias is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      alias: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if alias is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      alias:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if avatar is not url or data url', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      avatar: 'sdgsdgsdgdsgsdgdsgdsgdsg' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsUrlOrDataUrl);
  });

  test('should return an error if leagueId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      leagueId: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if leagueId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      leagueId: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if leagueId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      leagueId:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if nameShort is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      nameShort: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if nameShort is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      nameShort: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if nameShort is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      nameShort:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if sportId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      sportId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if leagueId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      sportId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if leagueId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      sportId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if leagueId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create({
      ...TEAM_PROPS,
      sportId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should allow to add team athlete', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create(TEAM_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Team = entityOrError.value as Team;
    const teamAthleteOrError: Either<EntityValidationDomainError, TeamAthlete> =
      TeamAthlete.create(TEAM_ATHLETE_PROPS);
    expect(teamAthleteOrError.isRight()).toBe(true);
    const teamAthlete: TeamAthlete = teamAthleteOrError.value as TeamAthlete;
    entity.addTeamAthlete(teamAthlete);
    expect(entity.teamAthletes).toBeDefined();
    expect(entity.teamAthletes.length).toEqual(1);
    expect(entity.teamAthletes[0]).toEqual(teamAthlete);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create(TEAM_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Team = entityOrError.value as Team;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, Team> = Team.create(TEAM_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Team = entityOrError.value as Team;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
