import { Either, EntityValidationDomainError, getEntityId, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  EntityPrefix,
  SportFeedAthleteAttribute,
  SportFeedAthleteAttributeProps
} from '../../../../../src/domain';

const SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS: SportFeedAthleteAttributeProps = {
  athleteAttributeId: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  enabled: true,
};

describe('SportFeedAthleteAttribute', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create(SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: SportFeedAthleteAttribute = entityOrError.value as SportFeedAthleteAttribute;
    expect(entity.athleteAttributeId).toBe(SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS.athleteAttributeId);
    expect(entity.enabled).toBe(SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS.enabled);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        id: '123456',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if athlete attribute id not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        athleteAttributeId: null as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if athlete attribute id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        athleteAttributeId: '12',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if athlete attribute id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        athleteAttributeId:
          'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if enabled not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        enabled: null as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if enabled is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create({
        ...SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS,
        enabled: 123 as any,
      });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create(SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: SportFeedAthleteAttribute = entityOrError.value as SportFeedAthleteAttribute;
    const newValue: boolean = false;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ enabled: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.enabled).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedAthleteAttribute> =
      SportFeedAthleteAttribute.create(SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: SportFeedAthleteAttribute = entityOrError.value as SportFeedAthleteAttribute;
    const newValue: boolean = '123' as any;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ enabled: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });
});
