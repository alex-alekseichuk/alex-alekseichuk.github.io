import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { GameAthlete, GameAthleteProps, GameTeam, GameTeamProps } from '../../../../../src/domain';

const GAME_TEAM_PROPS: GameTeamProps = {
  teamId: '123456789',
};

const GAME_ATHLETE_PROPS: GameAthleteProps = {
  athleteId: '123456789',
  position: 'center',
  starter: true,
};

describe('GameTeam', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create(GAME_TEAM_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameTeam = entityOrError.value as GameTeam;
    expect(entity.teamId).toBe(GAME_TEAM_PROPS.teamId);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create({
      ...GAME_TEAM_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create({
      ...GAME_TEAM_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create({
      ...GAME_TEAM_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if teamId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create({
      ...GAME_TEAM_PROPS,
      teamId: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if teamId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create({
      ...GAME_TEAM_PROPS,
      teamId: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if teamId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create({
      ...GAME_TEAM_PROPS,
      teamId:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should allow to add game athlete', function () {
    const entityOrError: Either<EntityValidationDomainError, GameTeam> = GameTeam.create(GAME_TEAM_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameTeam = entityOrError.value as GameTeam;
    const gameAthleteOrError: Either<EntityValidationDomainError, GameAthlete> =
      GameAthlete.create(GAME_ATHLETE_PROPS);
    expect(gameAthleteOrError.isRight()).toBe(true);
    const gameAthlete: GameAthlete = gameAthleteOrError.value as GameAthlete;
    entity.addGameAthlete(gameAthlete);
    expect(entity.gameAthletes).toBeDefined();
    expect(entity.gameAthletes.length).toEqual(1);
    expect(entity.gameAthletes[0]).toEqual(gameAthlete);
  });
});
