import { Either, EntityValidationDomainError, getEntityId, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { EntityPrefix, GameStat, GameStatProps } from '../../../../../src/domain';

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

describe('GameStat', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create(GAME_STAT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameStat = entityOrError.value as GameStat;
    expect(entity.id).toBe(GAME_STAT_PROPS.id);
    expect(entity.name).toBe(GAME_STAT_PROPS.name);
  });

  test('should return an error if id not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      id: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not string', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create({
      ...GAME_STAT_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create(GAME_STAT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameStat = entityOrError.value as GameStat;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, GameStat> = GameStat.create(GAME_STAT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: GameStat = entityOrError.value as GameStat;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
