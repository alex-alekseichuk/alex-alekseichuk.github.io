import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { Championship, ChampionshipProps, ChampionshipStatus } from '../../../../../src/domain';

const CHAMPIONSHIP_PROPS: ChampionshipProps = {
  enabled: true,
  endDate: new Date(2023, 6, 30),
  name: 'EPL Championship 2022/2023',
  nameShort: 'EPL 22/23',
  repeated: false,
  startDate: new Date(2022, 9, 1),
  status: ChampionshipStatus.InProgress,
};

describe('Championship', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> =
      Championship.create(CHAMPIONSHIP_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Championship = entityOrError.value as Championship;
    expect(entity.enabled).toBe(CHAMPIONSHIP_PROPS.enabled);
    expect(entity.endDate).toBe(CHAMPIONSHIP_PROPS.endDate);
    expect(entity.name).toBe(CHAMPIONSHIP_PROPS.name);
    expect(entity.nameShort).toBe(CHAMPIONSHIP_PROPS.nameShort);
    expect(entity.repeated).toBe(CHAMPIONSHIP_PROPS.repeated);
    expect(entity.startDate).toBe(CHAMPIONSHIP_PROPS.startDate);
    expect(entity.status).toBe(CHAMPIONSHIP_PROPS.status);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if endDate not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      endDate: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if endDate is not date', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      endDate: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsDate);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if nameShort not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      nameShort: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if nameShort is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      nameShort: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if nameShort is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      nameShort: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if nameShort is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      nameShort:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if repeated not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      repeated: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if repeated is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      repeated: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should return an error if startDate not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      startDate: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if startDate is not date', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      startDate: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsDate);
  });

  test('should return an error if status not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      status: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if status is not enum', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> = Championship.create({
      ...CHAMPIONSHIP_PROPS,
      status: '123123123' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> =
      Championship.create(CHAMPIONSHIP_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Championship = entityOrError.value as Championship;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, Championship> =
      Championship.create(CHAMPIONSHIP_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Championship = entityOrError.value as Championship;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
