import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import {
  Athlete,
  AthleteAttributeValue,
  AthleteAttributeValueProps,
  AthleteProps,
  AthleteStatus
} from '../../../../../src/domain';

const ATHLETE_PROPS: AthleteProps = {
  name: 'David Jones',
  nameShort: 'Jones D.',
  sportId: '123456789',
  status: AthleteStatus.Active,
};

const ATHLETE_ATTRIBUTE_VALUE_PROPS: AthleteAttributeValueProps = {
  athleteAttributeId: '123456789',
  value: 'Right',
};

describe('Athlete', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create(ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Athlete = entityOrError.value as Athlete;
    expect(entity.name).toBe(ATHLETE_PROPS.name);
    expect(entity.nameShort).toBe(ATHLETE_PROPS.nameShort);
    expect(entity.status).toBe(ATHLETE_PROPS.status);
  });

  test('should return an error if id is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      id: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      name: 'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if nameShort not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      nameShort: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if nameShort is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      nameShort: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if nameShort is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      nameShort: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if nameShort is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      nameShort:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if sportId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      sportId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if leagueId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      sportId: 123456 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if leagueId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      sportId: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if leagueId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      sportId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if status not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      status: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if status is not enum', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create({
      ...ATHLETE_PROPS,
      status: '123123123' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsEnum);
  });

  test('should allow to add athlete attribute values', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create(ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Athlete = entityOrError.value as Athlete;
    const championshipOrError: Either<EntityValidationDomainError, AthleteAttributeValue> =
      AthleteAttributeValue.create(ATHLETE_ATTRIBUTE_VALUE_PROPS);
    expect(championshipOrError.isRight()).toBe(true);
    const athleteAttributeValue: AthleteAttributeValue = championshipOrError.value as AthleteAttributeValue;
    entity.addAthleteAttributeValue(athleteAttributeValue);
    expect(entity.athleteAttributeValues).toBeDefined();
    expect(entity.athleteAttributeValues.length).toEqual(1);
    expect(entity.athleteAttributeValues[0]).toEqual(athleteAttributeValue);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create(ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Athlete = entityOrError.value as Athlete;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, Athlete> = Athlete.create(ATHLETE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: Athlete = entityOrError.value as Athlete;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
