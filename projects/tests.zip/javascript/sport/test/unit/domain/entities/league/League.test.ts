import { Either, EntityValidationDomainError, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { League, LeagueProps, Season, SeasonProps, SeasonStatus } from '../../../../../src/domain';

const LEAGUE_PROPS: LeagueProps = {
  avatar: 'https://images.unsplash.com/photo-1627570725892-9e5c7c240993',
  enabled: true,
  name: 'English Premier League',
  nameShort: 'EPL',
  sportId: '123456789',
  sportFeedData: {
    apiKey: '123456789',
    apiKeyType: 'production',
    rateLimitRequests: 10,
    rateLimitTimeIntervalSeconds: 1000,
    sportFeedId: '123456789',
  },
};

const SEASON_PROPS: SeasonProps = {
  endDate: new Date('2022-05-05'),
  name: 'EPL 2021/2022 Season',
  startDate: new Date('2021-10-05'),
  status: SeasonStatus.InProgress,
  year: 2022,
};

describe('League', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create(LEAGUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: League = entityOrError.value as League;
    expect(entity.enabled).toBe(LEAGUE_PROPS.enabled);
    expect(entity.name).toBe(LEAGUE_PROPS.name);
    expect(entity.sportFeedData).toBeDefined();
    expect(entity.sportFeedData.apiKey).toBe(LEAGUE_PROPS.sportFeedData.apiKey);
    expect(entity.sportFeedData.apiKeyType).toBe(LEAGUE_PROPS.sportFeedData.apiKeyType);
    expect(entity.sportId).toBe(LEAGUE_PROPS.sportId);
    expect(entity.sportFeedData.rateLimitRequests).toBe(LEAGUE_PROPS.sportFeedData.rateLimitRequests);
    expect(entity.sportFeedData.rateLimitTimeIntervalSeconds).toBe(
      LEAGUE_PROPS.sportFeedData.rateLimitTimeIntervalSeconds
    );
    expect(entity.sportFeedData.sportFeedId).toBe(LEAGUE_PROPS.sportFeedData.sportFeedId);
  });

  test('should return an error if avatar not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      avatar: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if avatar is not url or data url', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      avatar: 'sdgsdgsdgdsgsdgdsgdsgdsg' as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsUrlOrDataUrl);
  });

  test('should return an error if enabled not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      enabled: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if enabled is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      enabled: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should return an error if name not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      name: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if name is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      name: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if name is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      name: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if name is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      name: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if nameShort not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      nameShort: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if nameShort is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      nameShort: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if nameShort is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      nameShort: '1',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if nameShort is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      nameShort:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if sportId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if sportId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportId: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if sportId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportId: '123',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if sportId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportId:
        'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if apiKey not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKey: null as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if apiKey is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKey: 123 as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if apiKey is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKey: '123',
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if apiKey is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKey:
          'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if apiKeyType not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKeyType: null as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if apiKeyType is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKeyType: 123 as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if apiKeyType is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKeyType: '1' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if apiKeyType is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        apiKeyType:
          'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if rateLimitRequests is too small', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        rateLimitRequests: -999999,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Min);
  });

  test('should return an error if rateLimitRequests is not a number', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        rateLimitRequests: '123' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsNumber);
  });

  test('should return an error if rateLimitRequests is too big', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        rateLimitRequests: 999999999,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Max);
  });

  test('should return an error if rateLimitTimeIntervalSeconds is not a number', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        rateLimitTimeIntervalSeconds: '123' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsNumber);
  });

  test('should return an error if rateLimitTimeIntervalSeconds is too small', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        rateLimitTimeIntervalSeconds: -999999,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Min);
  });

  test('should return an error if rateLimitTimeIntervalSeconds is too big', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        rateLimitTimeIntervalSeconds: 999999999,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Max);
  });

  test('should return an error if sportFeedId not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        sportFeedId: null as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if sportFeedId is not a string', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        sportFeedId: 123 as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsString);
  });

  test('should return an error if sportFeedId is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        sportFeedId: '123' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if sportFeedId is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create({
      ...LEAGUE_PROPS,
      sportFeedData: {
        ...LEAGUE_PROPS.sportFeedData,
        sportFeedId:
          'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg' as any,
      },
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should allow to add season', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create(LEAGUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: League = entityOrError.value as League;
    const seasonOrError: Either<EntityValidationDomainError, Season> = Season.create(SEASON_PROPS);
    expect(seasonOrError.isRight()).toBe(true);
    const season: Season = seasonOrError.value as Season;
    entity.addSeason(season);
    expect(entity.seasons).toBeDefined();
    expect(entity.seasons.length).toEqual(1);
    expect(entity.seasons[0]).toEqual(season);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create(LEAGUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: League = entityOrError.value as League;
    const newValue: string = 'New Value';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.name).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, League> = League.create(LEAGUE_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: League = entityOrError.value as League;
    const newValue: string = '1';
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ name: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });
});
