import { Either, EntityValidationDomainError, getEntityId, ValidationType } from 'core';
import { describe, expect, test } from '@jest/globals';
import { EntityPrefix, SportFeedGameStat, SportFeedGameStatProps } from '../../../../../src/domain';

const SPORT_FEED_GAME_STAT_PROPS: SportFeedGameStatProps = {
  enabled: true,
  gameStatId: getEntityId(EntityPrefix.GameStat, 'goal'),
  weight: 1,
};

describe('SportFeedGameStat', () => {
  test('should create entity', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> =
      SportFeedGameStat.create(SPORT_FEED_GAME_STAT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: SportFeedGameStat = entityOrError.value as SportFeedGameStat;
    expect(entity.enabled).toBe(SPORT_FEED_GAME_STAT_PROPS.enabled);
    expect(entity.gameStatId).toBe(SPORT_FEED_GAME_STAT_PROPS.gameStatId);
    expect(entity.weight).toBe(SPORT_FEED_GAME_STAT_PROPS.weight);
  });

  test('should return an error if id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      id: '123456',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      id: 'dfgdfdfgdfgdfgdgdgfdgdfgdfgfdgdfgfdgdfgfgdgdfgdfgdfgdfgdfgdfgddfgdfgfdgdfgdfgdfgdfgdfgdfgfdgdfgdfgdfg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if enabled not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      enabled: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if enabled is not boolean', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      enabled: 123 as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.IsBoolean);
  });

  test('should return an error if game stat id not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      gameStatId: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if game stat id is too short', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      gameStatId: '12',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MinLength);
  });

  test('should return an error if game stat id is too long', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      gameStatId:
        'sdfgdgdsgdsgsdgdsgdsgdsgsgshdffgjfgjdgsgsgsdgdsgdsgdsgdsgdsgdsgsdgsdgdsgdsgsdgdsgdsgdsgdsgdsgdsg',
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.MaxLength);
  });

  test('should return an error if weight not provided', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      weight: null as any,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Required);
  });

  test('should return an error if weight is too small', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      weight: -999999,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Min);
  });

  test('should return an error if weight is too big', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> = SportFeedGameStat.create({
      ...SPORT_FEED_GAME_STAT_PROPS,
      weight: 999999,
    });
    expect(entityOrError.isLeft()).toBe(true);
    const error: EntityValidationDomainError = entityOrError.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Max);
  });

  test('should update entity', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> =
      SportFeedGameStat.create(SPORT_FEED_GAME_STAT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: SportFeedGameStat = entityOrError.value as SportFeedGameStat;
    const newValue: number = 15;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ weight: newValue });
    expect(updateResult.isRight()).toBe(true);
    expect(entity.weight).toBe(newValue);
  });

  test('should return an error from update if firstName not valid', function () {
    const entityOrError: Either<EntityValidationDomainError, SportFeedGameStat> =
      SportFeedGameStat.create(SPORT_FEED_GAME_STAT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    const entity: SportFeedGameStat = entityOrError.value as SportFeedGameStat;
    const newValue: number = -999999;
    const updateResult: Either<EntityValidationDomainError, void> = entity.update({ weight: newValue });
    expect(updateResult.isLeft()).toBe(true);
    const error: EntityValidationDomainError = updateResult.value as EntityValidationDomainError;
    expect(error.errors?.length).toBeGreaterThan(0);
    expect(error.errors![0].type).toBe(ValidationType.Min);
  });
});
