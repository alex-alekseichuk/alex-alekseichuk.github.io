import { EntityNotFoundRepositoryError, getEntityId } from 'core/src';
import { beforeEach, describe, expect, test } from '@jest/globals';
import 'reflect-metadata';
import { container } from 'tsyringe';
import {
  AthleteAttribute,
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  GameStat,
  GameStatProps,
  Sport,
  SportFeed,
  SportFeedAthleteAttribute,
  SportFeedAthleteAttributeProps,
  SportFeedGameStat,
  SportFeedGameStatProps,
  SportFeedProps,
  SportProps
} from '../../../../../../src/domain';
import { SportPostgresRepository } from '../../../../../../src/infra';
import setupPostgreSQL, { postgreSQLDataSource } from '../../../../../../src/main/config/postgres';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'test_soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Test Soccer',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS: SportFeedAthleteAttributeProps = {
  athleteAttributeId: ATHLETE_ATTRIBUTE_PROPS.id,
  enabled: true,
};

const SPORT_FEED_GAME_STAT_PROPS: SportFeedGameStatProps = {
  gameStatId: GAME_STAT_PROPS.id,
  enabled: true,
  weight: 1,
};

describe('SportPostgresRepository', () => {
  beforeAll(async () => {
    await setupPostgreSQL();
  });
  beforeEach(async () => {
    container.clearInstances();
  });
  afterEach(async () => {
    await postgreSQLDataSource.dropDatabase();
    await postgreSQLDataSource.synchronize();
  });

  test('should return error if no entity by id in repository', async function () {
    const repository = container.resolve(SportPostgresRepository);

    const sportOrError = await repository.getById(SPORT_PROPS.id);

    expect(sportOrError.isLeft()).toBe(true);
    expect(sportOrError.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should save Sport entities in postgres repository', async function () {
    const repository = container.resolve(SportPostgresRepository);

    const entityOrError = await Sport.create(SPORT_PROPS);
    await repository.save(entityOrError.value as Sport);
    expect(entityOrError.isRight()).toBe(true);

    await repository.save(entityOrError.value as Sport);
    const entitiesList: Sport[] = await repository.getList();

    expect(Array.isArray(entitiesList)).toBe(true);
    expect(entitiesList.length).toBe(1);
    expect(entitiesList[0].id).toBe(SPORT_PROPS.id);
  });

  test('should get entity by id from repository', async function () {
    const repository = container.resolve(SportPostgresRepository);

    const entityOrError = await Sport.create(SPORT_PROPS);
    await repository.save(entityOrError.value as Sport);
    expect(entityOrError.isRight()).toBe(true);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);
    const entity: Sport = sportOrError.value as Sport;
    expect(entity.id).toBe(SPORT_PROPS.id);
  });

  test('should get entity by id or name from repository', async function () {
    const repository = container.resolve(SportPostgresRepository);

    const entityOrError = await Sport.create(SPORT_PROPS);
    await repository.save(entityOrError.value as Sport);
    expect(entityOrError.isRight()).toBe(true);

    let sportOrError = await repository.getByIdOrName({
      id: '234',
      name: SPORT_PROPS.name,
    });
    expect(sportOrError.isRight()).toBe(true);
    let entity: Sport = sportOrError.value as Sport;
    expect(entity.id).toBe(SPORT_PROPS.id);
    sportOrError = await repository.getByIdOrName({ id: SPORT_PROPS.id, name: '123' });
    expect(sportOrError.isRight()).toBe(true);
    entity = sportOrError.value as Sport;
    expect(entity.id).toBe(SPORT_PROPS.id);
  });

  test('should update entity in repository if it already exists', async function () {
    const repository = container.resolve(SportPostgresRepository);

    let entityOrError = await Sport.create(SPORT_PROPS);

    expect(entityOrError.isRight()).toBe(true);
    await repository.save(entityOrError.value as Sport);
    const newEnabled: boolean = !SPORT_PROPS.enabled;
    const newName: string = 'New Name';
    entityOrError = Sport.create({
      id: SPORT_PROPS.id,
      enabled: newEnabled,
      gameAthletePositions: SPORT_PROPS.gameAthletePositions,
      name: newName,
    });
    expect(entityOrError.isRight()).toBe(true);
    await repository.save(entityOrError.value as Sport);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);
    const entity: Sport = sportOrError.value as Sport;
    expect(entity.enabled).toBe(newEnabled);
    expect(entity.name).toBe(newName);
  });

  test('should save athlete attribute in repository', async function () {
    const repository = container.resolve(SportPostgresRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let entity: Sport = entityOrError.value as Sport;
    const athleteAttributeOrError = AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(athleteAttributeOrError.isRight()).toBe(true);

    const athleteAttribute: AthleteAttribute = athleteAttributeOrError.value as AthleteAttribute;
    entity.addAthleteAttribute(athleteAttribute);
    await repository.save(entity);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    entity = sportOrError.value as Sport;
    expect(Array.isArray(entity.athleteAttributes)).toBe(true);
    expect(entity.athleteAttributes.length).toBe(1);
    expect(entity.athleteAttributes[0].id).toBe(athleteAttribute.id);
  });

  test('should save game stat in repository', async function () {
    const repository = container.resolve(SportPostgresRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let entity: Sport = entityOrError.value as Sport;
    const gameStatOrError = GameStat.create(GAME_STAT_PROPS);
    expect(gameStatOrError.isRight()).toBe(true);

    const gameStat: GameStat = gameStatOrError.value as GameStat;
    entity.addGameStat(gameStat);
    await repository.save(entity);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    entity = sportOrError.value as Sport;

    expect(Array.isArray(entity.gameStats)).toBe(true);
    expect(entity.gameStats.length).toBe(1);
    expect(entity.gameStats[0].id).toBe(gameStat.id);
  });

  test('should save sport feed in repository', async function () {
    const repository = container.resolve(SportPostgresRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let entity: Sport = entityOrError.value as Sport;
    const sportFeedOrError = SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);

    const sportFeed: SportFeed = sportFeedOrError.value as SportFeed;
    entity.addSportFeed(sportFeed);
    await repository.save(entity);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);
    entity = sportOrError.value as Sport;

    expect(Array.isArray(entity.sportFeeds)).toBe(true);
    expect(entity.sportFeeds.length).toBe(1);
    expect(entity.sportFeeds[0].id).toBe(sportFeed.id);
  });

  test('should save sport feed athlete attribute in repository', async function () {
    const repository = container.resolve(SportPostgresRepository);

    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let entity: Sport = entityOrError.value as Sport;

    const sportFeedOrError = SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);

    const sportFeed: SportFeed = sportFeedOrError.value as SportFeed;
    entity.addSportFeed(sportFeed);

    const athleteAttributeOrError = AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(athleteAttributeOrError.isRight()).toBe(true);

    const athleteAttribute: AthleteAttribute = athleteAttributeOrError.value as AthleteAttribute;
    entity.addAthleteAttribute(athleteAttribute);

    const sportFeedAthleteAttributeOrError = SportFeedAthleteAttribute.create(
      SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS
    );
    expect(sportFeedAthleteAttributeOrError.isRight()).toBe(true);
    const sportFeedAthleteAttribute: SportFeedAthleteAttribute =
      sportFeedAthleteAttributeOrError.value as SportFeedAthleteAttribute;
    sportFeed.addSportFeedAthleteAttribute(sportFeedAthleteAttribute);

    await repository.save(entity);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    entity = sportOrError.value as Sport;
    expect(Array.isArray(entity.sportFeeds)).toBe(true);
    expect(entity.sportFeeds.length).toBe(1);

    const sportFeedAthleteAttributes: SportFeedAthleteAttribute[] =
      entity.sportFeeds[0].sportFeedAthleteAttributes;
    expect(Array.isArray(sportFeedAthleteAttributes)).toBe(true);
    expect(sportFeedAthleteAttributes.length).toBe(1);
    expect(sportFeedAthleteAttributes[0].id).toBe(sportFeedAthleteAttribute.id);
  });

  test('should save sport feed game stat in repository', async function () {
    const repository = container.resolve(SportPostgresRepository);

    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);
    let entity: Sport = entityOrError.value as Sport;

    const sportFeedOrError = SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);
    const sportFeed: SportFeed = sportFeedOrError.value as SportFeed;
    entity.addSportFeed(sportFeed);

    const gameStatOrError = GameStat.create(GAME_STAT_PROPS);
    expect(gameStatOrError.isRight()).toBe(true);
    const gameStat: GameStat = gameStatOrError.value as GameStat;
    entity.addGameStat(gameStat);

    const sportFeedGameStatOrError = SportFeedGameStat.create(SPORT_FEED_GAME_STAT_PROPS);
    expect(sportFeedGameStatOrError.isRight()).toBe(true);
    const sportFeedGameStat: SportFeedGameStat = sportFeedGameStatOrError.value as SportFeedGameStat;
    sportFeed.addSportFeedGameStat(sportFeedGameStat);

    await repository.save(entity);

    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    entity = sportOrError.value as Sport;
    expect(Array.isArray(entity.sportFeeds)).toBe(true);
    expect(entity.sportFeeds.length).toBe(1);
    const sportFeedGameStats: SportFeedGameStat[] = entity.sportFeeds[0].sportFeedGameStats;
    expect(Array.isArray(sportFeedGameStats)).toBe(true);
    expect(sportFeedGameStats.length).toBe(1);
    expect(sportFeedGameStats[0].id).toBe(sportFeedGameStat.id);
  });
});
