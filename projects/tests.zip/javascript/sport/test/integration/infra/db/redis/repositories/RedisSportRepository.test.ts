import { EntityNotFoundRepositoryError, getEntityId } from 'core/src';
import { beforeEach, describe, expect, test } from '@jest/globals';
import 'reflect-metadata';
import { container } from 'tsyringe';
import {
  AthleteAttribute,
  AthleteAttributeDataFormat,
  AthleteAttributeProps,
  EntityPrefix,
  GameStat,
  GameStatProps,
  Sport,
  SportFeed,
  SportFeedAthleteAttribute,
  SportFeedAthleteAttributeProps,
  SportFeedGameStat,
  SportFeedGameStatProps,
  SportFeedProps,
  SportProps
} from '../../../../../../src/domain';
import { SportEntityRepository, SportRedisRepository } from '../../../../../../src/infra';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'test_soccer'),
  enabled: true,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Test Soccer',
};

const SPORT_PROPS_FOR_UPDATING: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'test_soccer'),
  enabled: false,
  gameAthletePositions: ['goalkeeper', 'forward', 'midfielder', 'defender'],
  name: 'Test Soccer Updated',
};

const ATHLETE_ATTRIBUTE_PROPS: AthleteAttributeProps = {
  id: getEntityId(EntityPrefix.AthleteAttribute, 'weight'),
  dataFormat: AthleteAttributeDataFormat.Number,
  name: 'Weight',
};

const GAME_STAT_PROPS: GameStatProps = {
  id: getEntityId(EntityPrefix.GameStat, 'goal'),
  name: 'Goal Scored',
};

const SPORT_FEED_PROPS: SportFeedProps = {
  id: getEntityId(EntityPrefix.SportFeed, 'sport_radar_soccer_v4'),
  name: 'SportRadarSoccerv4',
};

const SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS: SportFeedAthleteAttributeProps = {
  athleteAttributeId: ATHLETE_ATTRIBUTE_PROPS.id,
  enabled: true,
};

const SPORT_FEED_GAME_STAT_PROPS: SportFeedGameStatProps = {
  gameStatId: GAME_STAT_PROPS.id,
  enabled: true,
  weight: 1,
};

describe('RedisSportRepository', () => {
  beforeEach(() => {
    container.clearInstances();
  });

  test('should save Sport entities in redis repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const resolveEntityRepository = container.resolve(SportEntityRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    await repository.save(entityOrError.value as Sport);
    const entityRepository = await resolveEntityRepository.getRepository();
    const sport = await entityRepository.search().where('id').eq(SPORT_PROPS.id).return.first();
    await resolveEntityRepository.closeClient();
    expect(sport).toBeTruthy();
  });

  test('should get Sport entities by id from redis repository ', async () => {
    const repository = await container.resolve(SportRedisRepository);
    const sport = await repository.getById(SPORT_PROPS.id);
    expect(sport.isRight()).toBe(true);

    const sportValue = sport.value as Sport;
    expect(sportValue.id).toBe(SPORT_PROPS.id);
  });

  test('should get list of Sport entities from redis repository ', async () => {
    const repository = container.resolve(SportRedisRepository);
    const sports = await repository.getList();
    expect(sports[0]).toBeInstanceOf(Sport);
  });

  test('should get Sport entities by id with method getByIdOrName() from redis repository ', async () => {
    const repository = container.resolve(SportRedisRepository);
    const { id } = SPORT_PROPS;
    const sport = await repository.getByIdOrName({ id });
    expect(sport.isRight()).toBe(true);

    const sportValue = sport.value as Sport;
    expect(sportValue.id).toBe(SPORT_PROPS.id);
  });

  test('should get Sport entities by name with method getByIdOrName() from redis repository ', async () => {
    const repository = container.resolve(SportRedisRepository);
    const { name } = SPORT_PROPS;
    const sport = await repository.getByIdOrName({ name });
    expect(sport.isRight()).toBe(true);

    const sportValue = sport.value as Sport;
    expect(sportValue.name).toBe(SPORT_PROPS.name);
  });

  test('should return error if no entities by id in repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const sportOrError = await repository.getById('fakeId');

    expect(sportOrError.isLeft()).toBe(true);
    expect(sportOrError.value).toBeInstanceOf(EntityNotFoundRepositoryError);
  });

  test('should update entities in repository if it already exists', async () => {
    const repository = container.resolve(SportRedisRepository);
    let entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    await repository.save(entityOrError.value as Sport);
    entityOrError = Sport.create(SPORT_PROPS_FOR_UPDATING);
    expect(entityOrError.isRight()).toBe(true);

    await repository.save(entityOrError.value as Sport);
    const sportOrError = await repository.getById(SPORT_PROPS_FOR_UPDATING.id);
    expect(sportOrError.isRight()).toBe(true);

    const entity: Sport = sportOrError.value as Sport;
    expect(entity.enabled).toBe(SPORT_PROPS_FOR_UPDATING.enabled);
    expect(entity.name).toBe(SPORT_PROPS_FOR_UPDATING.name);
  });

  test('should save athlete attribute in repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let sport: Sport = entityOrError.value as Sport;
    const athleteAttributeOrError = AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(athleteAttributeOrError.isRight()).toBe(true);

    const athleteAttributeValue = <AthleteAttribute>athleteAttributeOrError.value;
    sport.addAthleteAttribute(athleteAttributeValue);
    await repository.save(sport);
    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    sport = <Sport>sportOrError.value;
    expect(Array.isArray(sport.athleteAttributes)).toBe(true);
    expect(sport.athleteAttributes.length).toBe(1);

    const athleteAttribute = JSON.parse(sport.athleteAttributes[0] as unknown as string);
    expect(athleteAttribute.id).toBe(athleteAttributeValue.id);
  });

  test('should save game stat in repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let sport = <Sport>entityOrError.value;
    const gameStatOrError = GameStat.create(GAME_STAT_PROPS);
    expect(gameStatOrError.isRight()).toBe(true);

    const gameStatValue = <GameStat>gameStatOrError.value;
    sport.addGameStat(gameStatValue);
    await repository.save(sport);
    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    sport = <Sport>sportOrError.value;
    expect(Array.isArray(sport.gameStats)).toBe(true);
    expect(sport.gameStats.length).toBe(1);

    const gameStat = JSON.parse(sport.gameStats[0] as unknown as string);
    expect(gameStat.id).toBe(gameStatValue.id);
  });

  test('should save sport feed in repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let sport = <Sport>entityOrError.value;
    const sportFeedOrError = SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);

    const sportFeedValue = <SportFeed>sportFeedOrError.value;
    sport.addSportFeed(sportFeedValue);
    await repository.save(sport);
    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    sport = <Sport>sportOrError.value;
    expect(Array.isArray(sport.sportFeeds)).toBe(true);
    expect(sport.sportFeeds.length).toBe(1);

    const sportFeed = JSON.parse(sport.sportFeeds[0] as unknown as string);
    expect(sportFeed.id).toBe(sportFeedValue.id);
  });

  test('should save sport feed athlete attribute in repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let sport = <Sport>entityOrError.value;
    const sportFeedOrError = SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);

    const sportFeed = <SportFeed>sportFeedOrError.value;
    sport.addSportFeed(sportFeed);
    const athleteAttributeOrError = AthleteAttribute.create(ATHLETE_ATTRIBUTE_PROPS);
    expect(athleteAttributeOrError.isRight()).toBe(true);

    const athleteAttribute = <AthleteAttribute>athleteAttributeOrError.value;
    sport.addAthleteAttribute(athleteAttribute);
    const sportFeedAthleteAttributeOrError = SportFeedAthleteAttribute.create(
      SPORT_FEED_ATHLETE_ATTRIBUTE_PROPS
    );
    expect(sportFeedAthleteAttributeOrError.isRight()).toBe(true);

    const sportFeedAthleteAttribute = <SportFeedAthleteAttribute>sportFeedAthleteAttributeOrError.value;
    sportFeed.addSportFeedAthleteAttribute(sportFeedAthleteAttribute);
    await repository.save(sport);
    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    sport = <Sport>sportOrError.value;
    expect(Array.isArray(sport.sportFeeds)).toBe(true);
    expect(sport.sportFeeds.length).toBe(1);

    const sportFeedParse = JSON.parse(sport.sportFeeds[0] as unknown as string);
    expect(Array.isArray(sportFeedParse.sportFeedAthleteAttributes)).toBe(true);
    expect(sportFeedParse.sportFeedAthleteAttributes.length).toBe(1);
    expect(sportFeedParse.sportFeedAthleteAttributes[0].id).toBe(sportFeedAthleteAttribute.id);
  });

  test('should save sport feed game stat in repository', async () => {
    const repository = container.resolve(SportRedisRepository);
    const entityOrError = Sport.create(SPORT_PROPS);
    expect(entityOrError.isRight()).toBe(true);

    let sport = <Sport>entityOrError.value;
    const sportFeedOrError = SportFeed.create(SPORT_FEED_PROPS);
    expect(sportFeedOrError.isRight()).toBe(true);

    const sportFeed = <SportFeed>sportFeedOrError.value;
    sport.addSportFeed(sportFeed);
    const gameStatOrError = GameStat.create(GAME_STAT_PROPS);
    expect(gameStatOrError.isRight()).toBe(true);

    const gameStat = <GameStat>gameStatOrError.value;
    sport.addGameStat(gameStat);
    const sportFeedGameStatOrError = SportFeedGameStat.create(SPORT_FEED_GAME_STAT_PROPS);
    expect(sportFeedGameStatOrError.isRight()).toBe(true);

    const sportFeedGameStat = <SportFeedGameStat>sportFeedGameStatOrError.value;
    sportFeed.addSportFeedGameStat(sportFeedGameStat);
    await repository.save(sport);
    const sportOrError = await repository.getById(SPORT_PROPS.id);
    expect(sportOrError.isRight()).toBe(true);

    sport = <Sport>sportOrError.value;
    expect(Array.isArray(sport.sportFeeds)).toBe(true);
    expect(sport.sportFeeds.length).toBe(1);

    // const sportFeedGameStats: SportFeedGameStat[] =
    //   entity.sportFeeds[0].sportFeedGameStats;

    const sportFeedParse = JSON.parse(sport.sportFeeds[0] as unknown as string);

    expect(Array.isArray(sportFeedParse.sportFeedGameStats)).toBe(true);
    expect(sportFeedParse.sportFeedGameStats.length).toBe(1);
    expect(sportFeedParse.sportFeedGameStats[0].id).toBe(sportFeedGameStat.id);
  });

  test('should remove Sport entities with index which created while testing', async () => {
    const resolveEntityRepository = container.resolve(SportEntityRepository);
    const entityRepository = await resolveEntityRepository.getRepository();
    const sport = await entityRepository.search().where('id').eq(SPORT_PROPS.id).return.first();

    if (sport) {
      await entityRepository.remove(sport.entityId);
    }

    const removedSport = await entityRepository.search().where('id').eq(SPORT_PROPS.id).return.first();

    expect(removedSport).toBe(null);

    await entityRepository.dropIndex();
    await resolveEntityRepository.closeClient();
  });
});
