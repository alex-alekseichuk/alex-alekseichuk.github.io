import { HttpAdapter } from 'core';
import { describe, expect, test } from '@jest/globals';
import request from 'supertest';
import { GameStat, SportFeed, SportProps } from '../../../src/domain';
import setupApp from '../../../src/main/config/app';
import env from '../../../src/main/config/env';

const defaultSports: Partial<SportProps>[] = [
  {
    id: 'spt_fake_soccer',
    sportFeeds: [
      {
        id: 'sfe_fake_soccer',
      },
    ] as SportFeed[],
    gameStats: [
      {
        id: 'gst_goal',
      },
    ] as GameStat[],
  },
];

const newSport: Partial<SportProps> = {
  id: 'spt_temp_sport',
  name: 'Temp Sport',
  enabled: true,
};

const sportUpdates: Partial<SportProps> = {
  name: 'Temp Sport - New',
  enabled: false,
};

describe('SportHttpController', () => {
  const adapter: HttpAdapter = setupApp();
  const app = adapter.getInstance();
  const httpPrefix = env.baseRoute;

  test('Should return sports populated by seed', function () {
    return request(app)
      .get(`/${httpPrefix}/sports`)
      .expect(200)
      .then((res) => {
        expect(Array.isArray(res.body)).toBe(true);
        expect(res.body.length).toBe(defaultSports.length);

        for (let i = 0; i < defaultSports.length; i++) {
          const defaultSport = defaultSports[i];
          const item = res.body.find((sport: any) => sport && sport.id === defaultSport.id);

          expect(item).toBeDefined();
          expect(item.id).toBe(defaultSport.id);

          if (defaultSport.sportFeeds) {
            expect(Array.isArray(item.sportFeedEntities)).toBe(true);
            expect(item.sportFeedEntities.length).toBe(defaultSport.sportFeeds.length);

            for (let k = 0; i < defaultSport.sportFeeds.length; i++) {
              const expectedFeedItem = defaultSport.sportFeeds[k];
              const feedItem = item.sportFeedEntities.find(
                (feed: any) => feed && feed.id === expectedFeedItem.id
              );

              expect(feedItem).toBeDefined();
              expect(feedItem.id).toBe(expectedFeedItem.id);
            }
          }

          if (defaultSport.gameStats) {
            expect(Array.isArray(item.gameStatEntities)).toBe(true);
            expect(item.gameStatEntities.length).toBe(defaultSport.gameStats.length);

            for (let k = 0; i < defaultSport.gameStats.length; i++) {
              const expectedGameStatItem = defaultSport.gameStats[k];
              const gameStatItem = item.gameStatEntities.find(
                (gameStat: any) => gameStat && gameStat.id === expectedGameStatItem.id
              );

              expect(gameStatItem).toBeDefined();
              expect(gameStatItem.id).toBe(expectedGameStatItem.id);
            }
          }
        }
      });
  });

  for (let i = 0; i < defaultSports.length; i++) {
    test('Should return sport by id', function () {
      const sport = defaultSports[i];

      return request(app)
        .get(`/${httpPrefix}/sports/${sport.id}`)
        .expect(200)
        .then((res) => {
          expect(res.body).toBeDefined();
          expect(res.body.id).toBe(sport.id);
        });
    });
  }

  test('Should create new sport', function () {
    return request(app)
      .post(`/${httpPrefix}/sports`)
      .send(newSport)
      .expect(200)
      .then((res) => {
        expect(res.body).toBeDefined();
        expect(res.body.id).toBe(newSport.id);
        expect(res.body.name).toBe(newSport.name);
      });
  });

  test('Should update the sport', function () {
    return request(app)
      .patch(`/${httpPrefix}/sports/${newSport.id}`)
      .send(sportUpdates)
      .expect(200)
      .then((res) => {
        expect(res.body).toBeDefined();
        expect(res.body.name).toBe(sportUpdates.name);
        expect(res.body.enabled).toBe(sportUpdates.enabled);
      });
  });

  test('Should return the updated sport list', async function () {
    return request(app)
      .get(`/${httpPrefix}/sports`)
      .expect(200)
      .then((res) => {
        expect(Array.isArray(res.body)).toBe(true);
        expect(res.body.length).toBe(defaultSports.length + 1);

        const sportItem = res.body.find((sport: any) => sport && sport.id === newSport.id);

        expect(sportItem).toBeDefined();
        expect(sportItem.id).toBe(newSport.id);
        expect(sportItem.name).toBe(sportUpdates.name);
        expect(sportItem.enabled).toBe(sportUpdates.enabled);
      });
  });
});
