import 'reflect-metadata';
import { RedisQueueAdapter } from 'core/src';
import { getEntityId, QueueCallbackType } from '../../../../../../../../node_modules/core';
import { describe, expect, test } from '@jest/globals';
import { CreateSport, CreateSportOutputDto } from '../../../../../../src/application';
import { EntityPrefix, Sport, SportCreatedEvent, SportProps } from '../../../../../../src/domain';
import { SportInMemoryRepository } from '../../../../../../src/infra';
import url from '../../../../../../src/main/config/redis';

const SPORT_PROPS: SportProps = {
  id: getEntityId(EntityPrefix.Sport, 'soccer'),
  enabled: true,
  gameAthletePositions:[],
  name: 'Soccer',
};

describe('CreateSportUseCase', () => {
  test('should create entity in repository', async () => {
    const repository = new SportInMemoryRepository();
    const queue = new RedisQueueAdapter(url);

    const useCase = new CreateSport(repository, queue);
    const output = await useCase.execute(SPORT_PROPS);
    expect(output.isRight()).toBe(true);

    const entity: Sport = output.value as Sport;
    expect(entity.id).toBe(SPORT_PROPS.id);
  });

  test('should trigger created event in queue', async () => {
    const repository: SportInMemoryRepository = new SportInMemoryRepository();
    const queue = new RedisQueueAdapter(url);

    const callbackData: { callback: QueueCallbackType } = {
      callback: async () => {},
    };
    const spy: jest.SpyInstance = jest.spyOn(callbackData, 'callback');
    await queue.consume(SportCreatedEvent.name, callbackData.callback);
    const useCase: CreateSport = await new CreateSport(repository, queue);
    const output: CreateSportOutputDto = await useCase.execute(SPORT_PROPS);
    expect(output.isRight()).toBe(true);
    expect(spy).toHaveBeenCalled();

    await queue.subscriber.disconnect();
  });
});
