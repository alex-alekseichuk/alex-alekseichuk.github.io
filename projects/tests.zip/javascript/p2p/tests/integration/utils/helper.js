import request from 'supertest';
import { initDbForTests } from './init-test-db';
import { createMerchantServer } from '../../../src/merchant-server/server';
import { signParams } from '../../../src/common/utils/crypto';
import { createApp } from '../../../src/p2p/app';

export const userId = 1;
export const cardNumber = '0000111122223333';
export const depositId = 1;
export const currency = 'RUB';
export const bank = 'sberbank';
export const amount = 500;
export const incorrectSignature = 'signature';

let helper;

export async function getHelper() {
  if (!helper) {
    helper = new Helper();
  }
  await helper.init();

  return helper;
}

class Helper {
  async init() {
    this.container = createApp();
    this.mysql = this.container.mysql;

    await initDbForTests(this.mysql);

    this.merchant = await this.mysql.queryRow("SELECT * FROM merchants WHERE name='test'");

    this.app = this.container.httpApp;
    this.client = request(this.app.callback());

    this.merchantServer = createMerchantServer();

    this.postMerchantCreateDeposit = new WithSign(
      this,
      client => client.post('/merchant/create-deposit'),
      () => ({
        data: {
          amount,
          currency,
          bank,
          merchantId: this.merchant?.id,
          userId,
          depositId,
        },
      }),
    );
    this.getMerchantDepositStatus = new WithSign(
      this,
      client => client.get('/merchant/get-deposit-status'),
      () => ({ merchantId: this.merchant?.id, depositId }),
    );
    this.postCancelMerchantDeposit = new WithSign(
      this,
      client => client.post('/merchant/cancel-deposit'),
      () => ({ data: { merchantId: this.merchant?.id, depositId } }),
    );
  }

  async close() {
    this.merchantServer.close();
    this.container.close();
  }

  async deleteAllDeposits() {
    await this.mysql.query('DELETE FROM deposits');
  }

  async getDepositByPaymentAmount(payment_amount) {
    return this.mysql.queryRow('SELECT * FROM deposits WHERE ?', [{ payment_amount }]);
  }

  async postCreateDeposit() {
    return this.client.post('/deposit/create').send(
      {
        userId,
        data: {
          amount,
          currency,
          bank,
        },
      },
    );
  }

  async getDepositStatus() {
    return this.client.get('/deposit/status').send({ userId });
  }

  async postCancelDeposit(params = {}) {
    return this.client.post('/deposit/cancel').send({ userId, ...params });
  }

  // eslint-disable-next-line no-shadow
  async sendPaymentSms(amount) {
    return this.client.post('/sms/write_new').send(
      {
        card_number: cardNumber,
        secret_key: '1',
        text: `${amount} RUB, Баланс: 100000 RUB`,
        time: new Date().getTime(),
        id: 1,
      },
    );
  }
}

class WithSign {
  constructor(_helper, requestFunc, getData) {
    this.helper = _helper;
    this.client = _helper.client;
    this.requestFunc = requestFunc;
    this.getData = getData;
  }

  async withSign(params = {}) {
    const data = this.getData();

    return this.requestFunc(this.client).send(await signParams({ ...data, ...params }, helper.merchant?.secret));
  }

  async noSign(params = {}) {
    const data = this.getData();

    return this.requestFunc(this.client).send({ ...data, ...params });
  }

  async incorrectSign(params = {}) {
    const data = this.getData();

    return this.requestFunc(this.client).send({ ...data, signature: incorrectSignature, ...params });
  }
}
