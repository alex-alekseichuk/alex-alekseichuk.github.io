import { asyncMap } from '../../../src/common/utils/async-map';

export async function initDbForTests(db) {
  await asyncMap([
    'cards',
    'cards_presets',
    'deposits',
    'sms_new_log',
    'payments',
    'merchants',
  ], table => db.query(`DELETE FROM ${table}`));

  await db.runSqlScript('./db/p2p/seed/test-card.sql');
  await db.runSqlScript('./db/p2p/seed/test-merchant.sql');
}
