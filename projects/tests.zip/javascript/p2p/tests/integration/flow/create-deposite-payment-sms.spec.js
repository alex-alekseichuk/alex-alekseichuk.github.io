import { jest } from '@jest/globals';
import { getHelper } from '../utils/helper';

describe('Flow: create deposit, send payment SMS, parse SMS, match deposit', () => {
  let helper;

  let merchantsService;

  beforeAll(async () => {
    helper = await getHelper();
    merchantsService = helper.container.merchantsService;
    merchantsService.notifyDepositStatus = jest.fn();
  });

  beforeEach(async () => {
    await helper.deleteAllDeposits();
    merchantsService.notifyDepositStatus.mockReset();
  });

  afterAll(async () => {
    merchantsService.notifyDepositStatus.mockRestore();
    await helper.close();
  });

  it('should create and match deposit', async () => {
    const resCreateDeposit = await helper.postCreateDeposit();

    let deposit = await helper.getDepositByPaymentAmount(resCreateDeposit.body.payment_amount);

    expect(deposit).toBeDefined();
    expect(merchantsService.notifyDepositStatus).toHaveBeenCalledTimes(1);

    const resSendSms = await helper.sendPaymentSms(deposit.payment_amount);

    expect(resSendSms.status).toBe(200);

    const sms = await helper.mysql.queryRow('SELECT * FROM sms_new_log');

    expect(sms).toBeDefined();

    await helper.container.cron.jobs['parseSmsToPayments'].func();

    const payment = await helper.mysql.queryRow('SELECT * FROM payments WHERE ?', [{ amount: deposit.payment_amount }]);

    expect(payment).toBeDefined();

    await helper.container.cron.jobs['matchPayments'].func();

    deposit = await helper.mysql.queryRow('SELECT * FROM deposits WHERE ?', [{ id: deposit.id }]);
    expect(deposit.status).toBe('PAYED');
    expect(deposit.payment_id).toBe(payment.id);
    expect(merchantsService.notifyDepositStatus).toHaveBeenCalledTimes(2);
  });
});
