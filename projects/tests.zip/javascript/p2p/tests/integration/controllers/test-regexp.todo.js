import { isCashWithdrawal, parseAmount } from '../../../src/p2p/cron/parse-sms-to-payments';
import { parseBalanceAmount } from '../../../src/p2p/services/card-operations';

const smsSamples = [
  {
    text: 'Пополнение. Счет RUB. 1 RUB. Александр С. Доступно 2 RUB',
    amount: 1,
    balance: 2,
    must_ignore: false,
  },
  {
    text: 'VISA6658 10:55 зачисление 7р KUDIMOV, ANDREY Баланс: 0р',
    amount: 7,
    balance: 0,
    must_ignore: false,
  },
  {
    text: `Перевод 4998.15р от ДМИТРИЙ АЛЕКСАНДРОВИЧ Б.
Баланс VISA3087: 11886.23р`,
    amount: 4998.15,
    balance: 11886.23,
    must_ignore: false,
  },
  {
    text: `Перевод 2499.01р от ДМИТРИЙ АЛЕКСАНДРОВИЧ Б.
Баланс VISA3087: 1198.47р`,
    amount: 2499.01,
    balance: 1198.47,
    must_ignore: false,
  },
  {
    text: 'Пополнение. Счет RUB. 2198.24 RUB. Егор В. Доступно 4209.24 RUB',
    amount: 2198.24,
    balance: 4209.24,
    must_ignore: false,
  },
  {
    text: 'VISA9111 17:53 зачисление 798.71р QIWI Баланс: 0р',
    amount: 798.71,
    balance: 0,
    must_ignore: false,
  },
  {
    text: 'Зачисление от #TRACEABLE #TRACEABLE 497.19р Карта*9651 Баланс 1497.19р 12:29',
    amount: 497.19,
    balance: 1497.19,
    must_ignore: false,
  },
  {
    text: 'Зачисление от www.vostbank.ru 498.83р Карта*4149 Баланс 519.96р 13:27',
    amount: 498.83,
    balance: 519.96,
    must_ignore: false,
  },
  {
    text: 'VISA4472 14:04 Перевод 3998,26р от Никита Алексеевич С.',
    amount: 3998.26,
    balance: undefined,
    must_ignore: false,
  },
  {
    text: 'VISA3087 09:33 Выдача 55000р ATM 60007606 Баланс: 4799.44р',
    must_ignore: true,
  },
  {
    text: 'VISA8499 09:24 Выдача 50000р ATM 60005584 Баланс: 18874.74р',
    must_ignore: true,
  },
  {
    text: 'VISA8499 09:23 Выдача 100000р ATM 60005584 Баланс: 68375.10р',
    must_ignore: true,
  },
  {
    text: 'VISA6658 22:10 Выдача 51000р ATM 60009044 Баланс: 1902.41р',
    must_ignore: true,
  },
  {
    text: 'Снятие, карта *5771. 49000 RUB. ATM.Tinkoff. Доступно 1014.54 RUB',
    must_ignore: true,
  },
  {
    text: 'Снятие, карта *9615. 1000 RUB. ATM.Tinkoff. Доступно 11.08 RUB',
    must_ignore: true,
  },
  {
    text: 'Снятие 57000.00р Карта*7183 D. 60, LIT. A,  Баланс 1263.80р 17:41',
    must_ignore: true,
  },
  {
    text: `Перевод 999.54р от МАКСИМ ВЛАДИМИРОВИЧ В.
Баланс MIR-1198: 111664.99р`,
    balance: 111664.99,
    amount: 999.54,
    must_ignore: false,
  },
];

const TEST_EXPRESSIONS_BALANCE = [
  {
    expression: /(Баланс|Доступно|Остаток)([A-Z0-9 -]+)?:? (\d+(\.\d+)*) ?(р|руб|r|rub|RUB)/i,
    index: 3,
  },

  {
    func: parseBalanceAmount,
  },
];

const TESTS_EXPRESSIONS_AMOUNT = [
  {
    expression: /(\d+([,.]\d+)*) ?(р|руб|r|rub|RUB)/i,
    index: 1,
  },
  {
    func: parseAmount,
  },
];

TEST_EXPRESSIONS_BALANCE.forEach(({ expression, index, func }, idx) => {
  let success = 0;

  smsSamples.forEach((sample) => {
    try {
      if (!sample.balance) {
        success++;

        return;
      }

      if (func && func(sample.text) === sample.balance) {
        success++;

        return;
      }

      const balance = sample.text.match(expression)[index];

      if (+balance === +sample.balance) success++;
      // eslint-disable-next-line
        } catch (e) {
    }
  });
  console.log(`Expression for balance: ${idx} passed ${success}/${smsSamples.length} tests`);
});
console.log('---------------------------');
TESTS_EXPRESSIONS_AMOUNT.forEach(({ expression, index, func }, idx) => {
  let success = 0;

  smsSamples.forEach((sample) => {
    try {
      if (!sample.amount) {
        success++;

        return;
      }

      if (func && func(sample.text) === sample.amount) {
        success++;

        return;
      }

      const balance = sample.text.match(expression)[index].replace(',', '.');

      if (+balance === +sample.amount) success++;
      // eslint-disable-next-line
        } catch (e) {
    }
  });
  console.log(`Expression for amount: ${idx} passed ${success}/${smsSamples.length} tests`);
});
console.log('---------------------------');

const TEST_IGNORE_REGEXP = [
  /(Выдача|снятие)/i,
  isCashWithdrawal,
];

TEST_IGNORE_REGEXP.forEach((reg, idx) => {
  let success = 0;

  smsSamples.forEach((sample) => {
    if (typeof reg === 'function' && reg(sample.text) === sample.must_ignore) {
      success++;
    } else if (reg.test(sample.text) === sample.must_ignore) {
      success++;
    }
  });

  console.log(`Expressions for ignore ${idx}: passed ${success}/${smsSamples.length} tests`);
});
