import { jest } from '@jest/globals';
import { getHelper, depositId } from '../utils/helper';

describe('Merchant routes', () => {
  let helper;

  beforeAll(async () => {
    helper = await getHelper();
  });

  afterAll(async () => {
    await helper.close();
  });

  describe('POST /merchant/create-deposit', () => {
    let merchantsService;

    beforeAll(async () => {
      merchantsService = helper.container.merchantsService;
      merchantsService.notifyDepositStatus = jest.fn();
    });

    beforeEach(async () => {
      await helper.deleteAllDeposits();
      merchantsService.notifyDepositStatus.mockReset();
    });

    afterAll(async () => {
      merchantsService.notifyDepositStatus.mockRestore();
    });

    it('should create deposit record', async () => {
      const response = await helper.postMerchantCreateDeposit.withSign();

      const result = response.body;
      const deposit = await helper.mysql.queryRow(
        'SELECT * FROM deposits WHERE ?',
        [{ payment_amount: result.payment_amount }],
      );

      expect(response.status).toBe(200);
      expect(result.card.payment_system).toBe('mir');
      expect(deposit).toBeDefined();
      expect(merchantsService.notifyDepositStatus).toHaveBeenCalledTimes(1);
    });

    it('should response 403 Forbidden for request w/o signature', async () => {
      const response = await helper.postMerchantCreateDeposit.noSign();
      const result = response.text;

      expect(response.status).toBe(403);
      expect(JSON.parse(result).message).toBe('Forbidden');
      expect(merchantsService.notifyDepositStatus).not.toHaveBeenCalled();
    });

    it('should response 403 Forbidden for request w/ incorrect signature', async () => {
      const response = await helper.postMerchantCreateDeposit.incorrectSign();
      const result = response.text;

      expect(response.status).toBe(403);
      expect(JSON.parse(result).message).toBe('Forbidden');
      expect(merchantsService.notifyDepositStatus).not.toHaveBeenCalled();
    });
  });

  describe('GET /merchant/get-deposit-status', () => {
    beforeAll(async () => {
      await helper.deleteAllDeposits();
      await helper.postMerchantCreateDeposit.withSign();
    });

    it('should response 200, status = WAITING after create deposit', async () => {
      const response = await helper.getMerchantDepositStatus.withSign();

      expect(response.status).toBe(200);
      expect(response.body.status).toBe('WAITING');
    });

    it('should response 403 on unknown merchantId', async () => {
      const response = await helper.getMerchantDepositStatus.withSign({ merchantId: 2 });

      expect(response.status).toBe(403);
    });

    it('should response 204 on unknown depositId', async () => {
      const response = await helper.getMerchantDepositStatus.withSign({ depositId: 2 });

      expect(response.status).toBe(204);
    });

    it('should response 403 Forbidden for request w/o signature', async () => {
      const response = await helper.getMerchantDepositStatus.noSign();
      const result = response.text;

      expect(response.status).toBe(403);
      expect(JSON.parse(result).message).toBe('Forbidden');
    });

    it('should response 403 Forbidden for request w/ incorrect signature', async () => {
      const response = await helper.getMerchantDepositStatus.incorrectSign();
      const result = response.text;

      expect(response.status).toBe(403);
      expect(JSON.parse(result).message).toBe('Forbidden');
    });
  });

  describe('POST /merchant/cancel-deposit', () => {
    beforeAll(async () => {
      await helper.deleteAllDeposits();
      await helper.postMerchantCreateDeposit.withSign();
    });

    it('should response 200, status = CANCELED after cancel deposit', async () => {
      const response = await helper.postCancelMerchantDeposit.withSign();

      expect(response.status).toBe(200);
      expect(response.body.cancelled).toBeTruthy();

      const deposit = await helper.mysql.queryRow(
        'SELECT * FROM deposits WHERE ? AND ?',
        [{ merchant_id: helper.merchant?.id }, { merchant_deposit_id: depositId }],
      );

      expect(deposit).toBeDefined();
      expect(deposit.status).toBe('CANCELED');
    });

    it.skip('should response 403 on unknown merchantId', async () => {
      const response = await helper.postCancelMerchantDeposit.withSign({ merchantId: 2 });

      expect(response.status).toBe(403);
    });

    it.skip('should response 204 on unknown depositId', async () => {
      const response = await helper.postCancelMerchantDeposit.withSign({ depositId: 2 });

      expect(response.status).toBe(204);
    });

    it('should response 403 Forbidden for request w/o signature', async () => {
      const response = await helper.postCancelMerchantDeposit.noSign();
      const result = response.text;

      expect(response.status).toBe(403);
      expect(JSON.parse(result).message).toBe('Forbidden');
    });

    it('should response 403 Forbidden for request w/ incorrect signature', async () => {
      const response = await helper.postCancelMerchantDeposit.incorrectSign();
      const result = response.text;

      expect(response.status).toBe(403);
      expect(JSON.parse(result).message).toBe('Forbidden');
    });
  });
});
