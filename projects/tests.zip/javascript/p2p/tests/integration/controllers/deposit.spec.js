import { jest } from '@jest/globals';
import { getHelper, userId } from '../utils/helper';

describe('Deposit routes', () => {
  let helper;

  beforeAll(async () => {
    helper = await getHelper();
  });

  afterAll(async () => {
    await helper.close();
  });

  describe('POST /deposit/create', () => {
    let merchantsService;

    beforeAll(async () => {
      merchantsService = helper.container.merchantsService;
      merchantsService.notifyDepositStatus = jest.fn();
    });

    beforeEach(async () => {
      await helper.deleteAllDeposits();
      merchantsService.notifyDepositStatus.mockReset();
    });

    afterAll(async () => {
      merchantsService.notifyDepositStatus.mockRestore();
    });

    it('should create deposit', async () => {
      const response = await helper.postCreateDeposit();
      const result = response.body;
      const deposit = await helper.mysql.queryRow('SELECT * FROM deposits WHERE ?', [{ payment_amount: result.payment_amount }]);

      expect(response.status).toBe(200);
      expect(result.card.payment_system).toBe('mir');
      expect(deposit).toBeDefined();
      expect(merchantsService.notifyDepositStatus).toHaveBeenCalledTimes(1);
    });
  });

  describe('GET /deposit/check', () => {
    beforeAll(async () => {
      await helper.deleteAllDeposits();
      await helper.postCreateDeposit();
    });

    it('should response exists = true if the user has a deposit', async () => {
      const response = await helper.client.get('/deposit/check').send({
        userId,
      });

      expect(response.status).toBe(200);
      expect(response.body.exists).toBe(true);
    });

    it('should response exists = false if there is no deposit for the user', async () => {
      const response = await helper.client.get('/deposit/check').send({
        userId: 2,
      });

      expect(response.status).toBe(200);
      expect(response.body.exists).toBe(false);
    });
  });

  describe('GET /deposit/status', () => {
    beforeAll(async () => {
      await helper.deleteAllDeposits();
      await helper.postCreateDeposit();
    });

    it('should response status = WAITING', async () => {
      const response = await helper.getDepositStatus();

      expect(response.status).toBe(200);
      expect(response.body.status).toBe('WAITING');
    });
  });

  describe('GET /deposit/limits', () => {
    it('should response ', async () => {
      const response = await helper.client.get('/deposit/limits').send({
        userId,
      });
      const limit = response.body.sberbank;
      const min_limit = await helper.mysql.queryRow('SELECT min_amount FROM cards_presets WHERE ?', [{ min_amount: limit.min }]);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('sberbank');
      expect(min_limit.min_amount).toBe(100);
    });
  });

  describe('GET /deposit/cancel', () => {
    let merchantsService;

    beforeAll(async () => {
      merchantsService = helper.container.merchantsService;
      merchantsService.notifyDepositStatus = jest.fn();
    });

    beforeEach(async () => {
      await helper.deleteAllDeposits();
      await helper.postCreateDeposit();
      merchantsService.notifyDepositStatus.mockReset();
    });

    afterAll(async () => {
      merchantsService.notifyDepositStatus.mockRestore();
    });

    it('should response cancelled = true and make deposit as CANCELLED', async () => {
      const response = await helper.postCancelDeposit();
      const deposit = await helper.getDepositStatus();

      expect(deposit.status).toBe(200);
      expect(deposit.body.status).toBe('CANCELED');

      expect(response.status).toBe(200);
      expect(response.body.cancelled).toBe(true);
      expect(merchantsService.notifyDepositStatus).toHaveBeenCalledTimes(1);
    });
  });
});
