import { getHelper } from '../utils/helper';

describe('SMS routes', () => {
  let helper;

  beforeAll(async () => {
    helper = await getHelper();
  });

  afterAll(async () => {
    await helper.close();
  });

  describe('POST /sms/write_new', () => {
    beforeAll(async () => {
      await helper.deleteAllDeposits();
    });

    it('should todo', async () => {
    });
  });
});
