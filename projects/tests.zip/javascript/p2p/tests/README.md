# Tests

## Run tests

To run tests locally
you need `.env.test` file as config for your tests.
Create it from template.

```
npm run test:local
```

Run specified test file:

```
npm run test:local -- tests/integration/controllers/merchant.spec.js
```
