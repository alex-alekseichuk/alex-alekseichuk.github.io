
### Mark card alive
```
curl http://localhost:3000/sms/alive?card_number=0000111122223333&secret_key=1&protocol_version=1
```

Response:
```json
{"status":"ok"}
```

### Payment
```
t=`date +'%s'`
t=`expr $t '*' 1000`
curl -X POST -H "Content-type: application/json" \
    -d "{\"text\":\"498.03 RUB, Баланс: 100000 RUB\",\"time\":$t,\"id\":1}" \
     http://localhost:3000/sms/write_new?card_number=0000111122223333&secret_key=1
```
