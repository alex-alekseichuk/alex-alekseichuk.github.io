### Client Offer

```
curl http://localhost:3000/client/offer?userId=1
```

Response:
```json
{"active":false,"count":0,"percent":2,"minAmount":500}
```
