### Create a deposit:

```
curl -X POST -H "Content-type: application/json" \
    -d '{"data":{"amount":500,"currency":"RUB","bank":"sberbank"}}' \
     http://localhost:3000/deposit/create?userId=1
```

Reply:

```json
{"card":{"number":"0000111122223333","bank_type":"sberbank","payment_system":"mir"},"payment_amount":498.29,"created":"2022-09-16T08:22:59.000Z","timeout_minutes":20}
```

### Get current deposit of the user:

```
curl http://localhost:3000/deposit/check?userId=1
```

Response:
```json
{"exists":false}
```

### Cancel currently WAITING deposit of the user:

```
curl http://localhost:3000/deposit/cancel?userId=1
```

Response:

```json
{"cancelled":true}
```

### Get limits
```
curl http://localhost:3000/deposit/limits?userId=1
```

Response:

```json
{"sberbank":{"min":null,"max":null}}
```

### Get status
```
curl http://localhost:3000/deposit/status?userId=1
```

Response:
```json
{"status":"CANCELED"}
```