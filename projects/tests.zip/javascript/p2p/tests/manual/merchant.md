### Get merchant deposit status

This request doesn't work for now, because there is no signature.
TODO: add signature to this request

```
curl http://localhost:3000/merchant/get-deposit-status?merchantId=9580&depositId=1
```

Response:
```json
{"status":"WAITING"}
```
