### Full flow with safe parser_type

1. Create deposit, payment sms, match sms to payment, match payment to deposit

```
curl -X POST -H "Content-type: application/json" \
    -d '{"data":{"amount":500,"currency":"RUB","bank":"sberbank"}}' \
     http://localhost:3000/deposit/create?userId=1
```

2. Create payment SMS. Put payment_amount into text field for matching.

```
t=`date +'%s'`
t=`expr $t '*' 1000`
curl -X POST -H "Content-type: application/json" \
    -d "{\"text\":\"499.21 RUB, Баланс: 100000 RUB\",\"time\":$t,\"id\":1}" \
     http://localhost:3000/sms/write_new?card_number=0000111122223333&secret_key=1
```

3. Parse SMS to payment by cron.
4. Match payment to deposit by cron.

Result:
- Post to merchant server
- Created records in deposits, sms_new_log, and payments tables.
- deposit.status is PAYED
- sms_new_log.processed is 1, .ignored is 0
- payment.processed is 1, .matched is 1
