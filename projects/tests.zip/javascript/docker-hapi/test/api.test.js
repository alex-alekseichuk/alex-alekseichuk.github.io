// API endpoints tests
'use strict';

const chakram = require('chakram');
const expect = chakram.expect;

const mysql = require('../mysql');
const mongo = require('../mongo');

beforeEach(function() {
    return mysql.clearDb()
        .then(mongo.clearDb);
});

describe("Registration endpoint POST /register", function () {
    it("should return new user id", function () {
        var user = {email: "some_reg@email.com", password: "1234567"};
        var response = chakram.post("http://localhost:3000/register", user);
        expect(response).to.have.status(201);
        expect(response).to.have.json('id', function(id) {
            expect(id).to.be.a('number');
        });
        return chakram.wait();
    });
});

describe("Authentication endpoint POST /auth", function () {
    it("should return auth. token", function () {
        var user_login = {email: "some_auth@email.com", password: "1234567"};
        return chakram.post("http://localhost:3000/register", user_login)
            .then(function(response) {
                expect(response).to.have.status(201);
                return chakram.post("http://localhost:3000/auth", user_login);
            })
            .then(function(response){
                expect(response).to.have.status(200);
                expect(response).to.have.json('token', function(id) {
                    expect(id).to.be.a('string');
                });
                expect(response).to.have.header('Authorization', function(id) {
                    expect(id).to.be.a('string');
                });
            });
    });
});

describe("Logout endpoint POST /logout", function () {
    it("should make auth. token invalid", function () {
        var user_login = {email: "some_logout@email.com", password: "1234567"};
        var token;
        return chakram.post("http://localhost:3000/register", user_login)
            .then(function(response) {
                expect(response).to.have.status(201);
                return chakram.post("http://localhost:3000/auth", user_login);
            })
            .then(function(response){
                expect(response).to.have.status(200);
                token = response.body.token;
                return chakram.post("http://localhost:3000/logout", undefined, {
                    headers: {
                        "Authorization": token
                    }
                });
            })
            .then(function(response){
                expect(response).to.have.status(200);
                return chakram.post("http://localhost:3000/logout", undefined, {
                    headers: {
                        "Authorization": token
                    }
                });
            })
            .then(function(response){
                expect(response).to.have.status(401);
            });
    });
});

describe("List items endpoint GET /list", function () {
    it("should not list without auth. token", function () {
        return chakram.get("http://localhost:3000/items")
            .then(function(response) {
                expect(response).to.have.status(401);
            });
    });
    it("should list with auth. token", function () {
        var user_login = {email: "some_list@email.com", password: "1234567"};
        var item = {
            title: 'title1',
            description: 'description1',
            price: 12.34,
            barcode: "1234567890",
            category: "cars"
        };
        var token;
        return chakram.post("http://localhost:3000/register", user_login)
            .then(function(response) {
                expect(response).to.have.status(201);
                return chakram.post("http://localhost:3000/auth", user_login);
            })
            .then(function(response){
                expect(response).to.have.status(200);
                token = response.body.token;
                return chakram.post("http://localhost:3000/items", item, {
                    headers: {
                        "Authorization": token
                    }
                });
            })
            .then(function(response){
                expect(response).to.have.status(201);
                return chakram.get("http://localhost:3000/items", {
                    headers: {
                        "Authorization": token
                    }
                });
            })
            .then(function(response){
                expect(response).to.have.status(200);
                expect(response).to.comprise.of.json([item]);
            });
    });
});

describe("Add item endpoint POST /list", function () {
    it("should not able to add item without auth. token", function () {
        var item = {
            title: 'title1',
            description: 'description1',
            price: 12.34,
            barcode: "1234567890",
            category: "cars"
        };
        return chakram.post("http://localhost:3000/items", item)
            .then(function(response) {
                expect(response).to.have.status(401);
            });
    });
    it("should return item id", function () {
        var user_login = {email: "some_add_item@email.com", password: "1234567"};
        var item = {
            title: 'title1',
            description: 'description1',
            price: 12.34,
            barcode: "1234567890",
            category: "cars"
        };
        var token;
        return chakram.post("http://localhost:3000/register", user_login)
            .then(function(response) {
                expect(response).to.have.status(201);
                return chakram.post("http://localhost:3000/auth", user_login);
            })
            .then(function(response){
                expect(response).to.have.status(200);
                token = response.body.token;
                return chakram.post("http://localhost:3000/items", item, {
                    headers: {
                        "Authorization": token
                    }
                });
            })
            .then(function(response){
                expect(response).to.have.status(201);
                expect(response).to.have.json('_id', function(id) {
                    expect(id).to.be.a('string');
                });
            });
    });
});
