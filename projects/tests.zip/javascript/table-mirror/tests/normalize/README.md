## normalize

```puml
@startuml
left to right direction
rectangle source {
  entity records {
    * id
    --
    * title
    * category
  }
}
rectangle destination {
  entity categories {
    * id
    --
    * title
  }
  entity items {
    * id
    * category_id
    --
    * title
    --
    * mirror_id
  }
}
categories <-- items : category_id
records <-- items #line:red;text:red : mirror_id
@enduml
```
