DROP TABLE IF EXISTS new2;
DROP TABLE IF EXISTS new1;
DROP TABLE IF EXISTS old;

CREATE TABLE old (
	id INT auto_increment NOT NULL,
	name varchar(100) NULL,
	email varchar(100) NULL UNIQUE,
	CONSTRAINT old_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO old (name, email) VALUES ('Alan', 'alan@web.com');

CREATE TABLE new1 (
	id INT auto_increment NOT NULL,
	name varchar(100) NULL,
	CONSTRAINT new1_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE new2 (
	id INT auto_increment NOT NULL,
	new1_id INT NOT NULL,
	email varchar(100) NOT NULL UNIQUE,
	CONSTRAINT new2_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;

ALTER TABLE new2 ADD CONSTRAINT fk_new2_new1_id FOREIGN KEY (new1_id) REFERENCES new1(id) ON DELETE CASCADE ON UPDATE CASCADE;
