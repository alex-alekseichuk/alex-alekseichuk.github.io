import {helper as getHelper} from '../helper.mjs'

describe('1-split-1-to-1 case', () => {
    let helper
    let mapping

    async function insertToOld() {
        const [{insertId}] = await helper.db.query(`INSERT INTO \`old\` (name, email) VALUES ('A', 'e');`)
        return insertId
    }

    async function insertToNewTables() {
        const [{insertId: new1Id}] = await helper.db.query(`INSERT INTO new1 (name) VALUES ('A');`)
        const [{insertId: new2Id}] = await helper.db.query(`INSERT INTO new2 (email, new1_id) VALUES ('e', ${new1Id});`)
        return {new1Id, new2Id}
    }

    beforeEach(async () => {
        helper = await getHelper()
        await helper.applySql('./tests/1-split-1-to-1/create-tables.sql')
        mapping = await helper.getMapping('./tests/1-split-1-to-1/1-split-1-to-1.yaml')
    })

    it('should add and drop mirroring', async () => {
        await mapping.addMirror()
        await mapping.dropMirror()
    })

    describe('when mirrored', () => {
        beforeEach(async () => {
            await mapping.addMirror()
        })

        it('should insert into new1 and new2 tables on insert to old table', async () => {
            const oldId = await insertToOld()
            expect(oldId).toBeGreaterThan(0)
            const [new1Records] = await helper.db.query(`SELECT * FROM \`new1\` WHERE mirror_id=${oldId};`)
            expect(new1Records.length).toEqual(1)
            expect(new1Records[0]).toMatchObject({
                name: 'A',
            })
            const [new2Records] = await helper.db.query(`SELECT * FROM \`new2\` WHERE mirror_id=${oldId};`)
            expect(new2Records.length).toEqual(1)
            expect(new2Records[0]).toMatchObject({
                email: 'e',
                new1_id: new1Records[0].id,
            })
        })

        it('should insert+update into old table on insert to new1 and new2 tables', async () => {
            const {new1Id, new2Id} = await insertToNewTables()
            expect(new1Id).toBeGreaterThan(0)
            expect(new2Id).toBeGreaterThan(0)

            const [new1Records] = await helper.db.query(`SELECT * FROM \`new1\` WHERE id=${new1Id};`)
            const [new2Records] = await helper.db.query(`SELECT * FROM \`new2\` WHERE id=${new2Id};`)
            const new1MirrorId = new1Records[0].mirror_id
            const new2MirrorId = new2Records[0].mirror_id
            expect(new1MirrorId).toEqual(new2MirrorId)

            const [oldRecords] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${new1MirrorId};`)
            expect(oldRecords.length).toEqual(1)
            expect(oldRecords[0]).toMatchObject({
                name: 'A',
                email: 'e',
            })
        })

        it('should delete from new1 and new2 tables on delete from old table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`DELETE FROM \`old\` WHERE id=${oldId};`)
            const [new1Records] = await helper.db.query(`SELECT * FROM new1 WHERE mirror_id=${oldId};`)
            expect(new1Records.length).toEqual(0)
            const [new2Records] = await helper.db.query(`SELECT * FROM new2 WHERE mirror_id=${oldId};`)
            expect(new2Records.length).toEqual(0)
        })

        it('should delete from old table on delete from new1 table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`DELETE FROM new1 WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(0)
        })

        it('should not delete from old table on delete from new2 table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`DELETE FROM new2 WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(1)
        })

        it('should update record in new1 and new2 tables on update record in old table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`UPDATE \`old\` SET name='A2', email='e2' WHERE id=${oldId};`)
            const [new1Records] = await helper.db.query(`SELECT * FROM new1 WHERE mirror_id=${oldId};`)
            const [new2Records] = await helper.db.query(`SELECT * FROM new2 WHERE mirror_id=${oldId};`)
            expect(new1Records.length).toEqual(1)
            expect(new2Records.length).toEqual(1)
            expect(new1Records[0]).toMatchObject({
                name: 'A2',
            })
            expect(new2Records[0]).toMatchObject({
                email: 'e2',
            })
        })

        it('should update record in old table on update record in new1 table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`UPDATE new1 SET name='A2' WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                name: 'A2',
                email: 'e',
            })
        })

        it('should update record in old table on update record in new2 table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`UPDATE new2 SET email='e2' WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                name: 'A',
                email: 'e2',
            })
        })

        afterEach(async () => {
            await mapping.dropMirror()
        })
    })

    afterEach(async () => {
        await helper.applySql('./tests/1-split-1-to-1/drop-tables.sql')
    })
    afterEach(async () => {
        await helper.close()
    })
})
