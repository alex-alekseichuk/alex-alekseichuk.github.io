## 1-split-1-to-1

```puml
@startuml
left to right direction
rectangle source {
  entity old {
    * id
    --
    * name
    email
  }
}
rectangle destination {
  entity new1 {
    * id
    --
    * name
    --
    * mirror_id
  }
  entity new2 {
    * id
    * new1_id
    --
    * email
    --
    * mirror_id
  }
}
new1 <-- new2 : new1_id
old <-- new2 #line:red;text:red : mirror_id
old <-- new1 #line:red;text:red : mirror_id
@enduml
```
