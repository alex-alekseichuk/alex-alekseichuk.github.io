## 1-mirrro-1-inherit-2

```puml
@startuml
left to right direction
rectangle source {
  entity flat {
    * id
    --
    * type
    type1_field
    type2_field
  }
}
rectangle destination {
  entity base {
    * id
    --
    * type
    --
    * mirror_id
  }
  entity type1 {
    * id
    --
    * field
  }
  entity type2 {
    * id
    --
    * field
  }
}
base <-- type1 : id
base <-- type2 : id
flat <-- base #line:red;text:red : mirror_id
@enduml
```
