import {helper as getHelper} from '../helper.mjs'

describe('1-mirror-1 case', () => {
    let helper
    let mapping

    async function insertToOld() {
        const [{insertId}] = await helper.db.query(`
                INSERT INTO \`old\` (first_name, last_name, email) VALUES ('A', 'B', 'e');
            `)
        return insertId
    }

    async function insertToNew() {
        const [{insertId}] = await helper.db.query(`
                INSERT INTO \`new\` (full_name, email) VALUES ('A B', 'e');
            `)
        return insertId
    }

    beforeEach(async () => {
        helper = await getHelper()
        await helper.applySql('./tests/1-mirror-1/create-tables.sql')
        mapping = await helper.getMapping('./tests/1-mirror-1/1-mirror-1.yaml')
    })

    it('should load mirroring schema', async () => {
        const schema = await helper.loadYaml('./tests/1-mirror-1/1-mirror-1.yaml')
        expect(schema).toBeDefined()
        expect(schema.tables).toBeDefined()
    })

    it('should add and drop mirroring', async () => {
        await mapping.addMirror()
        await mapping.dropMirror()
    })

    describe('when mirrored', () => {
        beforeEach(async () => {
            await mapping.addMirror()
        })

        it('should insert into new table on insert to old table', async () => {
            const insertId = await insertToOld()
            expect(insertId).toBeGreaterThan(0)
            const [records] = await helper.db.query(`SELECT * FROM \`new\` WHERE mirror_id=${insertId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                full_name: 'A B',
                email: 'e',
            })
        })

        it('should insert into old table on insert to new table', async () => {
            const insertId = await insertToNew()
            expect(insertId).toBeGreaterThan(0)
            const [newRecords] = await helper.db.query(`SELECT * FROM \`new\` WHERE id=${insertId};`)
            const mirrorId = newRecords[0].mirror_id
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${mirrorId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                first_name: 'A',
                last_name: 'B',
                email: 'e',
            })
        })

        it('should delete from new table on delete from old table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`DELETE FROM \`old\` WHERE id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`new\` WHERE mirror_id=${oldId};`)
            expect(records.length).toEqual(0)
        })

        it('should delete from old table on delete from new table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`DELETE FROM \`new\` WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(0)
        })

        it('should update record in new table on update record in old table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`UPDATE \`old\` SET first_name='A2', last_name='B2', email='e2' WHERE id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`new\` WHERE mirror_id=${oldId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                full_name: 'A2 B2',
                email: 'e2',
            })
        })

        it('should update record in old table on update record in new table', async () => {
            const oldId = await insertToOld()
            await helper.db.query(`UPDATE \`new\` SET full_name='A2 B2', email='e2' WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                first_name: 'A2',
                last_name: 'B2',
                email: 'e2',
            })
        })

        afterEach(async () => {
            await mapping.dropMirror()
        })
    })

    afterEach(async () => {
        await helper.applySql('./tests/1-mirror-1/drop-tables.sql')
    })
    afterEach(async () => {
        await helper.close()
    })
})
