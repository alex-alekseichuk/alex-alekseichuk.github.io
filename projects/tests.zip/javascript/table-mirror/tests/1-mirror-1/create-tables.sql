DROP TABLE IF EXISTS new;
DROP TABLE IF EXISTS old;

CREATE TABLE old (
        id INT auto_increment NOT NULL,
        first_name varchar(100) NULL,
        last_name varchar(100) NULL,
        email varchar(100) NOT NULL UNIQUE,
        CONSTRAINT old_PK PRIMARY KEY (id)
)
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO old (first_name, last_name, email) VALUES ('Alan', 'Smithy', 'alan@web.com');

CREATE TABLE new (
        id INT auto_increment NOT NULL,
        full_name varchar(201) NULL,
        email varchar(100) NOT NULL UNIQUE,
        CONSTRAINT new_PK PRIMARY KEY (id)
)
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_0900_ai_ci;
