## 1-mirror-1

```puml
@startuml
left to right direction
rectangle source {
  entity old {
    * id
    --
    * first_name
    * last_name
    * email
  }
}
rectangle destination {
  entity new {
    * id
    --
    * full_name
    * email
    --
    * mirror_id
  }
}
old <-- new #line:red;text:red : mirror_id
@enduml
```
