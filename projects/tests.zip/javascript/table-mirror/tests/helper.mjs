import {promises as fs} from "fs";
import YAML from "yaml";
import {db as getDb} from '../db.mjs'
import {mapping} from "../mapping.mjs";

export async function helper() {
  const _helper = {
    db: await getDb(),

    close: async function () {
      _helper.db && await _helper.db.close()
    },

    getMapping,
    loadYaml,
    applySql,
  }
  return _helper

  async function loadYaml(yamlPath) {
    try {
      const sFile = await fs.readFile(yamlPath, 'utf8')
      return YAML.parse(sFile)
    } catch (err) {
      console.error(err)
    }
  }

  async function getMapping(schemaPath) {
    const schema = await loadYaml(schemaPath)
    return await mapping(_helper.db, schema)
  }

  async function applySql(sqlPath) {
    const sql = await fs.readFile(sqlPath, 'utf8')
    await _helper.db.queryMultiple(sql)
  }
}
