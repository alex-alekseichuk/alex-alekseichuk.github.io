## 1-to-1-mirror-1-to-1

```puml
@startuml
left to right direction
rectangle source {
  entity old1 {
    * id
    --
    * name
  }
  entity old2 {
    * id
    * old1_id
    --
    * email
  }
}
rectangle destination {
  entity new1 {
    * id
    --
    * name
    --
    * mirror_id
  }
  entity new2 {
    * id
    * new1_id
    --
    * email
    --
    * mirror_id
  }
}
old1 <-- old2 : old1_id
new1 <-- new2 : new1_id
old1 <-- new1 #line:red;text:red : mirror_id
old2 <-- new2 #line:red;text:red : mirror_id
@enduml
```
