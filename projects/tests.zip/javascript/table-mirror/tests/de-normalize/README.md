## de-normalize

```puml
@startuml
left to right direction
rectangle source {
  entity categories {
    * id
    --
    * title
  }
  entity items {
    * id
    * category_id
    --
    * title
  }
}
rectangle records {
  entity new {
    * id
    --
    * title
    * category
    --
    * mirror_id
  }
}
categories <-- items : category_id
items <-- records #line:red;text:red : mirror_id
@enduml
```
