DROP TABLE IF EXISTS new;
DROP TABLE IF EXISTS old2;
DROP TABLE IF EXISTS old1;

CREATE TABLE old1 (
	id INT auto_increment NOT NULL,
	name varchar(100) NULL,
	CONSTRAINT old1_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE old2 (
	id INT auto_increment NOT NULL,
	email varchar(100) NULL UNIQUE,
	old1_id INT NOT NULL,
	CONSTRAINT old2_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;

ALTER TABLE old2 ADD CONSTRAINT fk_old2_old1_id FOREIGN KEY (old1_id) REFERENCES old1(id) ON DELETE CASCADE ON UPDATE CASCADE;

INSERT INTO old1 (name) VALUES ('Alan');
INSERT INTO old2 (email, old1_id) VALUES ('alan@web.com', LAST_INSERT_ID());

CREATE TABLE new (
	id INT auto_increment NOT NULL,
	name varchar(100) NULL,
	email varchar(100) UNIQUE,
	CONSTRAINT new_PK PRIMARY KEY (id)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
