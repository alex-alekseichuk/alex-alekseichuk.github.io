## 1-to-1-join-1

```puml
@startuml
left to right direction
rectangle source {
  entity old1 {
    * id
    --
    * name
  }
  entity old2 {
    * id
    * old1_id
    --
    * email
  }
}
rectangle destination {
  entity new {
    * id
    --
    * name
    email
    --
    * mirror_old1_id
    * mirror_old2_id
  }
}
old1 <-- old2 : old1_id
old1 <-- new #line:red;text:red : mirror_old1_id
old2 <-- new #line:red;text:red : mirror_old2_id
@enduml
```
