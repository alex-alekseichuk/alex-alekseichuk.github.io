import {helper as getHelper} from '../helper.mjs'

describe('1-to-1-join-1 case', () => {
    let helper
    let mapping

    async function insertToOldTables() {
        const [{insertId: old1Id}] = await helper.db.query(`INSERT INTO old1 (name) VALUES ('A');`)
        const [{insertId: old2Id}] = await helper.db.query(`INSERT INTO old2 (email, old1_id) VALUES ('e', ${old1Id});`)
        return {old1Id, old2Id}
    }

    async function insertToNew() {
        const [{insertId}] = await helper.db.query(`INSERT INTO \`new\` (name, email) VALUES ('A', 'e');`)
        return insertId
    }

    async function insertRecord() {
        const newId = await insertToNew()
        const [newRecords] = await helper.db.query(`SELECT * FROM \`new\` WHERE id=${newId};`)
        const old1Id = newRecords[0].mirror_old1_id
        const old2Id = newRecords[0].mirror_old2_id
        return {newId, old1Id, old2Id}
    }

    beforeEach(async () => {
        helper = await getHelper()
        await helper.applySql('./tests/1-to-1-join-1/create-tables.sql')
        mapping = await helper.getMapping('./tests/1-to-1-join-1/1-to-1-join-1.yaml')
    })

    it('should add and drop mirroring', async () => {
        await mapping.addMirror()
        await mapping.dropMirror()
    })

    describe('when mirrored', () => {
        beforeEach(async () => {
            await mapping.addMirror()
        })

        it('should insert+update into new table on insert to old1 and old2 tables', async () => {
            const {old1Id, old2Id} = await insertToOldTables()
            expect(old1Id).toBeGreaterThan(0)
            expect(old2Id).toBeGreaterThan(0)

            const [newRecords] = await helper.db.query(`SELECT * FROM \`new\` WHERE mirror_old1_id=${old1Id};`)
            expect(newRecords.length).toEqual(1)
            expect(newRecords[0]).toMatchObject({
                mirror_old1_id: old1Id,
                mirror_old2_id: old2Id,
                name: 'A',
                email: 'e',
            })
        })

        it('should insert into old1 and old2 tables on insert into new table', async () => {
            const newId = await insertToNew()
            expect(newId).toBeGreaterThan(0)
            const [newRecords] = await helper.db.query(`SELECT * FROM \`new\` WHERE id=${newId};`)

            const [old1Records] = await helper.db.query(`SELECT * FROM old1 WHERE id=${newRecords[0].mirror_old1_id};`)
            expect(old1Records.length).toEqual(1)
            expect(old1Records[0]).toMatchObject({
                name: 'A',
            })
            const [old2Records] = await helper.db.query(`SELECT * FROM old2 WHERE id=${newRecords[0].mirror_old2_id};`)
            expect(old2Records.length).toEqual(1)
            expect(old2Records[0]).toMatchObject({
                email: 'e',
                old1_id: old1Records[0].id,
            })
        })

        it('should delete from old1 and old2 tables on delete from new table', async () => {
            const newId = await insertToNew()
            const [newRecords] = await helper.db.query(`SELECT * FROM \`new\` WHERE id=${newId};`)
            await helper.db.query(`DELETE FROM \`new\` WHERE id=${newId};`)
            const [old1Records] = await helper.db.query(`SELECT * FROM old1 WHERE id=${newRecords[0].mirror_old1_id};`)
            expect(old1Records.length).toEqual(0)
            const [old2Records] = await helper.db.query(`SELECT * FROM old2 WHERE id=${newRecords[0].mirror_old2_id};`)
            expect(old2Records.length).toEqual(0)
        })

        it('should delete from new table on delete from old1 table', async () => {
            const {old1Id} = await insertToOldTables()
            await helper.db.query(`DELETE FROM old1 WHERE id=${old1Id};`)
            const [records] = await helper.db.query(`SELECT * FROM \`new\` WHERE mirror_old1_id=${old1Id};`)
            expect(records.length).toEqual(0)
        })

        it('should not delete from new table on delete from old2 table', async () => {
            const newId = await insertToNew()
            const [newRecords] = await helper.db.query(`SELECT * FROM \`new\` WHERE id=${newId};`)
            const old2Id = newRecords[0].mirror_old2_id
            await helper.db.query(`DELETE FROM old2 WHERE id=${old2Id};`)
            const [records] = await helper.db.query(`SELECT * FROM \`new\` WHERE id=${newId};`)
            expect(records.length).toEqual(1)
        })

        it.only('should update record in old1 and old2 tables on update record in new table', async () => {
            const {newId, old1Id, old2Id} = await insertRecord()
            await helper.db.query(`UPDATE \`new\` SET name='A2', email='e2' WHERE id=${newId};`)
            const [old1Records] = await helper.db.query(`SELECT * FROM old1 WHERE mirror_id=${old1Id};`)
            const [old2Records] = await helper.db.query(`SELECT * FROM old2 WHERE mirror_id=${old2Id};`)
            expect(old1Records.length).toEqual(1)
            expect(old2Records.length).toEqual(1)
            expect(old1Records[0]).toMatchObject({
                name: 'A2',
            })
            expect(old2Records[0]).toMatchObject({
                email: 'e2',
            })
        })

        it('should update record in old table on update record in new1 table', async () => {
            const oldId = await insertToOldTables()
            await helper.db.query(`UPDATE new1 SET name='A2' WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                name: 'A2',
                email: 'e',
            })
        })

        it('should update record in old table on update record in new2 table', async () => {
            const oldId = await insertToOldTables()
            await helper.db.query(`UPDATE new2 SET email='e2' WHERE mirror_id=${oldId};`)
            const [records] = await helper.db.query(`SELECT * FROM \`old\` WHERE id=${oldId};`)
            expect(records.length).toEqual(1)
            expect(records[0]).toMatchObject({
                name: 'A',
                email: 'e2',
            })
        })

        afterEach(async () => {
            await mapping.dropMirror()
        })
    })

    afterEach(async () => {
        await helper.applySql('./tests/1-split-1-to-1/drop-tables.sql')
    })
    afterEach(async () => {
        await helper.close()
    })
})
