# PyTest tests for several routes.

## Manual tests

### Load login URL with 100 requests

There is a script post-login.sh.
It can be used for manual test of limit-login rule in firewall.
