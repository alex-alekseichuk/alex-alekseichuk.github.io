from locust import HttpUser, between, task, constant


class PingUser(HttpUser):
    wait_time = constant(0.01)

    @task
    def ping(self):
        self.client.get("/ping")


class LoginUser(HttpUser):
    wait_time = between(1, 2)
    token = None

    def login(self):
        res = self.client.post("/auth/login", json={
            "email": "flexapi.admin@pearlxinfra.com",
            "password": "provide-password"
        }, catch_response=True)
        self.token = res.json()["token"]
        print(f"Logged in {self.token}")
        return self.token

    def logout(self):
        self.client.post("/auth/logout", headers={"Authorization": f"Bearer {self.token}"})

    def on_start(self):
        self.login()

    def on_stop(self):
        self.logout()


class MeUser(LoginUser):
    @task
    def me(self):
        self.client.get("/auth/me")

