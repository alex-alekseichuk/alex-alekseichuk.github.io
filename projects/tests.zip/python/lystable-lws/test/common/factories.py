from factory.alchemy import base


class ModelFactory(base.Factory):
    """ Base class of factory_boy stubs for SQLAlchemy models
    """
    @classmethod
    def _create(cls, model_class, *args, **kwargs):
        session = None
        if 'session' in kwargs:
            session = kwargs.pop('session')
        obj = model_class(*args, **kwargs)
        if session:
            session.add(obj)
        return obj
