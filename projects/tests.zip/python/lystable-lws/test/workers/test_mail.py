from nameko.containers import ServiceContainer
from nameko.testing.services import (
    entrypoint_waiter, replace_dependencies, worker_factory)
import pytest

from lws.core.app import app
from lws.core.nameko import dispatcher
from lws.workers.mail import MailWorker, Notification, TextNotification


@pytest.fixture(autouse=True)
def mandrill_dummy_key(config_override):
    config_override['MANDRILL_API_KEY'] = 'dummy'
    return config_override['MANDRILL_API_KEY']


def test_html_notification(dummy_mailer):
    notification = Notification(
        template_name='my-template',
        to=[{'email': 'foo@bar.com'}, {'email': 'fizz@bar.com', 'type': 'cc'}],
        context={'var': 'value'},
        meta={'subject': 'Override subject'},
    )

    worker = worker_factory(MailWorker)
    worker.send_notification(notification.event_data)

    worker.mandrill.messages.send_template.assert_called_once_with(
        template_name='my-template',
        template_content=[],
        message={
            'merge_language': 'handlebars',
            'to': [
                {'email': 'foo@bar.com'},
                {'email': 'fizz@bar.com', 'type': 'cc'},
            ],
            'global_merge_vars': {'var': 'value'},
            'subject': 'Override subject',
        },
        async=False,
        send_at=None,
    )


def test_text_notification(dummy_mailer):
    notification = TextNotification(
        text='My Email text',
        html='<b>My Email text</b>',
        to=[{'email': 'foo@bar.com'}, {'email': 'fizz@bar.com', 'type': 'cc'}],
        meta={'subject': 'Override subject'},
    )

    worker = worker_factory(MailWorker)
    worker.send_text_notification(notification.event_data)

    worker.mandrill.messages.send.assert_called_once_with(
        message={
            'text': 'My Email text',
            'html': '<b>My Email text</b>',
            'merge_language': 'handlebars',
            'to': [
                {'email': 'foo@bar.com'},
                {'email': 'fizz@bar.com', 'type': 'cc'},
            ],
            'subject': 'Override subject',
        },
        async=False,
        send_at=None,
    )


def test_dispatch_notification(rabbit_config, dummy_mailer):
    notification = Notification(
        template_name='my-template',
        to=[{'email': 'foo@bar.com'}, {'email': 'fizz@bar.com', 'type': 'cc'}],
        context={'var': 'value'},
        meta={'subject': 'Override subject'},
    )

    container = ServiceContainer(MailWorker, rabbit_config)
    mandrill = replace_dependencies(container, 'mandrill')

    container.start()

    with app.test_request_context('/'):
        dispatch = dispatcher()

        with entrypoint_waiter(container, 'send_notification'):
            dispatch(notification)

    mandrill.messages.send_template.assert_called_once_with(
        template_name='my-template',
        template_content=[],
        message={
            'merge_language': 'handlebars',
            'to': [
                {'email': 'foo@bar.com'},
                {'email': 'fizz@bar.com', 'type': 'cc'},
            ],
            'global_merge_vars': {'var': 'value'},
            'subject': 'Override subject',
        },
        async=False,
        send_at=None,
    )

    container.stop()


def test_notification_meta_full():
    notification = Notification(
        template_name='my-template',
        to=[{'email': 'foo@bar.com'}, {'email': 'fizz@bar.com', 'type': 'cc'}],
        context={'var': 'value'},
        meta={
            'html': 'test',
            'text': 'test',
            'subject': 'test',
            'from_email': 'test',
            'from_name': 'test',
            'headers': {
                'Any': 'header'
            },
            'important': False,
            'track_opens': False,
            'track_clicks': False,
            'auto_text': False,
            'auto_html': False,
            'inline_css': False,
            'url_strip_qs': False,
            'preserve_recipients': False,
            'view_content_link': False,
            'bcc_address': 'test',
            'tracking_domain': 'test',
            'signing_domain': 'test',
            'return_path_domain': 'test',
            'merge': False,
            'tags': 'test',
            'subaccount': 'test',
            'google_analytics_domains': ('test.com', 'test.org'),
            'google_analytics_campaign': 'test',
            'attachments': [
                {
                    'type': 'type',
                    'name': 'name',
                    'content': 'content'
                }],
            'images': [
                {
                    'type': 'type',
                    'name': 'name',
                    'content': 'content'
                }]
        },
    )


def test_notification_meta_empty():
    with pytest.raises(ValueError):
        notification = Notification(
            template_name='my-template',
            to=[{'email': 'foo@bar.com'}],
            context={'var': 'value'},
            meta={}
        )


def test_notification_meta_min():
    notification = Notification(
        template_name='my-template',
        to=[{'email': 'foo@bar.com'}],
        context={'var': 'value'},
        meta={
            'subject': 'test'
        }
    )


def test_notification_meta_incorrect():
    with pytest.raises(ValueError):
        notification = Notification(
            template_name='my-template',
            to=[{'email': 'foo@bar.com'}],
            context={'var': 'value'},
            meta={
                'subject': 7,
                'attachments': 0
            }
        )


def test_notification_meta_change_types():
    notification = Notification(
        template_name='my-template',
        to=[{'email': 'foo@bar.com'}],
        context={'var': 'value'},
        meta={
            'html': '',  # str
            'text': False,  # str
            'subject': True,  # str
            'from_email': 1,  # str
            'from_name': 1.1,  # str
            'important': False,  # bool
            'track_opens': "test",  # bool
            'track_clicks': 1,  # bool
            'auto_text': 1.1,  # bool
            'auto_html': "test",  # bool
            'inline_css': False,  # bool
            'url_strip_qs': False,  # bool
            'preserve_recipients': False,  # bool
            'view_content_link': False,  # bool
            'bcc_address': 'test',  # str
            'tracking_domain': 'test',  # str
            'signing_domain': 'test',  # str
            'return_path_domain': 'test',  # str
            'merge': False,  # bool
            'tags': 'test',  # str
            'subaccount': 'test',  # str
            'google_analytics_domains': 'test.com',
            'google_analytics_campaign': 'test',  # str
            'attachments': {},
            'images': [{
                'type': False,
                'name': 1,
                'content': 1.1
            }]
        },
    )
    meta = notification.event_data['meta']
    assert meta['html'] == ''
    assert meta['text'] == 'False'
    assert meta['subject'] == 'True'
    assert meta['from_email'] == '1'
    assert meta['from_name'] == '1.1'
    assert meta['important'] == False
    assert meta['track_opens'] == True
    assert meta['track_clicks'] == True
    assert meta['auto_text'] == True
    assert meta['auto_html'] == True
    assert meta['inline_css'] == False
    assert meta['url_strip_qs'] == False
    assert meta['preserve_recipients'] == False
    assert meta['view_content_link'] == False
    assert meta['bcc_address'] == 'test'
    assert meta['tracking_domain'] == 'test'
    assert meta['signing_domain'] == 'test'
    assert meta['return_path_domain'] == 'test'
    assert meta['merge'] == False
    assert meta['tags'] == ['test']
    assert meta['subaccount'] == 'test'
    assert meta['google_analytics_domains'] == ['test.com']
    assert meta['google_analytics_campaign'] == 'test'
    assert meta['attachments'] == []
    assert meta['images'] == [{'name': '1', 'content': '1.1', 'type': 'False'}]
