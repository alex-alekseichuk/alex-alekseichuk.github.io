import flex

from lws.core.docs.swagger import SwaggerGenerator
from lws.core.service import Service
from lws.core.service.decorators import route
from lws.core.service.views import ResourceView
from lws.serialise import Schema, fields
from lws.serialise.decorators import noschema


class BarSchema(Schema):
    a_field = fields.Integer()


class FooSchema(Schema):
    a_field = fields.Integer(required=True)
    another_field = fields.String()
    nested_field = fields.Nested(BarSchema)

    class Meta:
        title = 'foo'


class TestView(ResourceView):

    schema = FooSchema

    def index(self, schema):
        """docstring index"""
        pass

    def get(self, schema, id):
        """docstring get"""
        pass

    def post(self, schema):
        """docstring post"""
        pass

    def put(self, schema):
        """docstring put"""
        pass

    @route(rule='foo', method='get')
    def foo(self, schema):
        """docstring foo"""
        pass

    @route(rule='not_same_name', method='post')
    @noschema
    def bar(self, schema):
        """docstring bar"""
        pass

    @route(rule='internal', method='get', internal=True)
    @noschema
    def internal(self, schema):
        """docstring internal"""
        pass


class AnotherTestView(ResourceView):

    def get(self, id):
        """docstring another get"""
        pass


class TestService(Service):

    name = 'tests'
    root = TestView
    another = AnotherTestView

    @route(rule='on_service', method='get')
    def on_service(self):
        """docstring on service"""
        pass

    @route(rule='on_service/<int:id>', method='get')
    def on_service_with_params(self, id):
        """docstring on service with params"""
        pass


def delete_keys_from_dict(dict_del, the_keys):
    """
    Delete the keys present in the the_keys from the dictionary.
    Loops recursively over nested dictionaries.
    """
    new_dict = dict_del.copy()

    if type(the_keys) is not set:
        the_keys = set(the_keys)
    for k, v in new_dict.items():
        if k in the_keys:
            del new_dict[k]
        if isinstance(v, dict):
            delete_keys_from_dict(v, the_keys)
    return new_dict


def test_endpoint_generation():
    expected = {
        '/tests/': {
            'get': {
                'description': TestView.index.__doc__,
                'tags': [TestService.name]
            },
            'post': {
                'description': TestView.post.__doc__,
                'tags': [TestService.name]
            }
        },
        '/tests/<int:id>/': {
            'get': {
                'description': TestView.get.__doc__,
                'tags': [TestService.name]
            },
            'put': {
                'description': TestView.put.__doc__,
                'tags': [TestService.name]
            }
        },
        '/tests/another/<int:id>/': {
            'get': {
                'description': AnotherTestView.get.__doc__,
                'tags': [TestService.name]
            },
        },
        '/tests/foo/': {
            'get': {
                'description': TestView.foo.__doc__,
                'tags': [TestService.name]
            },
        },
        '/tests/not_same_name/': {
            'post': {
                'description': TestView.bar.__doc__,
                'tags': [TestService.name]
            },
        },
        '/tests/on_service/': {
            'get': {
                'description': TestService.on_service.__doc__,
                'tags': [TestService.name]
            },
        },
        '/tests/on_service/<int:id>/': {
            'get': {
                'description': TestService.on_service_with_params.__doc__,
                'tags': [TestService.name]
            },
        },
        '/tests/ping/': {
            'get': {
                'description': TestService.ping.__doc__,
                'tags': [TestService.name]
            },
        },
    }

    generator = SwaggerGenerator([TestService])
    result = generator.paths_for_service(TestService, responses=False)
    # We delete the responses from the results dictionary -- it's a separate
    # concern handled by ``smore``.
    result_without_responses = delete_keys_from_dict(result, ['responses'])
    assert result_without_responses == expected
    assert not result.get('/tests/internal/')

    flex.load(generator.generate())


def test_swagger_schema():
    services = [
        s for s in Service.__subclasses__()
        if not s.__module__.startswith('test')
    ]
    swagger = SwaggerGenerator(services)
    result = swagger.generate()

    # Flex will raise an error if the schema does not validate.
    flex.load(result)
