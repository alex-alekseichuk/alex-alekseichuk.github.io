import pytest
from flask import json

from lws.core.app import app
from lws.core.auth import perms


@pytest.yield_fixture(autouse=True)
def session(session):
    yield session


@pytest.mark.parametrize(
    ('checks', 'expected_status_code'),
    [
        ([], 200),
        ([perms.is_authenticated], 403),
    ]
)
def test_no_token(checks, expected_status_code,
                  jwt_key, test_view):
    c = app.test_client()

    # Equivalent to:
    #
    # @app.route('/test_view')
    # @perms.checkers(*checks)
    # def test_view():
    #     ...
    #

    app.view_functions['test_view'] = perms.checkers(*checks)(test_view)

    res = c.get('/test_view')

    assert res.status_code == expected_status_code

    if expected_status_code == 200:
        assert res.data == b'ok'
    else:
        assert res.data != b'ok'


@pytest.mark.parametrize(
    ('checks', 'expected_status_code'),
    [
        ([], 200),
        ([perms.is_authenticated], 403),
    ]
)
def test_unauthenticated_token(checks, expected_status_code,
                               jwt_key, test_view):
    c = app.test_client()

    # Equivalent to:
    #
    # @app.route('/test_view')
    # @perms.checkers(*checks)
    # def test_view():
    #     ...
    #
    app.view_functions['test_view'] = perms.checkers(*checks)(test_view)

    res = c.post('/users/generate_token/',
                 content_type='application/json')
    res = json.loads(res.data)
    token = res['data']['token']

    res = c.get('/test_view', headers=[
        ('Authorization', 'Bearer {}'.format(token))])

    assert res.status_code == expected_status_code

    if expected_status_code == 200:
        assert res.data == b'ok'
    else:
        assert res.data != b'ok'


@pytest.mark.parametrize(
    ('checks', 'expected_status_code'),
    [
        ([], 200),
        ([perms.is_authenticated], 200),
    ]
)
def test_authenticated_token(checks, expected_status_code,
                             jwt_key, user, password, test_view):
    c = app.test_client()

    # Equivalent to:
    #
    # @app.route('/test_view')
    # @perms.checkers(*checks)
    # def test_view():
    #     ...
    #
    app.view_functions['test_view'] = perms.checkers(*checks)(test_view)

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': password,
    }), content_type='application/json')

    res = json.loads(res.data)
    token = res['data']['token']

    res = c.get('/test_view', headers=[
        ('Authorization', 'Bearer {}'.format(token))])

    assert res.status_code == expected_status_code

    if expected_status_code == 200:
        assert res.data == b'ok'
    else:
        assert res.data != b'ok'


def test_nonexisting_url(test_view):
    # See bug LYS-473
    client = app.test_client()
    response = client.get('/urldoesnotexist')
    assert response.status_code == 404
