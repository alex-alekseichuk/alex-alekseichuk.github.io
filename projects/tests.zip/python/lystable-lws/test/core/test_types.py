import pytest

from sqlalchemy.sql.sqltypes import Integer

from lws.core.db.types import CrossServiceForeignKey


def test_cross_service_foreign_key_type():
    with pytest.raises(TypeError):
        CrossServiceForeignKey()

    with pytest.raises(ValueError):
        CrossServiceForeignKey('invalid')

    with pytest.raises(ValueError):
        CrossServiceForeignKey('')

    with pytest.raises(ValueError):
        CrossServiceForeignKey('too.many.dots')

    csk_type = CrossServiceForeignKey('service.Model')
    assert type(csk_type.impl) == Integer
