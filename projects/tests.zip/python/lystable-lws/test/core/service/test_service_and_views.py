import mock
import pytest
from flask import Flask, json
from flask.views import http_method_funcs
from werkzeug.urls import url_decode

from lws.core.service import ResourceView, Service
from lws.core.service.decorators import route, PAGING_LIMIT_MAX
from lws.core.app import setup_error_handlers
from lws.core.exceptions import BadRequest, SchemaError
from lws.serialise import Schema, fields
from lws.serialise.decorators import noschema
from test.core.service.utils import mock_query


app = Flask(__name__)
setup_error_handlers(app)


@pytest.yield_fixture
def client():
    with app.test_client() as client:
        yield client


class FooSchema(Schema):
    id = fields.Integer()
    name = fields.String(attribute='fullname')
    req1 = fields.Integer(required=True)
    req2 = fields.Integer(required=True)


class FooView(ResourceView):

    # GET /
    def index(self):
        return mock_query('index')

    # POST /
    def post(self):
        return 'post'

    # GET /<int>
    def get(self, id):
        return 'get {0}'.format(id)

    # PATCH, PUT /<int>
    def patch(self, id):
        return 'patch {0}'.format(id)

    # DELETE /<int>
    def delete(self, id):
        return 'delete {0}'.format(id)

    # GET /thisthing
    @route(rule='thisthing')
    def thisthing(self):
        return 'this thing'

    # GET /baz/<int>
    @route(rule='baz/<int:id>', method='post')
    def otherthing(self, id):
        return 'other thing {0}'.format(id)

    # PUT /changemethod
    @route(rule='changemethod', method='put')
    def changemethod(self):
        return 'change method'

    # Not mapped
    def donotmap(self):
        return 'private function'


class FooViewWithSchema(ResourceView):

    schema = FooSchema

    def index(self, schema):
        return mock_query([
            {'id': 1, 'fullname': 'first', 'req1': 1, 'req2': 2},
            {'id': 2, 'fullname': 'second', 'req1': 1, 'req2': 2},
            {'id': 3, 'fullname': '3-rd', 'req1': 1, 'req2': 2},
        ])

    @noschema
    def get(self, id):
        """docstring foo get"""
        return {'id': 1, 'fullname': 'first', 'req1': 1, 'req2': 2}

    def post(self, schema):
        """docstring foo post"""
        data = {'id': 1, 'fullname': 'first'}
        loaded = schema.load(data)

        # Raise an error with several fields missing
        raise SchemaError(loaded.errors)


class FooViewWithErrors(ResourceView):

    def index(self):
        raise BadRequest('Very bad request')

    def get(self, id):
        raise TypeError('Built in error')


class FooViewWithBaseRule(ResourceView):

    def index(self, foo_id):
        return mock_query('base rule {}'.format(foo_id))

    def post(self, foo_id):
        return 'base rule post {}'.format(foo_id, id)

    def get(self, foo_id, id):
        return 'base rule get {} {}'.format(foo_id, id)


class FooService(Service):

    permission_checkers = ()

    root = FooView
    schema = FooViewWithSchema
    errors = FooViewWithErrors
    baserule = FooViewWithBaseRule.mount('<int:foo_id>/baserule')

    @route(rule='service_view')
    def service_view(self):
        return 'service view'

    @route(rule='post_service_view', method='post')
    def post_service_view(self):
        return 'post service view'

FooService.register_on(app)

rules = [(rule.endpoint, rule.rule) for rule in app.url_map.iter_rules()]

expected_rules = [
    ('index', '/'),
    ('object', '/<int:id>/'),
    ('thisthing', '/thisthing/'),
    ('otherthing', '/baz/<int:id>/'),
    ('changemethod', '/changemethod/'),
    ('schema.index', '/schema/'),
    ('schema.object', '/schema/<int:id>/'),
    ('errors.index', '/errors/'),
    ('errors.object', '/errors/<int:id>/'),
    ('baserule.index', '/<int:foo_id>/baserule/'),
    ('baserule.object', '/<int:foo_id>/baserule/<int:id>/'),
    ('service_view', '/service_view/'),
    ('post_service_view', '/post_service_view/'),
    ('ping', '/ping/'),
    ('static', '/static/<path:filename>')  # added by Flask
]


def test_urls_set_up_correctly():
    for rule in expected_rules:
        assert rule in rules

    assert len(rules) == len(expected_rules)


@pytest.mark.parametrize('method,url,response', [
    ('post', '/', 'post'),
    ('get', '/123/', 'get 123'),
    ('put', '/123/', 'patch 123'),  # automatically aliased
    ('patch', '/123/', 'patch 123'),
    ('delete', '/123/', 'delete 123'),
    ('get', '/thisthing/', 'this thing'),
    ('post', '/baz/123/', 'other thing 123'),
    ('put', '/changemethod/', 'change method'),
])
def test_resourceview_response(method, url, response, client):
    assert json.loads(getattr(client, method)(url).data) == {'data': response}


def test_resourceview_response_index(client):
    assert json.loads(getattr(client, 'get')('/').data) == {
        'data': 'index',
        'meta': {'offset': 0, 'total': 0}}


@pytest.mark.parametrize('method,url,response', [
    ('get', '/service_view/', 'service view'),
    ('post', '/post_service_view/', 'post service view')
])
def test_service_response(method, url, response, client):
    assert json.loads(getattr(client, method)(url).data) == {'data': response}


def test_method_not_allowed(client):
    assert client.trace().status_code == 405
    assert client.post('/thisthing/').status_code == 405


def test_cannot_reach_changed_method(client):
    assert client.get('/changemethod/').status_code == 405


def test_schema_decoration(client):
    response = client.get('/schema/')
    data = json.loads(response.data)

    # The schema renames `fullname` to `name`, so the function is decorated
    assert data['data'] == [
        {'id': 1, 'name': 'first', 'req1': 1, 'req2': 2},
        {'id': 2, 'name': 'second', 'req1': 1, 'req2': 2},
        {'id': 3, 'name': '3-rd', 'req1': 1, 'req2': 2}
    ]

    # Undecorated means no renaming of attribute
    response = client.get('/schema/1/')
    data = json.loads(response.data)
    assert data == {'data': {
        'id': 1, 'fullname': 'first', 'req1': 1, 'req2': 2
    }}


def test_private_function_not_mapped():
    assert '_donotmap' not in [k for k, v in rules]


def test_bad_request(client):
    response = client.get('/errors/')
    assert response.status_code == 400
    assert json.loads(response.data) == {
        'errors': [{
            'paths': None,
            'detail': 'Very bad request',
            'title': 'Bad Request',
            'status': 400
        }]
    }


def test_builtin_exception(client):
    response = client.get('/errors/123/')
    assert response.status_code == 500
    assert json.loads(response.data) == {
        'errors': [{
            'paths': None,
            'detail': 'An error occured while processing this request.',
            'title': 'Internal Server Error',
            'status': 500
        }]
    }


def test_more_than_one_error(client):
    response = client.post('/schema/')
    data = json.loads(response.data)

    first_error = {
        'detail': 'Missing data for required field.',
        'status': 400,
        'title': 'Bad Request',
        'paths': ['/req1']
    }

    second_error = {
        'detail': 'Missing data for required field.',
        'status': 400,
        'title': 'Bad Request',
        'paths': ['/req2']
    }

    assert len(data['errors']) == 2
    assert first_error in data['errors']
    assert second_error in data['errors']


def test_changed_base_rule_index(client):
    response = client.get('/1/baserule/')
    assert json.loads(response.data) == {
        'data': 'base rule 1',
        'meta': {'offset': 0, 'total': 0}}


def test_changed_base_rule_get(client):
    response = client.get('/2/baserule/3/')
    assert json.loads(response.data) == {'data': 'base rule get 2 3'}


def test_changed_base_rule_post(client):
    response = client.post('/5/baserule/')
    assert json.loads(response.data) == {'data': 'base rule post 5'}


def test_route_decorator_only_accepts_http_methods():
    for http_method in http_method_funcs:
        assert route(rule='', method=http_method)

    with pytest.raises(ValueError):
        route(rule='', method='moo')


def test_service_ping(client):
    response = client.get('/ping/')

    assert json.loads(response.data) == {'data': 'pong'}


def test_service_ping_permissions():
    class PingService(Service):
        pass

    pingapp = Flask(__name__)
    PingService.register_on(pingapp)

    # Test with a separate test client that does not have a token, nor
    # attempting to contact a service with permissions removed.
    # Otherwise, the ping fails without authentication.
    with pingapp.test_client() as client:
        response = client.get('/ping/')
        assert json.loads(response.data) == {'data': 'pong'}


@pytest.mark.parametrize('url,offset,limit,links', [
    ('/?page[offset]=1', 1, PAGING_LIMIT_MAX, None),  # no paging case
    ('/?page[limit]=2', 0, 2, {  # first page
        'last': {'page[offset]': '4', 'page[limit]': '2'},
        'next': {'page[offset]': '2', 'page[limit]': '2'}}),
    ('/?page[offset]=1&page[limit]=2', 1, 2, {  # page in the middle
        'first': {'page[offset]': '0', 'page[limit]': '2'},
        'last': {'page[offset]': '4', 'page[limit]': '2'},
        'next': {'page[offset]': '3', 'page[limit]': '2'},
        'prev': {'page[offset]': '0', 'page[limit]': '2'}}),
    ('/?page[offset]=5&page[limit]=2', 5, 2, {  # last page
        'first': {'page[offset]': '0', 'page[limit]': '2'},
        'prev': {'page[offset]': '3', 'page[limit]': '2'}}),
    ('/?p1=v1&page[limit]=2', 0, 2, {  # additional parameters forwarding
        'last': {'page[offset]': '4', 'page[limit]': '2', 'p1': 'v1'},
        'next': {'page[offset]': '2', 'page[limit]': '2', 'p1': 'v1'}}),
])
def test_paging_params(client, url, offset, limit, links):
    with mock.patch.object(FooView, 'index') as mock_index:
        total = 7
        mock_index.__internal = False
        mock_index.return_value = query = mock_query('index', total=total)

        # prepare data to check
        data = {
            'data': 'index',
            'meta': {'offset': offset, 'total': total}}
        if links is not None:
            data['links'] = links

        actual_data = json.loads(client.get(url).data)

        # extract all links parameters to checks
        if 'links' in actual_data:
            actual_data['links'] = {
                k: url_decode(link[link.index('/?') + 2:]).to_dict()
                for k, link in actual_data['links'].items()
            }

        assert actual_data == data
        query.limit.assert_called_once_with(limit)
        query.offset.assert_called_once_with(offset)
