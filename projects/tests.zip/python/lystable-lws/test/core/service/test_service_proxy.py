import pytest
from flask import Blueprint, request
from werkzeug.routing import BuildError

from lws.core.app import app
from lws.core.service import (
    register_service, unregister_service, ResourceView, Service)
from lws.core.service.decorators import route
from lws.core.service.utils import (
    request_json, ServiceProxy, request_overrides)
from test.core.service.utils import mock_query


class TestView(ResourceView):

    def index(self):
        return mock_query([{'name': 'test 1'}])

    def get(self, id):
        return {'name': 'test 1'}

    @route(rule='<int:id>/others/')
    def list_tests(self, id):
        return {'name': 'test {}'.format(id)}

    @route(rule='internal', internal=True)
    def internal_view(self):
        return 'internal content'


class DummyView(ResourceView):

    def index(self):
        return mock_query([{'name': 'dummy 1'}])

    def get(self, id):
        return {'name': 'dummy 1'}

    @route(rule='<int:id>/others/')
    def list_dummies(self, id):
        return {'name': 'dummy {}'.format(id)}


class TestService(Service):

    root = TestView
    dummies = DummyView

    @route(rule='request_data')
    def request_data(self):
        return request_json()

    @route(rule='request_get_method')
    def request_get_method(self):
        return request.method

    @route(rule='request_post_method', method='post')
    def request_post_method(self):
        return request.method


bp = Blueprint('test', __name__)
service = TestService.register_on(bp)


@pytest.yield_fixture
def test_service():
    register_service(service)

    # blueprints can be registered on the same app multiple times, but the
    # name must be unique per instance
    app.register_blueprint(bp, url_prefix='/test')

    yield service

    unregister_service('test')


def test_override():
    with app.test_request_context('/', data='{"foo": "bar"}'):
        assert request_json() == {'foo': 'bar'}

        with request_overrides(data={'foo': 'baz', 'tar': 1}):
            assert request_json() == {'foo': 'baz', 'tar': 1}

        assert request_json() == {'foo': 'bar'}


class TestProxy(object):

    def test_root_resource_view(self, test_service):
        proxy = ServiceProxy('test')

        with app.test_request_context('/'):
            request.auth_data = {'user_id': 1}

            res = proxy.index()
            assert res['data'] == [{'name': 'test 1'}]

            res = proxy.get(id=1)
            assert res['data'] == {'name': 'test 1'}

            res = proxy.list_tests(id=2)
            assert res['data'] == {'name': 'test 2'}

    def test_overriding_request_data(self, test_service):
        proxy = ServiceProxy('test')

        with app.test_request_context('/', data='{"foo": "bar"}'):
            request.auth_data = {'user_id': 1}

            res = proxy.request_data()
            assert res['data'] == {'foo': 'bar'}

            with request_overrides(data={'foo': 'baz', 'tar': 1}):
                res = proxy.request_data()

            assert res['data'] == {'foo': 'baz', 'tar': 1}

    def test_overriding_request_method(self, test_service):
        proxy = ServiceProxy('test')

        with app.test_request_context('/', method='get'):
            request.auth_data = {'user_id': 1}

            res = proxy.request_get_method()
            assert res['data'] == 'GET'

            with request_overrides(method='post'):
                res = proxy.request_post_method()

            assert res['data'] == 'POST'

    def test_overriding_request_method_by_proxy(self, test_service):
        proxy = ServiceProxy('test')

        with app.test_request_context('/', method='post'):
            request.auth_data = {'user_id': 1}

            # call POST method
            res = proxy.request_post_method()
            assert res['data'] == 'POST'

            # then call GET method
            res = proxy.index()
            assert res['data'] == [{'name': 'test 1'}]

    def test_custom_view_on_resource(self, test_service):
        proxy = ServiceProxy('test')

        with app.test_request_context('/'):
            request.auth_data = {'user_id': 1}

            res = proxy.dummies.list_dummies(id=2)
            assert res['data'] == {'name': 'dummy 2'}

    def test_missing_params(self, test_service):
        proxy = ServiceProxy('test')

        with app.test_request_context('/'):
            request.auth_data = {'user_id': 1}

            with pytest.raises(BuildError):
                proxy.dummies.list_dummies()

    def test_internal_api(self, client, test_service):
        proxy = ServiceProxy('test')

        res = client.get('/test/internal/')
        assert res.status_code == 401

        with app.test_request_context('/'):
            request.auth_data = {'user_id': 1}

            res = proxy.internal_view()
            assert res['data'] == 'internal content'
