import mock

from lws.core.service import Service
from lws.core.service.decorators import route
from lws.core.service.utils import register_service
from lws.core.exceptions import ImproperlyConfigured


def mock_query(items, total=None):
    query = mock.MagicMock()
    if total is None:
        if type(items) is list:
            total = len(items)
        else:
            total = 0
    query.configure_mock(**{
        'all.return_value': items,
        'count.return_value': total,
        'limit.return_value': query,
        'offset.return_value': query
    })
    return query


class RuleUniquenessTestHelper():
    name = 'name'

    def __init__(self, name):
        self.name = name


class InternetMarketing(Service):  # uselss service that always fails
    name = 'internetmarketing'
    permission_checkers = ()
    app_or_blueprint = RuleUniquenessTestHelper('internet_marketing')

    @route(rule='ripoff', method='post')
    def get_paid_for_playing_with_google_analytics(self):
        return '£££££'

    @route(rule='ripoff', method='post')
    def get_paid_for_pretending_to_be_playing_with_google_analytics(self):
        return '£££££'


class RuleUniquenessTestServiceA(Service):  # uselss service that always fails
    name = 'rule_a'
    permission_checkers = ()
    app_or_blueprint = RuleUniquenessTestHelper('uniqueness_helper_a')

    @route(rule='route_a', method='post')
    def method_a(self):
        return ':)'

    @route(rule='/route_a', method='post')
    def method_b(self):
        return ':)'


class RuleUniquenessTestServiceB(Service):  # uselss service that always fails
    name = 'rule_b'
    permission_checkers = ()
    app_or_blueprint = RuleUniquenessTestHelper('uniqueness_helper_b')

    @route(rule='route_a', method='post')
    def method_a(self):
        return ':)'

    @route(rule='route_a/', method='post')
    def method_b(self):
        return ':)'


class RuleUniquenessTestServiceC(Service):  # uselss service that always fails
    name = 'rule_c'
    permission_checkers = ()
    app_or_blueprint = RuleUniquenessTestHelper('uniqueness_helper_c')

    @route(rule='/route_a', method='post')
    def method_a(self):
        return ':)'

    @route(rule='route_a/', method='post')
    def method_b(self):
        return ':)'


class PizzaInsurance(Service):  # uselss service that works
    name = 'pizza'
    permission_checkers = ()
    app_or_blueprint = RuleUniquenessTestHelper('pizza_insurance')

    @route(rule='sell-pizza-insurance', method='post')
    def collect_premiums(self):
        return '£££££'

    @route(rule='sue-customer-for-destroying-insured-items', method='post')
    def collect_damages(self):
        return '£££££'


def test_rule_uniqueness():
    for service in [InternetMarketing, RuleUniquenessTestServiceA,
                    RuleUniquenessTestServiceB, RuleUniquenessTestServiceC]:
        failed = False
        try:
            register_service(service)
        except ImproperlyConfigured:
            failed = True
        assert failed

    register_service(PizzaInsurance)
