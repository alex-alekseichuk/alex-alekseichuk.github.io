import requests
from lws.core.s3 import upload_content, get_url


def test_upload_data(app_context, mock_s3):
    bucket_name = 'lystable-test'
    key_name = 'key_name'
    content = bytes(range(0, 255))
    upload_content(bucket_name, key_name, content)
    url = get_url(bucket_name, key_name)
    response = requests.get(url)
    assert response.status_code == 200
    assert response.content == content
