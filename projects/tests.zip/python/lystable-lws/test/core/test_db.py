import itertools
import os
import re
import warnings

from itertools import zip_longest

from alembic.script import ScriptDirectory
from alembic.environment import EnvironmentContext
from alembic.command import upgrade, downgrade
from alembic.config import Config
import pytest
import sqlalchemy as sa
from sqlalchemy.schema import MetaData

from lws.core.app import app
from lws.core.db import DB_URI_KEY, Base, create_db, create_tables, get_engine
from lws.core.service import discover_services, registered_services


@pytest.yield_fixture
def clean_database(request):
    connstring = app.config[DB_URI_KEY]
    create_db(connstring, drop_if_exists=True)

    try:
        yield
    finally:
        create_db(connstring, drop_if_exists=True)
        create_tables(app)


def test_migration_uniqueness():
    """ Make sure migration heads are unique """

    discover_services()
    for service in registered_services.values():
        script_location = os.path.join(service.app_or_blueprint.root_path,
                                       'migrations')
        if os.path.exists(script_location):
            heads = ScriptDirectory(script_location).get_heads()
            assert len(heads) <= 1, (
                'Migrations for service {} have branched'.format(
                    service.name))


def _alembic_setup(service):
    """ Create Alembic configuration objects
    """
    script_location = os.path.join(service.root_path, 'migrations')
    if not os.path.isdir(script_location):
        return None, None

    cfg = Config()
    cfg.set_main_option("script_location", script_location)
    cfg.set_main_option(
        "version_table", "alembic_{}_version".format(service.name))
    script = ScriptDirectory.from_config(cfg)
    return cfg, script


def _upgrade_to_head(service):
    """ Utility function that upgrades a given service to the HEAD of
    its alembic migrations.
    """
    cfg, script = _alembic_setup(service)
    if not cfg:
        # no migrations for this service, skipping
        return

    # run the upgrade
    upgrade(cfg, "head")

    # and check current aligns with HEAD
    try:
        engine = get_engine(app.config[DB_URI_KEY])
        conn = engine.connect()
        with EnvironmentContext(cfg, script) as env_context:
            table = "alembic_%s_version" % service.name
            env_context.configure(conn, version_table=table)
            migration_context = env_context.get_context()
            head = env_context.get_head_revision()
            current = migration_context.get_current_revision()
    finally:
        conn.close()
    assert head == current


def test_migrations(clean_database):
    """
    Make sure migrations run in both directions.
    """
    discover_services()
    services = registered_services.values()

    # migrate to head
    for service in services:
        _upgrade_to_head(service.app_or_blueprint)

    # migrate back down again, step by step
    for service in services:
        cfg, script = _alembic_setup(service.app_or_blueprint)
        if cfg:
            def down():
                downgrade(cfg, "-1")

                # continue until current revision is None
                try:
                    engine = get_engine(app.config[DB_URI_KEY])
                    conn = engine.connect()
                    with EnvironmentContext(cfg, script) as env_context:
                        table = ("alembic_%s_version" %
                                 service.name)
                        env_context.configure(conn, version_table=table)
                        migration_context = env_context.get_context()
                        current = migration_context.get_current_revision()
                finally:
                    conn.close()
                if current:
                    down()
            down()

    # ensure everything is gone after all the downgrades
    engine = get_engine(app.config[DB_URI_KEY])
    meta = MetaData()
    meta.reflect(bind=engine)
    remaining_tables = [table for table in meta.tables
                        if not table.startswith('alembic_')]
    assert len(remaining_tables) == 0


def _compare_tables(t1, t2, expected, ignorable_indexes):
    """ Compare two SQLAlchemy Table objects for equality. """
    # Check columns

    def sort_key(column):
        return column.name

    def column_not_expected_mismatch(column):
        return column.name not in expected

    def column_is_expected_mismatch(column):
        return column.name in expected

    t1_expected_mismatches = filter(column_is_expected_mismatch, t1.columns)
    t2_expected_mismatches = filter(column_is_expected_mismatch, t2.columns)

    # We only check mis-matched columns that are in one table and not the
    # other one.
    only_in_t1 = [
        t1_col for t1_col in t1_expected_mismatches
        if t1_col.name not in map(lambda c: c.name, t2_expected_mismatches)
    ]
    only_in_t2 = [
        t2_col for t2_col in t2_expected_mismatches
        if t2_col.name not in map(lambda c: c.name, t1_expected_mismatches)
    ]

    all_mismatches = itertools.chain(
        sorted(only_in_t1, key=sort_key),
        sorted(only_in_t2, key=sort_key),
    )

    # Mismatches where the missing column is not null and lacks a server
    # default are not allowed.
    for mismatch_col in all_mismatches:
        col_nullable = mismatch_col.nullable
        col_has_default = mismatch_col.server_default is not None
        assert col_nullable or col_has_default, mismatch_col

    t1_columns = filter(column_not_expected_mismatch, t1.columns)
    t1_columns = sorted(t1_columns, key=sort_key)

    t2_columns = filter(column_not_expected_mismatch, t2.columns)
    t2_columns = sorted(t2_columns, key=sort_key)

    for t1_col, t2_col in zip_longest(t1_columns, t2_columns):
        regex = "object at 0x[0-9a-z]+"
        t1_column_repr = re.sub(regex, "", repr(t1_col))
        t2_column_repr = re.sub(regex, "", repr(t2_col))

        assert t1_column_repr == t2_column_repr
        assert t1_col.autoincrement == t2_col.autoincrement

    # Check indexes

    def column_names(columns):
        return tuple(
            '{}.{}'.format(t1.name, getattr(col, "name", None))
            for col in columns
        )

    t1_indexes = {
        column_names(idx.columns)
        for idx in t1.indexes
    }
    t2_indexes = {
        column_names(idx.columns)
        for idx in t2.indexes
    }
    t1_indexes = {
        idx_cols for idx_cols in t1_indexes
        if idx_cols not in ignorable_indexes
    }
    t2_indexes = {
        idx_cols for idx_cols in t2_indexes
        if idx_cols not in ignorable_indexes
    }

    assert t1_indexes == t2_indexes

    # Check PKs
    t1_pk = column_names(t1.primary_key.columns)
    t2_pk = column_names(t2.primary_key.columns)
    assert t1_pk == t2_pk

    # Check FKs
    def describe_fk(fk_constraint):
        source = column_names(fk_constraint.columns)
        target = tuple(fk.target_fullname for fk in fk_constraint.elements)
        return source, target

    t1_fks = {
        describe_fk(fk_constraint) for fk_constraint in t1.constraints
        if isinstance(fk_constraint, sa.ForeignKeyConstraint)
    }
    t2_fks = {
        describe_fk(fk_constraint) for fk_constraint in t2.constraints
        if isinstance(fk_constraint, sa.ForeignKeyConstraint)
    }

    assert t1_fks == t2_fks


def test_migration_head_against_current_models(clean_database):
    """
    Compare database tables generated by sqlalchemy to those generated by
    migrations.
    """
    discover_services()
    services = registered_services.values()

    engine = get_engine(app.config[DB_URI_KEY])

    Base.metadata.create_all(engine)

    # allow tables to declare that certain columns will not match,
    # for example, if a column has been removed from the model class but not
    # yet dropped
    expected_mismatches = {}
    for mismatch_table in Base.metadata.tables.values():
        mismatch_columns = mismatch_table.info.get('allow_mismatch_cols', [])
        expected_mismatches[mismatch_table.name] = mismatch_columns

    ignore_indexes_for_tables = {}
    for ignore_indexes_table in Base.metadata.tables.values():
        table_name = ignore_indexes_table.name

        ignore_indexes = ignore_indexes_table.info.get('ignore_indexes', set())
        # Make composite/single indexes all tuples, incl. table for better
        # error messages.
        full_name = lambda idx: '{}.{}'.format(table_name, idx)
        # TODO: Python 3 does not have `basestring`, fix this test
        ignore_indexes = {
            (full_name(idx),) if isinstance(idx, basestring) else
            tuple(
                full_name(idx_component) for idx_component in idx
            )
            for idx in ignore_indexes
        }

        ignore_indexes_for_tables[table_name] = ignore_indexes

    # inspect platform database
    meta = MetaData()
    meta.reflect(bind=engine)
    model_tables = dict(meta.tables)

    # drop and recreate platform database
    create_db(app.config[DB_URI_KEY], drop_if_exists=True)
    # migrate to head
    for service in services:
        _upgrade_to_head(service.app_or_blueprint)

    # inspect platform database
    meta = MetaData()
    meta.reflect(bind=engine)
    migration_tables = dict(meta.tables)

    # For consistency, order the table names
    sorted_table_names = sorted(migration_tables)

    # compare model and migration versions
    for name in sorted_table_names:
        migration_table = migration_tables[name]
        if name.startswith("alembic"):
            continue
        if name in model_tables:  # ignore absent models
            _compare_tables(
                migration_table,
                model_tables[name],
                expected_mismatches.get(name, []),
                ignore_indexes_for_tables.get(name, set()),
            )
        else:
            msg = 'Table `{}` has no corresponding model'.format(
                migration_table.name)
            warnings.warn(msg)

    # compare migration and model versions
    for name, model_table in model_tables.items():
        _compare_tables(
            model_table,
            migration_tables[name],
            expected_mismatches.get(name, []),
            ignore_indexes_for_tables.get(name, set()),
        )
