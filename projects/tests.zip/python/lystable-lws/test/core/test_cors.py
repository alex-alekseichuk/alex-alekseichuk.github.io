import pytest

from flask import json

from lws.core.app import app
from lws.core.cors import request_origins


@pytest.yield_fixture
def client():
    with app.test_client() as client:
        yield client


@app.route('/cors/')
def cors_view():
    return 'cors_view'


def test_cors_options_bad_request_without_header(client):
    # No Origin header set
    response = client.options('/cors/')
    assert response.status_code == 400
    assert json.loads(response.data)['errors'][0]['detail'] == \
        'Origin header not set for OPTIONS request'


def test_no_cors_headers_without_origin(client):
    # No Origin header set
    response = client.get('/cors/')
    assert 'Access-Control-Allow-Origin' not in response.headers


def test_options_response(client):
    headers = {'Origin': 'http://localhost/'}
    response = client.options('/cors/', headers=headers)
    # Response is empty (at least until we may add a self describing API)
    assert not json.loads(response.data)

    # All headers set
    assert 'Access-Control-Allow-Origin' in response.headers
    assert 'Access-Control-Allow-Methods' in response.headers
    assert 'Access-Control-Allow-Headers' in response.headers
    assert 'Access-Control-Max-Age' in response.headers

    # Expose not set
    assert 'Access-Control-Expose-Headers' not in response.headers


def test_get_response(client):
    headers = {'Origin': 'http://localhost/'}
    response = client.get('/cors/', headers=headers)

    # OPTIONS headers not set
    assert 'Access-Control-Allow-Methods' not in response.headers
    assert 'Access-Control-Allow-Headers' not in response.headers
    assert 'Access-Control-Max-Age' not in response.headers

    # Origin and Expose set
    assert 'Access-Control-Allow-Origin' in response.headers
    assert 'Access-Control-Expose-Headers' in response.headers


def test_cors_does_not_break_404(client):
    assert client.get('/doesnotexist').status_code == 404


def test_request_origins():
    with app.test_request_context():
        app.config['CORS_ORIGINS'] = '*'
        assert request_origins() == ['*']

        app.config['CORS_ORIGINS'] = 'http://localhost/,http://www.google.com/'
        assert request_origins() == [
            'http://localhost/',
            'http://www.google.com/'
        ]
