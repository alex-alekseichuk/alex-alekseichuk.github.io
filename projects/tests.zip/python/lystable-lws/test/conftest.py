import eventlet
eventlet.monkey_patch()  # noqa

import pytest
from flask import g, config, json
from mock import patch
from nameko.testing import rabbit
from nameko.testing.utils import get_rabbit_config, reset_rabbit_vhost

from lws.core.app import app, configure_app
from lws.core.auth import checks  # noqa
from lws.core.auth import perms
from lws.core.db import (
    DB_URI_KEY, create_db, drop_db, create_tables, get_engine,
    session_factory, reset_tables)
from lws.services.users.models import User, UserProfile

import mock
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler


def replace_list_item(l, old, new):
    l.remove(old)
    l.append(new)


@pytest.yield_fixture(autouse=True)
def handle_auth_override(request):
    perm_checkers = request.keywords.get('default_perm_checkers')
    if perm_checkers is None:
        checkers = perms.DEFAULT_CHECKERS
    else:
        checkers = perm_checkers.args[0]

    with patch.object(perms, 'DEFAULT_CHECKERS', checkers):
        yield


def configure_testing_settings(app):
    configure_app()

    # set some testing specific configuration
    app.config['TESTING'] = True
    app.error_handlers[None] = []

    if DB_URI_KEY not in app.config:
        app.config[DB_URI_KEY] = (
            'postgres://localhost:5432/lystable_testing')
    if 'BASE_CLIENT_URL' not in app.config:
        app.config['BASE_CLIENT_URL'] = 'http://test.lystable.com'


def pytest_configure(config):
    configure_testing_settings(app)
    create_db(app.config[DB_URI_KEY], drop_if_exists=True)
    create_tables(app)


def pytest_unconfigure(config):
    drop_db(app.config[DB_URI_KEY])


@pytest.yield_fixture
def test_view():
    """ Register a new testing view and return the view function.

    This fixture takes care of the necessary tear down to ensure the
    view can be re-registered.

    If the view function needs updating you can swap it out of the
    registry like so::

        app.view_functions['test_view'] = my_custom_view

    Teardown will still be done with custom views in the registry

    """

    orig_url_map = app.url_map

    def test_view():
        return 'ok'

    app.add_url_rule('/test_view', 'test_view', test_view)

    yield test_view

    del app.view_functions['test_view']
    app.url_map = orig_url_map


@pytest.yield_fixture
def config_override():
    new_config = config.Config(app.root_path, defaults=app.config)
    with patch.object(app, 'config', new=new_config):
        yield new_config


@pytest.fixture
def jwt_key(config_override):
    config_override['JWT_KEY'] = 'secret'
    return config_override['JWT_KEY']


@pytest.yield_fixture()
def app_context():
    with app.app_context():
        yield


@pytest.yield_fixture()
def session(app_context):
    engine = get_engine(app.config[DB_URI_KEY])
    session = session_factory(bind=engine)
    g.session = session
    reset_tables(session)

    yield session

    if session.dirty:
        fail_msg = 'test completed leaving a dirty session: {}'.format(
            session.dirty)

        session.rollback()
        session.close()
        pytest.fail(fail_msg)

    session.close()


@pytest.fixture
def password():
    return 'password1'


@pytest.fixture
def user(session, password):
    u = User(email='foo@bar.com', password=password,
             status=User.STATUS_VERIFIED)
    session.add(u)
    session.commit()
    return u


@pytest.fixture
def admin_user(session, user):
    user.is_admin = True
    session.commit()
    return user


@pytest.fixture
def unverified_user(session, user):
    user.status = User.STATUS_UNVERIFIED
    session.commit()
    return user


@pytest.fixture
def user_profile(session, user):
    profile = UserProfile(user=user, team_id=1)
    session.commit()
    return profile


@pytest.yield_fixture(autouse=True)
def dummy_mailer():
    with patch('lws.workers.mail.Mandrill') as mailer:
        yield mailer.return_value


@pytest.yield_fixture
def rabbit_config(config_override):
    config = config_override

    # ensure we have an isolated vhost to be destructive in
    app.config['AMQP_URI'] += '_test'
    config.update(get_rabbit_config(app.config['AMQP_URI']))

    rabbit_manager = rabbit.Client(app.config['RABBIT_CTL_URI'])
    reset_rabbit_vhost(config['vhost'], config['username'], rabbit_manager)

    yield config

    rabbit_manager.delete_vhost(config['vhost'])


class HeaderProxy(object):

    def __init__(self, func, headers):
        self.func = func
        self.default_headers = headers

    def __call__(self, *args, **kwargs):
        kwargs['headers'] = kwargs.get('headers', self.default_headers)
        return self.func(*args, **kwargs)


class ClientWithToken(object):
    """ Wraps any call to a client with a token header. """

    def __init__(self, client, token, session_token):
        self.client = client
        self.token = token
        self.session_token = session_token

    def __getattr__(self, attr):
        func = getattr(self.client, attr)
        return HeaderProxy(func, {
            'Authorization': 'Bearer {}'.format(self.token)
        })


@pytest.yield_fixture
def client(session, jwt_key, user, password):
    with app.test_client() as client:
        data = json.dumps({
            'email': user.email,
            'password': password
        })
        response = client.post('/users/authenticate/', data=data)
        response_data = json.loads(response.data)['data']
        yield ClientWithToken(client, response_data['token'],
                              response_data['session_token'])


@pytest.yield_fixture
def profile_client(session, jwt_key, user, password, user_profile):
    with app.test_client() as client:
        data = json.dumps({
            'email': user.email,
            'password': password,
            'team_id': user_profile.team_id
        })
        response = client.post('/users/authenticate/', data=data)
        response_data = json.loads(response.data)['data']
        yield ClientWithToken(client, response_data['token'],
                              response_data['session_token'])


MOCK_S3_PORT = 8001  # port of mock S3 HTTP server


@pytest.yield_fixture
def mock_s3(config_override):
    """ Mock single bucket/key for tests and listen dummy HTTP server.
    """
    config_override['S3_BUCKETS'] = {
        'picture': 'lystable-pictures'
    }
    with mock.patch('lws.core.s3.get_bucket') as mock_get_bucket:
        bucket = mock.MagicMock()
        mock_get_bucket.return_value = bucket
        key = mock.MagicMock()
        bucket.new_key.return_value = key
        bucket.get_key.return_value = key
        key.generate_url = lambda expires_in, force_http: (
            'http://localhost:{}/{}'.format(
                MOCK_S3_PORT, key.set_contents_from_string.call_count))

        class S3HTTPHandler(BaseHTTPRequestHandler):
            def do_GET(s):
                # accept only last saved content
                if s.path != '/{}'.format(
                        key.set_contents_from_string.call_count):
                    s.send_response(404)
                s.send_response(200)
                s.send_header("Content-type", "text/html")
                s.end_headers()
                s.wfile.write(
                    bytes(key.set_contents_from_string.call_args[0][0]))

        try:
            server = HTTPServer(('localhost', MOCK_S3_PORT), S3HTTPHandler)
            thread = threading.Thread(target=server.serve_forever)
            thread.deamon = True
            thread.start()
            yield
        finally:
            server.shutdown()
