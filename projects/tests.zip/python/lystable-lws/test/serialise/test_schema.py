import pytest

from test.services.suppliers.factories import SupplierFactory

from lws.core.exceptions import BadRequest
from lws.serialise import Schema, fields
from lws.services.suppliers.models import Supplier


class SupplierSchema(Schema):
    id = fields.Integer(read_only=True)
    email = fields.Email(required=True)
    name = fields.String(required=True)

    class Meta:
        model = Supplier
        many_exclude = ('name', )


@pytest.fixture
def supplier(session):
    supplier = SupplierFactory()
    session.add(supplier)
    session.commit()

    return supplier


def test_schema_model():
    assert Supplier == SupplierSchema().model


def test_excluding_on_many(supplier):
    schema = SupplierSchema()
    many_schema = SupplierSchema(many=True)

    assert 'name' in schema.dump(supplier).data

    # preferred
    assert 'name' not in schema.dump([supplier], many=True).data

    # compat
    assert 'name' not in many_schema.dump([supplier]).data


def test_idempotent_many_serialisation(supplier):
    schema = SupplierSchema()

    assert 'name' in schema.dump(supplier).data
    assert 'name' not in schema.dump([supplier], many=True).data

    assert 'name' in schema.dump(supplier).data
    assert 'name' not in schema.dump([supplier], many=True).data


def test_does_not_update_read_only_field(session):
    schema = SupplierSchema()
    supplier = SupplierFactory(session=session)
    session.commit()

    data = schema.dump(supplier).data
    data['id'] += 10

    with pytest.raises(BadRequest):
        schema.update(data, supplier)

    session.rollback()


def test_include_read_only_field_without_change(session):
    schema = SupplierSchema()
    supplier = SupplierFactory(session=session)
    session.commit()

    data = schema.dump(supplier).data
    data['id'] = data['id']  # hey, it's explicit

    schema.update(data, supplier)
    session.rollback()
