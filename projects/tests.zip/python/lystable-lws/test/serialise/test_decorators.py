from flask import json, Flask

from lws.core.service import Service
from lws.core.service.decorators import route
from lws.serialise import Schema, fields
from lws.serialise.decorators import marshal_with

app = Flask(__name__)


class FooSchema(Schema):
    id = fields.Integer()
    name = fields.String()


class FooService(Service):

    permission_checkers = ()

    @route(rule='foo')
    @marshal_with(FooSchema)
    def foo(self, schema):
        return {'id': 1, 'name': 'foo'}

    @route(rule='foo_many')
    @marshal_with(FooSchema)
    def foo_many(self, schema):
        return [
            {'id': 1, 'name': 'foo'},
            {'id': 2, 'name': 'bar'}
        ]

    @route(rule='foo_statuscode')
    @marshal_with(FooSchema)
    def foo_statuscode(self, schema):
        return {'id': 1, 'name': 'foo'}, 201


FooService.register_on(app)


def test_marshal_with():
    with app.test_request_context('/foo/'):
        data = json.loads(FooService().dispatch_request().data)

    assert data == {'data': {'id': 1, 'name': 'foo'}}


def test_marshal_with_many():
    with app.test_request_context('/foo_many/'):
        data = json.loads(FooService().dispatch_request().data)

    assert data == {
        'data': [{'id': 1, 'name': 'foo'}, {'id': 2, 'name': 'bar'}]
    }


def test_marshal_with_response_code():

    with app.test_request_context('/foo_statuscode/'):
        response = FooService().dispatch_request()

    assert json.loads(response.data) == {'data': {'id': 1, 'name': 'foo'}}
    assert response.status_code == 201
