import random
import pytest

from flask import json

from lws.services.suppliers.models import Supplier
from lws.services.reviews.models import Review


@pytest.fixture
def suppliers(session):
    supplier1 = Supplier(email='supplier1@supplier.com')
    supplier2 = Supplier(email='supplier2@supplier.com')
    session.add_all([supplier1, supplier2])
    session.commit()

    return supplier1, supplier2


@pytest.fixture
def reviews(session, suppliers, user_profile):
    review1 = Review(
        team_id=user_profile.team_id,
        supplier_id=suppliers[0].id,
        sentiment=True
    )
    review2 = Review(
        team_id=user_profile.team_id,
        supplier_id=suppliers[1].id,
        sentiment=True
    )
    review3 = Review(
        # This one does not belong to the user's team
        team_id=user_profile.team_id + 1,
        supplier_id=suppliers[1].id,
        sentiment=True
    )

    reviews = [review1, review2, review3]

    session.add_all(reviews)
    session.commit()

    return reviews


def test_reviews_index(user_profile, profile_client, reviews):
    team_id = user_profile.team_id

    response = profile_client.get('/reviews/')

    assert response.status_code == 200

    data = json.loads(response.data)['data']

    assert len(data) == 2  # does not include review belonging to other team

    ids = [
        r.id for r in reviews if r.team_id == team_id
    ]
    fetched_ids = [r['id'] for r in data]

    assert sorted(ids) == sorted(fetched_ids)


def test_reviews_index_filter_supplier(user_profile, profile_client, reviews):
    team_id = user_profile.team_id
    my_reviews = [
        r for r in reviews if r.team_id == team_id
    ]

    fetch_review = random.choice(my_reviews)

    response = profile_client.get(
        '/reviews/?supplier_id={}'.format(fetch_review.supplier_id)
    )

    data = json.loads(response.data)['data']

    assert data[0]['id'] == fetch_review.id


def test_review_get(user_profile, profile_client, reviews):
    team_id = user_profile.team_id
    my_reviews = [
        r for r in reviews if r.team_id == team_id
    ]

    fetch_review = random.choice(my_reviews)

    response = profile_client.get('/reviews/{}/'.format(fetch_review.id))

    data = json.loads(response.data)['data']

    assert response.status_code == 200
    assert data['id'] == fetch_review.id


def test_review_cannot_get_outside_team(user_profile, profile_client, reviews):
    response = profile_client.get('/reviews/{}'.format(reviews[2].id))
    assert response.status_code == 404


def test_create_review(session, suppliers, user_profile, profile_client):
    review_data = {
        'comment': 'this is a comment',
        'supplier_id': suppliers[0].id,
        'sentiment': True
    }

    response = profile_client.post('/reviews/', data=json.dumps(review_data))

    assert response.status_code == 201

    data = json.loads(response.data)['data']

    for k in review_data.keys():
        assert data[k] == review_data[k]

    review = session.query(Review).get(data['id'])

    assert review.supplier_id == suppliers[0].id


def test_update_review(session, suppliers, profile_client, user_profile):
    r = Review(
        comment='comment',
        supplier_id=suppliers[0].id,
        team_id=user_profile.team_id)
    session.add(r)
    session.commit()

    review_data = {
        'comment': 'different comment'
    }

    response = profile_client.put(
        '/reviews/{}/'.format(r.id),
        data=json.dumps(review_data)
    )

    assert response.status_code == 200

    session.refresh(r)

    assert r.comment == review_data['comment']
