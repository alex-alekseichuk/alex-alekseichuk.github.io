import json
from flask import request
from lws.core.service import ServiceProxy, encode
from lws.core.app import app
from lws.services.files.models import File


def test_filename(session, mock_s3):
    content = bytes(range(0, 256))
    filename = 'filename1'
    files_proxy = ServiceProxy('files')
    with app.test_request_context(
            '/', method='post', data=json.dumps({
                'type': File.PICTURE,
                'content': encode(content),
                'filename': filename,
            })):
        request.auth_data = {'user_id': 1}
        res = files_proxy.post()
    file_id = res['data']['id']
    assert file_id is not None
    file = session.query(File).get(file_id)
    assert file.filename == filename
    assert file.size == 256
