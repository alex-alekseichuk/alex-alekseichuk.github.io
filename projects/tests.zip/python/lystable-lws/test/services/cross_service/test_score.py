import random
import pytest

from flask import json, request

from lws.core.app import app
from lws.core.service.utils import ServiceProxy
from lws.services.reviews.models import Review

from test.services.suppliers.factories import SupplierFactory

reviews_proxy = ServiceProxy('reviews')


@pytest.fixture
def suppliers(session):
    suppliers = []

    for i in range(10):
        suppliers.append(SupplierFactory())

    session.add_all(suppliers)
    session.commit()

    return suppliers


@pytest.fixture
def reviews(suppliers, session, user_profile):
    for supplier in suppliers:
        reviews = [
            Review(
                sentiment=random.choice([True, False]),
                supplier_id=supplier.id,
                team_id=user_profile.team_id
            )
            for _ in range(random.randrange(0, 50))
        ]

        session.add_all(reviews)
    session.commit()

    return reviews


def test_lystable_score(reviews, suppliers, profile_client, session):
    for s in suppliers:
        reviews = session.query(Review).filter(Review.supplier_id == s.id)

        positive_reviews = len([r for r in reviews if r.sentiment is True])
        negative_reviews = len([r for r in reviews if r.sentiment is False])

        with app.test_request_context(
            '/score/{}'.format(s.id),
            data=json.dumps({'id': s.id})
        ):
            request.auth_data = {'user_id': 1, 'team_id': 1}
            response = reviews_proxy.score(id=s.id)

        expected_score = positive_reviews - negative_reviews

        assert response.get('data', 0) == expected_score
