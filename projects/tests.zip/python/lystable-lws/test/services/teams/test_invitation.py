import jwt

from flask import json

from lws.core.app import app
from test.utils import pop_diff
from test.services.users.factories import (UserFactory,  # noqa
    UserProfileFactory,  # noqa
)
from test.services.teams.factories import (
    TeamFactory, InvitationFactory, TeamConfigFactory)
from lws.services.teams.models import Invitation


def test_get_index_test_failure(session):
    client = app.test_client()
    # Unauthenticated request, fails
    res = client.get('/teams/0/invitations/')
    assert 403 == res.status_code
    user = UserFactory(session=session, password='password', status='VERIFIED')
    domain = user.email.split('@')[1]
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    team2 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    session.commit()

    UserProfileFactory(session=session, user_id=user.id, team_id=team1.id,
                       user_level='STANDARD')
    session.commit()

    # Authenticate, keep token
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    headers = [('Authorization', 'Bearer {}'.format(token))]

    # Unauthenticated request, still fails
    res = client.get('/teams/{}/invitations/'.format(team1.id))
    assert 403 == res.status_code

    # Authenticated request, wrong team ID:
    res = client.get('/teams/0/invitations/', headers=headers)
    assert 404 == res.status_code

    # Authenticated request, empty stuff:
    res = client.get(
        '/teams/{}/invitations/'.format(team1.id),
        headers=headers)
    assert 200 == res.status_code
    assert json.loads(res.data) == {
        'meta': {'offset': 0, 'total': 0}}
    # Authenticated request, team where the user is not a member:
    res = client.get('/teams/{}/invitations/'.format(team2.id),
                     headers=headers)
    assert 403 == res.status_code


def test_get_index(session):
    client = app.test_client()
    user = UserFactory(session=session, password='password', status='VERIFIED')
    domain = user.email.split('@')[1]
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    team2 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    session.commit()

    UserProfileFactory(session=session, user_id=user.id, team_id=team1.id,
                       user_level='STANDARD')
    session.commit()

    # Authenticate, keep token
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    headers = [('Authorization', 'Bearer {}'.format(token))]

    # New invitation:
    inv_data1 = dict(
        email='invitee1@not{}'.format(domain),
        inviting_id=user.id, team_id=team1.id,
    )
    InvitationFactory(session=session, **inv_data1)
    session.commit()
    inv_data1.update(dict(invited_id=None, accepted=None))

    # Compare incoming invitations to the new invitation:
    res = client.get('/teams/{}/invitations/'.format(team1.id),
                     headers=headers)
    assert 200 == res.status_code
    data = json.loads(res.data)['data']

    data = list(map(pop_diff, data))
    assert data == [inv_data1]

    # Second new invitation:
    inv_data2 = dict(
        email='invitee2@not{}'.format(domain),
        inviting_id=user.id, team_id=team1.id,
    )
    InvitationFactory(session=session, **inv_data2)
    session.commit()
    inv_data2.update(dict(invited_id=None, accepted=None))

    # Compare incoming invitations to the new invitations:
    res = client.get('/teams/{}/invitations/'.format(team1.id),
                     headers=headers)
    assert 200 == res.status_code
    data = json.loads(res.data)['data']
    data = list(map(pop_diff, data))
    assert data == [inv_data1, inv_data2]


def test_cancel_invitation_as_member(session):
    client = app.test_client()
    member = UserFactory(
        session=session, password='password', status='VERIFIED')
    domain = member.email.split('@')[1]
    owner = UserFactory(
        session=session, password='password', status='VERIFIED',
        email='owner@{}'.format(domain))
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    session.commit()
    UserProfileFactory(
        session=session, user_id=owner.id, team_id=team1.id,
        user_level='OWNER')
    UserProfileFactory(
        session=session, user_id=member.id, team_id=team1.id,
        user_level='STANDARD')
    session.commit()
    owner_inv = InvitationFactory(
        session=session,
        email='invitee1@not{}'.format(domain),
        inviting_id=owner.id, team_id=team1.id,
    )
    member_inv = InvitationFactory(
        session=session,
        email='invitee2@not{}'.format(domain),
        inviting_id=member.id, team_id=team1.id,
    )
    session.commit()
    # Get tokens, prepares headers:
    res = client.post(
        '/users/authenticate/',
        data=json.dumps({
            'email': member.email,
            'password': 'password',
            'team_id': team1.id,
        }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    member_headers = [('Authorization', 'Bearer {}'.format(token))]

    count = int(session.query(Invitation).count())
    res = client.delete(
        '/teams/{o}/invitations/{inv}/'.format(
            o=team1.id, inv=owner_inv.id),
        data=json.dumps({}),
        headers=member_headers
    )
    assert 403 == res.status_code

    res = client.delete(
        '/teams/{o}/invitations/{inv}/'.format(
            o=team1.id, inv=member_inv.id),
        data=json.dumps({}),
        headers=member_headers)
    assert 204 == res.status_code
    assert 1 == count - int(session.query(Invitation).count())


def test_cancel_invitation_as_owner(session):
    client = app.test_client()
    member = UserFactory(session=session, password='password',
                         status='VERIFIED',
                         )
    domain = member.email.split('@')[1]
    owner = UserFactory(session=session, password='password',
                        status='VERIFIED', email='owner@{}'.format(domain),
                        )
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    session.commit()
    UserProfileFactory(session=session, user_id=owner.id,
                       team_id=team1.id, user_level='OWNER')
    UserProfileFactory(session=session, user_id=member.id,
                       team_id=team1.id, user_level='STANDARD')
    session.commit()
    owner_inv = InvitationFactory(
        session=session,
        email='invitee1@not{}'.format(domain),
        inviting_id=owner.id, team_id=team1.id,
    )
    member_inv = InvitationFactory(
        session=session,
        email='invitee2@not{}'.format(domain),
        inviting_id=member.id, team_id=team1.id,
    )
    session.commit()
    # Get tokens, prepares headers:
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': owner.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    owner_headers = [('Authorization', 'Bearer {}'.format(token))]

    count = int(session.query(Invitation).count())
    res = client.delete(
        '/teams/{o}/invitations/{inv}/'.format(
            o=team1.id, inv=owner_inv.id),
        headers=owner_headers)
    assert 204 == res.status_code

    res = client.delete(
        '/teams/{o}/invitations/{inv}/'.format(
            o=team1.id, inv=member_inv.id),
        headers=owner_headers)
    assert 204 == res.status_code
    assert 2 == count - int(session.query(Invitation).count())


def test_member_cant_accept_inivitation(session, jwt_key):
    client = app.test_client()
    owner = UserFactory(
        session=session, password='password', status='VERIFIED')
    member = UserFactory(
        session=session, password='password', status='VERIFIED')
    domain = member.email.split('@')[1]
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    session.commit()
    UserProfileFactory(session=session, user_id=owner.id,
                       team_id=team1.id, user_level='OWNER')
    UserProfileFactory(session=session, user_id=member.id,
                       team_id=team1.id, user_level='STANDARD')
    member_inv = InvitationFactory(
        session=session, email=member.email,
        inviting_id=owner.id, team_id=team1.id,
    )
    session.commit()

    res = client.post('/users/authenticate/', data=json.dumps({
        'email': member.email,
        'password': 'password',
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    member_headers = [('Authorization', 'Bearer {}'.format(token))]

    # Will fail as the user is already a member:
    res = client.post(
        '/teams/{o}/invitations/{inv}/accept/'.format(
            o=team1.id, inv=member_inv.id),
        data=json.dumps({}),
        headers=member_headers)
    assert 400 == res.status_code
    #: Why this status_code is 400 and not 406:
    #: Instead of making a separate request to the User service to see if the
    #:  user is already a member, the Team service sends a naive
    #:  request to UserView.add_profile(), and if there already is a member
    #:  with that email, .add_profile() will throw an Http400.
    #: Would be a little nicer to get a 406, but does not seem to be worth the
    #:  effort of either (1) making a request to the User service to make sure
    #:  no user exists, or (2) catching and handling the Http400 that
    #:  .add_profile() throws.


def test_accept_invitation(session, jwt_key):
    client = app.test_client()
    member = UserFactory(session=session, password='password',
                         status='VERIFIED',
                         )
    domain = member.email.split('@')[1]
    invitee = UserFactory(session=session, password='password',
                          status='VERIFIED',
                          email='invitee@{}not'.format(domain),
                          )
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    session.commit()
    UserProfileFactory(session=session, user_id=member.id, team_id=team1.id,
                       user_level='STANDARD')
    session.commit()

    # Try to authentication to team without being a member:
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': invitee.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    assert 401 == res.status_code

    # Authenticate, keep token
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': invitee.email,
        'password': 'password',
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    invitee_headers = [('Authorization', 'Bearer {}'.format(token))]

    member_inv = InvitationFactory(
        session=session, email=invitee.email,
        inviting_id=member.id, team_id=team1.id,
    )

    # Will fail, open no invitation (not yet commited):
    res = client.post(
        '/teams/{o}/invitations/{inv}/accept/'.format(
            o=team1.id, inv=0),
        data=json.dumps({}),
        headers=invitee_headers)
    assert 404 == res.status_code
    session.commit()

    # Properly accept an invitation:
    res = client.post(
        '/teams/{o}/invitations/{inv}/accept/'.format(
            o=team1.id, inv=member_inv.id),
        data=json.dumps({}),
        headers=invitee_headers)
    assert 200 == res.status_code
    assert {
        "accepted": True,
        "email": "invitee@example.comnot",
        "invited_id": invitee.id,
        "inviting_id": member.id,
        "team_id": team1.id,
    } == pop_diff(json.loads(res.data)['data'])

    # Will fail, no open invitation (the first one has just been accepted):
    res = client.post(
        '/teams/{o}/invitations/{inv}/accept/'.format(
            o=team1.id, inv=member_inv.id),
        data=json.dumps({}),
        headers=invitee_headers)
    assert 404 == res.status_code

    # Authenticate the accepted user as a member of the team
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': invitee.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    payload = jwt.decode(token, jwt_key)
    payload.pop('exp')
    payload.pop('session_token')
    assert payload == {
        'user_id': invitee.id,
        'is_admin': False,
        'team_id': team1.id,
        'user_level': 'STANDARD',
    }


def test_post_invite(session):
    client = app.test_client()
    # Unauthenticated request, fails
    res = client.get('/teams/0/invitations/')
    assert 403 == res.status_code

    owner = UserFactory(session=session, password='password',
                        status='VERIFIED',
                        )
    domain = owner.email.split('@')[1]
    member = UserFactory(session=session, password='password',
                         status='VERIFIED', email='member@{}'.format(domain),
                         )
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    session.commit()

    owner_profile = UserProfileFactory(
        session=session, user_id=owner.id,
        team_id=team1.id, user_level='OWNER')
    member_profile = UserProfileFactory(
        session=session, user_id=member.id,
        team_id=team1.id, user_level='STANDARD')
    session.commit()

    res = client.post('/users/authenticate/', data=json.dumps({
        'email': owner.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    owner_headers = [('Authorization', 'Bearer {}'.format(token))]

    # Will be rejected due to user email and team with same domain:
    # Is this the behaviour we want? (I think it is...)
    res = client.post('/teams/{}/invitations/'.format(team1.id),
                      data=json.dumps({
                          'email': 'invitee@{}'.format(domain)
                      }), headers=owner_headers)
    assert 406 == res.status_code

    # Will be rejected due to the user already being a member:
    res = client.post('/teams/{}/invitations/'.format(team1.id),
                      data=json.dumps({
                          'email': member.email
                      }), headers=owner_headers)
    assert 406 == res.status_code
