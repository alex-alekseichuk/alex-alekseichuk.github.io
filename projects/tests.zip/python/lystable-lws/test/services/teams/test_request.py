import jwt

from flask import json

from lws.core.app import app
from test.utils import pop_diff

from test.services.teams.factories import (
    TeamFactory, AccessRequestFactory, TeamConfigFactory)
from test.services.users.factories import UserFactory, UserProfileFactory


def test_get_index_test_failure(session):
    client = app.test_client()
    # Unauthenticated request, fails
    res = client.get('/teams/0/access-requests/')
    assert res.status_code == 403
    user = UserFactory(session=session, password='password', status='VERIFIED')
    domain = user.email.split('@')[1]
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    team2 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    session.commit()

    UserProfileFactory(session=session, user_id=user.id,
                       team_id=team1.id, user_level='OWNER')
    session.commit()

    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    headers = [('Authorization', 'Bearer {}'.format(token))]

    # Unauthenticated request, still fails
    res = client.get('/teams/567987/access-requests/')
    assert res.status_code == 403

    res = client.get('/teams/0/access-requests/', headers=headers)
    assert res.status_code == 404

    # Authenticated request, empty stuff:
    res = client.get(
        '/teams/{}/access-requests/'.format(team1.id),
        headers=headers)
    assert res.status_code == 200
    assert json.loads(res.data) == {
        'meta': {'offset': 0, 'total': 0}}
    res = client.get('/teams/{}/access-requests/'.format(team2.id),
                     headers=headers)
    assert res.status_code == 403


def test_get_index(session):
    client = app.test_client()
    user = UserFactory(session=session, password='password',
                       status='VERIFIED')
    domain = user.email.split('@')[1]
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    team2 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    session.commit()

    UserProfileFactory(session=session, user_id=user.id,
                       team_id=team1.id, user_level='OWNER')
    session.commit()

    # Authenticate, keep token
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    headers = [('Authorization', 'Bearer {}'.format(token))]

    # New access request:
    ar1_data = dict(user_id=user.id, team_id=team1.id)
    AccessRequestFactory(session=session, **ar1_data)
    session.commit()
    ar1_data.update(dict(actioned_by=None, accepted=None))

    # list (one record) access requests
    res = client.get('/teams/{}/access-requests/'.format(team1.id),
                     headers=headers)
    assert res.status_code == 200
    data = json.loads(res.data)['data']

    data = list(map(pop_diff, data))
    assert data == [ar1_data]

    # New second access request:
    ar2_data = dict(user_id=user.id, team_id=team1.id)
    ar2_data.update(dict(actioned_by=66, accepted=True))
    AccessRequestFactory(session=session, **ar2_data)
    session.commit()

    # list first and second access requests
    res = client.get('/teams/{}/access-requests/'.format(team1.id),
                     headers=headers)
    assert res.status_code == 200
    data = json.loads(res.data)['data']
    data = list(map(pop_diff, data))
    assert data == [ar1_data, ar2_data]


def test_reject_request(session):
    client = app.test_client()
    owner = UserFactory(session=session, password='password',
                        status='VERIFIED')
    domain = owner.email.split('@')[1]
    team1 = TeamFactory(
        session=session,
        config=TeamConfigFactory(primary_domain=domain))
    user1 = UserFactory(session=session, email='user1@not{}'.format(domain),
                        status='VERIFIED', password='password')
    session.commit()

    UserProfileFactory(session=session, user_id=owner.id,
                       team_id=team1.id, user_level='OWNER')
    access_request = AccessRequestFactory(
        session=session, user_id=user1.id, team_id=team1.id)
    session.commit()

    # Authenticate, keep tokens:
    res = client.post('/teams/', data=json.dumps(dict()))
    assert res.status_code == 403  # make sure app.test_client is behaving
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': owner.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    owner_token = json.loads(res.data)['data']['token']
    client = app.test_client()
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user1.email,
        'password': 'password'
    }), content_type='application/json')
    user1_token = json.loads(res.data)['data']['token']

    # Make new access request
    # Will fail as an existing request is pending:
    res = client.post(
        '/teams/{}/access-requests/'.format(team1.id),
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(user1_token))])
    assert res.status_code == 406

    # Reject the existing request:
    url = '/teams/{team_id}/access-requests/{id}/reject/'.format(
        team_id=team1.id, id=access_request.id)
    res = client.post(
        url,
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(owner_token))])
    data = pop_diff(json.loads(res.data)['data'])
    assert res.status_code == 200
    assert data == dict(team_id=team1.id,
                        user_id=user1.id,
                        actioned_by=owner.id,
                        accepted=False)

    # Make new access request
    # Will succeed - the existing request is no longer pending:
    res = client.post(
        '/teams/{}/access-requests/'.format(team1.id),
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(user1_token))])
    assert res.status_code == 201


def test_accept_request(session, jwt_key):
    client = app.test_client()
    owner = UserFactory(session=session, password='password',
                        status='VERIFIED')
    member = UserFactory(session=session, password='password',
                         status='VERIFIED')
    domain = owner.email.split('@')[1]
    team1 = TeamFactory(
        session=session,
        config=TeamConfigFactory(primary_domain=domain))
    # user1: user requesting access
    user1 = UserFactory(session=session, email='user1@not{}'.format(domain),
                        status='VERIFIED', password='password')
    session.commit()

    owner_profile = UserProfileFactory(
        session=session, user_id=owner.id,
        team_id=team1.id, user_level='OWNER')
    member_profile = UserProfileFactory(
        session=session, user_id=member.id,
        team_id=team1.id, user_level='STANDARD')

    access_request = AccessRequestFactory(
        session=session, user_id=user1.id, team_id=team1.id)
    session.commit()

    # Authenticate, keep tokens:
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': owner.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    owner_token = json.loads(res.data)['data']['token']
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': member.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    member_token = json.loads(res.data)['data']['token']
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user1.email,
        'password': 'password'
    }), content_type='application/json')
    user1_token = json.loads(res.data)['data']['token']

    # Send request to request access (word `request` overused, sorry):
    # Will fail as an existing request is pending:
    res = client.post(
        '/teams/{}/access-requests/'.format(team1.id),
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(user1_token))])
    assert res.status_code == 406

    # Accept the existing request as member:
    # Will fail as owner required
    url = '/teams/{team_id}/access-requests/{id}/accept/'.format(
        team_id=team1.id, id=access_request.id)
    res = client.post(
        url,
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(member_token))])
    assert res.status_code == 403

    # Accept the existing request as owner:
    res = client.post(
        url,
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(owner_token))])
    data = pop_diff(json.loads(res.data)['data'])
    assert res.status_code == 200
    assert pop_diff(data) == dict(team_id=team1.id,
                                  user_id=user1.id,
                                  actioned_by=owner.id,
                                  accepted=True)

    # Authenticate the accepted user as a member of the team
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user1.email,
        'password': 'password',
        'team_id': team1.id,
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    payload = jwt.decode(token, jwt_key)
    payload.pop('exp')
    payload.pop('session_token')
    assert payload == {
        'user_id': user1.id,
        'is_admin': False,
        'team_id': team1.id,
        'user_level': 'STANDARD',
    }

    # Will fail as the user is now a member of the team.
    res = client.post(
        '/teams/{}/access-requests/'.format(team1.id),
        data=json.dumps(dict()),
        headers=[('Authorization', 'Bearer {}'.format(user1_token))])
    assert res.status_code == 406


def test_post_create(session):
    client = app.test_client()
    user = UserFactory(session=session,
                       password='password',
                       status='VERIFIED')
    session.commit()
    res = client.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': 'password',
    }), content_type='application/json')
    token = json.loads(res.data)['data']['token']
    headers = [('Authorization', 'Bearer {}'.format(token))]

    domain = user.email.split('@')[1]
    team1 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain=domain))
    team2 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    team3 = TeamFactory(
        session=session, deleted=False,
        config=TeamConfigFactory(primary_domain='not{}'.format(domain)))
    session.commit()

    # Will be rejected due to user email and team with same domain:
    res = client.post('/teams/{}/access-requests/'.format(team1.id),
                      data=json.dumps(dict()), headers=headers)
    assert res.status_code == 406

    # Successful request:
    res = client.post('/teams/{}/access-requests/'.format(team2.id),
                      data=json.dumps(dict()), headers=headers)
    assert res.status_code == 201

    # Will be rejected due to existing pending access reuqest:
    res = client.post('/teams/{}/access-requests/'.format(team2.id),
                      data=json.dumps(dict()), headers=headers)
    assert res.status_code == 406

    UserProfileFactory(session=session, user_id=user.id,
                       team_id=team3.id)
    session.commit()
