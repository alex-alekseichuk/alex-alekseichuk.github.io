import pytest
from flask import json
from sqlalchemy import and_
from lws.services.teams.models import Team, AccessRequest, TeamConfig

from lws.services.teams.schemas import TeamSchema
from lws.services.users.models import UserProfile
from test.services.teams.factories import TeamFactory, TeamConfigFactory
from test.services.users.factories import UserProfileFactory, UserFactory

pytestmark = pytest.mark.default_perm_checkers([])


def test_list_teams_all(client, session):
    team1 = TeamFactory(session=session)
    team2 = TeamFactory(session=session)
    session.commit()

    res = client.get('/teams/')
    assert 200 == res.status_code

    schema = TeamSchema()
    data = json.loads(res.data)['data']

    assert data == schema.dump([team1, team2], many=True).data


def test_add_team(client, session):
    schema = TeamSchema()
    team_data = {
        'slug': 'slug_1',
        'display_name': 'display_name_1',
        'created_by': 1,
        'config': None
    }

    res = client.post('/teams/', data=json.dumps(team_data))
    assert 201 == res.status_code

    data = json.loads(res.data)['data']
    id = data['id']
    team_data['id'] = id
    team_data['created_at'] = data['created_at']
    assert data == team_data

    team = session.query(Team).get(id)
    assert schema.dump(team).data == team_data


def test_delete_team(client, session):
    team1 = TeamFactory(session=session, deleted=False)
    session.commit()

    res = client.delete('/teams/{id}/'.format(
        id=team1.id
    ))
    assert 204 == res.status_code
    team1 = session.query(Team).get(team1.id)
    assert team1.deleted is True


def test_update_team(client, session):
    team1 = TeamFactory(session=session)
    session.commit()

    schema = TeamSchema()
    team_data = schema.dump(team1).data
    team_data['slug'] = 'another_slug'
    team_data['display_name'] = 'another_display_name'

    res = client.put('/teams/{id}/'.format(
        id=team1.id
    ), data=json.dumps(team_data))

    assert 200 == res.status_code
    assert json.loads(res.data)['data'] == team_data

    team = session.query(Team).get(team1.id)
    assert schema.dump(team).data == team_data


def test_update_team_config(client, session):
    team1 = TeamFactory(session=session)
    session.commit()

    schema = TeamSchema()
    team_data = schema.dump(team1).data
    team_data['config']['primary_domain'] = 'another.domain.com'

    res = client.put('/teams/{id}/'.format(
        id=team1.id
    ), data=json.dumps(team_data))

    assert 200 == res.status_code
    assert json.loads(res.data)['data']['config'] == team_data['config']

    team_config = session.query(TeamConfig).get(team1.config.id)
    assert team_config.primary_domain == team_data['config']['primary_domain']


def test_get_team(client, session):
    schema = TeamSchema()
    team1 = TeamFactory(session=session)
    session.commit()

    res = client.get('/teams/{id}/'.format(
        id=team1.id
    ))
    assert 200 == res.status_code
    data = json.loads(res.data)['data']
    team_data = schema.dump(team1).data
    team_data['created_at'] = data['created_at']
    assert data == team_data


def test_join_new_team(session, user, client):
    schema = TeamSchema()
    team_data = {
        'slug': 'slug_1',
        'display_name': 'display_name_1',
        'created_by': 1,
        'config': {
            'primary_domain': user.email.split('@')[1]
        }
    }

    res = client.post('/teams/join/', data=json.dumps(team_data))
    assert 201 == res.status_code

    data = json.loads(res.data)['data']
    id = data['id']
    team_data['id'] = id
    team_data['created_at'] = data['created_at']
    assert data == team_data

    team = session.query(Team).get(id)
    assert schema.dump(team).data == team_data

    # check that user profile was created as well
    profile = session.query(UserProfile).filter(
        UserProfile.team_id == id).first()
    assert profile.user_id == user.id
    assert profile.user_level == UserProfile.USER_LEVEL_OWNER


def test_join_team_same_domain(session, user, client):
    team1 = TeamFactory(
        session=session,
        config=TeamConfigFactory(
            session=session, primary_domain=user.email.split('@')[1]))
    user1 = UserFactory(session=session)
    session.commit()
    UserProfileFactory(session=session, user_id=user1.id,
                       team_id=team1.id)
    session.commit()

    res = client.post('/teams/join/{}/'.format(team1.id))
    assert 200 == res.status_code

    # check that user profile was created as well
    profile = session.query(UserProfile).filter(and_(
        UserProfile.team_id == team1.id,
        UserProfile.user_id == user.id
    )).first()
    assert profile.user_level == UserProfile.USER_LEVEL_STANDARD


def test_join_team_another_domain(session, user, client):
    team1 = TeamFactory(
        session=session,
        config=TeamConfigFactory(
            session=session,
            primary_domain='another' + user.email.split('@')[1]))
    user1 = UserFactory(session=session)
    session.commit()
    UserProfileFactory(
        session=session, user_id=user1.id, team_id=team1.id)
    session.commit()

    res = client.post('/teams/join/{}/'.format(team1.id))
    assert 403 == res.status_code
    assert 'Access request created' in str(res.data)

    # check that user profile was not created
    profile = session.query(UserProfile).filter(and_(
        UserProfile.team_id == team1.id,
        UserProfile.user_id == user.id
    )).first()
    assert profile is None

    # check that access request was created
    access_request = session.query(AccessRequest).filter(and_(
        AccessRequest.team_id == team1.id,
        AccessRequest.user_id == user.id
    )).first()
    assert access_request is not None
