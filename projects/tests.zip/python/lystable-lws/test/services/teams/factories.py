import datetime
import factory
from lws.services.teams import models
from test.common.factories import ModelFactory


class TeamConfigFactory(ModelFactory):
    class Meta(object):
        model = models.TeamConfig

    primary_domain = ''


class TeamFactory(ModelFactory):
    class Meta(object):
        model = models.Team

    slug = factory.Sequence(lambda n: 'slug_{0}'.format(n))
    display_name = factory.Sequence(lambda n: 'team_{0}'.format(n))
    config = factory.SubFactory(TeamConfigFactory)
    created_by = factory.Sequence(lambda n: n)
    created_at = factory.Sequence(lambda n: datetime.datetime.now().replace(
        microsecond=0) + datetime.timedelta(hours=n))
    deleted = False


class AccessRequestFactory(ModelFactory):
    class Meta(object):
        model = models.AccessRequest

    user_id = factory.Sequence(lambda n: n)
    team_id = factory.Sequence(lambda n: n)
    created_at = factory.Sequence(lambda n: datetime.datetime.now().replace(
        microsecond=0) + datetime.timedelta(hours=n))
    actioned_by = None
    accepted = None


class InvitationFactory(ModelFactory):
    class Meta(object):
        model = models.Invitation

    inviting_id = factory.Sequence(lambda n: n)
    invited_id = None
    email = factory.Sequence(lambda n: 'invitee{0}@example.com'.format(n))
    team_id = factory.Sequence(lambda n: n)
    created_at = factory.Sequence(lambda n: datetime.datetime.now().replace(
        microsecond=0) + datetime.timedelta(hours=n))
    accepted = None
