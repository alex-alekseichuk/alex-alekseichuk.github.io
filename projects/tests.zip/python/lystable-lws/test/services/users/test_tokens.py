from datetime import datetime, timedelta
import jwt
import pytest
from flask import json, request

from lws.core.app import app
from lws.core.auth import perms
from lws.services.users.models import UserProfile, SessionToken


@pytest.yield_fixture(autouse=True)
def session(session):
    yield session


def test_authenticate(session, jwt_key, user, password):
    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': password,
    }), content_type='application/json')
    assert res.status_code == 200
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    assert payload['user_id'] == user.id
    assert not payload['is_admin']

    # Check that session token was created
    session_token_record = session.query(SessionToken).get(
        payload['session_token'])
    assert session_token_record.user_id == user.id


def test_authenticate_admin(jwt_key, admin_user, password):
    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': admin_user.email,
        'password': password,
    }), content_type='application/json')
    assert res.status_code == 200
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    assert payload['user_id'] == admin_user.id
    assert payload['is_admin']


def test_authenticate_unverified(unverified_user, password):
    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': unverified_user.email,
        'password': password,
    }), content_type='application/json')

    assert res.status_code == 403


def test_authenticate_with_invalid_credentials(jwt_key):
    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': 'test@example.com',
        'password': '',
    }), content_type='application/json')

    assert res.status_code == 401


def test_authenticate_with_profile(jwt_key, user_profile, password):
    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': user_profile.user.email,
        'password': password,
        'team_id': user_profile.team_id,
    }), content_type='application/json')
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    assert payload['user_id'] == user_profile.user.id
    assert not payload['is_admin']
    assert payload['team_id'] == user_profile.team_id
    assert payload['user_level'] == UserProfile.USER_LEVEL_STANDARD


def test_authenticate_with_unknown_profile(jwt_key, user, password):
    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': password,
        'team_id': 1,
    }), content_type='application/json')

    assert res.status_code == 401


def test_generate_token_with_profile(client, jwt_key, user_profile):
    res = client.post(
        '/users/generate_token/',
        data=json.dumps({'team_id': user_profile.team_id}),
        headers=[('Authorization', 'Bearer {}'.format(client.token))],
        content_type='application/json')
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    assert payload['user_id'] == user_profile.user.id
    assert not payload['is_admin']
    assert payload['team_id'] == user_profile.team_id
    assert payload['user_level'] == UserProfile.USER_LEVEL_STANDARD


def test_generate_unauthenticated_token(jwt_key):
    c = app.test_client()

    res = c.post('/users/generate_token/', content_type='application/json')
    assert res.status_code == 200
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    payload.pop('exp')

    assert payload == {}


def test_generate_auth_token_by_session_token(session, jwt_key, client, user):
    session_token_record = session.query(SessionToken).get(
        client.session_token)
    save_datetime = datetime.now() - timedelta(minutes=15)
    session_token_record.last_access = save_datetime
    session.commit()

    res = client.post('/users/generate_token/',
                      data=json.dumps({'session_token': client.session_token}),
                      content_type='application/json')
    assert res.status_code == 200
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    assert payload['user_id'] == user.id
    assert not payload['is_admin']

    # Check session token last_access is updated to current datetime
    # to have ability to identify expired session tokens
    session.refresh(session_token_record)
    assert session_token_record.last_access >= save_datetime


def test_generate_profile_token_another_team(session, jwt_key, user_profile,
                                             profile_client):
    user_profile2 = UserProfile(user=user_profile.user, team_id=2)
    session.commit()
    res = profile_client.post(
        '/users/generate_token/',
        data=json.dumps({
            'team_id': user_profile2.team_id}),
        headers=[('Authorization', 'Bearer {}'.format(profile_client.token))],
        content_type='application/json')
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)
    assert payload['user_id'] == user_profile.user.id
    assert not payload['is_admin']
    assert payload['team_id'] == user_profile2.team_id
    assert payload['user_level'] == UserProfile.USER_LEVEL_STANDARD


def test_revoke_session_token(client):
    res = client.post('/users/revoke/',
                      data=json.dumps({'session_token': client.session_token}),
                      content_type='application/json')
    assert res.status_code == 204
    res = client.post('/users/generate_token/',
                      data=json.dumps({'session_token': client.session_token}),
                      content_type='application/json')
    assert res.status_code == 401


def test_auth_data_context(jwt_key, user, password, test_view):
    from lws.core.auth import checks  # ensure auth_check is registered
    checks = checks

    c = app.test_client()

    res = c.post('/users/authenticate/', data=json.dumps({
        'email': user.email,
        'password': password,
    }), content_type='application/json')
    res = json.loads(res.data)
    token = res['data']['token']

    payload = jwt.decode(token, jwt_key)

    with pytest.raises(RuntimeError):
        # outside the request context
        request.auth_data is None

    # no auth checks
    app.view_functions['test_view'] = perms.checkers()(test_view)

    with app.test_request_context(
        '/test_view',
    ):
        app.preprocess_request()
        assert request.auth_data is None

    with app.test_request_context(
        '/test_view',
        headers=[('Authorization', 'Bearer {}'.format(token))],
    ):
        app.preprocess_request()
        assert request.auth_data == payload
