from lws.services.users import models
import factory
from lws.services.users.models import User
from test.common.factories import ModelFactory


class UserFactory(ModelFactory):
    class Meta(object):
        model = models.User

    password = factory.Sequence(lambda n: 'password_{0}'.format(n))
    email = factory.Sequence(lambda n: 'user{0}@example.com'.format(n))
    name = factory.Sequence(lambda n: 'user_name_{0}'.format(n))
    given_name = factory.Sequence(lambda n: 'given_name_{0}'.format(n))
    is_admin = False
    verification_code = factory.Sequence(lambda n: 'verify_{0}'.format(n))
    status = User.STATUS_VERIFIED


class UserProfileFactory(ModelFactory):
    class Meta(object):
        model = models.UserProfile

    team_id = factory.Sequence(lambda n: n)
