import pytest
from flask import request, json
from lws.core.exceptions import NotAcceptable, Forbidden
from lws.core.service import ServiceProxy
from lws.core.app import app

from lws.services.users.models import UserProfile
from lws.services.users.schemas import UserProfileSchema

from test.services.teams.factories import TeamFactory
from test.services.users.factories import UserFactory, UserProfileFactory


@pytest.yield_fixture
def users(session, password):
    user1 = UserFactory(session=session, password=password)
    user2 = UserFactory(session=session, password=password)
    session.commit()
    yield (user1, user2)


OWNER = 0
STANDARD = 1


@pytest.yield_fixture
def profiles(session, users):
    owner_profile = UserProfileFactory(
        session=session, user_id=users[OWNER].id,
        user_level=UserProfile.USER_LEVEL_OWNER)
    standard_profile = UserProfileFactory(
        session=session, user_id=users[STANDARD].id,
        team_id=owner_profile.team_id,
        user_level=UserProfile.USER_LEVEL_STANDARD)
    session.commit()
    yield (owner_profile, standard_profile)


@pytest.yield_fixture
def team_id(profiles):
    yield profiles[0].team_id


@pytest.yield_fixture
def owner_client(client, users, password):
    data = json.dumps({
        'email': users[OWNER].email,
        'password': password
    })
    response = client.post('/users/authenticate/', data=data)
    token = json.loads(response.data)['data']['token']
    client.token = token
    yield client


@pytest.yield_fixture
def standard_client(client, users, password):
    data = json.dumps({
        'email': users[STANDARD].email,
        'password': password
    })
    response = client.post('/users/authenticate/', data=data)
    token = json.loads(response.data)['data']['token']
    client.token = token
    yield client


@pytest.mark.parametrize(
    ('user_level',),
    [
        (UserProfile.USER_LEVEL_OWNER,),
        (UserProfile.USER_LEVEL_STANDARD,),
    ]
)
def test_add_first_profile(session, user_level):
    users_proxy = ServiceProxy('users')
    team1 = TeamFactory(session=session)
    session.commit()
    user = UserFactory(session=session)
    session.commit()
    profile_data = {
        'user_level': user_level,
        'user_id': user.id,
        'team_id': team1.id
    }
    with app.test_request_context('/', data=json.dumps(profile_data),
                                  method='post'):
        request.auth_data = {'user_id': user.id}
        data = users_proxy.profiles.post()['data']
    assert data['user_level'] == UserProfile.USER_LEVEL_OWNER
    assert data['user_id'] == profile_data['user_id']
    assert data['team_id'] == profile_data['team_id']

    profile = session.query(UserProfile).get(data['id'])
    assert profile.user_level == UserProfile.USER_LEVEL_OWNER
    assert profile.user_id == profile_data['user_id']
    assert profile.team_id == profile_data['team_id']


@pytest.mark.parametrize(
    ('user_level',),
    [
        (UserProfile.USER_LEVEL_OWNER,),
        (UserProfile.USER_LEVEL_STANDARD,),
    ]
)
def test_owner_adds_profile(session, users, user_level,
                            team_id):
    users_proxy = ServiceProxy('users')
    user = UserFactory(session=session)
    session.commit()
    profile_data = {
        'user_level': user_level,
        'user_id': user.id,
        'team_id': team_id
    }
    with app.test_request_context('/', data=json.dumps(profile_data),
                                  method='post'):
        request.auth_data = {'user_id': users[OWNER].id}
        data = users_proxy.profiles.post()['data']
    assert data['user_level'] == profile_data['user_level']
    assert data['user_id'] == profile_data['user_id']
    assert data['team_id'] == profile_data['team_id']

    profile = session.query(UserProfile).get(data['id'])
    assert profile.user_level == profile_data['user_level']
    assert profile.user_id == profile_data['user_id']
    assert profile.team_id == profile_data['team_id']


def test_non_member_list_profiles(client, profiles, team_id):
    res = client.get(
        '/users/profiles/',
        data=json.dumps({'team_id': team_id}))
    assert res.status_code == 403


def test_owner_list_profiles(profiles, owner_client, team_id):
    res = owner_client.get(
        '/users/profiles/',
        data=json.dumps({'team_id': team_id}))
    assert res.status_code == 200
    data = json.loads(res.data)
    schema = UserProfileSchema()
    assert data == {
        'data': schema.dump(profiles, many=True).data,
        'meta': {'offset': 0, 'total': 2}}


def test_standard_list_profiles(profiles, standard_client, team_id):
    res = standard_client.get(
        '/users/profiles/',
        data=json.dumps({'team_id': team_id}))
    assert res.status_code == 200
    data = json.loads(res.data)
    schema = UserProfileSchema()
    assert data == {
        'data': schema.dump(profiles, many=True).data,
        'meta': {'offset': 0, 'total': 2}}


def test_list_user_profiles(profiles, standard_client):
    res = standard_client.get('/users/user_profiles/')
    assert res.status_code == 200
    data = json.loads(res.data)
    schema = UserProfileSchema()
    assert data == {
        'data': schema.dump((profiles[STANDARD],), many=True).data,
    }


def test_upgrade_to_owner(session, users, profiles):
    users_proxy = ServiceProxy('users')
    profile_data = {
        'user_level': UserProfile.USER_LEVEL_OWNER
    }
    with app.test_request_context('/', data=json.dumps(profile_data),
                                  method='put'):
        request.auth_data = {'user_id': users[OWNER].id}
        data = users_proxy.profiles.put(id=profiles[STANDARD].id)['data']
    assert data['user_level'] == UserProfile.USER_LEVEL_OWNER
    assert session.query(UserProfile.user_level).filter(
        UserProfile.id == profiles[STANDARD].id
    ).scalar() == UserProfile.USER_LEVEL_OWNER


def test_cant_downgrade_last_owner(session, users, profiles):
    users_proxy = ServiceProxy('users')
    profile_data = {
        'user_level': UserProfile.USER_LEVEL_STANDARD
    }
    with app.test_request_context('/', data=json.dumps(profile_data),
                                  method='put'):
        request.auth_data = {'user_id': users[OWNER].id}
        with pytest.raises(NotAcceptable):
            users_proxy.profiles.put(id=profiles[OWNER].id)
    assert session.query(UserProfile.user_level).filter(
        UserProfile.id == profiles[OWNER].id
    ).scalar() == UserProfile.USER_LEVEL_OWNER


def test_standard_cant_upgrade(session, users, profiles):
    users_proxy = ServiceProxy('users')
    profile_data = {
        'user_level': UserProfile.USER_LEVEL_OWNER
    }
    with app.test_request_context('/', data=json.dumps(profile_data),
                                  method='put'):
        request.auth_data = {'user_id': users[STANDARD].id}
        with pytest.raises(Forbidden):
            users_proxy.profiles.put(id=profiles[STANDARD].id)
    assert session.query(UserProfile.user_level).filter(
        UserProfile.id == profiles[STANDARD].id
    ).scalar() == UserProfile.USER_LEVEL_STANDARD


def test_non_member_cant_upgrade(session, profiles, user):
    users_proxy = ServiceProxy('users')
    profile_data = {
        'user_level': UserProfile.USER_LEVEL_OWNER
    }
    with app.test_request_context('/', data=json.dumps(profile_data),
                                  method='put'):
        request.auth_data = {'user_id': user.id}
        with pytest.raises(Forbidden):
            users_proxy.profiles.put(id=profiles[STANDARD].id)
    assert session.query(UserProfile.user_level).filter(
        UserProfile.id == profiles[STANDARD].id
    ).scalar() == UserProfile.USER_LEVEL_STANDARD
