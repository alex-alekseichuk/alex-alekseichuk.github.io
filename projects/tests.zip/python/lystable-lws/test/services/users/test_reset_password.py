import mock
from flask import json
from lws.core.app import app
from lws.core.service import client_url
from lws.services.users.models import User, PasswordResetToken, SessionToken
from lws.services.users.service import RESET_PASSWORD_URL
from test.utils import check_notification_dispatched


@mock.patch('lws.services.users.service.dispatcher')
def test_reset_password(mock_dispatcher, session, user):
    client = app.test_client()

    # send email to start reset-password procedure
    res = client.post('/users/initiate_password_reset/',
                      data=json.dumps({'email': user.email}))
    assert res.status_code == 204
    reset = session.query(PasswordResetToken).filter(
        PasswordResetToken.user_id == user.id).one()
    assert reset is not None
    assert reset.used_at is None

    notification = check_notification_dispatched(mock_dispatcher)
    assert notification.event_data['template_name'] == 'reset_password'
    assert notification.event_data['to'] == [{'email': user.email}]
    assert notification.event_data['context'] == [{
        'name': 'reset_password_url',
        'content': client_url(RESET_PASSWORD_URL, token=reset.token)
    }]

    # submit reset password data
    new_password = 'new_password'
    res = client.post(
        '/users/reset_password/',
        data=json.dumps({'email': user.email, 'reset_token': reset.token,
                         'new_password': new_password}))
    assert res.status_code == 204
    session.refresh(reset)
    assert reset.used_at is not None
    session.refresh(user)
    assert user.password_hash == User.get_password_hash(new_password)


def test_init_reset_password_no_email():
    client = app.test_client()

    # send email to start reset-password procedure
    res = client.post('/users/initiate_password_reset/', data=json.dumps({}))
    assert res.status_code == 400


def test_init_reset_password_unknown_email(session):
    client = app.test_client()

    # send email to start reset-password procedure
    res = client.post('/users/initiate_password_reset/',
                      data=json.dumps({'email': 'no@email.com'}))
    assert res.status_code == 404


@mock.patch('lws.services.users.service.dispatcher')
def test_one_more_init_reset_password(
        mock_dispatcher, session, user, password):
    client = app.test_client()

    # send email to start reset-password procedure
    res = client.post('/users/initiate_password_reset/',
                      data=json.dumps({'email': user.email}))
    assert res.status_code == 204
    reset = session.query(PasswordResetToken).filter(
        PasswordResetToken.user_id == user.id).one()
    assert reset is not None
    assert (not reset.deleted)

    # send one more reset request
    res = client.post('/users/initiate_password_reset/',
                      data=json.dumps({'email': user.email}))
    assert res.status_code == 204

    # check previous one is deleted
    session.refresh(reset)
    assert reset.deleted

    # can't submit reset password for deleted request
    new_password = 'new_password'
    res = client.post(
        '/users/reset_password/',
        data=json.dumps({'email': user.email, 'reset_token': reset.token,
                         'new_password': new_password}))
    assert res.status_code == 400
    session.refresh(user)
    assert user.password_hash == User.get_password_hash(password)


@mock.patch('lws.services.users.service.dispatcher')
def test_reset_password_incorrect_token(
        mock_dispatcher, session, user, password):
    client = app.test_client()

    # send email to start reset-password procedure
    res = client.post('/users/initiate_password_reset/',
                      data=json.dumps({'email': user.email}))
    assert res.status_code == 204
    reset = session.query(PasswordResetToken).filter(
        PasswordResetToken.user_id == user.id).one()
    assert reset is not None

    # submit reset password with incorrect token
    new_password = 'new_password'
    res = client.post(
        '/users/reset_password/',
        data=json.dumps({'email': user.email, 'reset_token': reset.token + "f",
                         'new_password': new_password}))
    assert res.status_code == 400
    session.refresh(user)
    assert user.password_hash == User.get_password_hash(password)


@mock.patch('lws.services.users.service.dispatcher')
def test_delete_session_tokens_on_reset_password(
        mock_dispatcher, session, client, user):
    # there is some session_token
    assert session.query(SessionToken).filter(
        SessionToken.user_id == user.id).count() > 0

    # send email to start reset-password procedure
    res = client.post('/users/initiate_password_reset/',
                      data=json.dumps({'email': user.email}))
    assert res.status_code == 204
    reset = session.query(PasswordResetToken).filter(
        PasswordResetToken.user_id == user.id).one()

    # submit reset password data
    new_password = 'new_password'
    res = client.post(
        '/users/reset_password/',
        data=json.dumps({'email': user.email, 'reset_token': reset.token,
                         'new_password': new_password}))
    assert res.status_code == 204

    # check there is no any session_token
    assert session.query(SessionToken).filter(
        SessionToken.user_id == user.id).count() == 0
