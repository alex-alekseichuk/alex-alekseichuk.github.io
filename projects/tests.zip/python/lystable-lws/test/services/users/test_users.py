import mock
from flask import json
import requests
from lws.core.service import encode
from lws.core.service import client_url
from lws.services.files.models import File
from lws.services.users.models import User
from lws.services.users.schemas import UserSchema
from lws.services.users.service import VERIFY_EMAIL_URL
from test.utils import to_json, check_notification_dispatched
from test.services.users.factories import UserFactory


@mock.patch('lws.services.users.service.dispatcher')
def test_register(mock_dispatcher, client, session, password):
    user_data = {
        'email': 'user0@example.com',
        'password': password,
        'name': 'user_name_0',
        'given_name': 'given_name_0',
        'is_admin': False,
        'status': User.STATUS_UNCONFIRMED
    }
    res = client.post(
        '/users/register/', data=json.dumps(user_data), headers={})
    assert res.status_code == 201
    data = json.loads(res.data)
    user_id = data['data']['id']
    user = session.query(User).get(user_id)

    notification = check_notification_dispatched(mock_dispatcher)
    assert notification.event_data['template_name'] == 'registration'
    assert notification.event_data['to'] == [{'email': user.email}]
    assert notification.event_data['context'] == [{
        'name': 'verify_email_url',
        'content': client_url(VERIFY_EMAIL_URL,
                              code=user.verification_code)
    }]

    user_data['status'] = User.STATUS_UNCONFIRMED
    user_data['id'] = user_id
    user_data['profiles'] = []
    del user_data['password']
    user_data = to_json(user_data)
    assert user_data == UserSchema().dump(user).data
    assert user_data == data['data']


def test_register_existing_email(client, session, password):
    user = UserFactory(session=session)
    session.commit()
    user_data = UserFactory.build(email=user.email).to_dict()
    user_data['password'] = password
    res = client.post(
        '/users/register/', data=json.dumps(user_data), headers={})
    assert res.status_code == 409


def test_verify_email(client, session):
    user = UserFactory(session=session, status=User.STATUS_UNVERIFIED)
    session.commit()
    url = "http://test"
    res = client.get('/users/verify/{code}/?redirect={url}'.format(
        code=user.verification_code, url=url), headers=[])
    assert res.status_code == 204
    session.refresh(user)
    assert user.status == User.STATUS_VERIFIED


def test_upload_picture(session, mock_s3, user, client):
    assert user.picture_id is None
    content = bytes(range(0, 256))
    res = client.post('/users/{}/picture/'.format(user.id),
                      data=json.dumps({'content': encode(content)}))
    assert res.status_code == 201
    session.refresh(user)
    assert user.picture_id is not None
    res = client.get('/users/{}/picture_url/'.format(user.id))
    assert res.status_code == 200
    url = json.loads(res.data).get('data')
    response = requests.get(url)
    assert response.status_code == 200
    assert response.content == content


def test_upload_new_picture(session, mock_s3, user, client):
    assert user.picture_id is None
    content = bytes(range(0, 256))

    # upload picture
    res = client.post('/users/{}/picture/'.format(user.id),
                      data=json.dumps({'content': encode(content)}))
    assert res.status_code == 201
    session.refresh(user)
    assert user.picture_id is not None
    picture_id = user.picture_id

    # get URL
    res = client.get('/users/{}/picture_url/'.format(user.id))
    assert res.status_code == 200
    url = json.loads(res.data).get('data')

    # upload another picture
    res = client.post('/users/{}/picture/'.format(user.id),
                      data=json.dumps({'content': encode(content)}))
    assert res.status_code == 201

    response = requests.get(url)
    assert response.status_code == 404
    assert session.query(File).get(picture_id) is None


def test_google_callback(client):
    data = {
        'code': 'code'
    }
    with mock.patch('lws.services.users.service.requests') as mock_requests:
        post_response = mock.MagicMock()
        post_response.status_code = 200
        post_response.json.return_value = {'access_token': 'access_token1'}
        mock_requests.post.return_value = post_response
        get_response = mock.MagicMock()
        get_response.status_code = 200
        get_response.json.return_value = {
            'email': 'foo@bar.com', 'verified_email': True
        }
        mock_requests.get.return_value = get_response
        with mock.patch(
            'lws.services.users.service.UserService'
        ) as mock_UserService:
            generate_token = mock.MagicMock()
            generate_token.return_value = 'test_token'
            mock_UserService._generate_token = generate_token
            res = client.get(
                '/users/handle_google_callback/', data=json.dumps(data),
                headers={}
            )
    assert res.status_code == 200
    data = json.loads(res.data)
    assert data['data'] == 'test_token'
