import pytest

from flask import json

from lws.services.suppliers.models import Skill
from lws.services.suppliers.schemas import (
    SupplierSchema, SkillSchema, SupplierProfileSchema
)

from test.services.suppliers.factories import (
    SupplierFactory, SkillFactory, SupplierProfileFactory
)

pytestmark = pytest.mark.default_perm_checkers([])


def test_list_suppliers_all(profile_client, session):
    supplier1 = SupplierFactory(session=session)
    supplier2 = SupplierFactory(session=session)
    session.commit()

    res = profile_client.get('/suppliers/')
    assert 200 == res.status_code

    schema = SupplierSchema()
    data = json.loads(res.data)

    assert data == {
        'data': schema.dump([supplier1, supplier2], many=True).data,
        'meta': {'offset': 0, 'total': 2}}


def test_get_supplier(profile_client, session, user_profile):
    schema = SupplierSchema()
    spschema = SupplierProfileSchema()

    sp1 = SupplierProfileFactory(
        contact_email='foo@bar.com',
        team_id=user_profile.team_id
    )
    sp2 = SupplierProfileFactory(
        contact_email='foo@bar.com',
        team_id=user_profile.team_id + 1
    )
    sp3 = SupplierProfileFactory(
        contact_email='foo@bar.com',
        team_id=user_profile.team_id + 1
    )

    supplier1 = SupplierFactory(session=session, contextual_profile=sp1)
    supplier2 = SupplierFactory(session=session, contextual_profile=sp2)

    supplier1.profiles.append(sp3)

    session.commit()

    res = profile_client.get('/suppliers/{id}/'.format(
        id=supplier1.id
    ))
    assert 200 == res.status_code

    data = json.loads(res.data)
    assert data['data'] == schema.dump(supplier1).data
    # We should get sp1 here, not sp2
    assert data['data']['profile'] == spschema.dump(sp1).data

    # This should have no profile as the team_id does not match
    res = profile_client.get('/suppliers/{id}/'.format(
        id=supplier2.id
    ))
    assert 200 == res.status_code

    data = json.loads(res.data)
    assert data['data'] == schema.dump(supplier2).data
    assert data['data']['profile'] is None


def test_create_supplier_without_profile(
    profile_client, session, user_profile
):
    data = {
        'name': 'Foo Suppliers',
        'email': 'foo@bar.com'
    }

    response = profile_client.post('/suppliers/', data=json.dumps(data))
    supplier = json.loads(response.data)['data']

    assert response.status_code == 201
    assert supplier['email'] == data['email']

    db_supplier = session.query(SupplierSchema.get_model()).one()

    assert db_supplier.email == supplier['email']
    assert db_supplier.id == supplier['id']

    db_sp = session.query(SupplierProfileSchema.get_model()).one()

    # Profile is created but empty
    assert db_sp.team_id == user_profile.team_id
    assert db_sp.contact_email is None


def test_create_supplier_with_profile(profile_client, session, user_profile):
    data = {
        'name': 'Foo Suppliers',
        'email': 'foo@bar.com',
        'profile': {
            'contact_email': 'bar@bar.com'
        }
    }

    response = profile_client.post('/suppliers/', data=json.dumps(data))
    supplier = json.loads(response.data)['data']

    assert response.status_code == 201
    assert supplier['email'] == data['email']

    db_supplier = session.query(SupplierSchema.get_model()).one()

    assert db_supplier.email == supplier['email']
    assert db_supplier.id == supplier['id']

    assert db_supplier.contextual_profile.contact_email == \
        supplier['profile']['contact_email']

    db_sp = session.query(SupplierProfileSchema.get_model()).one()

    assert db_sp.team_id == user_profile.team_id
    assert db_sp.contact_email == supplier['profile']['contact_email']


def test_create_supplier_already_exists(profile_client, session):
    supplier = SupplierFactory(session=session)
    session.commit()

    data = {
        'name': supplier.name,
        'email': supplier.email
    }

    response = profile_client.post('/suppliers/', data=json.dumps(data))

    assert response.status_code == 409


def test_create_existing_supplier_with_profile(profile_client, session):
    supplier = SupplierFactory(session=session)
    session.expunge(supplier.profiles.one())
    session.commit()

    data = {
        'name': supplier.name,
        'email': supplier.email,
        'profile': {
            'contact_email': 'contact@foo.com'
        }
    }

    response = profile_client.post('/suppliers/', data=json.dumps(data))

    assert response.status_code == 201


def test_create_existing_supplier_with_existing_profile(
    profile_client,
    session
):
    supplier = SupplierFactory(session=session)
    session.commit()
    profile = supplier.profiles.one()

    data = {
        'name': supplier.name,
        'email': supplier.email,
        'profile': {
            'contact_email': profile.contact_email
        }
    }

    response = profile_client.post('/suppliers/', data=json.dumps(data))

    assert response.status_code == 409


def test_cannot_update_supplier(profile_client, session):
    supplier = SupplierFactory(session=session)
    session.commit()

    data = {
        'name': 'random stuff'
    }

    response = profile_client.put(
        '/suppliers/{0}/'.format(supplier.id),
        data=json.dumps(data))

    assert response.status_code == 400


def test_can_update_supplier_profile(profile_client, session):
    supplier = SupplierFactory(session=session)
    session.commit()

    data = {
        'profile': {
            'contact_email': 'contact@foo.com'
        }
    }

    response = profile_client.put(
        '/suppliers/{0}/'.format(supplier.id),
        data=json.dumps(data))

    supplier_data = json.loads(response.data)['data']
    assert response.status_code == 200
    assert supplier_data['profile']['contact_email'] == \
        data['profile']['contact_email']

    # Check that we haven't inadvertently made another profile
    count = session.query(SupplierProfileSchema.get_model()).count()
    assert count == 1


def test_list_skills_all(profile_client, session):
    skill1 = SkillFactory(session=session)
    skill2 = SkillFactory(session=session)
    session.commit()

    res = profile_client.get('/suppliers/skills/')
    assert 200 == res.status_code

    schema = SkillSchema()
    data = json.loads(res.data)

    assert data == {
        'data': schema.dump([skill1, skill2], many=True).data,
        'meta': {'offset': 0, 'total': 2}}


def test_get_skill(profile_client, session):
    schema = SkillSchema()
    skill1 = SkillFactory(session=session)
    session.commit()
    id = skill1.id

    res = profile_client.get('/suppliers/skills/{id}/'.format(
        id=id
    ))
    assert 200 == res.status_code

    data = json.loads(res.data)
    assert data['data'] == schema.dump(skill1).data


def test_add_skill(profile_client, session):
    schema = SkillSchema()
    skill_data = {
        'name': 'Skill 1'
    }

    res = profile_client.post(
        '/suppliers/skills/',
        data=json.dumps(skill_data)
    )
    assert res.status_code == 201

    data = json.loads(res.data)
    id = data['data']['id']
    skill_data['id'] = id

    skill = session.query(Skill).get(id)
    assert skill_data['id'] == skill.id
    assert skill_data['name'] == skill.name
    assert data['data'] == schema.dump(skill_data).data


def test_create_skill_empty(profile_client, session):
    res = profile_client.post('/suppliers/skills/', data='')
    assert res.status_code == 400


def test_create_skill_missing(profile_client, session):
    res = profile_client.post(
        '/suppliers/skills/',
        data=json.dumps({'name': None})
    )
    assert res.status_code == 400

    assert json.loads(res.data) == {
        'errors': [{
            'detail': 'Field may not be null.',
            'status': 400,
            'title': 'Bad Request',
            'paths': ['/name', ]
        }]
    }
