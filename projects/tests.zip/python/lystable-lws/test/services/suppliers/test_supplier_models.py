import pytest

from flask import request

from lws.core.app import app
from lws.services.suppliers.models import Supplier, SupplierProfile


@pytest.fixture
def suppliers(session):
    suppliers = [Supplier() for _ in range(3)]
    session.add_all(suppliers)
    session.commit()

    return suppliers


@pytest.fixture
def supplier_profiles(session, suppliers):
    supplier = suppliers[0]

    sp1 = SupplierProfile(
        supplier=supplier,
        team_id=1,
        contact_email='designer@supplier.com')
    sp2 = SupplierProfile(supplier=supplier, team_id=2)

    sps = [sp1, sp2]
    session.add_all(sps)
    session.commit()

    return sps


def test_profile_property_on_supplier(suppliers, supplier_profiles):
    supplier = suppliers[0]

    sp1, sp2 = supplier_profiles

    with app.test_request_context():
        request.auth_data = {'team_id': 1}
        assert supplier.contextual_profile is sp1

        request.auth_data = {'team_id': 2}
        assert supplier.contextual_profile is sp2

        request.auth_data = {'team_id': 3}
        assert supplier.contextual_profile is None


def test_supplier_profile_extra(supplier_profiles, session):
    extra1 = {
        'foo': 'bar',
        'baz': 'xyzzy'
    }
    extra2 = {
        'foo': 'bar',
        'baz': 'lorem'
    }

    sp1, sp2 = supplier_profiles

    sp1.extra = extra1
    sp2.extra = extra2

    session.add_all([sp1, sp2])
    session.commit()

    sps = session.query(SupplierProfile).filter(
        SupplierProfile.extra['foo'].astext == 'bar'
    ).all()

    assert sp1 in sps
    assert sp2 in sps

    assert session.query(SupplierProfile).filter(
        SupplierProfile.extra['baz'].astext == 'lorem'
    ).one() is sp2


def test_supplier_extra(suppliers, session):
    extra1 = {
        'foo': 'bar',
        'baz': 'xyzzy'
    }
    extra2 = {
        'foo': 'bar',
        'baz': 'lorem'
    }

    s1, s2, _ = suppliers

    s1.extra = extra1
    s2.extra = extra2

    session.add_all([s1, s2])
    session.commit()

    ss = session.query(Supplier).filter(
        Supplier.extra['foo'].astext == 'bar'
    ).all()

    assert s1 in ss
    assert s2 in ss

    assert session.query(Supplier).filter(
        Supplier.extra['baz'].astext == 'lorem'
    ).one() is s2
