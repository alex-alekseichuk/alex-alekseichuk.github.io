import factory
from lws.services.suppliers.models import Supplier, SupplierProfile, Skill
from test.common.factories import ModelFactory


class SupplierProfileFactory(ModelFactory):
    contact_email = factory.Sequence(
        lambda n: 'contact{0}@example.com'.format(n)
    )
    contact_name = factory.Sequence(
        lambda n: 'Supplier Contact {0}'.format(n)
    )
    team_id = 1

    class Meta:
        model = SupplierProfile


class SupplierFactory(ModelFactory):

    email = factory.Sequence(lambda n: 'supplier{0}@example.com'.format(n))
    name = factory.Sequence(lambda n: 'Supplier {0}'.format(n))
    contextual_profile = factory.SubFactory(SupplierProfileFactory)

    deleted = False

    class Meta:
        model = Supplier


class SkillFactory(ModelFactory):

    name = factory.Sequence(lambda n: 'Skill {0}'.format(n))

    class Meta:
        model = Skill
