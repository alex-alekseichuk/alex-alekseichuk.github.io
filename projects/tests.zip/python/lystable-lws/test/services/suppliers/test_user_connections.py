import pytest

from sqlalchemy.exc import DataError

from lws.services.suppliers.models import UserConnection
from test.services.suppliers.factories import SupplierFactory


@pytest.fixture
def supplier(session):
    supplier = SupplierFactory(session=session)
    session.commit()

    return supplier


def test_create_user_connection(supplier, session):
    uc = UserConnection(
        user_id=1,
        team_id=1,
        connection_source='contact_upload',
        supplier=supplier)
    session.add(uc)
    session.commit()

    assert supplier.user_connections.one() is uc


def test_create_user_connection_wrong_enum(supplier, session):
    uc = UserConnection(
        user_id=1,
        team_id=1,
        connection_source='invalid reason',
        supplier=supplier)

    session.add(uc)

    with pytest.raises(DataError):
        session.commit()


def test_create_connection(supplier, user_profile, profile_client, session):
    response = profile_client.post(
        '/suppliers/{}/connect/'.format(supplier.id)
    )

    assert response.status_code == 201

    uc = supplier.user_connections.one()

    assert uc.team_id == user_profile.team_id
    assert uc.user_id == user_profile.user_id
    assert uc.connection_source == 'endpoint'


def test_create_connection_second_time(
    supplier, user_profile, profile_client, session
):
    # Create the first connection
    response = profile_client.post(
        '/suppliers/{}/connect/'.format(supplier.id)
    )

    assert response.status_code == 201
    # Second conncetion with the same reason should fail
    response = profile_client.post(
        '/suppliers/{}/connect/'.format(supplier.id)
    )

    assert response.status_code == 400

    # Creating another connection with a different reason should work
    uc = UserConnection(
        user_id=user_profile.user_id,
        team_id=user_profile.team_id,
        supplier=supplier,
        connection_source='review'
    )

    session.add(uc)
    session.commit()

    # Another connection in a different team with the same reason
    # should also work
    uc = UserConnection(
        user_id=user_profile.user_id,
        team_id=user_profile.team_id + 1,
        supplier=supplier,
        connection_source='endpoint'
    )

    session.add(uc)
    session.commit()
