from flask import json


def to_json(dict):
    """ Serialises all values into JSON compatible values.
    """
    return json.loads(json.dumps(dict))


def pop_diff(d):
    """ Remove `created_at` ,`id` and `session_token` keys
    from incoming res.data to compare with the outgoing POST data.

    Parameters
    ----------
    d : dict
        incoming res.data

    Returns
    -------
    dict
        Filtered copy of source dictionary.

    """
    d.pop('created_at', None)
    d.pop('id', None)
    d.pop('session_token', None)
    return d


def check_notification_dispatched(mock_dispatcher):
    """ Assert one notification sending via mock_dispatcher.

    Returns
    -------
    mock of lws.core.nameko.Event
    """
    # check the notification dispatched
    mock_dispatcher.assert_called_once()
    mock_dispatcher.return_value.assert_called_once()

    # check the correct notification data dispatched
    args, kwargs = mock_dispatcher.return_value.call_args
    return args[0]
